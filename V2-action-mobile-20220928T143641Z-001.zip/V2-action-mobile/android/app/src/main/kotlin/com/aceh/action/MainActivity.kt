package com.aceh.action

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
