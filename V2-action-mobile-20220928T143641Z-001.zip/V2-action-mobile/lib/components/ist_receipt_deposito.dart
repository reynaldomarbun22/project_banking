import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:external_path/external_path.dart';
import 'package:flutter/services.dart';
import 'package:image_save/image_save.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/widgets.dart' as pw;

import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/utils/string_utils.dart';
import 'package:share/share.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:screenshot/screenshot.dart';

enum ISTReceiptStatusDeposito { success, failed, suspect }

class ISTReceiptItemDeposito {
  final String? key;
  final String? value;

  ISTReceiptItemDeposito({this.key, this.value});
  String toJson() => json.encode({
        'key': key,
        'value': value,
      });

  factory ISTReceiptItemDeposito.fromJson(dynamic json) {
    return ISTReceiptItemDeposito(key: json['key'], value: json['value']);
  }
}

class ISTReceiptDeposito extends StatefulWidget {
  const ISTReceiptDeposito({
    Key? key,
    this.noresi,
    required this.items,
    required this.onFinished,
    this.onCheck,
    this.onTap,
    this.description,
    this.id,
    required this.title,
    required this.type,
    this.idresi,
    required this.date,
    required this.detail,
    required this.time,
    required this.amount,
    required this.status,
    // @required this.imgTab,
    this.resiItem,
    this.memo,
    this.footer1,
    this.imgTab,
    this.titleimg,
    this.footer2,
    this.noref,
    this.addInfoImg,
  }) : super(key: key);
  final String? noresi;
  final String? noref;
  final String? title;
  final int? id;
  final String? memo;
  final String? idresi;
  final String? amount;
  final String? addInfoImg;
  final List<ISTReceiptItemDeposito> items;
  final List<ISTReceiptItemDeposito>? resiItem;
  final Function onFinished;
  final Function? onCheck;
  final Function? onTap;
  final String? imgTab;
  final ISTReceiptStatusDeposito status;
  final String type;
  final String? description;
  final String? detail;
  final String? time;
  final String? date;
  final String? titleimg;
  final Widget? footer1;
  final Widget? footer2;

  // final ISTReceipt data;
  // const ISTReceipt({Key key, @required this.data}) : super(key: key);

  @override
  _ISTReceiptDepositoState createState() => _ISTReceiptDepositoState();
}

class _ISTReceiptDepositoState extends State<ISTReceiptDeposito> {
  // var _printKey = GlobalKey();
  String statusStr = "";
  String imageStatus = "";
  // Uint8List _imageTabungan;
  bool isLoading = false;
  bool isSuccess = false;
  // ignore: unused_field
  Future<List<Directory>>? _externalStorageDirectories;

  // _saveinbox() async {
  //   Inbox(itemss: widget.items);
  //   InboxDBRepository repo = InboxDBRepository();
  //   await repo.open();
  //   InboxModel model = InboxModel();
  //   model.amount = widget.amount;
  //   model.status = widget.status.index.toString();
  //   model.title = widget.title;
  //   model.date =widget.date;
  //   var img = widget.type;
  //   var imgasset = "";
  //   if (img == 'PAYMENT_ZAKAT') {
  //     imgasset = 'assets/images/icon-wallet.png';
  //   } else if (img == 'TFBAS') {
  //     imgasset = 'assets/images/icon-wallet.png';
  //   }
  //   model.image = imgasset;
  //   await repo.insert(model);
  //   await repo.close();
  // }

  @override
  void initState() {
    switch (widget.status) {
      case ISTReceiptStatusDeposito.success:
        setState(() {
          statusStr = "Berhasil";
          imageStatus = "assets/images/icon-success.png";
        });
        break;
      case ISTReceiptStatusDeposito.failed:
        setState(() {
          statusStr = "Gagal";
          imageStatus = "assets/images/icon-failed.png";
        });
        break;
      case ISTReceiptStatusDeposito.suspect:
        setState(() {
          statusStr = "Sedang diproses";
          imageStatus = "assets/images/icon-warning.png";
        });
        break;

      default:
    }
    // _imageTabungan = Base64Decoder().convert(widget.imgTab);

    // _saveinbox();
    super.initState();
    print(widget.imgTab);

    print(widget.status);
  }

  // ignore: unused_element
  _changeStatus() {
    switch (widget.status) {
      case ISTReceiptStatusDeposito.success:
        setState(() {
          isSuccess = true;
          statusStr = "Berhasil";
          imageStatus = "assets/images/icon-success.png";
        });
        break;
      case ISTReceiptStatusDeposito.failed:
        setState(() {
          statusStr = "Gagal";
          imageStatus = "assets/images/icon-failed.png";
        });
        break;
      case ISTReceiptStatusDeposito.suspect:
        setState(() {
          statusStr = "Sedang diproses";
          imageStatus = "assets/images/icon-warning.png";
        });
        break;

      default:
    }
    return Container();
  }

  List<Widget> _buildItems() {
    List<Widget> ret = [];
    if (widget.items.isEmpty) {
      return [];
    }
    for (ISTReceiptItemDeposito item in widget.items) {
      ret.add(Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Expanded(flex: 1, child: Text(item.key!)),
          Expanded(
            flex: 1,
            child: Text(
              item.value!,
              textAlign: TextAlign.right,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          )
        ],
      ));
      ret.add(const Divider(
        thickness: 1,
      ));
    }
    return ret;
  }

  List<Widget> _buildResiItems() {
    List<Widget> ret = [];
    if (widget.resiItem == null || widget.resiItem!.isEmpty) {
      return [];
    }
    for (ISTReceiptItemDeposito item in widget.resiItem!) {
      ret.add(Column(children: [
        Padding(
          padding: const EdgeInsets.only(left: 32, right: 16),
          child: Row(
            // mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              SizedBox(
                  height: 11,
                  width: 80,
                  child: Text(
                    item.key!,
                    style: const TextStyle(fontSize: 8),
                  )),
              Container(
                  alignment: Alignment.center,
                  width: 10,
                  height: 11,
                  child: const Text(
                    ' :',
                    style: TextStyle(
                      fontSize: 8,
                    ),
                  )),
              Expanded(
                child: Container(
                  alignment: Alignment.topLeft,
                  height: 11,
                  width: 150,
                  // flex: 1,
                  child: Text(
                    item.value!,
                    textAlign: TextAlign.right,
                    style: const TextStyle(fontSize: 8),
                  ),
                ),
              )
            ],
          ),
        )
      ]));

      // ret.add(Divider(
      //   thickness: 12,
      // ));
    }
    return ret;
  }

//  void _printScreen() {
//     Printing.layoutPdf(onLayout: (PdfPageFormat format) async {
//       final doc = pw.Document();
//       RenderRepaintBoundary boundary = _printKey.currentContext.findRenderObject();
//   var image = await boundary.toImage();
//   var byteData = await image.toByteData(format: ImageByteFormat.png);
//   var pngBytes = byteData.buffer.asUint8List();
//       var image2 = PdfImage.file(doc.document, bytes: pngBytes);
//       // RenderRepaintBoundary boundary = _printKey.currentContext.findRenderObject();
//   // var image = pw.MemoryImage(File('assets/images.icon-deposito.png').readAsBytesSync());
//   // var byteData = await image.toByteData(format: ImageByteFormat.png);
//   // var pngBytes = byteData.buffer.asUint8List();
//       // final image = _printKey;

//       doc.addPage(pw.MultiPage(
//           pageFormat: format,
//           build: (pw.Context context) {
//             return <pw.Widget> [
//               pw.Image(image2)
//             ];
//           }));

//       return doc.save();
//     });
//   }

  //yoseph
  // _scrshot() async {
  //   Map<Permission, PermissionStatus> statuses = await [
  //     Permission.photos,
  //     Permission.storage,
  //     Permission.camera
  //   ].request();
  //   print(statuses);
  //   if (await Permission.storage.request().isGranted &&
  //       await Permission.photos.request().isGranted &&
  //       await Permission.camera.request().isGranted) {
  //     screenshotController
  //         .capture(pixelRatio: 3, delay: const Duration(milliseconds: 10))
  //         .then((image) async {
  //       var save = await ImageGallerySaver.saveImage(
  //         image!,
  //       );
  //       if (save != null && save.toString().isNotEmpty) {
  //         const DialogBox().showImageDialog(
  //           isError: false,
  //           onOk: () {
  //             Navigator.pop(context);
  //           },
  //           // image: Icon(
  //           //   Icons.camera_alt,
  //           //   color: Pallete.primary,
  //           // ),
  //           title: "Perhatian",
  //           buttonOk: "OK",
  //           context: context,
  //           message: "Berhasil unduh resi",
  //         );
  //       }
  //     }).catchError((onError) {
  //       print(onError);
  //     });
  //   } else {
  //     const DialogBox().showImageDialog(
  //       isError: true,
  //       onOk: () {
  //         Navigator.pop(context);
  //       },
  //       // image: Icon(
  //       //   Icons.camera_alt,
  //       //   color: Pallete.primary,
  //       // ),
  //       title: "Perhatian",
  //       buttonOk: "OK",
  //       context: context,
  //       message: "Gagal unduh resi",
  //     );
  //   }
  // }

  late String noref;
  String _result = "";
  Future<void> _saveImage() async {
    setState(() {
      noref = widget.noref!;
    });
    bool success = false;
    screenshotController
        .capture(pixelRatio: 3, delay: const Duration(milliseconds: 10))
        .then((image) async {
      print(image);
      print("ini datsssssSSSSSSSSS");
      try {
        success = (await ImageSave.saveImage(
          image,
          "$noref.jpg",
          albumName: "Action Mobile",
        ))!;
      } on PlatformException catch (e, s) {
        print(e);
        print(s);
      }
      setState(() {
        _result = success ? "Save to album success" : "Save to album failed";
        print(_result);
        const DialogBox().showImageDialog(
          isError: false,
          onOk: () {
            Navigator.pop(context);
          },
          // image: Icon(
          //   Icons.camera_alt,
          //   color: Pallete.primary,
          // ),
          title: "Perhatian",
          buttonOk: "OK",
          context: context,
          message: "Resi berhasil di unduh",
        );
        // showDialog(
        //   context: context,
        //   barrierDismissible: false,
        //   useRootNavigator: true,
        //   builder: (BuildContext context) {
        //     return AlertDialog(
        //       // contentPadding: EdgeInsets.all(8),
        //       shape: const RoundedRectangleBorder(
        //         borderRadius: BorderRadius.all(Radius.circular(20.0)),
        //       ),
        //       content: SizedBox(
        //         height: 230,
        //         child: Column(
        //           children: <Widget>[
        //             // SizedBox(
        //             //   height: 2,
        //             // ),

        //             const Text(
        //               'Resi berhasil di unduh',
        //               textAlign: TextAlign.center,
        //               style: TextStyle(
        //                 color: Pallete.primary,
        //               ),
        //             ),
        //             const SizedBox(
        //               height: 16,
        //             ),
        //             Container(
        //               alignment: Alignment.center,
        //               child: Row(
        //                 mainAxisAlignment: MainAxisAlignment.center,
        //                 children: [
        //                   SizedBox(
        //                     width: 120,
        //                     child: OutlineButton(
        //                       onPressed: () {
        //                         Navigator.pop(context);
        //                         setState(() {
        //                           // ss = false;
        //                         });
        //                       },
        //                       borderSide: const BorderSide(
        //                         color: Pallete.primary,
        //                       ),
        //                       splashColor: Pallete.primary,
        //                       shape: const RoundedRectangleBorder(
        //                         borderRadius:
        //                             BorderRadius.all(Radius.circular(18)),
        //                       ),
        //                       child: Text(
        //                         "Selesai",
        //                         style: Theme.of(context)
        //                             .textTheme
        //                             .bodyText1
        //                             ?.copyWith(
        //                                 fontWeight: FontWeight.w600,
        //                                 color: Pallete.primary),
        //                       ),
        //                     ),
        //                   ),
        //                 ],
        //               ),
        //             )
        //           ],
        //         ),
        //       ),
        //       //actions: _checkbutton(context),
        //     );
        //   },
        // );
      });
    });
  }

  Future<String> saveAndShare(Uint8List bytes) async {
    final directory = await getApplicationDocumentsDirectory();
    final image = File('${directory.path}/flutter.png');
    image.writeAsBytesSync(bytes);
    const text = 'Shared From Action Mobile';
    await Share.shareFiles([image.path], text: text);
    return directory.path;
  }

  // _share() async {
  //   await [
  //     Permission.photos,
  //     Permission.storage,
  //   ].request();
  //   screenshotController
  //       .capture(
  //     pixelRatio: 3,
  //   )
  //       .then((image) async {
  //     await Share.file(
  //         '${widget.noresi}${widget.noresi}',
  //         '${widget.noresi}.jpg',
  //         image!,
  //         'image/jpg');
  //   });
  // }

  final pdf = pw.Document();
  buildPDF() async {
    final font = await rootBundle.load("assets/fonts/poppins/Poppins-Bold.ttf");
    // ignore: unused_local_variable
    final ttf = pw.Font.ttf(font);
    final image = pw.MemoryImage(
      (await rootBundle.load('assets/images/depcerrjpg.jpg'))
          .buffer
          .asUint8List(),
    );
    pdf.addPage(
      pw.Page(
        build: (pw.Context context) => pw.Stack(children: [
          pw.Image(image),
          //  pw.Text('Hello World', style: pw.TextStyle(font: ttf, fontSize: 40))
          pw.Container(
            alignment: pw.Alignment.center,
            padding: const pw.EdgeInsets.only(top: 16),
            child: pw.Column(children: [
              pw.SizedBox(height: 24),
              pw.Container(
                  padding: const pw.EdgeInsets.only(right: 30),
                  alignment: pw.Alignment.topRight,
                  // padding: const EdgeInsets.all(16),
                  child: pw.Text(
                    widget.noresi!,
                    //  widget.noresi,
                    style: pw.TextStyle(
                      font: pw.Font.helvetica(),
                      fontSize: 8,
                    ),
                    textAlign: pw.TextAlign.center,
                  )),
              pw.SizedBox(
                height: 10,
              ),
              // pw.Container(
              //     padding: pw.EdgeInsets.only(bottom: 8),
              //     alignment: pw.Alignment.topCenter,
              //     // padding: const EdgeInsets.all(16),
              //     child: pw.Text(
              //       'SERTIFIKASI DEPOSITO MUDHARABAH',
              //       style: pw.TextStyle(
              //         decoration: pw.TextDecoration.underline,
              //         fontSize: 12,
              //         font: ttf,
              //         fontWeight: pw.FontWeight.bold,
              //       ),
              //       textAlign: pw.TextAlign.center,
              //     )),
              pw.Container(
                  padding:
                      const pw.EdgeInsets.only(bottom: 8, right: 16, left: 16),
                  alignment: pw.Alignment.topLeft,
                  // padding: const EdgeInsets.all(16),
                  child: pw.Text(
                    widget.description!,
                    style:
                        pw.TextStyle(fontSize: 12, font: pw.Font.helvetica()),
                    textAlign: pw.TextAlign.center,
                  )),
              pw.SizedBox(
                height: 16,
              ),

              // pw.ListView.builder(
              //     itemBuilder: (context, index) {
              //       return pw.Container(
              //         child: pw.Text(key[index],
              //             style: pw.TextStyle(fontSize: 10, font: ttf)),
              //       );
              //     },
              //     itemCount: key.length),
              pw.ListView.builder(
                padding: const pw.EdgeInsets.only(left: 40, right: 40),
                itemCount: widget.resiItem!.length,
                itemBuilder: (context, i) {
                  final a = widget.resiItem![i];
                  return pw.Container(
                      padding: const pw.EdgeInsets.only(left: 32),
                      width: 500,
                      alignment: pw.Alignment.center,
                      child: pw.Row(
                        // mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: pw.CrossAxisAlignment.center,
                        children: [
                          pw.Container(
                            alignment: pw.Alignment.topLeft,
                            width: 100,
                            height: 14,
                            child: pw.Text(a.key!,
                                style: pw.TextStyle(
                                  fontSize: 10,
                                  font: pw.Font.helvetica(),
                                )),
                          ),
                          pw.Container(
                            width: 10,
                            height: 14,
                            alignment: pw.Alignment.center,
                            child: pw.Text(':',
                                style: pw.TextStyle(
                                  fontSize: 10,
                                  font: pw.Font.helvetica(),
                                )),
                          ),
                          pw.Container(
                            height: 14,
                            child: pw.Text(a.value!,
                                textAlign: pw.TextAlign.left,
                                style: pw.TextStyle(
                                  fontSize: 10,
                                  font: pw.Font.helvetica(),
                                )),
                          )
                        ],
                      ));
                },
              ),
              pw.Container(
                  padding:
                      const pw.EdgeInsets.only(left: 16, top: 8, right: 16),
                  alignment: pw.Alignment.bottomRight,
                  // padding: const EdgeInsets.all(16),
                  child: pw.Text(
                    'PT. Bank Aceh Syariah',
                    //  widget.noresi,
                    style: pw.TextStyle(
                      fontSize: 10,
                      font: pw.Font.helveticaBold(),
                    ),
                    textAlign: pw.TextAlign.left,
                  )),
              pw.Container(
                  padding: const pw.EdgeInsets.only(left: 16, top: 8, right: 8),
                  alignment: pw.Alignment.bottomCenter,
                  // padding: const EdgeInsets.all(16),
                  child: pw.Text(
                    StringUtils.getValueAsString(widget.memo!),
                    //  widget.noresi,
                    style: pw.TextStyle(
                      fontSize: 8,
                      font: pw.Font.helvetica(),
                    ),
                    textAlign: pw.TextAlign.left,
                  )),
            ]),
          ),
        ]
            // child: pw.Text('Hello World!'),
            ),
      ),
    );
    if (Platform.isIOS) {
      Directory documentDirectory = await getApplicationDocumentsDirectory();
      // print(documentDirectory);
      String documentPath = documentDirectory.path;
      File receiptFile = File("$documentPath/${widget.noresi}.pdf");
      print(receiptFile);
      await receiptFile.writeAsBytes(await pdf.save());
      // await Share.shareFiles([receiptFile.path], '${widget.noresi}',
      //     '${widget.noresi}.pdf', receiptFile.readAsBytesSync(), 'pdf');
      const DialogBox().showImageDialog(
        isError: false,
        onOk: () {
          Navigator.pop(context);
        },
        // image: Icon(
        //   Icons.camera_alt,
        //   color: Pallete.primary,
        // ),
        title: "Perhatian",
        buttonOk: "OK",
        context: context,
        message: "Berhasil unduh Advice",
      );
      // await Share.file('${widget.noRef}', '${widget.noRef}.pdf',
      //     receiptFile.readAsBytesSync(), 'pdf');
    } else if (Platform.isAndroid) {
      if (await Permission.storage.request().isGranted) {
        // Directory documentDirectory = Directory('/storage/emulated/0/Download');
        String path = await ExternalPath.getExternalStoragePublicDirectory(
            ExternalPath.DIRECTORY_DOWNLOADS);
        print(path);
        // String documentPath = documentDirectory.path;

        File receiptFile = File("$path/${widget.noresi}.pdf");
        print(receiptFile);
        receiptFile.writeAsBytesSync(await pdf.save());
        const DialogBox().showImageDialog(
          isError: false,
          onOk: () {
            Navigator.pop(context);
          },
          // image: Icon(
          //   Icons.camera_alt,
          //   color: Pallete.primary,
          // ),
          title: "Perhatian",
          buttonOk: "OK",
          context: context,
          message: "Berhasil unduh Advice",
        );
      }
    }

//     final output = await getTemporaryDirectory();
//           final file = File('${output.path}/example.pdf');
//           file.writeAsBytesSync(await pdf.save());
//     return file;
// final output = await getTemporaryDirectory();
//     final path = "${output.path}/temp.pdf";
//     final file = await io.File(path).writeAsBytes(pdf.save());
  }

  ScreenshotController screenshotController = ScreenshotController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            const SizedBox(height: 8),
            Screenshot(
              controller: screenshotController,
              child: Container(
                color: Colors.white,
                // height: MediaQuery.of(context).size.height * 0.1,
                child: Padding(
                  padding: const EdgeInsets.only(top: 8, bottom: 8),
                  child: Column(
                    children: <Widget>[
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: const <Widget>[
                          Expanded(
                            flex: 1,
                            child: Center(
                              child: Image(
                                image: AssetImage(
                                    'assets/images/bank-logo-green.png'),
                                height: 40,
                              ),
                            ),
                          ),
                          Expanded(
                            flex: 1,
                            child: Center(
                              child: Image(
                                image: AssetImage(
                                    'assets/images/logo-app-green.png'),
                                // color: Pallete.primary,
                                height: 25,
                              ),
                            ),
                          )
                        ],
                      ),
                      const SizedBox(height: 16),
                      Container(
                        padding: const EdgeInsets.only(left: 64, right: 64),
                        alignment: Alignment.center,
                        child: const Text(
                          'PEMBUATAN DEPOSITO MUDHARABAH BERHASIL DILAKUKAN',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: Pallete.primary,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                      // Center(
                      //   child: new Image.memory(_imageTabungan),
                      // ),
                      const SizedBox(height: 16),

                      Container(
                        padding: const EdgeInsets.only(left: 8, right: 8),
                        child: Stack(alignment: Alignment.center, children: <
                            Widget>[
                          Container(
                            alignment: Alignment.center,
                            child: Image.asset('assets/images/depcerrjpg.jpg'),
                          ),
                          Column(children: <Widget>[
                            Container(
                                padding: const EdgeInsets.only(right: 30),
                                alignment: Alignment.topRight,
                                // padding: const EdgeInsets.all(16),
                                child: Text(
                                  widget.noresi!,
                                  //  widget.noresi,
                                  style: const TextStyle(
                                    fontSize: 8,
                                  ),
                                  textAlign: TextAlign.center,
                                )),
                            const SizedBox(
                              height: 10,
                            ),
                            Container(
                                padding: const EdgeInsets.only(
                                    bottom: 8, right: 16, left: 16),
                                alignment: Alignment.topCenter,
                                // padding: const EdgeInsets.all(16),
                                child: Text(
                                  widget.description!,
                                  style: const TextStyle(
                                      fontSize: 8, color: Colors.black),
                                  textAlign: TextAlign.center,
                                )),
                            // SizedBox(
                            //   height: 16,
                            // ),
                            Padding(
                              padding: const EdgeInsets.only(
                                  left: 16.0, right: 16, bottom: 16),
                              child: Column(
                                children: _buildResiItems(),
                              ),
                            ),
                            Container(
                                padding: const EdgeInsets.only(right: 30),
                                alignment: Alignment.bottomRight,
                                // padding: const EdgeInsets.all(16),
                                child: const Text(
                                  'PT. Bank Aceh Syariah',
                                  //  widget.noresi,
                                  style: TextStyle(
                                      fontSize: 8, fontWeight: FontWeight.bold),
                                  textAlign: TextAlign.center,
                                )),
                            const SizedBox(
                              height: 8,
                            ),
                            Container(
                                // padding: EdgeInsets.only(left: 8),
                                alignment: Alignment.bottomCenter,
                                // padding: const EdgeInsets.all(16),
                                child: Text(
                                  StringUtils.getValueAsString(widget.memo!),
                                  //  widget.noresi,
                                  style: const TextStyle(
                                    fontSize: 6,
                                  ),
                                  textAlign: TextAlign.left,
                                )),
                          ]),
                        ]),
                      ),

                      const SizedBox(height: 8),
                      Container(
                        alignment: Alignment.center,
                        child: const Text(
                          'BUKTI SETORAN AWAL',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: Pallete.primary,
                              fontWeight: FontWeight.bold,
                              fontSize: 16),
                        ),
                      ),
                      const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 16.0),
                        child: Divider(
                          thickness: 1,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: Column(
                          children: _buildItems(),
                        ),
                      ),
                      const SizedBox(height: 8),
                      // Padding(
                      //   padding: const EdgeInsets.symmetric(horizontal: 16.0),
                      //   child: widget.footer1,
                      // ),
                      // Padding(
                      //   padding: const EdgeInsets.symmetric(horizontal: 16.0),
                      //   child: widget.footer2,
                      // ),
                    ],
                  ),
                ),
              ),
            ),
            // widget.type == 'QRPAYMENT'
            //     ? Container()
            //     : ISTFlatButton(
            //         onPressed: () {
            //           DialogBox().showImageDialog(
            //               message:
            //                   "Apakah anda yakin akan di simpan ke favorit",
            //               buttonOk: 'Setuju',
            //               buttonCancel: "Batal",
            //               isError: false,
            //               image: Image(
            //                 image: AssetImage('assets/images/icon-warning.png'),
            //               ),
            //               onOk: widget.onTap,
            //               context: context);
            //         },
            //         text: 'Simpan ke favorit',
            //         color: Pallete.primary,
            //       ),
            // SizedBox(height: 4),
            // widget.status == ISTReceiptStatus.suspect &&
            //         widget.type == 'QRPAYMENT'
            //     ? Container()
            InkWell(
              child: const Text('Unduh Advice',
                  style: TextStyle(
                      color: Pallete.primary, fontWeight: FontWeight.bold)),
              onTap: () {
                buildPDF();
              },
            ),
            const SizedBox(
              height: 16,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: ISTOutlineButton(
                text: 'Selesai',
                onPressed: widget.onFinished as void Function()?,
              ),
            ),
            const SizedBox(height: 16),
            // widget.status == ISTReceiptStatus.suspect &&
            //         widget.type == 'QRPAYMENT'
            //     ? Container()
            Container(
              padding: const EdgeInsets.all(0),
              width: double.maxFinite,
              height: 50,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: TextButton(
                      onPressed: () {
                        _saveImage();
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const <Widget>[
                          Icon(
                            Icons.file_download,
                            color: Pallete.primary,
                          ),
                          SizedBox(width: 4),
                          Text(
                            "Unduh",
                            style: TextStyle(color: Pallete.primary),
                          )
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                    child: TextButton(
                      onPressed: () async {
                        final image = await screenshotController.capture();
                        if (image == null) return;
                        await saveAndShare(image);
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const <Widget>[
                          Icon(
                            Icons.share,
                            color: Pallete.primary,
                          ),
                          SizedBox(width: 4),
                          Text(
                            "Bagikan",
                            style: TextStyle(color: Pallete.primary),
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
