import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:flutter/material.dart';

class ISTCardAccountItem extends StatelessWidget {
  const ISTCardAccountItem({
    Key? key,
    this.index,
    this.isPrimary,
    this.accountBalance,
    this.accountType,
    this.accountNumber,
    this.accountName,
    this.callback,
  }) : super(key: key);
  final bool? isPrimary;
  final String? accountBalance;
  final String? accountType;
  final String? accountNumber;
  final String? accountName;
  final int? index;

  final Function(String? accountBalance, String? accountType,
      String? accountNumber, String? accountName)? callback;

  @override
  Widget build(BuildContext context) {
    _doSetDefaultRek() async {
      Map<String, Object?> param = {};
      param['listaccountke'] = index;
      final resp = await API.post(context, '/acct/setdefault/post', param);
      if (resp != null && resp['code'] == 0) {
        callback!(accountBalance, accountType, accountNumber,
            accountName);
      }
      Navigator.pop(context);
    }

    return Card(
      color: isPrimary! ? Pallete.primary : Colors.white,
      child: InkWell(
        onTap: () {
          isPrimary!
              ? Container()
              : const DialogBox().showImageDialog(
                  // title: '',
                  message: "Apakah anda yakin akan mengganti rekening anda",
                  buttonOk: 'Setuju',
                  buttonCancel: "Batal",
                  isError: false,
                  image: const Image(
                    image: AssetImage('assets/images/icon-warning.png'),
                  ),
                  onOk: () {
                    _doSetDefaultRek();
                  },
                  context: context);
        },
        child: Container(
          padding: const EdgeInsets.all(8),
          child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: <
              Widget>[
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  Text(
                    accountBalance!,
                    style: TextStyle(
                        color: !isPrimary! ? Pallete.primary : Colors.white,
                        fontWeight: FontWeight.bold),
                  ),
                  Text(accountType!,
                      style: TextStyle(
                          color: !isPrimary! ? Pallete.primary : Colors.white)),
                  Text(accountNumber!,
                      style: TextStyle(
                          color: !isPrimary! ? Pallete.primary : Colors.white)),
                  Text(accountName!,
                      style: TextStyle(
                          color: !isPrimary! ? Pallete.primary : Colors.white)),
                ],
              ),
            ),
          ]),
        ),
      ),
    );
  }
}

class ISTCardAccountTabunganItem extends StatelessWidget {
  const ISTCardAccountTabunganItem({
    Key? key,
    this.index,
    this.isPrimary,
    this.accountBalance,
    this.accountType,
    this.accountNumber,
    this.accountName,
    this.callback,
  }) : super(key: key);
  final bool? isPrimary;
  final String? accountBalance;
  final String? accountType;
  final String? accountNumber;
  final String? accountName;
  final int? index;

  final Function(String? accountBalance, String? accountType,
      String? accountNumber, String? accountName)? callback;

  @override
  Widget build(BuildContext context) {
    _doSetDefaultRek() async {
      // callback(this.accountBalance, this.accountType, this.accountNumber,
      //     this.accountName);
      callback!(accountBalance, accountType, accountNumber,
          accountName);
      // Navigator.pushReplacement(
      //     context,
      //     new MaterialPageRoute(
      //         builder: (context) => new PembukaanTabungan(
      //               rekening: accountName,
      //             )));
      Navigator.pop(context);
    }

    return Card(
      color: isPrimary! ? Pallete.primary : Colors.white,
      child: InkWell(
        onTap: () {
          _doSetDefaultRek();

          // isPrimary
          //     ? Container()
          //     : DialogBox().showImageDialog(
          //         // title: '',
          //         message: "Apakah anda yakin",
          //         buttonOk: 'Setuju',
          //         buttonCancel: "Batal",
          //         isError: false,
          //         image: Image(
          //           image: AssetImage('assets/images/icon-warning.png'),
          //         ),
          //         onOk: () {
          //           _doSetDefaultRek();
          //         },
          //         context: context);
        },
        child: Container(
          padding: const EdgeInsets.all(8),
          child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: <
              Widget>[
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  Text(
                    accountBalance!,
                    style: TextStyle(
                        color: !isPrimary! ? Pallete.primary : Colors.white,
                        fontWeight: FontWeight.bold),
                  ),
                  Text(accountType!,
                      style: TextStyle(
                          color: !isPrimary! ? Pallete.primary : Colors.white)),
                  Text(accountNumber!,
                      style: TextStyle(
                          color: !isPrimary! ? Pallete.primary : Colors.white)),
                  Text(accountName!,
                      style: TextStyle(
                          color: !isPrimary! ? Pallete.primary : Colors.white)),
                ],
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
