import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:flutter/material.dart';
import 'package:quiver/async.dart';

class ISTOTP extends StatefulWidget {
  final ValueChanged<String>? onFinishedVal;
  final PreferredSizeWidget? appBar;
  final String? appBarTitle;
  final bool isError;
  final String? errorText;
  final Object? data;
  final String? title;
  final Map<String, Object>? param;
  final String? state;
  const ISTOTP(
      {Key? key,
      this.state,
      this.appBarTitle,
      this.title,
      this.isError = false,
      this.errorText,
      this.onFinishedVal,
      this.appBar,
      this.data,
      this.param})
      : super(key: key);

  @override
  // ignore: no_logic_in_create_state
  _ISTOTPState createState() => _ISTOTPState(state: state);
}

class _ISTOTPState extends State<ISTOTP> {
  final String? state;

  int _current = 120;
  final int _start = 120;
  // ignore: unused_field
  var _visible = false;
  var _currentCodeLength = 0;
  var _inputCodes = <int?>[];
  var color = Colors.white;

  final _number = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
  late List<dynamic> _randomNumber;
  late bool _buttonisActive;

  _ISTOTPState({this.state});

  @override
  void initState() {
    setState(() {
      _buttonisActive = true;
      // _randomNumber = (_number..shuffle());
      _randomNumber = _number;
      startTimer();
    });
    super.initState();
  }

  _getNumber(index) {
    return _randomNumber[index];
  }

  late CountdownTimer countDownTimer;

  void alert() {}

  void startTimer() {
    countDownTimer = CountdownTimer(
      const Duration(seconds: 120),
      const Duration(seconds: 1),
    );
    _visible = false;
    var sub = countDownTimer.listen(null);
    sub.onData((duration) {
      setState(() {
        _current = _start - duration.elapsed.inSeconds;
      });
    });
    sub.onDone(() {
      _visible = true;
      sub.cancel();
    });
  }

  // _reSendOTP() async {
  //   var model = widget.arguments;
  //   await API.post(context, _registrationUrl, model.toJson());
  // }

//  _doOTP(value)async{

//         Map<String,Object> param = new Map();

//         param['otp'] = value;
//         final resp = await API.post(context, '/forgot/otp', param);
//         if (resp['code'] != null && resp['code'] == 0) {
//           Navigator.pushNamed(context, NewPassword.routeName);
//         } else {
//           DialogBox().showImageDialog(
//               message: resp['message'],
//               isError: true,
//               image: Image(
//                 image: AssetImage('assets/images/icon-failed.png'),
//               ),
//               buttonCancel: 'OK',
//               onOk: () {},
//               context: context);
//         }
//       }
  _doOTPregis() async {
    Map<String, Object>? param = {};
    param = widget.param;
    await API.post(context, '/register/step1', param!);
  }

  _doOTPforgotpass() async {
    Map<String, Object>? param = {};
    param = widget.param;

    final resp = await API.post(context, '/forgot/validation', param!);
    if (resp['code'] != null && resp['code'] == 0) {}
  }

  _doOTPforgotMpin() async {
    Map<String, Object>? param = {};
    param = widget.param;

    final resp = await API.post(context, '/forgot/validation', param!);
    if (resp['code'] != null && resp['code'] == 0) {}
  }

  _doOTPforgotUsername() async {
    Map<String, Object>? param = {};
    param = widget.param;

    final resp = await API.post(context, '/forgot/validation', param!);
    if (resp['code'] != null && resp['code'] == 0) {}
  }

  _doOTPlinkDevice() async {
    Map<String, Object>? param = {};
    param = widget.param;

    final resp = await API.post(context, '/login/newdevice/validate', param!);
    if (resp['code'] != null && resp['code'] == 0) {}
  }
  // else {
  //   DialogBox().showImageDialog(
  //       message: resp['message'],
  //       isError: true,
  //       image: Image(
  //         image: AssetImage('assets/images/icon-failed.png'),
  //       ),
  //       buttonCancel: 'OK',
  //       onOk: () {},
  //       context: context);
  // }

// _doOTPforgotpass(value)async{

//         Map<String,Object> param = new Map();

//         param['otp'] = value;
//         final resp = await API.post(context, '/forgot/otp', param);
//         if (resp['code'] != null && resp['code'] == 0) {
//           Navigator.pushNamed(context, NewPassword.routeName);
//         } else {
//           DialogBox().showImageDialog(
//               message: resp['message'],
//               isError: true,
//               image: Image(
//                 image: AssetImage('assets/images/icon-failed.png'),
//               ),
//               buttonCancel: 'OK',
//               onOk: () {},
//               context: context);
//         }
//       }

// _doOTPforgotMPIN(value)async{

//         Map<String,Object> param = new Map();

//         param['otp'] = value;
//         final resp = await API.post(context, '/forgot/otp', param);
//         if (resp['code'] != null && resp['code'] == 0) {
//           Navigator.pushNamed(context, NewPassword.routeName);
//         } else {
//           DialogBox().showImageDialog(
//               message: resp['message'],
//               isError: true,
//               image: Image(
//                 image: AssetImage('assets/images/icon-failed.png'),
//               ),
//               buttonCancel: 'OK',
//               onOk: () {},
//               context: context);
//         }
//       }
  @override
  dispose() {
    countDownTimer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // var text = _current != 0 ? "($_current detik) " : '';
    return Scaffold(
      backgroundColor: Colors.white,
      extendBodyBehindAppBar: false,
      appBar: widget.appBar ??
          AppBar(
            backgroundColor: Pallete.primary,
            centerTitle: true,
            leading: IconButton(
              icon: const Icon(Icons.arrow_back_ios),
              color: Colors.white,
              onPressed: () {
                Navigator.pop(context);
              },
            ),
            title: Text(
              widget.appBarTitle == null ? 'MPIN' : widget.appBarTitle!,
              style: const TextStyle(
                color: Colors.white,
                fontFamily: 'Poppins',
              ),
            ),
            elevation: 0.0,
          ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: <Widget>[
          Flexible(
            flex: 1,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                Text(
                  widget.title != null
                      ? widget.title!
                      : "Masukkan 6 digit MPIN Anda",
                  //style: TextStyle(fontSize: FontSize.TITLE),
                ),
                Visibility(
                  child: Container(
                      child: _current == 0
                          ? ISTFlatButton(
                              onPressed: () {
                                if (state == 'OTPregis') {
                                  _doOTPregis();
                                }
                                if (state == 'OTPforgotpass') {
                                  _doOTPforgotpass();
                                }
                                if (state == 'OTPforgotmpin') {
                                  _doOTPforgotMpin();
                                }
                                if (state == 'OTPlinkdevice') {
                                  _doOTPlinkDevice();
                                }
                                if (state == 'OTPforgotusername') {
                                  _doOTPforgotUsername();
                                }
                                startTimer();
                              },
                              text: 'Kirim ulang kode OTP',
                              color: Pallete.primary,
                            )
                          : Text(
                              'Kirim ulang kode OTP ($_current)',
                            )),
                ),
                Opacity(
                    opacity: widget.isError ? 1.0 : 0.0,
                    child: Center(
                        child: Text(
                      widget.errorText != null ? widget.errorText! : "",
                      style: const TextStyle(color: Pallete.error),
                    ))),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    circle(1),
                    circle(2),
                    circle(3),
                    circle(4),
                    circle(5),
                    circle(6),
                  ],
                ),
              ],
            ),
          ),
          Expanded(
            flex: 3,
            child: Container(
              padding: const EdgeInsets.only(left: 0, top: 0),
              child: _buttonisActive
                  ? Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: <Widget>[
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: <Widget>[
                            buildContainerCircle(_getNumber(1), true),
                            buildContainerCircle(_getNumber(2), true),
                            buildContainerCircle(_getNumber(3), true),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: <Widget>[
                            buildContainerCircle(_getNumber(4), true),
                            buildContainerCircle(_getNumber(5), true),
                            buildContainerCircle(_getNumber(6), true),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: <Widget>[
                            buildContainerCircle(_getNumber(7), true),
                            buildContainerCircle(_getNumber(8), true),
                            buildContainerCircle(_getNumber(9), true),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: <Widget>[
                            Opacity(
                                opacity: 0.0,
                                child: buildContainerCircle(3, false)),
                            buildContainerCircle(_getNumber(0), true),
                            buildContainerIcon(Icons.arrow_back)
                          ],
                        )
                      ],
                    )
                  : Container(),
            ),
          ),
          const SizedBox(
            height: 8,
          )
        ],
      ),
    );
  }

  Widget circle(int jumlah) {
    return Container(
      padding: const EdgeInsets.all(8),
      child: SizedBox(
          width: 15,
          height: 15,
          child: Container(
            decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: Pallete.thirdy, width: 2.0),
                color: _colorState(jumlah)),
          )),
    );
  }

  _colorState(int jumlah) {
    if (jumlah < _currentCodeLength + 1) {
      return Pallete.primary;
    }
  }

  Widget buildContainerIcon(IconData icon) {
    return InkResponse(
      onTap: () {
        _deleteCode();
      },
      child: Container(
        height: 80,
        width: 80,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: Colors.black12),
        ),
        child: Center(
          child: Icon(icon, size: 30, color: Pallete.primary),
        ),
      ),
    );
  }

  _onCodeClick(int? code) async {
    if (_inputCodes.length < 6) {
      _inputCodes.add(code);
      _currentCodeLength++;
      setState(() {
        color = const Color.fromRGBO(28, 58, 106, 1);
      });
    }

    if (_inputCodes.length == 6) {
      await finish();
    }
  }

  finish() async {
    await finished();
  }

  finished() async {
    setState(() {
      _buttonisActive = false;
    });
    await Future.delayed(const Duration(milliseconds: 500));
    widget.onFinishedVal!(_inputCodes.join());
    _cleanCode();
  }

  _cleanCode() {
    setState(() {
      _currentCodeLength = 0;
      _inputCodes = [];
      _buttonisActive = true;
    });
  }

  _deleteCode() {
    if (_currentCodeLength > 0) {
      _currentCodeLength--;
      _inputCodes.removeAt(_currentCodeLength);
      setState(() {
        color = Colors.white;
      });
    }
  }

  Widget buildContainerCircle(int? number, bool _isactive) {
    return Container(
      height: 80,
      width: 80,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(100),
          border: Border.all(color: Colors.black12)),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(100),
          splashColor: Pallete.primary,
          onTap: () {
            if (_isactive) {
              _onCodeClick(number);
            }
          },
          child: Center(
            child: Text(
              number.toString(),
              style: const TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.normal,
                  color: Pallete.primary),
            ),
          ),
        ),
      ),
    );
  }
}
