import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/landing/landing.dart';
import 'package:bpd_aceh/features/login/login.dart';
import 'package:bpd_aceh/features/splash/splash.dart';
import 'package:flutter/material.dart';

import '../dialog_box.dart';

class ISTForgotMPIN extends StatefulWidget {
  final ValueChanged<String>? onFinishedVal;
  final PreferredSizeWidget? appBar;
  final String? appBarTitle;
  final bool isError;
  final String? errorText;
  final Object? data;
  final String? title;

  const ISTForgotMPIN(
      {Key? key,
      this.appBarTitle,
      this.title,
      this.isError = false,
      this.errorText,
      this.onFinishedVal,
      this.appBar,
      this.data})
      : super(key: key);

  @override
  _ISTForgotMPINState createState() => _ISTForgotMPINState();
}

class _ISTForgotMPINState extends State<ISTForgotMPIN> {
  var _currentCodeLength = 0;
  var _inputCodes = <int?>[];
  var color = Colors.white;

  final _number = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
  late List<dynamic> _randomNumber;
  late bool _buttonisActive;

  @override
  void initState() {
    setState(() {
      _buttonisActive = true;
      // _randomNumber = (_number..shuffle());
      _randomNumber = _number;
    });
    super.initState();
  }

  _getNumber(index) {
    return _randomNumber[index];
  }

  _exitApp(BuildContext context) {
    const DialogBox().showImageDialog(
        image: const Image(
          image: AssetImage('assets/images/icon-warning.png'),
        ),
        message: "Anda Akan Membatalkan Proses Lupa MPIN",
        context: context,
        isError: true,
        onOk: () {
          Navigator.pushNamedAndRemoveUntil(
              context,
              LandingPageScreen.routeName,
              ModalRoute.withName(Splash.routeName));
          Navigator.pushNamed(context, LoginPage.routeName);
        },
        buttonOk: 'Ya',
        onCancel: () {
          Navigator.pop(context);
        },
        buttonCancel: 'Tidak');
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        onWillPop: () => _exitApp(context),
        // return
        child: Scaffold(
          backgroundColor: Colors.white,
          extendBodyBehindAppBar: false,
          appBar: widget.appBar ??
              AppBar(
                backgroundColor: Pallete.primary,
                centerTitle: true,
                leading: Container(),
                title: Text(
                  widget.appBarTitle == null ? 'MPIN' : widget.appBarTitle!,
                  style: const TextStyle(color: Colors.white),
                ),
                elevation: 0.0,
              ),
          body: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              Flexible(
                flex: 1,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    Text(
                      widget.title != null
                          ? widget.title!
                          : "Masukkan 6 digit MPIN Anda",
                      //style: TextStyle(fontSize: FontSize.TITLE),
                    ),
                    Opacity(
                        opacity: widget.isError ? 1.0 : 0.0,
                        child: Center(
                            child: Text(
                          widget.errorText != null ? widget.errorText! : "",
                          style: const TextStyle(color: Pallete.error),
                        ))),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        circle(1),
                        circle(2),
                        circle(3),
                        circle(4),
                        circle(5),
                        circle(6),
                      ],
                    ),
                  ],
                ),
              ),
              Expanded(
                flex: 3,
                child: Container(
                  padding: const EdgeInsets.only(left: 0, top: 0),
                  child: _buttonisActive
                      ? Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: <Widget>[
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: <Widget>[
                                buildContainerCircle(_getNumber(1), true),
                                buildContainerCircle(_getNumber(2), true),
                                buildContainerCircle(_getNumber(3), true),
                              ],
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: <Widget>[
                                buildContainerCircle(_getNumber(4), true),
                                buildContainerCircle(_getNumber(5), true),
                                buildContainerCircle(_getNumber(6), true),
                              ],
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: <Widget>[
                                buildContainerCircle(_getNumber(7), true),
                                buildContainerCircle(_getNumber(8), true),
                                buildContainerCircle(_getNumber(9), true),
                              ],
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: <Widget>[
                                Opacity(
                                    opacity: 0.0,
                                    child: buildContainerCircle(3, false)),
                                buildContainerCircle(_getNumber(0), true),
                                buildContainerIcon(Icons.arrow_back)
                              ],
                            )
                          ],
                        )
                      : Container(),
                ),
              ),
              const SizedBox(
                height: 8,
              )
            ],
          ),
        ));
  }

  Widget circle(int jumlah) {
    return Container(
      padding: const EdgeInsets.all(8),
      child: SizedBox(
          width: 15,
          height: 15,
          child: Container(
            decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: Pallete.thirdy, width: 2.0),
                color: _colorState(jumlah)),
          )),
    );
  }

  _colorState(int jumlah) {
    if (jumlah < _currentCodeLength + 1) {
      return Pallete.primary;
    }
  }

  Widget buildContainerIcon(IconData icon) {
    return InkResponse(
      onTap: () {
        _deleteCode();
      },
      child: Container(
        height: 80,
        width: 80,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: Colors.black12),
        ),
        child: Center(
          child: Icon(icon, size: 30, color: Pallete.primary),
        ),
      ),
    );
  }

  _onCodeClick(int? code) async {
    if (_inputCodes.length < 6) {
      _inputCodes.add(code);
      _currentCodeLength++;
      setState(() {
        color = const Color.fromRGBO(28, 58, 106, 1);
      });
    }
    if (_inputCodes.length == 6) {
      await finish();
    }
  }

  finish() async {
    await finished();
  }

  finished() async {
    setState(() {
      _buttonisActive = false;
    });
    await Future.delayed(const Duration(milliseconds: 500));
    widget.onFinishedVal!(_inputCodes.join());
    _cleanCode();
  }

  _cleanCode() {
    setState(() {
      _currentCodeLength = 0;
      _inputCodes = [];
      _buttonisActive = true;
    });
  }

  _deleteCode() {
    if (_currentCodeLength > 0) {
      _currentCodeLength--;
      _inputCodes.removeAt(_currentCodeLength);
      setState(() {
        color = Colors.white;
      });
    }
  }

  Widget buildContainerCircle(int? number, bool _isactive) {
    return Container(
      height: 80,
      width: 80,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(100),
          border: Border.all(color: Colors.black12)),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(100),
          splashColor: Pallete.primary,
          onTap: () {
            if (_isactive) {
              _onCodeClick(number);
            }
          },
          child: Center(
            child: Text(
              number.toString(),
              style: const TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.normal,
                  color: Pallete.primary),
            ),
          ),
        ),
      ),
    );
  }
}
