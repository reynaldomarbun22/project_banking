import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/example/domain/history_data.dart';
import 'package:bpd_aceh/components/example/widgets/history_card.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:flutter/material.dart';

class ExAppBar extends StatefulWidget {
  const ExAppBar({Key? key}) : super(key: key);

  @override
  _ExAppBarState createState() => _ExAppBarState();
}

class _ExAppBarState extends State<ExAppBar> {
  @override
  void initState() {
    super.initState();
    _callApi();
  }

  List<dynamic>? datafrBE = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: false,
      extendBody: true,
      backgroundColor: Colors.white,
      appBar: AppBar(
          title: const Image(
            image: AssetImage('assets/images/logo-app.png'),
            color: Colors.white,
          ),
          // Text(
          //   'Mutasi ',
          //   style: TextStyle(color: Colors.white),
          // ),
          centerTitle: true,
          elevation: 0.0,
          iconTheme: const IconThemeData(color: Colors.white),
          backgroundColor: Pallete.primary),
      body: Container(
        color: Colors.blueAccent,
        child: ListView(
          children: _dataFromBE(),
        ),
      ),
    );
  }

  _callApi() async {
    final respone = await API.postNoLoading(context, '/history', {});
    setState(() {
      datafrBE = respone;
    });
  }

  _dataFromBE() {
    List<Widget> history = [];

    for (var itemHistory in datafrBE!) {
      Widget icon;
      final item = HistoryData(
        amount: itemHistory['amount'],
        codeTrx: itemHistory['codeTrx'],
        date: itemHistory['date'],
        description: itemHistory['description'],
      );

      switch (item.codeTrx) {
        case 0:
          icon = const Icon(Icons.shopping_basket);
          break;
        case 1:
          icon = const Icon(Icons.compare_arrows);
          break;
        case 2:
          icon = const Icon(Icons.credit_card);
          break;
        default:
          icon = const Icon(Icons.warning);
      }

      // if (itemHistory != null) {
      //   if (itemHistory.codeTrx == 0) {
      //     icon = Icon(Icons.shopping_basket);
      //   } else if (itemHistory.codeTrx == 1) {
      //     icon = Icon(Icons.compare_arrows);
      //   } else if (itemHistory.codeTrx == 2) {
      //     icon = Icon(Icons.credit_card);
      //   }
      // }

      history.add(HistoryCard(
        amount: item.amount,
        date: item.date,
        description: item.description,
        icon: icon,
      ));
    }
    return history;
  }
}
