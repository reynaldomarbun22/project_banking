class HistoryData {
  final int? codeTrx;
  final String? description;
  final String? date;
  final String? amount;

  HistoryData({this.codeTrx, this.description, this.date, this.amount});
}
