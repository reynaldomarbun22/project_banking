import 'package:flutter/material.dart';

class HistoryCard extends StatelessWidget {
  final Widget? icon;
  final String? description;
  final String? date;
  final String? amount;

  const HistoryCard(
      {Key? key, this.icon, this.description, this.date, this.amount})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: <Widget>[
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          alignment: Alignment.center,
          height: 100,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: Colors.red,
            ),
            child: Row(
              children: <Widget>[
                Container(
                  padding: const EdgeInsets.all(4),
                  child: icon,
                ),
                Expanded(child: Text(description!)),
                Expanded(
                    child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[Text(date!), Text(amount!)],
                )),
                Container(
                    color: Colors.orange,
                    padding: const EdgeInsets.all(4),
                    child: const Icon(Icons.arrow_forward_ios)),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
