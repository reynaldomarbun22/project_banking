import 'package:flutter/material.dart';

class Pallete {
  static const primary =
      Color.fromRGBO(0, 101, 67, 1); //Color.fromRGBO(230, 33, 41, 1);
  static const secondary = Color.fromRGBO(230, 228, 0, 1);
  static const thirdy = Color.fromRGBO(0, 130, 74,
      1); //Color.fromRGBO(230, 228, 0, 1);//Color.fromRGBO(230, 33, 41, 1);
  static const homeBackground = Color.fromRGBO(255, 244, 240, 1);
  static const warning = Color.fromRGBO(242, 153, 74, 1);

  static const error = Color.fromRGBO(255, 1, 1, 1);

  static const grad1 = Color.fromRGBO(188, 236, 255, 1);
  static const grad2 = Color.fromRGBO(191, 212, 255, 1);
  static const grad3 = Color.fromRGBO(194, 187, 255, 1);

  static const buttonprimary = LinearGradient(
      begin: Alignment.centerLeft,
      end: Alignment.centerRight,
      colors: [Color.fromRGBO(8, 172, 247, 1), Color.fromRGBO(56, 51, 196, 1)]);
}
// rgb( 242, 153, 74, 1) suspect