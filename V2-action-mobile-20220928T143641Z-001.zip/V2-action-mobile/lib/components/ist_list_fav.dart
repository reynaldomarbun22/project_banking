import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/features/other/daftarFavorit/widget/tab_pembayaran.dart';
import 'package:bpd_aceh/features/other/daftarFavorit/widget/tab_pembelian.dart';
import 'package:bpd_aceh/features/other/daftarFavorit/widget/tab_transfer.dart';
import 'package:flutter/material.dart';

enum ISTFavoritEnum { transfer, pembelian, pembayaran, home }

class ISTListFav extends StatefulWidget {
  final List<ISTFavoritEnum> menu;
  final BuildContext context;
  final Function()? callback;

  const ISTListFav(
      {Key? key, required this.menu, required this.context, this.callback})
      : super(key: key);
  @override
  _ISTListFavState createState() => _ISTListFavState();
}

class _ISTListFavState extends State<ISTListFav>
    with SingleTickerProviderStateMixin {
  TabController? _tabController;
  List<TabTransferFavoriteItem> _listFilteredTransfer = [];
  List<TabTransferFavoriteItem> _listTransfer = [];
  bool loading = false;

  _doInqTransfer() async {
    if (_listTransfer.isEmpty) {
      setState(() {
        loading = true;
      });
    } else {
      setState(() {
        loading = false;
      });
    }
    final resp = await API.postNoLoading(context, '/getfavorite/transfer', {});
    if (resp != null && resp['code'] == 0) {
      var listResp = resp['favoritListDtos'];
      List<dynamic>? listRespDyn = (listResp);

      List<TabTransferFavoriteItem> listparam = [];
      if (listRespDyn != null) {
        for (var item in listRespDyn) {
          TabTransferFavoriteItem tf = TabTransferFavoriteItem(
            initial: item['transactionCode'],
            id: item['id'],
            noRek: item['dstAccountNo'],
            nameBank: item['bankName'],
            ownerName: item['dstAccountOwnerName'].toString().isEmpty
                ? "-"
                : item['dstAccountOwnerName'], //Value not in range: 1 #error
            destno: item['dstAccountNo'],
            destcode: item['dstBankCode'],
            callback: (noRek, ownerName, nameBank, destcode, id) {
              _doInqTransfer();
            },
          );
          listparam.add(tf);
        }
      }
      setState(() {
        _listTransfer = listparam;
        _listFilteredTransfer = _listTransfer;
        loading = false;
      });
    }
  }

  List<TabPaymentFavoriteItem> _listFilteredPayment = [];
  List<TabPaymentFavoriteItem> _listPayment = [];
  _doInqPayment() async {
    final resp = await API.postNoLoading(context, '/getfavorite/layanan', {});
    if (resp != null && resp['code'] == 0) {
      var listResp = resp['favoritListDtos'];
      List<dynamic>? listRespDyn = (listResp);
      List<TabPaymentFavoriteItem> listparam = [];
      if (listRespDyn != null) {
        //kalo lopping ga bsa nul jd pake!= null
        for (var item in listRespDyn) {
          TabPaymentFavoriteItem tf = TabPaymentFavoriteItem(
            id: item['id'],
            textType: item['nameId'],
            typePayment: "Layanan",
            desc: item['bpCustomerName'],
            noRek: item['dstAccountNo'],
            code: item['transactionCode'],
            kota: item['additionalData'],
            listPBB: item['tranAdditionalData2'],
            callback:
                (noRek, typePayment, desc, id, textType, code, kota, listPBB) {
              _doInqPayment();
            },
          );
          listparam.add(tf);
        }
      }
      setState(() {
        _listPayment = listparam;
        _listFilteredPayment = _listPayment;
      });
    }
  }

  List<TabPurchaseFavoriteItem> _listFilteredPurchase = [];
  List<TabPurchaseFavoriteItem> _listPurchase = [];
  // ignore: unused_element
  _doInqPurchase() async {
    final resp = await API.postNoLoading(context, '/getfavorite/purchase', {});
    if (resp != null && resp['code'] == 0) {
      var listResp = resp['favoritListDtos'];
      List<dynamic>? listRespDyn = (listResp);
      List<TabPurchaseFavoriteItem> listparam = [];
      if (listRespDyn != null) {
        for (var item in listRespDyn) {
          TabPurchaseFavoriteItem tf = TabPurchaseFavoriteItem(
            id: item['id'],
            typeProvider: item['nameId'],
            textProvider: item['tranAdditionalData1'],
            numberCard: item['dstAccountNo'],
            callback: (typeProvider, textProvider, numberCard, id) {
              _doInqPurchase();
            },
          );
          listparam.add(tf);
        }
      }
      setState(() {
        _listPurchase = listparam;
        _listFilteredPurchase = _listPurchase;
      });
    }
  }

  @override
  void initState() {
    _initFav();

    _doInqTransfer();
    //tambahkan SingleTickerProviderStateMikin pada class _HomeState
    super.initState();
  }

  List<Widget> tabs = [];
  List<Widget?> tabsview = [];
  _initFav() {
    List<Widget?> _tabsview = [];
    for (ISTFavoritEnum item in widget.menu) {
      if (item == ISTFavoritEnum.transfer) {
        _doInqTransfer();
        tabs.add(
          const Tab(
            child: Text(
              'Transfer',
              style: TextStyle(
                fontFamily: 'Poppins',
              ),
            ),
            // text: "Transfer",
          ),
        );
        _tabsview.add(_buildListTransfer());
      }
      if (item == ISTFavoritEnum.pembayaran) {
        _doInqPayment();
        tabs.add(
          const Tab(
            child: Text(
              'Layanan',
              style: TextStyle(
                fontFamily: 'Poppins',
              ),
            ),
            // text: "Transfer",
          ),
        );
        _tabsview.add(_buildpayment());
      }
      if (item == ISTFavoritEnum.pembelian) {
        // _doInqPurchase();
        tabs.add(
          const Tab(
            text: "Pembelian",
          ),
        );
        _tabsview.add(_buildpurchase());
      }
    }
    setState(() {
      tabsview = _tabsview;
    });
    _tabController = TabController(vsync: this, length: widget.menu.length);
  }

  @override
  void dispose() {
    _tabController!.dispose();
    super.dispose();
  }

  // List<ISTAvatarList> _listFilteredPurchases = [];

  TabController? controller;
  final TextEditingController _search = TextEditingController();
  int _tabindex = 0;
  String _searchText = "";
  Icon _searchIcon = const Icon(
    Icons.search,
    color: Colors.white,
  );
  Widget _appBarTitle = const Text(
    'Daftar Favorit',
    style: TextStyle(
        fontFamily: 'Poppins',
        //fontWeight: FontWeight.bold,
        color: Colors.white
        // fontSize: FontSize.TITLE,
        ),
  );

  void _searchPressed() {
    setState(() {
      if (_searchIcon.icon == Icons.search) {
        _searchIcon = const Icon(
          Icons.close,
          color: Colors.white,
        );
        _appBarTitle = TextField(
            style: const TextStyle(
              color: Colors.white,
              fontFamily: 'Poppins',
            ),
            autofocus: true,
            controller: _search,
            onChanged: (text) {
              setState(() {
                _searchText = text;
              });
            },
            decoration: const InputDecoration(
                border: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.white)),
                // prefixIcon: Icon(Icons.search),
                hintText: 'Cari Daftar Favorit...',
                hintStyle: TextStyle(
                  color: Colors.white,
                  fontSize: 13,
                  fontFamily: 'Poppins',
                )));
      } else {
        _searchIcon = const Icon(
          Icons.search,
          color: Colors.white,
        );
        _appBarTitle = const Text(
          // 'Hapus Daftar Favorit',
          'Daftar Favorit',
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'Poppins',
          ),
        );
        _searchText = "";
        _search.clear();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    List<Widget?> tabsviews = [
      if (widget.menu.contains(ISTFavoritEnum.transfer)) _buildListTransfer(),
      if (widget.menu.contains(ISTFavoritEnum.pembelian)) _buildpurchase(),
      if (widget.menu.contains(ISTFavoritEnum.pembayaran)) _buildpayment(),
    ];
    // if (widget.menu.contains(ISTFavoritEnum.transfer) ) {
    //   _doInqTransfer();
    //   tabs.add(
    //     Tab(
    //       text: "Transfer",
    //     ),
    //   );
    //   tabsviews.add(_buildListTransfer());
    // }if (widget.menu.contains(ISTFavoritEnum.pembayaran)) {
    //   _doInqPayment();
    //   tabs.add(
    //     Tab(
    //       text: "Pembayaran",
    //     ),
    //   );
    // }
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Pallete.primary,
        centerTitle: true,
        title: _appBarTitle,
        leading: IconButton(
            color: Colors.white,
            icon: const Icon(Icons.arrow_back_ios),
            onPressed: () {
              Navigator.pop(context);
            }),
        actions: <Widget>[
          IconButton(
            icon: _searchIcon,
            onPressed: _searchPressed,
          ),
        ],
      ),
      body: loading
          ? Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.only(top: 16),
              child: CircularProgressIndicator(
                backgroundColor: Colors.grey[350],
                strokeWidth: 3,
                valueColor:
                    const AlwaysStoppedAnimation<Color>(Pallete.primary),
                // valueColor:
                //     new AlwaysStoppedAnimation<Color>(Colors.red),
                // //   child: Container(
                // //   color: Colors.grey[300],
                // //   height: 100,
                // //   width: 100,
                // // )
              ),
            )
          : Column(
              children: <Widget>[
                const SizedBox(
                  height: 8,
                ),
                SizedBox(
                    height: 30,
                    child: DefaultTabController(
                        length: widget.menu.length,
                        initialIndex: _tabindex,
                        child: Material(
                            color: Colors.transparent,
                            child: TabBar(
                                unselectedLabelStyle: const TextStyle(
                                    fontWeight: FontWeight.normal,
                                    color: Colors.black54),
                                labelStyle: const TextStyle(
                                    fontWeight: FontWeight.bold),
                                labelColor: Pallete.primary,
                                unselectedLabelColor: Colors.black54,
                                // labelPadding: EdgeInsets.symmetric(vertical: 8),
                                indicatorColor: Colors.white,
                                controller: _tabController,
                                onTap: (index) {
                                  setState(() {
                                    _tabindex = index;
                                  });
                                },
                                tabs: tabs

                                // Tab(
                                //   text: "Transfer",
                                // ),
                                // Tab(
                                //   text: "Pembelian",
                                // ),
                                // Tab(
                                //   text: "Pembayaran",
                                // ),
                                )))),

                // SizedBox(height: 8,),
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 8.0),
                  child: Divider(
                    height: 2,
                    color: Pallete.primary,
                  ),
                ),
                Expanded(
                    child: TabBarView(
                        controller: _tabController,
                        children: [for (Widget? item in tabsviews) item!]
                        //
                        // tabsview
                        // // tabs
                        // [
                        //  _buildListTransfer(),
                        //   _buildpayment()
                        //  ]
                        ))
              ],
            ),
    );
  }

  _buildpurchase() {
    if (!widget.menu.contains(ISTFavoritEnum.pembelian)) return;
    if (_searchText.isNotEmpty) {
      List<TabPurchaseFavoriteItem> tempList = [];
      for (var item in _listFilteredPurchase) {
        if (item.textProvider != null) {
          if (item.textProvider!
              .toLowerCase()
              .contains(_searchText.toLowerCase())) {
            tempList.add(item);
          }
        }
      }
      _listFilteredPurchase = tempList;
    } else {
      _listFilteredPurchase = _listPurchase;
    }
    if (_listPurchase.isEmpty) {
      return const Center(
          child: Text(
        'Anda belum menambahkan favorit',
        style: TextStyle(color: Colors.grey),
      ));
    } else {
      return ListView.separated(
          itemBuilder: (context, index) {
            // ignore: unused_local_variable
            final item = _listFilteredPurchase[index];
            return _listFilteredPurchase[index];
          },
          separatorBuilder: (context, inx) {
            return Container();
          },
          // ignore: unnecessary_null_comparison
          itemCount: _listPurchase == null ? 0 : _listFilteredPurchase.length);
    }
  }

  _buildpayment() {
    if (!widget.menu.contains(ISTFavoritEnum.pembayaran)) return;

    if (_searchText.isNotEmpty) {
      List<TabPaymentFavoriteItem> tempList = [];
      for (var f in _listFilteredPayment) {
        if (f.textType != null || f.noRek != null) {
          if (f.textType!.toLowerCase().contains(_searchText) ||
              f.noRek!.toLowerCase().toString().contains(_searchText) ||
              f.typePayment!.toLowerCase().contains(_searchText)) {
            tempList.add(f);
          }
        }
      }

      _listFilteredPayment = tempList;
    } else {
      _listFilteredPayment = _listPayment;
    }
    if (_listPayment.isEmpty) {
      return const Center(
          child: Text(
        'Anda belum menambahkan favorit',
        style: TextStyle(color: Colors.grey),
      ));
    } else {
      return ListView.separated(
          itemBuilder: (context, index) {
            return _listFilteredPayment[index];
          },
          separatorBuilder: (context, inx) {
            return Container();
          },
          // ignore: unnecessary_null_comparison
          itemCount: _listPayment == null ? 0 : _listFilteredPayment.length);
    }
  }

  _buildListTransfer() {
    if (!widget.menu.contains(ISTFavoritEnum.transfer)) return;

    if (_searchText.isNotEmpty) {
      List<TabTransferFavoriteItem> tempList = [];
      for (var f in _listFilteredTransfer) {
        if (f.ownerName!.toLowerCase().contains(_searchText) ||
            f.nameBank!.toLowerCase().toString().contains(_searchText) ||
            f.noRek!.toLowerCase().toString().contains(_searchText)) {
          tempList.add(f);
        }
      }
      // for (TabTransferFavoriteItem item in _listFilteredTransfer) {
      // if (item.ownerName != null ||
      //     item.nameBank != null ||
      //     item.noRek != null) {
      // if (item.ownerName!
      //         .toLowerCase()
      //         .contains(_searchText.toLowerCase()) ||
      //     item.nameBank!
      //         .toLowerCase()
      //         .contains(_searchText.toLowerCase()) ||
      //     item.noRek!.toLowerCase().contains(_searchText.toLowerCase())) {
      //   _listFilteredTransfer.add(item);
      // }
      // }
      // }

      // tempList.add(item);
      _listFilteredTransfer = tempList;
    } else {
      _listFilteredTransfer = _listTransfer;
    }
    if (_listTransfer.isEmpty) {
      return const Center(
          child: Text(
        'Anda belum menambahkan favorit',
        style: TextStyle(color: Colors.grey),
      ));
    } else {
      return ListView.separated(
          itemBuilder: (context, index) {
            // ignore: unused_local_variable
            final item = _listFilteredTransfer[index];
            return _listFilteredTransfer[index];
          },
          separatorBuilder: (context, inx) {
            return Container();
          },
          // ignore: unnecessary_null_comparison
          itemCount: _listTransfer == null ? 0 : _listFilteredTransfer.length);
      //  return Column(
      //    children: _listPayment,
      //  );
    }
  }
}

// ignore: unused_element
_buildMenuFav(menu) {
  switch (menu) {
    case ISTFavoritEnum.transfer:
      return const Image(
        image: AssetImage('assets/images/icon-qr.png'),
        color: Pallete.primary,
      );
    case ISTFavoritEnum.pembelian:
      return const Image(
        image: AssetImage('assets/images/icon-qr.png'),
        color: Pallete.primary,
      );
    case ISTFavoritEnum.pembayaran:
      return const Image(
          image: AssetImage('assets/images/header-transfer.png'));
      // ignore: dead_code
      break;
    // case ISTMenu.statements:
    //   return Image(image: AssetImage('assets/images/header-statement.png'));
    // case ISTMenu.rekeningKu:
    //   return Image(image: AssetImage('assets/images/rekeningkuheader.png'));
    //   break;
    default:
  }
}
