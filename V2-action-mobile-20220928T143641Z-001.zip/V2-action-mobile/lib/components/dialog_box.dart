import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/core/utils/string_utils.dart';
import 'package:flutter/material.dart';

class DialogBox extends StatelessWidget {
  static const routeName = '/DialogBox';
  final String? title;
  final IconData? icon;
  final String? message;
  final String? message1;
  final bool isError;
  final String? buttonOk;
  final String? buttonCancel;
  final VoidCallback? onCancel;
  final VoidCallback? onOk;
  final BuildContext? context;
  final Widget? image;

  const DialogBox(
      {Key? key,
      this.title,
      this.isError = false,
      this.icon,
      this.message,
      this.message1,
      this.buttonOk,
      this.buttonCancel,
      this.onCancel,
      this.onOk,
      this.context,
      this.image})
      : super(key: key);

  _checkbutton(BuildContext? context) {
    List<Widget> list = [];
    if (buttonCancel != null) {
      list.add(
        OutlinedButton(
            style: OutlinedButton.styleFrom(
              side: const BorderSide(
                color: Colors.red,
              ),
              primary: Pallete.primary,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(18)),
              ),
            ),
            child: Text(
              buttonCancel!,
              style: Theme.of(context!)
                  .textTheme
                  .bodyText1!
                  .copyWith(fontWeight: FontWeight.w600, color: Colors.red),
            ),
            onPressed: onCancel ??
                () {
                  Navigator.of(context).pop();
                }),
      );
    }
    if (buttonOk != null) {
      list.add(
        OutlinedButton(
          style: OutlinedButton.styleFrom(
            side: const BorderSide(
              color: Pallete.primary,
            ),
            primary: Pallete.primary,
            // color: Colors.green,
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(18)),
            ),
          ),
          child: Text(
            buttonOk!,
            style: Theme.of(context!).textTheme.bodyText1!.copyWith(
                fontWeight: FontWeight.w600,
                color: isError ? Pallete.primary : Pallete.primary),
          ),
          onPressed: onOk ??
              () {
                Navigator.of(context).pop();
              },
        ),
      );
    }
    return list;
  }

  void showErrorDialog(
      {final icon,
      required final message,
      required final context,
      final image}) {
    showDialog(
      barrierDismissible: true, // user must tap button!
      builder: (BuildContext context) {
        return DialogBox(
          title: 'Peringatan',
          // icon: Icons.warning,
          image: image,
          isError: true,
          message: message,
          buttonOk: 'OK',
        );
      },
      context: context,
    );
  }

  void showImageDialog(
      {final icon,
      required final message,
      final message1,
      required final context,
      final String? title,
      final image,
      required final isError,
      final buttonOk,
      final buttonCancel,
      final VoidCallback? onCancel,
      final VoidCallback? onOk}) {
    showDialog(
      barrierDismissible: false,
      useRootNavigator: true,
      builder: (BuildContext? context) {
        return WillPopScope(
          child: DialogBox(
            title: title ?? 'Peringatan',
            image: image != null
                ? Image(
                    image: image.image,
                    height: MediaQuery.of(context!).size.width * 0.25,
                  )
                : Container(),
            // image: image,
            message: message,
            message1: message1,

            buttonOk: buttonOk,
            buttonCancel: buttonCancel,
            onCancel: onCancel,
            isError: isError,
            onOk: onOk,
          ),
          onWillPop: () async => false,
        );
      },
      context: context,
    );
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(20.0)),
      ),
      title: Column(
        children: <Widget>[
          icon != null
              ? Icon(
                  icon,
                  size: 100,
                )
              : Container(),
          image != null ? image! : Container(),
          const SizedBox(
            height: 0,
          ),
          Text(
            title != null ? title! : "",
            textAlign: TextAlign.center,
            style: TextStyle(
                //fontSize: Theme.of(context).textTheme.headline4.fontSize,
                color: isError
                    ? const Color.fromRGBO(171, 0, 0, 1)
                    : Pallete.primary),
          ),
          const SizedBox(
            height: 16,
          ),
        ],
      ),
      content: SingleChildScrollView(
        child: ListBody(
          children: <Widget>[
            Text(
              message ?? "",
              // style: TextStyle(color: Pallete.primary),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 12),
            message1 == null
                ? const SizedBox(height: 1)
                : Text(
                    StringUtils.getValueAsString(message1!),
                    textAlign: TextAlign.center,
                  ),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: _checkbutton(context),
            )
          ],
        ),
      ),

      //actions: _checkbutton(context),
    );
  }

  Widget alertdial() {
    var checkbutton = _checkbutton(context);
    return AlertDialog(
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(20.0))),
      title: Column(
        children: <Widget>[
          icon != null
              ? Icon(
                  icon,
                  size: 100,
                )
              : Container(),
          image != null ? image! : Container(),
          const SizedBox(
            height: 8,
          ),
          Text(
            title!,
            style: TextStyle(
                // fontSize: Theme.of(context).textTheme.headline4.fontSize,
                color: isError
                    ? const Color.fromRGBO(171, 0, 0, 1)
                    : Colors.black),
          ),
          const SizedBox(
            height: 8,
          ),
        ],
      ),
      content: SingleChildScrollView(
        child: ListBody(
          children: <Widget>[
            Text(
              message!,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            Container(
              decoration: const BoxDecoration(
                  border:
                      Border(top: BorderSide(color: Colors.grey, width: 1))),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: checkbutton,
              ),
            )
          ],
        ),
      ),
      // actions: _checkbutton(context),
    );
  }
}
