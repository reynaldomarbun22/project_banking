import 'package:bpd_aceh/components/palete.dart';
import 'package:flutter/material.dart';

class ISTCardStatement extends StatelessWidget {
  const ISTCardStatement({
    Key? key,
    this.kosong,
    this.debit,
    this.transactionAmt,
    this.transactionMemo,
    this.transactionDateTime,
    this.transactionStatus,
    this.transactionType,
  }) : super(key: key);
  final int? debit;
  final String? transactionAmt;
  final String? transactionMemo;
  final String? transactionDateTime;
  final String? transactionStatus;
  final String? transactionType;
  final bool? kosong;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Card(
        child: Container(
          // height: 140,
          padding: const EdgeInsets.all(8),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              // SizedBox(width: 8),
              Expanded(
                flex: 5,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    // Text(
                    //   '$transactionType',

                    // ),
                    Text(
                      transactionMemo == "" ? "-" : transactionMemo!,
                      style: const TextStyle(
                        fontFamily: 'Poppins',
                      ),
                      overflow: TextOverflow.fade,
                    ),
                    Text(
                      '$transactionDateTime',
                      style: TextStyle(
                        fontSize:
                            Theme.of(context).textTheme.overline!.fontSize,
                        fontFamily: 'Poppins',
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                  flex: 5,
                  child: Text(
                    '$transactionAmt',
                    textAlign: TextAlign.right,
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      color: debit == 0 ? Pallete.error : Pallete.primary,
                    ),
                  ))
            ],
          ),
        ),
      ),
    );
  }
}
