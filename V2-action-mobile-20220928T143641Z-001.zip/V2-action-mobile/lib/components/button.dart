import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'palete.dart';

class ISTOutlineButton extends StatelessWidget {
  final VoidCallback? onPressed;
  final String text;
  final Color color;

  const ISTOutlineButton(
      {Key? key,
      required this.onPressed,
      required this.text,
      this.color = Pallete.primary})
      : super(key: key);
  const ISTOutlineButton.white(
      {Key? key,
      required this.onPressed,
      required this.text,
      this.color = Colors.white})
      : super(key: key);
  const ISTOutlineButton.secondary(
      {Key? key,
      required this.onPressed,
      required this.text,
      this.color = Pallete.secondary})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 44,
      width: double.infinity,
      child: OutlinedButton(
        style: OutlinedButton.styleFrom(
          shadowColor: color,
          primary: color,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadiusDirectional.circular(30)),
          side: BorderSide(style: BorderStyle.solid, width: 1, color: color),
        ),
        child: Text(
          text,
          style: TextStyle(color: color),
        ),
        onPressed: onPressed,
      ),
    );
  }
}

class ISTOutlineIconButton extends StatelessWidget {
  final VoidCallback? onPressed;
  final String? image;
  final String? text;
  final EdgeInsetsGeometry? padding;

  const ISTOutlineIconButton(
      {Key? key, this.onPressed, this.image, this.text, this.padding})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding ?? const EdgeInsets.all(0.0),
      height: 100,
      child: OutlinedButton(
        style: OutlinedButton.styleFrom(
          primary: Pallete.buttonprimary.colors.first,
          padding: const EdgeInsets.only(left: 6),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadiusDirectional.circular(30),
          ),
          side: const BorderSide(
            style: BorderStyle.solid,
            width: 0.5,
            color: Pallete.secondary,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Container(
              padding: const EdgeInsets.all(7),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Pallete.secondary, width: 1)),
              width: 40,
              height: 40,
              child: Image(
                image: AssetImage(image!),
                color: Theme.of(context).textTheme.bodyText2!.color,
              ),
            ),
            const SizedBox(width: 6),
            Text(
              text!,
              style: Theme.of(context).textTheme.bodyText2,
            ),
            const SizedBox(width: 12),
          ],
        ),
        onPressed: onPressed,
      ),
    );
  }
}

class ISTShortcutButton extends StatelessWidget {
  final ImageProvider image;
  final String text;
  final GestureTapCallback onPressed;

  const ISTShortcutButton(
      {Key? key,
      required this.image,
      required this.text,
      required this.onPressed})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          highlightColor: Colors.transparent,
          borderRadius: BorderRadius.circular(10),
          child: SizedBox(
            height: 80,
            width: 80,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: <Widget>[
                const SizedBox(
                  height: 4,
                ),
                Container(
                    color: Colors.transparent,
                    height: 25,
                    child: Image(
                        width: 25,
                        height: 25,
                        image: image,
                        color: Theme.of(context).textTheme.bodyText2!.color)),
                const SizedBox(
                  height: 8,
                ),
                Text(
                  text,
                  style: Theme.of(context).textTheme.caption,
                ),
                const SizedBox(
                  height: 4,
                ),
              ],
            ),
          ),
          onTap: onPressed,
        ),
      ),
    );
  }
}

class ISTFlatButton extends StatelessWidget {
  final String text;
  final GestureTapCallback onPressed;
  final Color? color;

  const ISTFlatButton(
      {Key? key, this.text = "", required this.onPressed, this.color})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CupertinoButton(
      padding: const EdgeInsets.all(0),
      disabledColor: Colors.grey,
      onPressed: onPressed,
      child: Text(
        text,
        style: Theme.of(context)
            .textTheme
            .bodyText2!
            .copyWith(color: color ?? Pallete.buttonprimary.colors.first),
      ),
    );
  }
}
