import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_save/image_save.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share/share.dart';
import 'package:screenshot/screenshot.dart';

enum ISTReceiptStatusTabunganInbox {
  success,
  failed,
  suspect,
}

class ISTReceiptItemTabunganInbox {
  final String? key;
  final String? value;

  ISTReceiptItemTabunganInbox({this.key, this.value});

  String toJson() => json.encode({
        'key': key,
        'value': value,
      });

  factory ISTReceiptItemTabunganInbox.fromJson(dynamic json) {
    return ISTReceiptItemTabunganInbox(key: json['key'], value: json['value']);
  }
}

class ISTReceiptTabunganInbox extends StatefulWidget {
  const ISTReceiptTabunganInbox({
    Key? key,
    this.items,
    this.onFinished,
    this.onCheck,
    this.onTap,
    this.type,
    this.idresi,
    this.title,
    this.srcAcc,
    this.srcNOAcc,
    this.dstAcc,
    this.amount,
    this.time,
    this.memo,
    this.status,
    this.noRef,
    this.id,
    this.titleresi,
    this.footer1,
    this.footer2,
    this.footer3,
    this.titleresi1,
  }) : super(key: key);

  final String? noRef;
  final String? idresi;

  final String? memo;
  final String? time;
  final String? srcAcc;
  final String? dstAcc;
  final String? srcNOAcc;
  final String? title;
  final String? amount;
  final int? id;
  final String? titleresi;
  final String? titleresi1;
  final List<ISTReceiptItemTabunganInbox>? items;
  final Function? onFinished;
  final Function? onCheck;
  final Function? onTap;
  final ISTReceiptStatusTabunganInbox? status;
  final Widget? footer1;
  final Widget? footer2;
  final List<ISTReceiptItemTabunganInbox>? footer3;
  final String? type;

  //  static String encondeHeaderToJson(List<ISTReceiptItemTabunganInbox> list) {
  //   List jsonList = List();
  //   list.map((item) => jsonList.add(item.toJson())).toList();
  //   return json.encode(jsonList);
  // }

  // final ISTReceipt data;
  // const ISTReceipt({Key key,  this.data}) : super(key: key);

  @override
  _ISTReceiptTabunganInboxState createState() =>
      _ISTReceiptTabunganInboxState();
}

class _ISTReceiptTabunganInboxState extends State<ISTReceiptTabunganInbox> {
  String statusStr = "";
  String imageStatus = "";
  bool isLoading = false;
  bool isSuccess = false;
  bool _firstPress = true;

  // _saveinbox() async {
  //   InboxDBRepository repo = InboxDBRepository();
  //   await repo.open();
  //   InboxModel model = InboxModel();
  //   model.amount = widget.amount;
  //   model.status = widget.status.index.toString();
  //   model.title = widget.title;
  //   var img = widget.type;
  //   var imgasset = "";
  //   if( img == 'PAYMENT_ZAKAT') {
  //     imgasset ='assets/images/icon-wallet.png';
  //   }
  //   model.image = imgasset;
  //   await repo.insert(model);
  //   await repo.close();
  // }

  @override
  void initState() {
    switch (widget.status) {
      case ISTReceiptStatusTabunganInbox.success:
        setState(() {
          statusStr = "Berhasil";
          imageStatus = "assets/images/icon-success.png";
        });
        break;
      case ISTReceiptStatusTabunganInbox.failed:
        setState(() {
          statusStr = "Gagal";
          imageStatus = "assets/images/icon-failed.png";
        });
        break;
      case ISTReceiptStatusTabunganInbox.suspect:
        setState(() {
          statusStr = "Sedang diproses";
          imageStatus = "assets/images/icon-warning.png";
        });
        break;
        // case ISTReceiptStatusTabunganInbox.suspectQR:
        //   setState(() {
        //     statusStr = "Sedang diproses";
        //     imageStatus = "assets/images/icon-warning.png";
        //     type = 'QRPAYMENT';
        //   });
        // ignore: dead_code
        break;
      default:
    }
    super.initState();
  }

  _changeStatus() {
    switch (widget.status) {
      case ISTReceiptStatusTabunganInbox.success:
        setState(() {
          isSuccess = true;
          statusStr = "Berhasil";
          imageStatus = "assets/images/icon-success.png";
        });
        break;
      case ISTReceiptStatusTabunganInbox.failed:
        setState(() {
          statusStr = "Gagal";
          imageStatus = "assets/images/icon-failed.png";
        });
        break;
      case ISTReceiptStatusTabunganInbox.suspect:
        setState(() {
          statusStr = "Sedang diproses";
          imageStatus = "assets/images/icon-warning.png";
        });
        break;

      default:
    }
    return Container();
  }

  List<Widget> _buildItems() {
    List<Widget> ret = [];
    if (widget.items == null || widget.items!.isEmpty) {
      return [];
    }
    for (ISTReceiptItemTabunganInbox item in widget.items!) {
      ret.add(Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Expanded(
              flex: 1,
              child: item.key == null ? const Text("") : Text(item.key!)),
          Expanded(
            flex: 1,
            child: Text(
              item.value == null ? "" : item.value!,
              textAlign: TextAlign.right,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          )
        ],
      ));
      ret.add(const Divider(
        thickness: 1,
      ));
    }
    return ret;
  }

  List<Widget> _generatedList() {
    List<Widget> ret = [];
    if (widget.footer3 == null || widget.footer3!.isEmpty) {
      return [];
    }
    for (ISTReceiptItemTabunganInbox item in widget.footer3!) {
      ret.add(Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          Center(
            child: Text(
              item.value == null ? "" : item.value!,
              textAlign: TextAlign.right,
              style: TextStyle(
                fontWeight: item.value != "Info Penerbangan"
                    ? FontWeight.bold
                    : FontWeight.normal,
              ),
            ),
          )
        ],
      ));
    }
    return ret;
  }

  //yoseph
  // _scrshot() async {
  //   precacheImage(
  //       AssetImage(
  //         imageStatus,
  //       ),
  //       context);
  //   precacheImage(
  //       const AssetImage('assets/images/bank-logo-green.png'), context);
  //   precacheImage(
  //       const AssetImage('assets/images/logo-app-green.png'), context);
  //   precacheImage(const AssetImage('assets/images/icon-success.png'), context);
  //   Map<Permission, PermissionStatus> statuses = await [
  //     Permission.photos,
  //     Permission.storage,
  //     Permission.camera
  //   ].request();
  //   print(statuses);
  //   if (await Permission.storage.request().isGranted &&
  //       await Permission.photos.request().isGranted &&
  //       await Permission.camera.request().isGranted) {
  //     screenshotController
  //         .capture(pixelRatio: 3, delay: const Duration(milliseconds: 10))
  //         .then((image) async {
  //       var save =
  //           await ImageGallerySaver.saveImage(image!, name: "${widget.noRef}");
  //       if (save != null && save.toString().isNotEmpty) {
  //         const DialogBox().showImageDialog(
  //           isError: false,
  //           onOk: () {
  //             Navigator.pop(context);
  //           },
  //           // image: Icon(
  //           //   Icons.camera_alt,
  //           //   color: Pallete.primary,
  //           // ),
  //           title: "Perhatian",
  //           buttonOk: "OK",
  //           context: context,
  //           message: "Berhasil unduh resi",
  //         );
  //       }
  //     }).catchError((onError) {
  //       print(onError);
  //     });
  //   } else {
  //     const DialogBox().showImageDialog(
  //       isError: true,
  //       onOk: () {
  //         Navigator.pop(context);
  //       },
  //       // image: Icon(
  //       //   Icons.camera_alt,
  //       //   color: Pallete.primary,
  //       // ),
  //       title: "Perhatian",
  //       buttonOk: "OK",
  //       context: context,
  //       message: "Gagal unduh resi",
  //     );
  //   }
  // }
  // _scrshot() async {
  //   Map<Permission, PermissionStatus> statuses = await [
  //     Permission.photos,
  //     Permission.storage,
  //     Permission.camera
  //   ].request();
  //   print(statuses);
  //   if (await Permission.storage.request().isGranted ||
  //       await Permission.photos.request().isGranted ||
  //       await Permission.camera.request().isGranted) {
  //     screenshotController
  //         .capture(pixelRatio: 3, delay: Duration(milliseconds: 10))
  //         .then((File image) async {
  //       var save = await ImageGallerySaver.saveImage(image.readAsBytesSync(),
  //           name: "${widget.noref}");
  //       if (save != null && save.toString().isNotEmpty) {
  //         DialogBox().showImageDialog(
  //           isError: false,
  //           onOk: () {
  //             Navigator.pop(context);
  //           },
  //           // image: Icon(
  //           //   Icons.camera_alt,
  //           //   color: Pallete.primary,
  //           // ),
  //           title: "Perhatian",
  //           buttonOk: "OK",
  //           context: context,
  //           message: "Berhasil unduh resi",
  //         );
  //       }
  //     }).catchError((onError) {
  //       print(onError);
  //     });
  //   } else {
  //     DialogBox().showImageDialog(
  //       isError: true,
  //       onOk: () {
  //         Navigator.pop(context);
  //       },
  //       // image: Icon(
  //       //   Icons.camera_alt,
  //       //   color: Pallete.primary,
  //       // ),
  //       title: "Perhatian",
  //       buttonOk: "OK",
  //       context: context,
  //       message: "Gagal unduh resi",
  //     );
  //   }
  // }

  late String noref;
  String _result = "";
  Future<void> _saveImage() async {
    setState(() {
      noref = widget.noRef!;
    });
    bool success = false;
    screenshotController
        .capture(pixelRatio: 3, delay: const Duration(milliseconds: 10))
        .then((image) async {
      print(image);
      print("ini datsssssSSSSSSSSS");
      try {
        success = (await ImageSave.saveImage(
          image,
          "$noref.jpg",
          albumName: "Action Mobile",
        ))!;
      } on PlatformException catch (e, s) {
        print(e);
        print(s);
      }
      setState(() {
        _result = success ? "Save to album success" : "Save to album failed";
        print(_result);
        const DialogBox().showImageDialog(
          isError: false,
          onOk: () {
            Navigator.pop(context);
          },
          // image: Icon(
          //   Icons.camera_alt,
          //   color: Pallete.primary,
          // ),
          title: "Perhatian",
          buttonOk: "OK",
          context: context,
          message: "Resi berhasil di unduh",
        );
        // showDialog(
        //   context: context,
        //   barrierDismissible: false,
        //   useRootNavigator: true,
        //   builder: (BuildContext context) {
        //     return AlertDialog(
        //       // contentPadding: EdgeInsets.all(8),
        //       shape: const RoundedRectangleBorder(
        //         borderRadius: BorderRadius.all(Radius.circular(20.0)),
        //       ),
        //       content: SizedBox(
        //         height: 230,
        //         child: Column(
        //           children: <Widget>[
        //             // SizedBox(
        //             //   height: 2,
        //             // ),

        //             const Text(
        //               'Resi berhasil di unduh',
        //               textAlign: TextAlign.center,
        //               style: TextStyle(
        //                 color: Pallete.primary,
        //               ),
        //             ),
        //             const SizedBox(
        //               height: 16,
        //             ),
        //             Container(
        //               alignment: Alignment.center,
        //               child: Row(
        //                 mainAxisAlignment: MainAxisAlignment.center,
        //                 children: [
        //                   SizedBox(
        //                     width: 120,
        //                     child: OutlineButton(
        //                       onPressed: () {
        //                         Navigator.pop(context);
        //                         setState(() {
        //                           // ss = false;
        //                         });
        //                       },
        //                       borderSide: const BorderSide(
        //                         color: Pallete.primary,
        //                       ),
        //                       splashColor: Pallete.primary,
        //                       shape: const RoundedRectangleBorder(
        //                         borderRadius:
        //                             BorderRadius.all(Radius.circular(18)),
        //                       ),
        //                       child: Text(
        //                         "Selesai",
        //                         style: Theme.of(context)
        //                             .textTheme
        //                             .bodyText1
        //                             ?.copyWith(
        //                                 fontWeight: FontWeight.w600,
        //                                 color: Pallete.primary),
        //                       ),
        //                     ),
        //                   ),
        //                 ],
        //               ),
        //             )
        //           ],
        //         ),
        //       ),
        //       //actions: _checkbutton(context),
        //     );
        //   },
        // );
      });
    });
  }

  Future<String> saveAndShare(Uint8List bytes) async {
    final directory = await getApplicationDocumentsDirectory();
    final image = File('${directory.path}/flutter.png');
    image.writeAsBytesSync(bytes);
    const text = 'Shared From Action Mobile';
    await Share.shareFiles([image.path], text: text);
    return directory.path;
  }

  // _share() async {
  //   precacheImage(
  //       AssetImage(
  //         imageStatus,
  //       ),
  //       context);
  //   precacheImage(const AssetImage('assets/images/bank-logo-green.png'), context);
  //   precacheImage(const AssetImage('assets/images/logo-app-green.png'), context);
  //   precacheImage(const AssetImage('assets/images/icon-success.png'), context);
  //   await [
  //     Permission.photos,
  //     Permission.storage,
  //   ].request();
  //   screenshotController
  //       .capture(pixelRatio: 3, delay: const Duration(milliseconds: 10))
  //       .then((image) async {
  //     await Share.file('${widget.noRef}', '${widget.noRef}.jpg',
  //         image!, 'image/jpg');
  //   });
  // }

  ScreenshotController screenshotController = ScreenshotController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            const SizedBox(height: 8),
            Screenshot(
              controller: screenshotController,
              child: Container(
                color: Colors.white,
                // height: MediaQuery.of(context).size.height * 0.1,
                child: Padding(
                  padding: const EdgeInsets.only(top: 8, bottom: 8),
                  child: Column(
                    children: <Widget>[
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: const <Widget>[
                          Expanded(
                            flex: 1,
                            child: Center(
                              child: Image(
                                image: AssetImage(
                                    'assets/images/bank-logo-green.png'),
                                height: 40,
                              ),
                            ),
                          ),
                          Expanded(
                            flex: 1,
                            child: Center(
                              child: Image(
                                image: AssetImage(
                                    'assets/images/logo-app-green.png'),
                                // color: Pallete.primary,
                                height: 25,
                              ),
                            ),
                          )
                        ],
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'Status Transaksi',
                        style: TextStyle(color: Pallete.primary),
                      ),
                      Center(
                        child: Image(
                          image: AssetImage(widget.status ==
                                  ISTReceiptStatusTabunganInbox.suspect
                              ? "assets/images/icon-warning.png"
                              : widget.status ==
                                      ISTReceiptStatusTabunganInbox.failed
                                  ? "assets/images/icon-failed.png"
                                  : 'assets/images/icon-success.png'),
                          // ||
                          //         widget.status == ISTReceiptStatus.failed
                          //     ? imageStatus
                          //     : 'assets/images/icon-success.png'),
                          height: 100,
                        ),
                      ),
                      // Text(
                      //   widget.status == ISTReceiptStatusTabunganInbox.suspect
                      //       ? "Sedang diproses"
                      //       : widget.status == ISTReceiptStatusTabunganInbox.failed
                      //           ? "Gagal"
                      //           : 'Berhasil',
                      //   style: TextStyle(color: Pallete.primary),
                      // ),
                      Container(
                          child: widget.status ==
                                  ISTReceiptStatusTabunganInbox.suspect
                              ? const Text('Sedang diproses',
                                  style: TextStyle(color: Colors.orange))
                              : widget.status ==
                                      ISTReceiptStatusTabunganInbox.failed
                                  ? const Text('Gagal',
                                      style: TextStyle(color: Colors.red))
                                  : const Text('Berhasil',
                                      style:
                                          TextStyle(color: Pallete.primary))),
                      const SizedBox(height: 8),

                      // ignore: unrelated_type_equality_checks
                      // statusStr == 'Sedang diproses'
                      widget.status == ISTReceiptStatusTabunganInbox.suspect &&
                              widget.titleresi == "Qris Issuer"
                          ? Padding(
                              padding: EdgeInsets.symmetric(
                                  horizontal:
                                      MediaQuery.of(context).size.width * 0.35),
                              child: ISTOutlineButton(
                                color: Pallete.warning,
                                text: 'Cek Status',
                                onPressed: widget.onCheck as void Function()?,
                              ),
                            )
                          : _changeStatus(),
                      const SizedBox(height: 8),
                      // Text(widget.title),
                      widget.title == null
                          ? widget.titleresi == "Qris Issuer"
                              ? Text(
                                  widget.titleresi1!,
                                  textAlign: TextAlign.center,
                                )
                              : Text(
                                  widget.titleresi!,
                                  textAlign: TextAlign.center,
                                )
                          : Text(
                              widget.title!,
                              textAlign: TextAlign.center,
                            ),

                      // widget.titleresi == 'QR Issuer'
                      // ? Text(
                      //  widget.titleresi1,
                      //  textAlign: TextAlign.center,
                      // ) : Text(
                      //   widget.title,
                      //   textAlign: TextAlign.center,
                      // ),
                      Text(
                        widget.amount!,
                        style: TextStyle(
                            fontSize:
                                Theme.of(context).textTheme.headline4!.fontSize,
                            fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(height: 8),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: Column(
                          children: _buildItems(),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: Column(
                          children: _generatedList(),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: widget.footer1,
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: widget.footer2,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            // widget.type != transactionType
            // widget.status == ISTReceiptStatusTabunganInbox.success ||
            //         widget.status == ISTReceiptStatusTabunganInbox.suspect &&
            //             widget.type == 'QRPAYMENT'
            // widget.status == ISTReceiptStatusTabunganInbox.success &&
            //             widget.type == 'QRPAYMENT' ||
            //         widget.status == ISTReceiptStatusTabunganInbox.suspect &&
            widget.titleresi == "Pesawat Garuda Indonesia" ||
                    widget.titleresi == "Kereta Api Indonesia" ||
                    widget.titleresi == "Samsat Aceh" ||
                    widget.titleresi == "e-Setor Pemkot Banda Aceh" ||
                    widget.titleresi == "Universitas Teuku Umar" ||
                    widget.titleresi == "Citilink" ||
                    widget.titleresi == "UIN AR Raniry" ||
                    widget.titleresi == "Lion"
                // widget.titleresi == "Qris Issuer"
                ? Container()
                : widget.titleresi == "Qris Issuer"
                    ? Container()
                    : ISTFlatButton(
                        onPressed: () {
                          const DialogBox().showImageDialog(
                              message:
                                  "Apakah anda yakin akan di simpan ke favorit",
                              buttonOk: 'Setuju',
                              buttonCancel: "Batal",
                              isError: false,
                              image: const Image(
                                image: AssetImage(
                                    'assets/images/icon-warning.png'),
                              ),
                              onOk: widget.onTap as void Function()?,
                              context: context);
                          // ignore: todo
                          //TODO FAVORITE
                        },
                        text: 'Simpan ke favorit',
                        color: Pallete.primary,
                      ),
            const SizedBox(height: 4),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: ISTOutlineButton(
                text: 'Selesai',
                onPressed: widget.onFinished as void Function()?,
              ),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(0),
              width: double.maxFinite,
              height: 50,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: TextButton(
                      onPressed: () {
                        if (_firstPress == true) {
                          _saveImage();
                        }
                        setState(() {
                          _firstPress = false;
                        });
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const <Widget>[
                          Icon(
                            Icons.file_download,
                            color: Pallete.primary,
                          ),
                          SizedBox(width: 4),
                          Text(
                            "Unduh",
                            style: TextStyle(color: Pallete.primary),
                          )
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                    child: TextButton(
                      onPressed: () async {
                        final image = await screenshotController.capture();
                        if (image == null) return;
                        await saveAndShare(image);
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const <Widget>[
                          Icon(
                            Icons.share,
                            color: Pallete.primary,
                          ),
                          SizedBox(width: 4),
                          Text(
                            "Bagikan",
                            style: TextStyle(color: Pallete.primary),
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
