import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/features/other/daftarFavorit/widget/tab_pembayaran.dart';
import 'package:bpd_aceh/features/other/daftarFavorit/widget/tab_pembelian.dart';
import 'package:bpd_aceh/features/other/daftarFavorit/widget/tab_transfer.dart';
import 'package:flutter/material.dart';

enum ISTNotifEnum { notif, inbox }

class ISTListNotif extends StatefulWidget {
  final List<ISTNotifEnum> menu;
  final BuildContext context;
  final Function() callback;

  const ISTListNotif(
      {Key? key,
      required this.menu,
      required this.context,
      required this.callback})
      : super(key: key);
  @override
  _ISTListNotifState createState() => _ISTListNotifState();
}

class _ISTListNotifState extends State<ISTListNotif>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  List<TabTransferFavoriteItem> _listFilteredTransfer = [];
  List<TabTransferFavoriteItem> _listTransfer = [];
  bool loading = false;

  _doInqTransfer() async {
    if (_listTransfer.isEmpty) {
      setState(() {
        loading = true;
      });
    } else {
      setState(() {
        loading = false;
      });
    }
    final resp = await API.postNoLoading(context, '/getfavorite/transfer', {});
    if (resp != null && resp['code'] == 0) {
      var listResp = resp['favoritListDtos'];
      List<dynamic> listRespDyn = (listResp);

      List<TabTransferFavoriteItem> listparam = [];
      // ignore: unnecessary_null_comparison
      if (listRespDyn != null) {
        for (var item in listRespDyn) {
          TabTransferFavoriteItem tf = TabTransferFavoriteItem(
            initial: item['transactionCode'],
            id: item['id'],
            noRek: item['dstAccountNo'],
            nameBank: item['bankName'],
            ownerName: item['dstAccountOwnerName'].toString().isEmpty
                ? "-"
                : item['dstAccountOwnerName'], //Value not in range: 1 #error
            destno: item['dstAccountNo'],
            destcode: item['dstBankCode'],
            callback: (noRek, ownerName, nameBank, destcode, id) {
              _doInqTransfer();
            },
          );
          listparam.add(tf);
        }
      }
      setState(() {
        _listTransfer = listparam;
        _listFilteredTransfer = _listTransfer;
        loading = false;
      });
    }
  }

  List<TabPaymentFavoriteItem> _listFilteredPayment = [];
  List<TabPaymentFavoriteItem> _listPayment = [];
  _doInqPayment() async {
    final resp = await API.postNoLoading(context, '/getfavorite/layanan', {});
    if (resp != null && resp['code'] == 0) {
      var listResp = resp['favoritListDtos'];
      List<dynamic> listRespDyn = (listResp);
      List<TabPaymentFavoriteItem> listparam = [];
      // ignore: unnecessary_null_comparison
      if (listRespDyn != null) {
        //kalo lopping ga bsa nul jd pake!= null
        for (var item in listRespDyn) {
          TabPaymentFavoriteItem tf = TabPaymentFavoriteItem(
            id: item['id'],
            textType: item['nameId'],
            typePayment: "Layanan",
            desc: item['bpCustomerName'],
            noRek: item['dstAccountNo'],
            code: item['transactionCode'],
            kota: item['additionalData'],
            listPBB: item['tranAdditionalData2'],
            callback:
                (noRek, typePayment, desc, id, textType, code, kota, listPBB) {
              _doInqPayment();
            },
          );
          listparam.add(tf);
        }
      }
      setState(() {
        _listPayment = listparam;
        _listFilteredPayment = _listPayment;
      });
    }
  }

  // ignore: unused_field
  List<TabPurchaseFavoriteItem> _listFilteredPurchase = [];
  List<TabPurchaseFavoriteItem> _listPurchase = [];
  // ignore: unused_element
  _doInqPurchase() async {
    final resp = await API.postNoLoading(context, '/getfavorite/purchase', {});
    if (resp != null && resp['code'] == 0) {
      var listResp = resp['favoritListDtos'];
      List<dynamic> listRespDyn = (listResp);
      List<TabPurchaseFavoriteItem> listparam = [];
      // ignore: unnecessary_null_comparison
      if (listRespDyn != null) {
        for (var item in listRespDyn) {
          TabPurchaseFavoriteItem tf = TabPurchaseFavoriteItem(
            id: item['id'],
            typeProvider: item['nameId'],
            textProvider: item['tranAdditionalData1'],
            numberCard: item['dstAccountNo'],
            callback: (typeProvider, textProvider, numberCard, id) {
              _doInqPurchase();
            },
          );
          listparam.add(tf);
        }
      }
      setState(() {
        _listPurchase = listparam;
        _listFilteredPurchase = _listPurchase;
      });
    }
  }

  @override
  void initState() {
    _initFav();

    _doInqTransfer();
    //tambahkan SingleTickerProviderStateMikin pada class _HomeState
    super.initState();
  }

  List<Widget> tabs = [];
  List<Widget> tabsview = [];
  _initFav() {
    List<Widget> _tabsview = [];
    for (ISTNotifEnum item in widget.menu) {
      if (item == ISTNotifEnum.inbox) {
        _doInqTransfer();
        tabs.add(
          const Tab(
            child: Text(
              'Inbox',
              style: TextStyle(
                fontFamily: 'Poppins',
              ),
            ),
            // text: "Transfer",
          ),
        );
        _tabsview.add(_buildInbox());
      }
      if (item == ISTNotifEnum.notif) {
        _doInqPayment();
        tabs.add(
          const Tab(
            child: Text(
              'Informasi Terkini',
              style: TextStyle(
                fontFamily: 'Poppins',
              ),
            ),
            // text: "Transfer",
          ),
        );
        _tabsview.add(_buildNotif());
      }
    }
    setState(() {
      tabsview = _tabsview;
    });
    _tabController = TabController(vsync: this, length: widget.menu.length);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  // List<ISTAvatarList> _listFilteredPurchases = [];

  late TabController controller;
  final TextEditingController _search = TextEditingController();
  int _tabindex = 0;
  String _searchText = "";
  Icon _searchIcon = const Icon(
    Icons.search,
    color: Colors.white,
  );
  Widget _appBarTitle = const Text(
    'Informasi',
    style: TextStyle(
        fontFamily: 'Poppins',
        //fontWeight: FontWeight.bold,
        color: Colors.white
        // fontSize: FontSize.TITLE,
        ),
  );

  void _searchPressed() {
    setState(() {
      if (_searchIcon.icon == Icons.search) {
        _searchIcon = const Icon(
          Icons.close,
          color: Colors.white,
        );
        _appBarTitle = TextField(
            style: const TextStyle(
              color: Colors.white,
              fontFamily: 'Poppins',
            ),
            autofocus: true,
            controller: _search,
            onChanged: (text) {
              setState(() {
                _searchText = text;
              });
            },
            decoration: const InputDecoration(
                border: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.white)),
                // prefixIcon: Icon(Icons.search),
                hintText: 'Cari Daftar Favorit...',
                hintStyle: TextStyle(
                  color: Colors.white,
                  fontSize: 13,
                  fontFamily: 'Poppins',
                )));
      } else {
        _searchIcon = const Icon(
          Icons.search,
          color: Colors.white,
        );
        _appBarTitle = const Text(
          // 'Hapus Daftar Favorit',
          'Daftar Favorit',
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'Poppins',
          ),
        );
        _searchText = "";
        _search.clear();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    List<Widget> tabsviews = [
      if (widget.menu.contains(ISTNotifEnum.inbox)) _buildInbox(),
      if (widget.menu.contains(ISTNotifEnum.notif)) _buildNotif(),
    ];
    // if (widget.menu.contains(ISTNotifEnum.transfer) ) {
    //   _doInqTransfer();
    //   tabs.add(
    //     Tab(
    //       text: "Transfer",
    //     ),
    //   );
    //   tabsviews.add(_buildListTransfer());
    // }if (widget.menu.contains(ISTNotifEnum.pembayaran)) {
    //   _doInqPayment();
    //   tabs.add(
    //     Tab(
    //       text: "Pembayaran",
    //     ),
    //   );
    // }
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Pallete.primary,
        centerTitle: true,
        title: _appBarTitle,
        leading: IconButton(
            color: Colors.white,
            icon: const Icon(Icons.arrow_back_ios),
            onPressed: () {
              Navigator.pop(context);
            }),
        actions: <Widget>[
          IconButton(
            icon: _searchIcon,
            onPressed: _searchPressed,
          ),
        ],
      ),
      body: loading
          ? Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.only(top: 16),
              child: CircularProgressIndicator(
                backgroundColor: Colors.grey[350],
                strokeWidth: 3,
                valueColor: const AlwaysStoppedAnimation<Color>(Pallete.primary),
                // valueColor:
                //     new AlwaysStoppedAnimation<Color>(Colors.red),
                // //   child: Container(
                // //   color: Colors.grey[300],
                // //   height: 100,
                // //   width: 100,
                // // )
              ),
            )
          : Column(
              children: <Widget>[
                const SizedBox(
                  height: 8,
                ),
                SizedBox(
                    height: 30,
                    child: DefaultTabController(
                        length: widget.menu.length,
                        initialIndex: _tabindex,
                        child: Material(
                            color: Colors.transparent,
                            child: TabBar(
                                unselectedLabelStyle: const TextStyle(
                                    fontWeight: FontWeight.normal,
                                    color: Colors.black54),
                                labelStyle:
                                    const TextStyle(fontWeight: FontWeight.bold),
                                labelColor: Pallete.primary,
                                unselectedLabelColor: Colors.black54,
                                // labelPadding: EdgeInsets.symmetric(vertical: 8),
                                indicatorColor: Colors.white,
                                controller: _tabController,
                                onTap: (index) {
                                  setState(() {
                                    _tabindex = index;
                                  });
                                },
                                tabs: tabs

                                // Tab(
                                //   text: "Transfer",
                                // ),
                                // Tab(
                                //   text: "Pembelian",
                                // ),
                                // Tab(
                                //   text: "Pembayaran",
                                // ),
                                )))),

                // SizedBox(height: 8,),
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 8.0),
                  child: Divider(
                    height: 2,
                    color: Pallete.primary,
                  ),
                ),
                Expanded(
                    child: TabBarView(
                        controller: _tabController,
                        children: [for (Widget item in tabsviews) item]
                        //
                        // tabsview
                        // // tabs
                        // [
                        //  _buildListTransfer(),
                        //   _buildpayment()
                        //  ]
                        ))
              ],
            ),
    );
  }

  _buildNotif() {
    if (!widget.menu.contains(ISTNotifEnum.notif)) return;

    if (_searchText.isNotEmpty) {
      List<TabPaymentFavoriteItem> tempList = [];
      for (TabPaymentFavoriteItem item in _listFilteredPayment) {
        if (item.textType != null || item.noRek != null) {
          if (item.textType!
                  .toLowerCase()
                  .contains(_searchText.toLowerCase()) ||
              item.noRek!.toLowerCase().contains(_searchText.toLowerCase())) {
            tempList.add(item);
          }
        }
      }
      _listFilteredPayment = tempList;
    } else {
      _listFilteredPayment = _listPayment;
    }
    if (_listPayment.isEmpty) {
      return const Center(
          child: Text(
        'Anda belum menambahkan favorit',
        style: TextStyle(color: Colors.grey),
      ));
    } else {
      return ListView.separated(
          itemBuilder: (context, index) {
            return _listFilteredPayment[index];
          },
          separatorBuilder: (context, inx) {
            return Container();
          },
          // ignore: unnecessary_null_comparison
          itemCount: _listPayment == null ? 0 : _listFilteredPayment.length);
    }
  }

  _buildInbox() {
    if (!widget.menu.contains(ISTNotifEnum.inbox)) return;

    // ignore: unnecessary_null_comparison
    if (_searchText.isNotEmpty || _searchText == null) {
      List<TabTransferFavoriteItem> tempList = [];
      for (var item in _listFilteredTransfer) {
        if (item.ownerName != null ||
            item.nameBank != null ||
            item.noRek != null) {
          if (item.ownerName!
                  .toLowerCase()
                  .contains(_searchText.toLowerCase()) ||
              item.nameBank!
                  .toLowerCase()
                  .contains(_searchText.toLowerCase()) ||
              item.noRek!.toLowerCase().contains(_searchText.toLowerCase())) {
            tempList.add(item);
          }
        }
      }

      // tempList.add(item);
      _listFilteredTransfer = tempList;
    } else {
      _listFilteredTransfer = _listTransfer;
    }
    if (_listTransfer.isEmpty) {
      return const Center(
          child: Text(
        'Anda belum menambahkan favorit',
        style: TextStyle(color: Colors.grey),
      ));
    } else {
      return ListView.separated(
          itemBuilder: (context, index) {
            // ignore: unused_local_variable
            final item = _listFilteredTransfer[index];
            return _listFilteredTransfer[index];
          },
          separatorBuilder: (context, inx) {
            return Container();
          },
          // ignore: unnecessary_null_comparison
          itemCount: _listTransfer == null ? 0 : _listFilteredTransfer.length);
      //  return Column(
      //    children: _listPayment,
      //  );
    }
  }
}

// ignore: unused_element
_buildMenuFav(menu) {
  switch (menu) {
    case ISTNotifEnum.inbox:
      return const Image(
        image: AssetImage('assets/images/icon-qr.png'),
        color: Pallete.primary,
      );
    case ISTNotifEnum.notif:
      return const Image(
        image: AssetImage('assets/images/icon-qr.png'),
        color: Pallete.primary,
      );
      // ignore: dead_code
      break;

    default:
  }
}
