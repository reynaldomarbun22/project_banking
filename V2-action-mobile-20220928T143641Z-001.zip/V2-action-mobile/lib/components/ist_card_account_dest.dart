import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/features/other/rekeningku/pengaturanRekening/page/ist_list_rek.dart';
import 'package:bpd_aceh/features/other/rekeningku/penutupanRekening/confirm_penutupan_rek.dart';
import 'package:flutter/material.dart';

class ISTCardAccountDestItem extends StatefulWidget {
  const ISTCardAccountDestItem({
    Key? key,
    this.index,
    this.isPrimary,
    this.accountBalance,
    this.accountType,
    this.accountNumber,
    this.accountName,
    this.callback,
    this.callback2,
  }) : super(key: key);
  final bool? isPrimary;
  final String? accountBalance;
  final String? accountType;
  final String? accountNumber;
  final String? accountName;
  final Function? callback2;
  final int? index;

  final Function(String accountBalance, String accountType,
      String accountNumber, String accountName)? callback;

  @override
  _ISTCardAccountDestItemState createState() => _ISTCardAccountDestItemState();
}

class _ISTCardAccountDestItemState extends State<ISTCardAccountDestItem> {
  String? accNo;

  void showAccountTabungan2({
    required BuildContext context,
    List<ISTCardAccountTujuanItem>? list,
    List<ISTListRek>? listRek,
  }) {
    showDialog(
        context: context,
        barrierDismissible: true,
        builder: (context) {
          return Center(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Colors.white,
              ),
              height: MediaQuery.of(context).size.height * 0.7,
              width: MediaQuery.of(context).size.width * 0.8,
              child: Scaffold(
                  body: Column(children: <Widget>[
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.7 - 52,
                  // child: SingleChildScrollView(
                  child: Center(
                    child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    const SizedBox(height: 16),
                    const Image(
                      image: AssetImage('assets/images/rek.png'),
                      // color: Pallete.primary,
                      width: 70,
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      "Pilih Rekening Pencairan",
                      style: TextStyle(
                          color: Pallete.primary,
                          fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    // Text('Silakan pilih rekening',
                    //     style: TextStyle(color: Pallete.primary)),
                    // Text('untuk dijadikan rekening utama',
                    //     style: TextStyle(color: Pallete.primary)),
                    const SizedBox(height: 8),
//sadasdas
                    Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12.0,
                        ),
                        child: SizedBox(
                          height: MediaQuery.of(context).size.height * 0.7 -
                              187,
                          child: SingleChildScrollView(
                              child: Column(children: list!)),
                        )),
                    //asdasdas
                  ],
                    ),
                    // ),
                  ),
                ),
                const Spacer(),
                const SizedBox(
                  height: 8,
                ),
                ISTFlatButton(
                  onPressed: () {
                Navigator.pop(context);
                  },
                  text: 'Tutup',
                  color: Pallete.primary,
                )
              ])),
            ),
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    _doSetDefaultRek() async {
      Map<String, Object?> param = {};
      param['accNo'] = widget.accountNumber;
      final resp = await API.post(context, '/penutupan-rek/list', param);
      if (resp != null && resp['code'] == 0) {
        var listResp = resp['accountList'];
        List<dynamic> listRespDyn = (listResp);
        List<ISTCardAccountTujuanItem> listParam2 = [];
        // ignore: unused_local_variable
        List<ISTListRek> listParamss = [];

        for (var i = 0; i < listRespDyn.length; i++) {
          ISTCardAccountTujuanItem cardItem = ISTCardAccountTujuanItem(
            accountBalance: listRespDyn[i]['accountBalance'], //
            accountName: listRespDyn[i]['accountOwnerName'],
            accountNumberTujuan: listRespDyn[i]['accountNo'], //
            accountType: listRespDyn[i]['accountProductName'], //
            isPrimary: listRespDyn[i]['accountDefault'],
            index: i,
            callback:
                (accountBalance, accountType, accountNumber, accountName) {
              // Navigator.push(context);
              // Navigator.pushReplacement(
              //     context,
              //     new MaterialPageRoute(
              //         builder: (context) => new PembukaanTabungan(
              //               name: accountName,
              //             )));
              setState(() {
                accNo = accountNumber;
              });
              if (widget.callback != null) {
                widget.callback!(accountBalance!, accountName!, accountNumber!,
                    accountType!);
              }
            },
          );

          listParam2.add(cardItem);
        }
        showAccountTabungan2(
          context: context,
          list: listParam2,
        );
      }
    }

    return Card(
      color: widget.isPrimary! ? Pallete.primary : Colors.white,
      child: InkWell(
        onTap: () {
          _doSetDefaultRek();
        },
        child: Container(
          padding: const EdgeInsets.all(8),
          child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: <Widget>[
                      Text(
                        widget.accountBalance!,
                        style: TextStyle(
                            color: !widget.isPrimary!
                                ? Pallete.primary
                                : Colors.white,
                            fontWeight: FontWeight.bold),
                      ),
                      Text(widget.accountType!,
                          style: TextStyle(
                              color: !widget.isPrimary!
                                  ? Pallete.primary
                                  : Colors.white)),
                      Text(widget.accountNumber!,
                          style: TextStyle(
                              color: !widget.isPrimary!
                                  ? Pallete.primary
                                  : Colors.white)),
                      Text(widget.accountName!,
                          style: TextStyle(
                              color: !widget.isPrimary!
                                  ? Pallete.primary
                                  : Colors.white)),
                    ],
                  ),
                ),
              ]),
        ),
      ),
    );
  }
}

class ISTCardAccountTujuanItem extends StatelessWidget {
  const ISTCardAccountTujuanItem({
    Key? key,
    this.index,
    this.isPrimary,
    this.accountBalance,
    this.accountType,
    this.accountNumberTujuan,
    this.accountName,
    this.callback,
  }) : super(key: key);
  final bool? isPrimary;
  final String? accountBalance;
  final String? accountType;
  final String? accountNumberTujuan;
  final String? accountName;
  final int? index;

  final Function(String? accountBalance, String? accountType,
      String? accountNumberTujuan, String? accountName)? callback;

  @override
  Widget build(BuildContext context) {
    _doSetDefaultRek() async {
      callback!(accountBalance, accountType, accountNumberTujuan,
          accountName);
      Map<String, Object?> param = {};
      param['amount'] = accountBalance;
      param['dstAccNo'] = accountNumberTujuan;
      final resp =
          await API.postNoLoading(context, '/penutupan-rek/inquiry', param);
      if (resp['code'] == 0) {
        List<ISTConfirmationItem> listParam = [];
        List<dynamic> listMap = resp['resi'];
        for (var item in listMap) {
          ISTConfirmationItem itemParam =
              ISTConfirmationItem(key: item['key'], value: item['value']);
          listParam.add(itemParam);
        }
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => ConfirmationPenutupanRek(
                      list: listParam,
                    )));
      } else {
        const DialogBox().showImageDialog(
            message: resp['message'],
            isError: true,
            image: const Image(
              image: AssetImage('assets/images/icon-failed.png'),
            ),
            buttonCancel: 'OK',
            onOk: () {},
            context: context);
      }
    }

    return Card(
      color: isPrimary! ? Pallete.primary : Colors.white,
      child: InkWell(
        onTap: () {
          _doSetDefaultRek();

          // isPrimary
          //     ? Container()
          //     : DialogBox().showImageDialog(
          //         // title: '',
          //         message: "Apakah anda yakin",
          //         buttonOk: 'Setuju',
          //         buttonCancel: "Batal",
          //         isError: false,
          //         image: Image(
          //           image: AssetImage('assets/images/icon-warning.png'),
          //         ),
          //         onOk: () {
          //           _doSetDefaultRek();
          //         },
          //         context: context);
        },
        child: Container(
          padding: const EdgeInsets.all(8),
          child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: <
              Widget>[
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  Text(
                    accountBalance!,
                    style: TextStyle(
                        color: !isPrimary! ? Pallete.primary : Colors.white,
                        fontWeight: FontWeight.bold),
                  ),
                  Text(accountType!,
                      style: TextStyle(
                          color: !isPrimary! ? Pallete.primary : Colors.white)),
                  Text(accountNumberTujuan!,
                      style: TextStyle(
                          color: !isPrimary! ? Pallete.primary : Colors.white)),
                  Text(accountName!,
                      style: TextStyle(
                          color: !isPrimary! ? Pallete.primary : Colors.white)),
                ],
              ),
            ),
          ]),
        ),
      ),
    );
  }
}

class ISTCardAccountTabunganItem extends StatelessWidget {
  const ISTCardAccountTabunganItem({
    Key? key,
    this.index,
    this.isPrimary,
    this.accountBalance,
    this.accountType,
    this.accountNumber,
    this.accountName,
    this.callback,
  }) : super(key: key);
  final bool? isPrimary;
  final String? accountBalance;
  final String? accountType;
  final String? accountNumber;
  final String? accountName;
  final int? index;

  final Function(String? accountBalance, String? accountType,
      String? accountNumber, String? accountName)? callback;

  @override
  Widget build(BuildContext context) {
    _doSetDefaultRek() async {
      // callback(this.accountBalance, this.accountType, this.accountNumber,
      //     this.accountName);
      callback!(accountBalance, accountType, accountNumber,
          accountName);
      // Navigator.pushReplacement(
      //     context,
      //     new MaterialPageRoute(
      //         builder: (context) => new PembukaanTabungan(
      //               rekening: accountName,
      //             )));
      Navigator.pop(context);
    }

    return Card(
      color: isPrimary! ? Pallete.primary : Colors.white,
      child: InkWell(
        onTap: () {
          _doSetDefaultRek();

          // isPrimary
          //     ? Container()
          //     : DialogBox().showImageDialog(
          //         // title: '',
          //         message: "Apakah anda yakin",
          //         buttonOk: 'Setuju',
          //         buttonCancel: "Batal",
          //         isError: false,
          //         image: Image(
          //           image: AssetImage('assets/images/icon-warning.png'),
          //         ),
          //         onOk: () {
          //           _doSetDefaultRek();
          //         },
          //         context: context);
        },
        child: Container(
          padding: const EdgeInsets.all(8),
          child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: <
              Widget>[
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  Text(
                    accountBalance!,
                    style: TextStyle(
                        color: !isPrimary! ? Pallete.primary : Colors.white,
                        fontWeight: FontWeight.bold),
                  ),
                  Text(accountType!,
                      style: TextStyle(
                          color: !isPrimary! ? Pallete.primary : Colors.white)),
                  Text(accountNumber!,
                      style: TextStyle(
                          color: !isPrimary! ? Pallete.primary : Colors.white)),
                  Text(accountName!,
                      style: TextStyle(
                          color: !isPrimary! ? Pallete.primary : Colors.white)),
                ],
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
