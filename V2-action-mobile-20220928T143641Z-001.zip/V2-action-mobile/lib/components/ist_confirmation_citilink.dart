import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:flutter/material.dart';

class ISTConfirmationItem1 {
  final String? key;
  final String? value;
  ISTConfirmationItem1({this.key, this.value});
}

class ISTConfirmationCitilink extends StatelessWidget {
  const ISTConfirmationCitilink({
    Key? key,
    required this.items,
    required this.title,
    required this.onFinished,
    this.items1,
  }) : super(key: key);

  final String title;
  final List<ISTConfirmationItem1>? items;
  final Function onFinished;
  final List<ISTConfirmationItem1>? items1;

  List<Widget> _buildItems() {
    List<Widget> ret = [];
    if (items == null || items!.isEmpty) {
      return [];
    }

    for (ISTConfirmationItem1 item in items!) {
      ret.add(Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Expanded(flex: 1, child: Text(item.key!)),
          Expanded(
            flex: 1,
            child: Text(
              item.value!,
              textAlign: TextAlign.right,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontFamily: 'Poppins',
              ),
            ),
          )
        ],
      ));
      ret.add(const Divider(
        thickness: 1,
      ));
    }
    for (ISTConfirmationItem1 itemData in items1!) {
      ret.add(Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text(
            itemData.value!,
            style: TextStyle(
              fontWeight: itemData.value != "Info Penerbangan"
                  ? FontWeight.bold
                  : FontWeight.normal,
              fontFamily: 'Poppins',
            ),
          ),
        ],
      ));
    }
    return ret;
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: <Widget>[
        const SizedBox(height: 16),
        Center(child: Text(title)),
        const SizedBox(height: 16),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
                border: Border.all(
                  color:
                      _buildItems().isNotEmpty ? Pallete.primary : Colors.white,
                  width: 0.5,
                ),
                borderRadius: BorderRadius.circular(10)),
            child: Column(
              children: _buildItems(),
            ),
          ),
        ),
        const SizedBox(height: 16),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: ISTOutlineButton(
            text: 'Lanjut',
            onPressed: onFinished as void Function()?,
          ),
        )
      ],
    );
  }
}
