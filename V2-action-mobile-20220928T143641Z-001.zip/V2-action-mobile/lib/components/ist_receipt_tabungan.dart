import 'dart:convert';
import 'dart:typed_data';

import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/utils/string_utils.dart';
// import 'package:esys_flutter_share/esys_flutter_share.dart';
// import 'package:modern_form_esys_flutter_share/modern_form_esys_flutter_share.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_save/image_save.dart';
import 'package:screenshot/screenshot.dart';

enum ISTReceiptStatusTabungan { success, failed, suspect }

class ISTReceiptItemTabungan {
  final String? key;
  final String? value;

  ISTReceiptItemTabungan({this.key, this.value});
}

class ISTReceiptTabungan extends StatefulWidget {
  const ISTReceiptTabungan({
    Key? key,
    required this.items,
    required this.onFinished,
    this.onCheck,
    this.onTap,
    this.id,
    required this.title,
    required this.type,
    this.idresi,
    required this.date,
    required this.detail,
    this.time,
    required this.amount,
    required this.status,
    // @required this.imgTab,
    this.resiItem,
    this.footer1,
    this.imgTab,
    this.titleimg,
    this.footer2,
    this.noref,
    this.addInfoImg,
  }) : super(key: key);
  final String? noref;
  final String? title;
  final int? id;
  final String? idresi;
  final String? amount;
  final String? addInfoImg;
  final List<ISTReceiptItemTabungan>? items;
  final List<ISTReceiptItemTabungan>? resiItem;
  final Function onFinished;
  final Function? onCheck;
  final Function? onTap;
  final String? imgTab;
  final ISTReceiptStatusTabungan status;
  final String type;
  final String? detail;
  final String? time;
  final String? date;
  final String? titleimg;
  final Widget? footer1;
  final Widget? footer2;

  // final ISTReceipt data;
  // const ISTReceipt({Key key, @required this.data}) : super(key: key);

  @override
  _ISTReceiptTabunganState createState() => _ISTReceiptTabunganState();
}

class _ISTReceiptTabunganState extends State<ISTReceiptTabungan> {
  String statusStr = "";
  String imageStatus = "";
  late Uint8List _imageTabungan;
  bool isLoading = false;
  bool isSuccess = false;
  // _saveinbox() async {
  //   Inbox(itemss: widget.items);
  //   InboxDBRepository repo = InboxDBRepository();
  //   await repo.open();
  //   InboxModel model = InboxModel();
  //   model.amount = widget.amount;
  //   model.status = widget.status.index.toString();
  //   model.title = widget.title;
  //   model.date =widget.date;
  //   var img = widget.type;
  //   var imgasset = "";
  //   if (img == 'PAYMENT_ZAKAT') {
  //     imgasset = 'assets/images/icon-wallet.png';
  //   } else if (img == 'TFBAS') {
  //     imgasset = 'assets/images/icon-wallet.png';
  //   }
  //   model.image = imgasset;
  //   await repo.insert(model);
  //   await repo.close();
  // }

  @override
  void initState() {
    switch (widget.status) {
      case ISTReceiptStatusTabungan.success:
        setState(() {
          statusStr = "Berhasil";
          imageStatus = "assets/images/icon-success.png";
        });
        break;
      case ISTReceiptStatusTabungan.failed:
        setState(() {
          statusStr = "Gagal";
          imageStatus = "assets/images/icon-failed.png";
        });
        break;
      case ISTReceiptStatusTabungan.suspect:
        setState(() {
          statusStr = "Sedang diproses";
          imageStatus = "assets/images/icon-warning.png";
        });
        break;

      default:
    }
    _imageTabungan = const Base64Decoder().convert(widget.imgTab!);

    // _saveinbox();
    super.initState();
    print(widget.imgTab);

    print(widget.status);
  }

  _changeStatus() {
    switch (widget.status) {
      case ISTReceiptStatusTabungan.success:
        setState(() {
          isSuccess = true;
          statusStr = "Berhasil";
          imageStatus = "assets/images/icon-success.png";
        });
        break;
      case ISTReceiptStatusTabungan.failed:
        setState(() {
          statusStr = "Gagal";
          imageStatus = "assets/images/icon-failed.png";
        });
        break;
      case ISTReceiptStatusTabungan.suspect:
        setState(() {
          statusStr = "Sedang diproses";
          imageStatus = "assets/images/icon-warning.png";
        });
        break;

      default:
    }
    return Container();
  }

  List<Widget> _buildItems() {
    List<Widget> ret = [];
    if (widget.items == null || widget.items!.isEmpty) {
      return [];
    }
    for (ISTReceiptItemTabungan item in widget.items!) {
      ret.add(Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Text(item.key!),
          Text(
            item.value!,
            textAlign: TextAlign.right,
            style: const TextStyle(fontWeight: FontWeight.bold),
          )
        ],
      ));
      ret.add(const Divider(
        thickness: 1,
      ));
    }
    return ret;
  }

  List<Widget> _buildResiItems() {
    List<Widget> ret = [];
    if (widget.resiItem == null || widget.resiItem!.isEmpty) {
      return [];
    }
    for (ISTReceiptItemTabungan item in widget.resiItem!) {
      ret.add(Column(children: [
        Padding(
          padding: const EdgeInsets.only(right: 16),
          child: Row(
            // mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              SizedBox(
                  height: 16,
                  width: 100,
                  child: Text(
                    item.key!,
                    style: const TextStyle(fontSize: 12),
                  )),
              const SizedBox(
                  width: 8,
                  height: 16,
                  child: Text(
                    ' :',
                    style: TextStyle(fontSize: 12),
                  )),
              Container(
                alignment: Alignment.topLeft,
                height: 16,
                width: 150,
                // flex: 1,
                child: Text(
                  item.value!,
                  textAlign: TextAlign.right,
                  style: const TextStyle(fontSize: 12),
                ),
              )
            ],
          ),
        )
      ]));

      // ret.add(Divider(
      //   thickness: 12,
      // ));
    }
    return ret;
  }

  //yoseph
  // _scrshot() async {
  //   Map<Permission, PermissionStatus> statuses = await [
  //     Permission.photos,
  //     Permission.storage,
  //     Permission.camera
  //   ].request();
  //   print(statuses);
  //   if (await Permission.storage.request().isGranted &&
  //       await Permission.photos.request().isGranted &&
  //       await Permission.camera.request().isGranted) {
  //     screenshotController
  //         .capture(pixelRatio: 3, delay: const Duration(milliseconds: 10))
  //         .then((image) async {
  //       var save = await ImageGallerySaver.saveImage(
  //         image!,  name: "${widget.date}"
  //       );
  //       if (save != null && save.toString().isNotEmpty) {
  //         const DialogBox().showImageDialog(
  //           isError: false,
  //           onOk: () {
  //             Navigator.pop(context);
  //           },
  //           // image: Icon(
  //           //   Icons.camera_alt,
  //           //   color: Pallete.primary,
  //           // ),
  //           title: "Perhatian",
  //           buttonOk: "OK",
  //           context: context,
  //           message: "Berhasil unduh resi",
  //         );
  //       }
  //     }).catchError((onError) {
  //       print(onError);
  //     });
  //   } else {
  //     const DialogBox().showImageDialog(
  //       isError: true,
  //       onOk: () {
  //         Navigator.pop(context);
  //       },
  //       // image: Icon(
  //       //   Icons.camera_alt,
  //       //   color: Pallete.primary,
  //       // ),
  //       title: "Perhatian",
  //       buttonOk: "OK",
  //       context: context,
  //       message: "Gagal unduh resi",
  //     );
  //   }
  // }

  // _share() async {
  //   await [
  //     Permission.photos,
  //     Permission.storage,
  //   ].request();
  //   screenshotController
  //       .capture(
  //     pixelRatio: 3,
  //   )
  //       .then((image) async {
  //     await Share.file(
  //         '${widget.amount}${widget.title}',
  //         '${widget.amount}${widget.title}.jpg',
  //         image!,
  //         'image/jpg');
  //   });
  // }

  late String noref;
  String _result = "";
  Future<void> _saveImage() async {
    setState(() {
      noref = widget.noref!;
    });
    bool success = false;
    screenshotController
        .capture(pixelRatio: 3, delay: const Duration(milliseconds: 10))
        .then((image) async {
      print(image);
      print("ini datsssssSSSSSSSSS");
      try {
        success = (await ImageSave.saveImage(
          image,
          "$noref.jpg",
          albumName: "Action Mobile",
        ))!;
      } on PlatformException catch (e, s) {
        print(e);
        print(s);
      }
      setState(() {
        _result = success ? "Save to album success" : "Save to album failed";
        print(_result);
        const DialogBox().showImageDialog(
          isError: false,
          onOk: () {
            Navigator.pop(context);
          },
          // image: Icon(
          //   Icons.camera_alt,
          //   color: Pallete.primary,
          // ),
          title: "Perhatian",
          buttonOk: "OK",
          context: context,
          message: "Resi berhasil di unduh",
        );
        // showDialog(
        //   context: context,
        //   barrierDismissible: false,
        //   useRootNavigator: true,
        //   builder: (BuildContext context) {
        //     return AlertDialog(
        //       // contentPadding: EdgeInsets.all(8),
        //       shape: const RoundedRectangleBorder(
        //         borderRadius: BorderRadius.all(Radius.circular(20.0)),
        //       ),
        //       content: SizedBox(
        //         height: 230,
        //         child: Column(
        //           children: <Widget>[
        //             // SizedBox(
        //             //   height: 2,
        //             // ),

        //             const Text(
        //               'Resi berhasil di unduh',
        //               textAlign: TextAlign.center,
        //               style: TextStyle(
        //                 color: Pallete.primary,
        //               ),
        //             ),
        //             const SizedBox(
        //               height: 16,
        //             ),
        //             Container(
        //               alignment: Alignment.center,
        //               child: Row(
        //                 mainAxisAlignment: MainAxisAlignment.center,
        //                 children: [
        //                   SizedBox(
        //                     width: 120,
        //                     child: OutlineButton(
        //                       onPressed: () {
        //                         Navigator.pop(context);
        //                         setState(() {
        //                           // ss = false;
        //                         });
        //                       },
        //                       borderSide: const BorderSide(
        //                         color: Pallete.primary,
        //                       ),
        //                       splashColor: Pallete.primary,
        //                       shape: const RoundedRectangleBorder(
        //                         borderRadius:
        //                             BorderRadius.all(Radius.circular(18)),
        //                       ),
        //                       child: Text(
        //                         "Selesai",
        //                         style: Theme.of(context)
        //                             .textTheme
        //                             .bodyText1
        //                             ?.copyWith(
        //                                 fontWeight: FontWeight.w600,
        //                                 color: Pallete.primary),
        //                       ),
        //                     ),
        //                   ),
        //                 ],
        //               ),
        //             )
        //           ],
        //         ),
        //       ),
        //       //actions: _checkbutton(context),
        //     );
        //   },
        // );
      });
    });
  }

  ScreenshotController screenshotController = ScreenshotController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            const SizedBox(height: 8),
            Screenshot(
              controller: screenshotController,
              child: Container(
                color: Colors.white,
                // height: MediaQuery.of(context).size.height * 0.1,
                child: Padding(
                  padding: const EdgeInsets.only(top: 8, bottom: 8),
                  child: Column(
                    children: <Widget>[
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: const <Widget>[
                          Center(
                            child: Image(
                              image: AssetImage(
                                  'assets/images/bank-logo-green.png'),
                              height: 40,
                            ),
                          ),
                          Center(
                            child: Image(
                              image: AssetImage(
                                  'assets/images/logo-app-green.png'),
                              // color: Pallete.primary,
                              height: 25,
                            ),
                          )
                        ],
                      ),
                      const SizedBox(height: 16),
                      Container(
                        alignment: Alignment.center,
                        child: const Text(
                          'PEMBUATAN REKENING BARU',
                          style: TextStyle(
                              color: Pallete.primary,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                      Container(
                        alignment: Alignment.center,
                        child: const Text(
                          'BERHASIL DILAKUKAN',
                          style: TextStyle(
                              color: Pallete.primary,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                      // Center(
                      //   child: new Image.memory(_imageTabungan),
                      // ),
                      const SizedBox(height: 16),

                      Container(
                        padding: const EdgeInsets.only(left: 8, right: 8),
                        child: Stack(
                            alignment: Alignment.bottomCenter,
                            children: <Widget>[
                              Container(
                                alignment: Alignment.center,
                                child: Image.memory(_imageTabungan),
                              ),
                              Column(children: <Widget>[
                                Container(
                                  alignment: Alignment.center,
                                  child: Text(
                                    StringUtils.getValueAsString(
                                        widget.titleimg!),
                                    style: const TextStyle(
                                      fontSize: 12,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                                const SizedBox(
                                  height: 8,
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(
                                      left: 16.0, right: 16, bottom: 16),
                                  child: Column(
                                    children: _buildResiItems(),
                                  ),
                                ),
                                Container(
                                    padding: const EdgeInsets.only(bottom: 8),
                                    alignment: Alignment.bottomLeft,
                                    // padding: const EdgeInsets.all(16),
                                    child: Text(
                                      StringUtils.getValueAsString(
                                          widget.addInfoImg!),
                                      style: const TextStyle(
                                        fontSize: 6,
                                      ),
                                    ))
                              ]),
                            ]),
                      ),

                      const SizedBox(height: 8),
                      widget.status == ISTReceiptStatusTabungan.suspect &&
                              widget.type == 'QRPAYMENT'
                          ? Padding(
                              padding: EdgeInsets.symmetric(
                                  horizontal:
                                      MediaQuery.of(context).size.width * 0.35),
                              child: ISTOutlineButton(
                                color: Pallete.warning,
                                text: 'Cek Status',
                                onPressed:
                                    // _cekStatusQR();
                                    // ignore: unnecessary_statements
                                    widget.onCheck as void Function()?,
                              ),
                            )
                          : _changeStatus(),
                      // FlatButton(
                      //     onPressed: null,
                      //     child: Text(
                      //       "Cek Status",
                      //       style: TextStyle(color: Pallete.WARNING),
                      //     )),
                      const SizedBox(height: 8),
                      Container(
                        alignment: Alignment.center,
                        child: const Text(
                          'BUKTI SETORAN AWAL',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: Pallete.primary,
                              fontWeight: FontWeight.bold,
                              fontSize: 16),
                        ),
                      ),
                      // Text(
                      //   widget.amount,
                      //   style: TextStyle(
                      //       fontSize:
                      //           Theme.of(context).textTheme.headline4.fontSize,
                      //       fontWeight: FontWeight.w600),
                      // ),
                      const SizedBox(height: 8),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: Column(
                          children: _buildItems(),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: widget.footer1,
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: widget.footer2,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            // widget.type == 'QRPAYMENT'
            //     ? Container()
            //     : ISTFlatButton(
            //         onPressed: () {
            //           DialogBox().showImageDialog(
            //               message:
            //                   "Apakah anda yakin akan di simpan ke favorit",
            //               buttonOk: 'Setuju',
            //               buttonCancel: "Batal",
            //               isError: false,
            //               image: Image(
            //                 image: AssetImage('assets/images/icon-warning.png'),
            //               ),
            //               onOk: widget.onTap,
            //               context: context);
            //         },
            //         text: 'Simpan ke favorit',
            //         color: Pallete.primary,
            //       ),
            // SizedBox(height: 4),
            // widget.status == ISTReceiptStatus.suspect &&
            //         widget.type == 'QRPAYMENT'
            //     ? Container()
            Container(
              padding: const EdgeInsets.all(0),
              width: double.maxFinite,
              height: 50,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: TextButton(
                      onPressed: () {
                        _saveImage();
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const <Widget>[
                          Icon(
                            Icons.file_download,
                            color: Pallete.primary,
                          ),
                          SizedBox(width: 4),
                          Text(
                            "Unduh",
                            style: TextStyle(color: Pallete.primary),
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: ISTOutlineButton(
                text: 'Selesai',
                onPressed: widget.onFinished as void Function()?,
              ),
            ),
            const SizedBox(height: 16),
            // widget.status == ISTReceiptStatus.suspect &&
            //         widget.type == 'QRPAYMENT'
            //     ? Container()
          ],
        ),
      ),
    );
  }
}
