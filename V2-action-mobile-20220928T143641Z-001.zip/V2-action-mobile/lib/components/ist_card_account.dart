import 'package:bpd_aceh/components/ist_card_account_item.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/features/other/rekeningku/pengaturanRekening/page/ist_list_rek.dart';
import 'package:bpd_aceh/features/statements/statements.dart';
import 'package:flutter/material.dart';

enum ISTMenu { home, transfer, qr, billpay, other, statements, rekeningKu }

class ISTCardAccount extends StatefulWidget {
  const ISTCardAccount({
    Key? key,
    required this.context,
    required this.menu,
    this.showName = true,
    this.callback,
    // this.isLoading=true,
    // this.account
  }) : super(key: key);
  // final ValueChanged<ISTCardAccountItem> account;
  final BuildContext? context;
  final ISTMenu menu;
  final bool showName;
  final Function()? callback;

  // final bool isLoading;

  @override
  _ISTCardAccountState createState() => _ISTCardAccountState();
}

class _ISTCardAccountState extends State<ISTCardAccount> {
  String greetings = "";
  bool isLoading = true;
  bool showPass = true;
  bool showwPass1 = false;
  @override
  void initState() {
    initGreetings();
    _doInquiryListAccountSingle();
    super.initState();
  }

  String? _accountBalance = "";
  String? _accountName = "";
  String? _accountNumber = "";
  String? _accountType = "";

  _doInquiryListAccount() async {
    final resp = await API.post(context, '/acct/listAccount', {});
    if (resp != null && resp['code'] == 0) {
      var listResp = resp['accountList'];
      List<dynamic> listRespDyn = (listResp);
      List<ISTCardAccountItem> listParam = [];
      // ignore: unused_local_variable
      List<ISTListRek> listParamss = [];
      for (var i = 0; i < listRespDyn.length; i++) {
        ISTCardAccountItem cardItem = ISTCardAccountItem(
          accountBalance: listRespDyn[i]['accountBalance'], //
          accountName: listRespDyn[i]['accountOwnerName'],
          accountNumber: listRespDyn[i]['accountNo'], //
          accountType: listRespDyn[i]['accountProductName'], //
          isPrimary: listRespDyn[i]['accountDefault'],
          index: i,
          callback: (accountBalance, accountType, accountNumber, accountName) {
            Navigator.pop(context);
            setState(() {
              _accountBalance = accountBalance;
              _accountType = accountType;
              _accountNumber = accountNumber;
              _accountName = accountName;
            });
            if (widget.callback != null) widget.callback!();
          },
        );

        listParam.add(cardItem);
      }
      showAccountDialog(
        context: context,
        list: listParam,
      );
    }
  }

  _doInquiryListAccountSingle() async {
    setState(() {
      isLoading = true;
    });
    final resp = await API.postNoLoading(context, '/acct/getdefaultacc', {});
    if (resp != null && resp['code'] == 0) {
      var listResp = resp['accountList'];
      List<dynamic> listRespDyn = (listResp);
      List<ISTCardAccountItem> listParam = [];
      // List<ISTListRek> listParamsss = [];
      for (var item in listRespDyn) {
        ISTCardAccountItem cardItem = ISTCardAccountItem(
          accountBalance: item['accountBalance'],
          accountName: item['accountOwnerName'],
          accountNumber: item['accountNo'],
          accountType: item['accountProductName'],
          isPrimary: true,
          callback: (accountBalance, accountType, accountNumber, accountName) {
            Navigator.pop(context);
            setState(() {
              _accountBalance = accountBalance;
              _accountType = accountType;
              _accountNumber = accountNumber;
              _accountName = accountName;
            });
            if (widget.callback != null) widget.callback!();
          },
        );
        // ISTListRek cardRek = ISTListRek(
        //   accountBalance: item['accountBalance'],
        //   accountName:item['accountOwnerName'],
        //   accountNumber: item['accountNo'],
        //   accountType: item['accountProductName'],
        //   isPrimary: true,
        // );
        listParam.add(cardItem);
        //  listParamsss.add(cardRek);
      }
      ISTCardAccountItem accItem = listParam[0];
      // ISTListRek accRek = listParamsss[0];
      if (!mounted) return;
      {
        setState(() {
          //   _accountBalance = accRek.accountBalance;
          // _accountName = accRek.accountName;
          // _accountNumber = accRek.accountNumber;
          // _accountType = accRek.accountType;
          _accountBalance = accItem.accountBalance;
          _accountName = accItem.accountName;
          _accountNumber = accItem.accountNumber;
          _accountType = accItem.accountType;
        });
      }
      await ISTConstants().setString(ISTConstants.acctName, _accountName);
      await ISTConstants().setString(ISTConstants.acctNumber, _accountNumber);

      setState(() {
        isLoading = false;
      });
    }
    // showPass = await ISTConstants().getConstants(ISTConstants.showBalance);
  }

  initGreetings() {
    DateTime now = DateTime.now();
    if (now.hour < 12) {
      setState(() {
        greetings = "Selamat Pagi";
      });
    } else if (now.hour >= 12 && now.hour < 18) {
      setState(() {
        greetings = "Selamat Siang";
      });
    } else if (now.hour >= 18 && now.hour <= 24) {
      setState(() {
        greetings = "Selamat Malam";
      });
    }
  }
  // final bool isLoading;

  @override
  Widget build(BuildContext context) {
    _onShowBalance() async {
      setState(() {
        showPass = !showPass;
        // showwPass1 = !showwPass1;
      });
      // await ISTConstants().setConstants(ISTConstants.showBalance, showPass);
    }

    return SizedBox(
      height: 128,
      child: Stack(
        children: <Widget>[
          Container(
            height: 70,
            decoration: const BoxDecoration(
                color: Pallete.primary,
                // color: Colors.black,
                borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(10),
                    bottomRight: Radius.circular(10))),
          ),
          isLoading
              ? const SkeletonCard()
              : Positioned(
                  top: 10,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8.0),
                    child: Container(
                      // color: Colors.white,
                      height: 118,
                      width: MediaQuery.of(context).size.width - 16,
                      decoration: BoxDecoration(
                        boxShadow: [
                          BoxShadow(
                            color: Pallete.primary.withOpacity(0.3),
                            spreadRadius: 0.2,
                            blurRadius: 5,
                          )
                        ],
                        color: Colors.white,
                        borderRadius: const BorderRadius.all(Radius.circular(10)),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          Expanded(
                            flex: 7,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                widget.menu != ISTMenu.home
                                    ? Expanded(
                                        child: _buildMenuImage(widget.menu))
                                    : const SizedBox(width: 0, height: 0),
                                widget.menu == ISTMenu.home
                                    ? const Image(
                                      height: 44,
                                      image: AssetImage(
                                        'assets/images/user.png',
                                      ),
                                      // Icon(
                                      //   Icons.person_outline,
                                      color: Pallete.primary,
                                      // size: 44,
                                    )
                                    : const SizedBox(width: 0, height: 0),
                                widget.menu == ISTMenu.home
                                    ? Text(
                                      '$greetings,',
                                      style: const TextStyle(
                                        color: Pallete.primary,
                                      ),
                                    )
                                    : const SizedBox(width: 0, height: 0),
                                widget.menu == ISTMenu.home
                                    ? Container(
                                        padding:
                                            const EdgeInsets.symmetric(horizontal: 8),
                                        child: Text(
                                          _accountName!,
                                          overflow: TextOverflow.ellipsis,
                                          style: const TextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: Pallete.primary,
                                          ),
                                        ),
                                      )
                                    : const SizedBox(width: 0, height: 0),
                              ],
                            ),
                          ),
                          Expanded(
                              flex: 9,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: <Widget>[
                                  // Row(
                                  //   children: [
                                  //     new FlatButton(
                                  //       onPressed: _visibilitymethod,
                                  //       child: IconButton(
                                  //         // color: Pallete.primary,
                                  //         icon: Icon(
                                  //           showPass
                                  //               ? Icons.visibility
                                  //               : Icons.visibility_off,
                                  //           color: Pallete.primary,
                                  //         ),
                                  //         onPressed: null,
                                  //       ),
                                  //     ),
                                  //     a == true
                                  //         ? new Container(
                                  //             // width: 30.0,
                                  //             // height: 30.0,
                                  //             // color: Colors.red,
                                  //             child: Text('LIHAT SALDO'),
                                  //           )
                                  //         : new Container(
                                  //             child: Text(
                                  //               '$_accountBalance',
                                  //             ),
                                  //             // width: 30.0,
                                  //             // height: 30.0,
                                  //             // color: Colors.red,
                                  //           ),
                                  //   ],
                                  // ),

                                  // Row(
                                  //   mainAxisAlignment: MainAxisAlignment.end,
                                  //   children: [
                                  //     FlatButton(
                                  //         onPressed: _onShowBalance,
                                  //         child: Row(
                                  //           children: [
                                  //             IconButton(
                                  //               // color: Pallete.primary,
                                  //               icon: Icon(
                                  //                 showPass
                                  //                     ? Icons.visibility
                                  //                     : Icons.visibility_off,
                                  //                 color: Pallete.primary,
                                  //               ),
                                  //               onPressed: null,
                                  //             ),
                                  //             Text(
                                  //               'LIHAT SALDO',
                                  //               style: TextStyle(
                                  //                   color: Pallete.primary,
                                  //                   fontWeight:
                                  //                       FontWeight.bold),
                                  //             ),
                                  //           ],
                                  //         )),
                                  //   ],
                                  // ),

                                  Container(
                                    padding: const EdgeInsets.symmetric(vertical: 1),
                                    child: InkWell(
                                      onTap: _onShowBalance,
                                      child: SizedBox(
                                        height: 29,
                                        child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.end,
                                            children: [
                                              Padding(
                                                padding: const EdgeInsets.only(
                                                  bottom: 10,
                                                ),
                                                child: IconButton(
                                                  padding: const EdgeInsets.only(
                                                      left: 16,
                                                      top: 8,
                                                      right: 2),
                                                  // iconSize: 10,
                                                  // color: Pallete.primary,
                                                  icon: Icon(
                                                    showPass
                                                        ? Icons.visibility
                                                        : Icons.visibility_off,
                                                    color: Pallete.primary,
                                                    size: 20,
                                                  ),
                                                  onPressed: _onShowBalance,
                                                ),
                                              ),
                                              !showPass
                                                  ? Padding(
                                                      padding:
                                                          const EdgeInsets.only(
                                                              top: 8),
                                                      child: Text(
                                                        '$_accountBalance',
                                                        textAlign:
                                                            TextAlign.end,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        style: const TextStyle(
                                                            color:
                                                                Pallete.primary,
                                                            fontWeight:
                                                                FontWeight
                                                                    .bold),
                                                      ),
                                                    )
                                                  : const Padding(
                                                      padding:
                                                          EdgeInsets.only(
                                                              top: 8),
                                                      child: Text(
                                                        'Lihat Saldo',
                                                        style: TextStyle(
                                                            color:
                                                                Pallete.primary,
                                                            fontWeight:
                                                                FontWeight
                                                                    .bold),
                                                      ),
                                                    ),
                                            ]),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    padding: const EdgeInsets.symmetric(vertical: 1),
                                    child: Text('$_accountType',
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                          color: Pallete.primary,
                                        )),
                                  ),
                                  Container(
                                    padding: const EdgeInsets.symmetric(vertical: 1),
                                    // padding: EdgeInsets.only(top: 2),
                                    child: Text('$_accountNumber',
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                          color: Pallete.primary,
                                        )),
                                  ),
                                  widget.showName
                                      ? Container(
                                          padding:
                                              const EdgeInsets.symmetric(vertical: 1),
                                          child: Text('$_accountName',
                                              textAlign: TextAlign.end,
                                              overflow: TextOverflow.ellipsis,
                                              style: const TextStyle(
                                                color: Pallete.primary,
                                              )),
                                        )
                                      : Container(),
                                ],
                              )),
                          Expanded(
                              flex: 2,
                              child: IconButton(
                                color: Pallete.primary,
                                icon: const Icon(Icons.keyboard_arrow_down),
                                onPressed: () {
                                  _doInquiryListAccount();
                                },
                              ))
                        ],
                      ),
                    ),
                  ),
                ),
        ],
      ),
    );
  }
}

_buildMenuImage(menu) {
  switch (menu) {
    case ISTMenu.billpay:
      return const Image(image: AssetImage('assets/images/ISTcardPay.png'));
    case ISTMenu.qr:
      return const Image(
        image: AssetImage('assets/images/qris2.png'),
        height: 200,
        width: 200,
        // color: Pallete.primary,
      );
    case ISTMenu.transfer:
      return const Image(image: AssetImage('assets/images/ISTcardTF.png'));
    case ISTMenu.other:
      return const Image(image: AssetImage('assets/images/Lainnyaheader.png'));
      // ignore: dead_code
      break;
    case ISTMenu.statements:
      return const Image(image: AssetImage('assets/images/ISTmutasi.png'));
    case ISTMenu.rekeningKu:
      return const Image(image: AssetImage('assets/images/ISTmutasi.png'));
      // ignore: dead_code
      break;
    default:
  }
}

void showAccountDialog({
  required BuildContext context,
  List<ISTCardAccountItem>? list,
  List<ISTListRek>? listRek,
}) {
  showDialog(
      context: context,
      barrierDismissible: true,
      builder: (context) {
        return Center(
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: Colors.white,
            ),
            height: MediaQuery.of(context).size.height * 0.7,
            width: MediaQuery.of(context).size.width * 0.8,
            child: Scaffold(
                body: Column(children: <Widget>[
              SizedBox(
                height: MediaQuery.of(context).size.height * 0.7 - 52,
                // child: SingleChildScrollView(
                child: Center(
                  child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  const Image(
                    image: AssetImage(
                        'assets/images/HeaderDaftarRekening.png'),
                    // color: Pallete.primary,
                    width: 90,
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    "Daftar Rekening Tabungan Anda",
                    style: TextStyle(
                        color: Pallete.primary,
                        fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  // Text('Silakan pilih rekening',
                  //     style: TextStyle(color: Pallete.primary)),
                  // Text('untuk dijadikan rekening utama',
                  //     style: TextStyle(color: Pallete.primary)),
                  const SizedBox(height: 8),
//sadasdas
                  Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12.0,
                      ),
                      child: SizedBox(
                        height:
                            MediaQuery.of(context).size.height * 0.7 - 187,
                        child: SingleChildScrollView(
                            child: Column(children: list!)),
                      )),
                  //asdasdas
                ],
                  ),
                  // ),
                ),
              ),
              const Spacer(),
              const SizedBox(
                height: 8,
              ),
              ISTFlatButton(
                onPressed: () {
              Navigator.pop(context);
                },
                text: 'Tutup',
                color: Pallete.primary,
              )
            ])),
          ),
        );
      });
}
