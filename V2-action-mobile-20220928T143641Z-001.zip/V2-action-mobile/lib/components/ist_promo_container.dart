import 'package:bpd_aceh/components/loading_screen.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:flutter/material.dart';

class SkeletonCardPromo extends StatefulWidget {
  final double height;
  // final double width;

  const SkeletonCardPromo({
    Key? key,
    this.height = 300,
    // this.width = 200
  }) : super(key: key);

  @override
  createState() => SkeletonCardSPromoState();
}

class SkeletonCardSPromoState extends State<SkeletonCardPromo>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    _controller = AnimationController(
        duration: const Duration(milliseconds: 1500), vsync: this);
    _controller.repeat();
    super.initState();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var _childrenLoad = <Widget>[];
    // for (var i = 0; i < 7; i++) {
    _childrenLoad.add(
      SizedBox(
        height: 128,
        child: Stack(
          children: <Widget>[
            Container(
              height: 70,
              decoration: const BoxDecoration(
                  color: Pallete.primary,
                  borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(10),
                      bottomRight: Radius.circular(10))),
            ),
            Positioned(
              top: 8,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0),
                child: Container(
                  height: 118,
                  width: MediaQuery.of(context).size.width - 16,
                  decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Pallete.primary.withOpacity(0.3),
                        spreadRadius: 0.2,
                        blurRadius: 5,
                      )
                    ],
                    color: Colors.white,
                    borderRadius: const BorderRadius.all(Radius.circular(10)),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      Expanded(
                        flex: 7,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            LoadAnimation(
                              child: Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  color: const Color.fromRGBO(0, 0, 0, .06),
                                ),
                                height: 88,
                                width: 88,
                              ),
                            )
                          ],
                        ),
                      ),
                      Expanded(
                          flex: 9,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: <Widget>[
                              Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(100),
                                  color: const Color.fromRGBO(0, 0, 0, .06),
                                ),
                                height: 12,
                              ),
                              const SizedBox(
                                height: 8,
                              ),
                              Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(100),
                                  color: const Color.fromRGBO(0, 0, 0, .06),
                                ),
                                height: 12,
                              ),
                              const SizedBox(
                                height: 8,
                              ),
                              Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(100),
                                  color: const Color.fromRGBO(0, 0, 0, .06),
                                ),
                                height: 12,
                              ),
                              const SizedBox(
                                height: 8,
                              ),
                              Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(100),
                                  color: const Color.fromRGBO(0, 0, 0, .06),
                                ),
                                height: 12,
                              ),
                            ],
                          )),
                      Expanded(
                          flex: 2,
                          child: Container(
                              // padding: const EdgeInsets.only(
                              //     left: 5, right: 5, top: 14),
                              // child: Container(
                              //   height: 34,
                              //   decoration: BoxDecoration(
                              //     borderRadius: BorderRadius.circular(10),
                              //     color: Color.fromRGBO(0, 0, 0, .06),
                              //   ),
                              // ),
                              ))
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
      // Container(
      //   height: 300,
      //   decoration: BoxDecoration(
      //     borderRadius: BorderRadius.circular(10),
      //     color: Colors.red,
      //   ),
      // ),
    );
    // }
    return LoadAnimation(
      child: Row(
        children: _childrenLoad,
        // child: _childrenLoad,
      ),
    );
  }
}

class ISTPromoContainer extends StatelessWidget {
  const ISTPromoContainer({Key? key, required this.widget, required this.onTap})
      : super(key: key);

  final Widget widget;
  final GestureTapCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 4, left: 8),
      child: Material(
        color: Colors.transparent,
        child: InkWell(onTap: onTap, child: widget),
      ),
    );
  }
}
