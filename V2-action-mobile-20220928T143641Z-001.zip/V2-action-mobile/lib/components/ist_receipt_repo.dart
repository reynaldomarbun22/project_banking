import 'dart:convert';
// import 'dart:io';
import 'dart:io';
import 'dart:typed_data';
import 'package:external_path/external_path.dart';
import 'package:flutter/services.dart';
import 'package:image_save/image_save.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/widgets.dart' as pw;

import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/utils/string_utils.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PDAM/tirtadaroy/widgets/list_detail.dart';
import 'package:flutter/material.dart';
import 'package:image_gallery_saver/image_gallery_saver.dart';
import 'package:permission_handler/permission_handler.dart';
// import 'package:quiver/io.dart';
import 'package:share/share.dart';
import 'package:screenshot/screenshot.dart';

enum ISTReceiptStatusInbox {
  success,
  failed,
  suspect,
}

class ISTReceiptItemInbox {
  final String? key;
  final String? value;

  ISTReceiptItemInbox({this.key, this.value});

  String toJson() => json.encode({
        'key': key,
        'value': value,
      });

  factory ISTReceiptItemInbox.fromJson(dynamic json) {
    return ISTReceiptItemInbox(key: json['key'], value: json['value']);
  }
}

class ISTReceiptInbox extends StatefulWidget {
  const ISTReceiptInbox({
    Key? key,
    this.items,
    this.onFinished,
    this.onCheck,
    this.onTap,
    this.type,
    this.idresi,
    this.title,
    this.srcAcc,
    this.srcNOAcc,
    this.dstAcc,
    this.receiptItemImage,
    this.receiptItemTitle,
    this.imageTab,
    this.amount,
    this.time,
    this.memo,
    this.status,
    this.noRef,
    this.id,
    this.titleresi,
    this.footer1,
    this.detail,
    this.footer2,
    this.transactionGroup,
    this.footer3,
    this.titleresi1,
    this.listdetail,
    this.listtotalbayar,
    this.jenistabungan,
    this.additional,
    this.bilyet,
    this.titledepo,
  }) : super(key: key);

  final String? noRef;
  final String? idresi;
  final String? jenistabungan;
  final String? memo;
  final String? time;
  final String? srcAcc;
  final String? transactionGroup;
  final String? dstAcc;
  final String? detail;
  final String? srcNOAcc;
  final String? imageTab;
  final String? title;
  final String? receiptItemTitle;
  final String? amount;
  final String? bilyet;
  final String? titledepo;
  final int? id;
  final String? titleresi;
  final String? titleresi1;
  final List<ISTReceiptItemInbox>? items;
  final List<ISTReceiptItemInbox>? receiptItemImage;
  final Function? onFinished;
  final Function? onCheck;
  final Function? onTap;
  final ISTReceiptStatusInbox? status;
  final Widget? footer1;
  final Widget? footer2;
  final String? additional;
  final List<ISTReceiptItemInbox>? footer3;
  final List<DetailItem>? listdetail;
  final List<ISTReceiptItemInbox>? listtotalbayar;

  final String? type;

  //  static String encondeHeaderToJson(List<ISTReceiptItemInbox> list) {
  //   List jsonList = List();
  //   list.map((item) => jsonList.add(item.toJson())).toList();
  //   return json.encode(jsonList);
  // }

  // final ISTReceipt data;
  // const ISTReceipt({Key key,  this.data}) : super(key: key);

  @override
  _ISTReceiptInboxState createState() => _ISTReceiptInboxState();
}

class _ISTReceiptInboxState extends State<ISTReceiptInbox> {
  // ignore: unused_field
  final GlobalKey<State<StatefulWidget>> _printKey = GlobalKey();
  String statusStr = "";
  String imageStatus = "";
  bool isLoading = false;
  bool isSuccess = false;
  bool _firstPress = true;
  late Uint8List _imageTabungan;
  // ignore: unused_field
  Future<List<Directory>>? _externalStorageDirectories;
  // _saveinbox() async {
  //   InboxDBRepository repo = InboxDBRepository();
  //   await repo.open();
  //   InboxModel model = InboxModel();
  //   model.amount = widget.amount;
  //   model.status = widget.status.index.toString();
  //   model.title = widget.title;
  //   var img = widget.type;
  //   var imgasset = "";
  //   if( img == 'PAYMENT_ZAKAT') {
  //     imgasset ='assets/images/icon-wallet.png';
  //   }
  //   model.image = imgasset;
  //   await repo.insert(model);
  //   await repo.close();
  // }

  @override
  void initState() {
    switch (widget.status) {
      case ISTReceiptStatusInbox.success:
        setState(() {
          statusStr = "Berhasil";
          imageStatus = "assets/images/icon-success.png";
        });
        break;
      case ISTReceiptStatusInbox.failed:
        setState(() {
          statusStr = "Gagal";
          imageStatus = "assets/images/icon-failed.png";
        });
        break;
      case ISTReceiptStatusInbox.suspect:
        setState(() {
          statusStr = "Sedang diproses";
          imageStatus = "assets/images/icon-warning.png";
        });
        break;
        // case ISTReceiptStatusInbox.suspectQR:
        //   setState(() {
        //     statusStr = "Sedang diproses";
        //     imageStatus = "assets/images/icon-warning.png";
        //     type = 'QRPAYMENT';
        //   });
        // ignore: dead_code
        break;
      default:
    }
    sasd();
    _imageTabungan = const Base64Decoder().convert(widget.imageTab!);
    super.initState();
  }

  _changeStatus() {
    switch (widget.status) {
      case ISTReceiptStatusInbox.success:
        setState(() {
          isSuccess = true;
          statusStr = "Berhasil";
          imageStatus = "assets/images/icon-success.png";
        });
        break;
      case ISTReceiptStatusInbox.failed:
        setState(() {
          statusStr = "Gagal";
          imageStatus = "assets/images/icon-failed.png";
        });
        break;
      case ISTReceiptStatusInbox.suspect:
        setState(() {
          statusStr = "Sedang diproses";
          imageStatus = "assets/images/icon-warning.png";
        });
        break;

      default:
    }
    return Container();
  }

  List<Widget> _buildItems() {
    List<Widget> ret = [];
    if (widget.items == null || widget.items!.isEmpty) {
      return [];
    }
    for (ISTReceiptItemInbox item in widget.items!) {
      ret.add(Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Expanded(
              flex: 1,
              child: item.key == null ? const Text("") : Text(item.key!)),
          Expanded(
            flex: 1,
            child: Text(
              item.value == null ? "" : item.value!,
              textAlign: TextAlign.right,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          )
        ],
      ));
      ret.add(const Divider(
        thickness: 1,
      ));
    }
    return ret;
  }

  List<Widget> _buildResitotal() {
    List<Widget> ret = [];
    if (widget.listtotalbayar == null || widget.listtotalbayar!.isEmpty) {
      return [];
    }
    for (ISTReceiptItemInbox item in widget.listtotalbayar!) {
      ret.add(Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Expanded(
              flex: 1,
              child: item.key == null ? const Text("") : Text(item.key!)),
          Expanded(
            flex: 1,
            child: Text(
              item.value == null ? "" : item.value!,
              textAlign: TextAlign.right,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          )
        ],
      ));
      ret.add(const Divider(
        thickness: 1,
      ));
    }
    return ret;
  }

  Widget buildItemtest() {
    return ListView.separated(
        separatorBuilder: (ctx, index) {
          return const Divider(
            height: 0,
          );
        },
        // physics: const NeverScrollableScrollPhysics(),
        itemCount: widget.listdetail!.length,
        itemBuilder: (context, index) {
          final item = widget.listdetail![index];
          return Container(
              padding: const EdgeInsets.only(bottom: 10, left: 16, right: 16),
              child: Column(
                children: [
                  Container(
                    color: Colors.grey[200],
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text("Periode"),
                            Text(item.periode!),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text("Pemakaian"),
                            Text(item.pemakaian!),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text("Denda"),
                            Text(item.denda!),
                          ],
                        ),
                        // Row(
                        //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        //   children: [
                        //     Text("Biaya"),
                        //     Text(item.biaya),
                        //   ],
                        // ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text("Tagihan"),
                            Text(item.tagihan!),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(item.noReffStr!),
                            Text(item.noReff!),
                          ],
                        ),
                        // Row(
                        //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        //   children: [
                        //     Text("noReffStr"),
                        //     Text(item.noReffStr),
                        //   ],
                        // ),
                      ],
                    ),
                  ),
                ],
              ));
        });
  }

  List key = [];
  sasd() {
    for (ISTReceiptItemInbox item in widget.receiptItemImage!) {
      key.add(item.key);

      print(key);
    }
  }

  List<Widget> _buildResiItems() {
    List<Widget> ret = [];
    if (widget.receiptItemImage == null || widget.receiptItemImage!.isEmpty) {
      return [];
    }
    for (ISTReceiptItemInbox item in widget.receiptItemImage!) {
      ret.add(Column(children: [
        Padding(
          padding: const EdgeInsets.only(left: 16, right: 16),
          child: Row(
            // mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              SizedBox(
                  height: 11,
                  width: 100,
                  child: Text(
                    item.key!,
                    style: const TextStyle(fontSize: 8),
                  )),
              Container(
                  alignment: Alignment.center,
                  width: 50,
                  height: 1,
                  child: const Text(
                    ' :',
                    style: TextStyle(fontSize: 8),
                  )),
              Expanded(
                child: Container(
                  alignment: Alignment.topLeft,
                  height: 11,
                  width: 150,
                  // flex: 1,
                  child: Text(
                    item.value!,
                    textAlign: TextAlign.right,
                    style: const TextStyle(fontSize: 8),
                  ),
                ),
              )
            ],
          ),
        )
      ]));

      // ret.add(Divider(
      //   thickness: 12,
      // ));
    }
    return ret;
  }

  List<Widget> _buildResiItemsTab() {
    List<Widget> ret = [];
    if (widget.receiptItemImage == null || widget.receiptItemImage!.isEmpty) {
      return [];
    }
    for (ISTReceiptItemInbox item in widget.receiptItemImage!) {
      ret.add(Column(children: [
        Padding(
          padding: const EdgeInsets.only(right: 16),
          child: Row(
            // mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              SizedBox(
                  height: 16,
                  width: 100,
                  child: Text(
                    item.key!,
                    style: const TextStyle(fontSize: 12),
                  )),
              const SizedBox(
                  width: 8,
                  height: 16,
                  child: Text(
                    ' :',
                    style: TextStyle(fontSize: 12),
                  )),
              Container(
                alignment: Alignment.topLeft,
                height: 16,
                // width: 230,
                // flex: 1,
                child: Text(
                  item.value!,
                  textAlign: TextAlign.right,
                  style: const TextStyle(fontSize: 12),
                ),
              )
            ],
          ),
        )
      ]));

      // ret.add(Divider(
      //   thickness: 12,
      // ));
    }
    return ret;
  }

  List<Widget> _generatedList() {
    List<Widget> ret = [];
    if (widget.footer3 == null || widget.footer3!.isEmpty) {
      return [];
    }
    for (ISTReceiptItemInbox item in widget.footer3!) {
      ret.add(Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          Center(
            child: Text(
              item.value == null ? "" : item.value!,
              textAlign: TextAlign.right,
              style: TextStyle(
                fontWeight: item.value != "Info Penerbangan"
                    ? FontWeight.bold
                    : FontWeight.normal,
              ),
            ),
          )
        ],
      ));
    }
    return ret;
  }

  final pdf = pw.Document();
  buildPDF() async {
    final font = await rootBundle.load("assets/fonts/poppins/Poppins-Bold.ttf");
    // ignore: unused_local_variable
    final ttf = pw.Font.ttf(font);
    final image = pw.MemoryImage(
      (await rootBundle.load('assets/images/depcerrjpg.jpg'))
          .buffer
          .asUint8List(),
    );
    pdf.addPage(
      pw.Page(
        build: (pw.Context context) => pw.Stack(children: [
          pw.Image(image),
          //  pw.Text('Hello World', style: pw.TextStyle(font: ttf, fontSize: 40))
          pw.Container(
            alignment: pw.Alignment.center,
            padding: const pw.EdgeInsets.only(top: 16),
            child: pw.Column(children: [
              pw.SizedBox(height: 24),
              pw.Container(
                  padding: const pw.EdgeInsets.only(right: 30),
                  alignment: pw.Alignment.topRight,
                  // padding: const EdgeInsets.all(16),
                  child: pw.Text(
                    widget.bilyet!,
                    //  widget.noresi,
                    style: pw.TextStyle(
                      font: pw.Font.helvetica(),
                      fontSize: 8,
                    ),
                    textAlign: pw.TextAlign.center,
                  )),
              pw.SizedBox(
                height: 10,
              ),
              pw.Container(
                  padding:
                      const pw.EdgeInsets.only(bottom: 8, right: 16, left: 16),
                  alignment: pw.Alignment.topLeft,
                  // padding: const EdgeInsets.all(16),
                  child: pw.Text(
                    widget.memo!,
                    style:
                        pw.TextStyle(fontSize: 12, font: pw.Font.helvetica()),
                    textAlign: pw.TextAlign.center,
                  )),
              pw.SizedBox(
                height: 24,
              ),

              // pw.ListView.builder(
              //     itemBuilder: (context, index) {
              //       return pw.Container(
              //         child: pw.Text(key[index],
              //             style: pw.TextStyle(fontSize: 10, font: ttf)),
              //       );
              //     },
              //     itemCount: key.length),
              pw.ListView.builder(
                padding: const pw.EdgeInsets.only(left: 40, right: 40),
                itemCount: widget.receiptItemImage!.length,
                itemBuilder: (context, i) {
                  final a = widget.receiptItemImage![i];
                  return pw.Container(
                      padding: const pw.EdgeInsets.only(left: 32),
                      width: 500,
                      alignment: pw.Alignment.center,
                      child: pw.Row(
                        // mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: pw.CrossAxisAlignment.center,
                        children: [
                          pw.Container(
                            alignment: pw.Alignment.topLeft,
                            width: 100,
                            child: pw.Text(a.key!,
                                style: pw.TextStyle(
                                    fontSize: 10, font: pw.Font.helvetica())),
                          ),
                          pw.Container(
                            width: 10,
                            alignment: pw.Alignment.center,
                            child: pw.Text(':',
                                style: pw.TextStyle(
                                    fontSize: 10, font: pw.Font.helvetica())),
                          ),
                          pw.Container(
                            child: pw.Text(a.value!,
                                textAlign: pw.TextAlign.left,
                                style: pw.TextStyle(
                                    fontSize: 10, font: pw.Font.helvetica())),
                          )
                        ],
                      ));
                },
              ),
              pw.Container(
                  padding: const pw.EdgeInsets.only(right: 30),
                  alignment: pw.Alignment.bottomRight,
                  // padding: const EdgeInsets.all(16),
                  child: pw.Text(
                    'PT. Bank Aceh Syariah',
                    //  widget.noresi,
                    style: pw.TextStyle(
                        font: pw.Font.helveticaBold(),
                        fontSize: 8,
                        fontWeight: pw.FontWeight.bold),
                    textAlign: pw.TextAlign.center,
                  )),
              pw.SizedBox(
                height: 8,
              ),
              pw.Container(
                  // padding: EdgeInsets.only(left: 8),
                  alignment: pw.Alignment.bottomCenter,
                  // padding: const EdgeInsets.all(16),
                  child: pw.Text(
                    widget.footer1.toString(),
                    //  widget.noresi,
                    style: pw.TextStyle(
                      font: pw.Font.helvetica(),
                      fontSize: 8,
                    ),
                    textAlign: pw.TextAlign.left,
                  )),
            ]),
          ),
        ]
            // child: pw.Text('Hello World!'),
            ),
      ),
    );
    // var save = await ImageGallerySaver.saveImage(
    //       pdf.readAsBytesSync(),
    // );
    if (Platform.isIOS) {
      Directory documentDirectory = await getApplicationDocumentsDirectory();
      // print(documentDirectory);
      String documentPath = documentDirectory.path;
      File receiptFile = File("$documentPath/${widget.noRef}.pdf");
      print(receiptFile);
      await receiptFile.writeAsBytes(await pdf.save());
      // await Share.share('${widget.noRef}', '${widget.noRef}.pdf',
      //     receiptFile.readAsBytesSync(), 'pdf');
      // ignore: unnecessary_null_comparison
      if (receiptFile != null) {
        const DialogBox().showImageDialog(
          isError: false,
          onOk: () {
            Navigator.pop(context);
          },
          // image: Icon(
          //   Icons.camera_alt,
          //   color: Pallete.primary,
          // ),
          title: "Perhatian",
          buttonOk: "OK",
          context: context,
          message: "Berhasil unduh Advice",
        );
      }
      //     // await Share.file('${widget.noRef}', '${widget.noRef}.pdf',
      //     //     receiptFile.readAsBytesSync(), 'pdf');
    } else if (Platform.isAndroid) {
      if (await Permission.storage.request().isGranted) {
        // Directory documentDirectory = Directory('/storage/emulated/0/Download');
        String path = await ExternalPath.getExternalStoragePublicDirectory(
            ExternalPath.DIRECTORY_DOWNLOADS);
        print(path);
        // String documentPath = documentDirectory.path;

        File receiptFile = File("$path/${widget.noRef}.pdf");
        print(receiptFile);
        receiptFile.writeAsBytesSync(await pdf.save());
        const DialogBox().showImageDialog(
          isError: false,
          onOk: () {
            Navigator.pop(context);
          },
          // image: Icon(
          //   Icons.camera_alt,
          //   color: Pallete.primary,
          // ),
          title: "Perhatian",
          buttonOk: "OK",
          context: context,
          message: "Berhasil unduh Advice",
        );
      }
    }

    // final output = await getTemporaryDirectory();
    //       final file = File('${output.path}/example.pdf');
    //       file.writeAsBytesSync(await pdf.save());
    // return file;
// final output = await getTemporaryDirectory();
//     final path = "${output.path}/temp.pdf";
//     final file = await io.File(path).writeAsBytes(pdf.save());
  }

  // yoseph
  // _scrshot() async {
  //   precacheImage(
  //       AssetImage(
  //         imageStatus,
  //       ),
  //       context);
  //   precacheImage(
  //       const AssetImage('assets/images/bank-logo-green.png'), context);
  //   precacheImage(
  //       const AssetImage('assets/images/logo-app-green.png'), context);
  //   precacheImage(const AssetImage('assets/images/icon-success.png'), context);
  //   Map<Permission, PermissionStatus> statuses = await [
  //     Permission.photos,
  //     Permission.storage,
  //     Permission.camera
  //   ].request();
  //   print(statuses);
  //   if (await Permission.storage.request().isGranted &&
  //       await Permission.photos.request().isGranted &&
  //       await Permission.camera.request().isGranted) {
  //     screenshotController
  //         .capture(pixelRatio: 3, delay: const Duration(milliseconds: 10))
  //         .then((image) async {
  //       var save =
  //           await ImageGallerySaver.saveImage(image!, name: "${widget.noRef}");
  //       if (save != null && save.toString().isNotEmpty) {
  //         const DialogBox().showImageDialog(
  //           isError: false,
  //           onOk: () {
  //             Navigator.pop(context);
  //           },
  //           // image: Icon(
  //           //   Icons.camera_alt,
  //           //   color: Pallete.primary,
  //           // ),
  //           title: "Perhatian",
  //           buttonOk: "OK",
  //           context: context,
  //           message: "Berhasil unduh resi",
  //         );
  //       }
  //     }).catchError((onError) {
  //       print(onError);
  //     });
  //   } else {
  //     const DialogBox().showImageDialog(
  //       isError: true,
  //       onOk: () {
  //         Navigator.pop(context);
  //       },
  //       // image: Icon(
  //       //   Icons.camera_alt,
  //       //   color: Pallete.primary,
  //       // ),
  //       title: "Perhatian",
  //       buttonOk: "OK",
  //       context: context,
  //       message: "Gagal unduh resi",
  //     );
  //   }
  // }

  late String noref;
  String _result = "";
  Future<void> _saveImage() async {
    setState(() {
      noref = widget.noRef!;
    });
    bool success = false;
    screenshotController
        .capture(pixelRatio: 3, delay: const Duration(milliseconds: 10))
        .then((image) async {
      print(image);
      print("ini datsssssSSSSSSSSS");
      try {
        success = (await ImageSave.saveImage(
          image,
          "$noref.jpg",
          albumName: "Action Mobile",
        ))!;
      } on PlatformException catch (e, s) {
        print(e);
        print(s);
      }
      setState(() {
        _result = success ? "Save to album success" : "Save to album failed";
        print(_result);
        const DialogBox().showImageDialog(
          isError: false,
          onOk: () {
            Navigator.pop(context);
          },
          // image: Icon(
          //   Icons.camera_alt,
          //   color: Pallete.primary,
          // ),
          title: "Perhatian",
          buttonOk: "OK",
          context: context,
          message: "Resi berhasil di unduh",
        );
        // showDialog(
        //   context: context,
        //   barrierDismissible: false,
        //   useRootNavigator: true,
        //   builder: (BuildContext context) {
        //     return AlertDialog(
        //       // contentPadding: EdgeInsets.all(8),
        //       shape: const RoundedRectangleBorder(
        //         borderRadius: BorderRadius.all(Radius.circular(20.0)),
        //       ),
        //       content: SizedBox(
        //         height: 230,
        //         child: Column(
        //           children: <Widget>[
        //             // SizedBox(
        //             //   height: 2,
        //             // ),

        //             const Text(
        //               'Resi berhasil di unduh',
        //               textAlign: TextAlign.center,
        //               style: TextStyle(
        //                 color: Pallete.primary,
        //               ),
        //             ),
        //             const SizedBox(
        //               height: 16,
        //             ),
        //             Container(
        //               alignment: Alignment.center,
        //               child: Row(
        //                 mainAxisAlignment: MainAxisAlignment.center,
        //                 children: [
        //                   SizedBox(
        //                     width: 120,
        //                     child: OutlineButton(
        //                       onPressed: () {
        //                         Navigator.pop(context);
        //                         setState(() {
        //                           // ss = false;
        //                         });
        //                       },
        //                       borderSide: const BorderSide(
        //                         color: Pallete.primary,
        //                       ),
        //                       splashColor: Pallete.primary,
        //                       shape: const RoundedRectangleBorder(
        //                         borderRadius:
        //                             BorderRadius.all(Radius.circular(18)),
        //                       ),
        //                       child: Text(
        //                         "Selesai",
        //                         style: Theme.of(context)
        //                             .textTheme
        //                             .bodyText1
        //                             ?.copyWith(
        //                                 fontWeight: FontWeight.w600,
        //                                 color: Pallete.primary),
        //                       ),
        //                     ),
        //                   ),
        //                 ],
        //               ),
        //             )
        //           ],
        //         ),
        //       ),
        //       //actions: _checkbutton(context),
        //     );
        //   },
        // );
      });
    });
  }

  Future<String> saveAndShare(Uint8List bytes) async {
    final directory = await getApplicationDocumentsDirectory();
    final image = File('${directory.path}/flutter.png');
    image.writeAsBytesSync(bytes);
    const text = 'Shared From Action Mobile';
    await Share.shareFiles([image.path], text: text);
    return directory.path;
  }

  // _share() async {
  //   precacheImage(
  //       AssetImage(
  //         imageStatus,
  //       ),
  //       context);
  //   precacheImage(
  //       const AssetImage('assets/images/bank-logo-green.png'), context);
  //   precacheImage(
  //       const AssetImage('assets/images/logo-app-green.png'), context);
  //   precacheImage(const AssetImage('assets/images/icon-success.png'), context);
  //   await [
  //     Permission.photos,
  //     Permission.storage,
  //   ].request();
  //   screenshotController
  //       .capture(pixelRatio: 3, delay: const Duration(milliseconds: 10))
  //       .then((image) async {
  //     await Share.file(
  //         '${widget.noRef}', '${widget.noRef}.jpg', image!, 'image/jpg');
  //   });
  // }

  advicedownload() async {
    Map<Permission, PermissionStatus> statuses = await [
      Permission.photos,
      Permission.storage,
      Permission.camera
    ].request();
    print(statuses);
    if (await Permission.storage.request().isGranted &&
        await Permission.photos.request().isGranted &&
        await Permission.camera.request().isGranted) {
      adviceController
          .capture(pixelRatio: 3, delay: const Duration(milliseconds: 10))
          .then((image) async {
        var save = await ImageGallerySaver.saveImage(image!,
            name: "${widget.receiptItemTitle}");
        if (save != null && save.toString().isNotEmpty) {
          const DialogBox().showImageDialog(
            isError: false,
            onOk: () {
              Navigator.pop(context);
            },
            // image: Icon(
            //   Icons.camera_alt,
            //   color: Pallete.primary,
            // ),
            title: "Perhatian",
            buttonOk: "OK",
            context: context,
            message: "Berhasil unduh advice",
          );
        }
      }).catchError((onError) {
        print(onError);
      });
    } else {
      const DialogBox().showImageDialog(
        isError: true,
        onOk: () {
          Navigator.pop(context);
        },
        // image: Icon(
        //   Icons.camera_alt,
        //   color: Pallete.primary,
        // ),
        title: "Perhatian",
        buttonOk: "OK",
        context: context,
        message: "Gagal unduh advice",
      );
    }
  }

  ScreenshotController adviceController = ScreenshotController();

  ScreenshotController screenshotController = ScreenshotController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
          child: widget.transactionGroup == 'OPENINGDEPOSITO'
              ? Column(
                  children: <Widget>[
                    const SizedBox(height: 8),
                    Screenshot(
                      controller: screenshotController,
                      child: Container(
                        color: Colors.white,
                        // height: MediaQuery.of(context).size.height * 0.1,
                        child: Padding(
                          padding: const EdgeInsets.only(top: 8),
                          child: Column(
                            children: <Widget>[
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: const <Widget>[
                                  Expanded(
                                    flex: 1,
                                    child: Center(
                                      child: Image(
                                        image: AssetImage(
                                            'assets/images/bank-logo-green.png'),
                                        height: 40,
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    flex: 1,
                                    child: Center(
                                      child: Image(
                                        image: AssetImage(
                                            'assets/images/logo-app-green.png'),
                                        // color: Pallete.primary,
                                        height: 25,
                                      ),
                                    ),
                                  )
                                ],
                              ),
                              const SizedBox(height: 16),
                              Container(
                                padding:
                                    const EdgeInsets.only(left: 64, right: 64),
                                alignment: Alignment.center,
                                child: const Text(
                                  'PEMBUATAN DEPOSITO MUDHARABAH BERHASIL DILAKUKAN',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      color: Pallete.primary,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                              const SizedBox(height: 16),
                              Screenshot(
                                controller: adviceController,
                                child: Container(
                                  padding:
                                      const EdgeInsets.only(left: 8, right: 8),
                                  child: Stack(
                                      alignment: Alignment.center,
                                      children: <Widget>[
                                        Container(
                                          alignment: Alignment.center,
                                          child: Image.asset(
                                              'assets/images/depcerrjpg.jpg'),
                                        ),
                                        Column(children: <Widget>[
                                          // Container(
                                          //     padding:
                                          //         EdgeInsets.only(bottom: 8),
                                          //     alignment: Alignment.topCenter,
                                          //     // padding: const EdgeInsets.all(16),
                                          //     child: Text(
                                          //       widget.receiptItemTitle,
                                          //       style: TextStyle(
                                          //           decoration: TextDecoration
                                          //               .underline,
                                          //           fontSize: 12,
                                          //           fontWeight:
                                          //               FontWeight.bold,
                                          //           color: Pallete.primary),
                                          //       textAlign: TextAlign.center,
                                          //     )),
                                          Container(
                                              padding: const EdgeInsets.only(
                                                  right: 30),
                                              alignment: Alignment.topRight,
                                              // padding: const EdgeInsets.all(16),
                                              child: Text(
                                                widget.bilyet!,
                                                //  widget.noresi,
                                                style: const TextStyle(
                                                  fontSize: 8,
                                                ),
                                                textAlign: TextAlign.center,
                                              )),
                                          const SizedBox(
                                            height: 10,
                                          ),
                                          Container(
                                              padding: const EdgeInsets.only(
                                                  bottom: 8,
                                                  right: 16,
                                                  left: 16),
                                              alignment: Alignment.topCenter,
                                              // padding: const EdgeInsets.all(16),
                                              child: Text(
                                                widget.memo!,
                                                style: const TextStyle(
                                                    fontSize: 8,
                                                    color: Colors.black),
                                                textAlign: TextAlign.center,
                                              )),
                                          const SizedBox(
                                            height: 8,
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                left: 16.0,
                                                right: 16,
                                                bottom: 16),
                                            child: Column(
                                              children: _buildResiItems(),
                                            ),
                                          ),
                                          Container(
                                              padding: const EdgeInsets.only(
                                                  right: 30),
                                              alignment: Alignment.bottomRight,
                                              // padding: const EdgeInsets.all(16),
                                              child: const Text(
                                                'PT. Bank Aceh Syariah',
                                                //  widget.noresi,
                                                style: TextStyle(
                                                    fontSize: 8,
                                                    fontWeight:
                                                        FontWeight.bold),
                                                textAlign: TextAlign.center,
                                              )),
                                          const SizedBox(
                                            height: 8,
                                          ),
                                          Container(
                                              padding: const EdgeInsets.only(
                                                  left: 8),
                                              alignment: Alignment.bottomCenter,
                                              // padding: const EdgeInsets.all(16),
                                              child: Text(
                                                widget.additional!,
                                                //  widget.noresi,
                                                style: const TextStyle(
                                                  fontSize: 6,
                                                ),
                                                textAlign: TextAlign.left,
                                              )),
                                        ]),
                                      ]),
                                ),
                              ),
                              const SizedBox(height: 8),
                              Container(
                                alignment: Alignment.center,
                                child: const Text(
                                  'BUKTI SETORAN AWAL',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      color: Pallete.primary,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16),
                                ),
                              ),
                              const Padding(
                                padding: EdgeInsets.symmetric(horizontal: 16.0),
                                child: Divider(
                                  thickness: 1,
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 16.0),
                                child: Column(
                                  children: _buildItems(),
                                ),
                              ),
                              const SizedBox(height: 8),
                            ],
                          ),
                        ),
                      ),
                    ),
                    InkWell(
                        child: const Text('Unduh Advice',
                            style: TextStyle(
                                color: Pallete.primary,
                                fontWeight: FontWeight.bold)),
                        onTap: () {
                          // if(Platform.isIOS){
                          //   advicedownload();
                          // } else{}
                          // buildPDF();
                          // _testPDF();
                        }),
                    const SizedBox(height: 16),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16.0),
                      child: ISTOutlineButton(
                        text: 'Selesai',
                        onPressed: widget.onFinished as void Function()?,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.all(0),
                      width: double.maxFinite,
                      height: 50,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Expanded(
                            child: TextButton(
                              onPressed: () {
                                _saveImage();
                              },
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: const <Widget>[
                                  Icon(
                                    Icons.file_download,
                                    color: Pallete.primary,
                                  ),
                                  SizedBox(width: 4),
                                  Text(
                                    "Unduh",
                                    style: TextStyle(color: Pallete.primary),
                                  )
                                ],
                              ),
                            ),
                          ),
                          Expanded(
                            child: TextButton(
                              onPressed: () async {
                                final image =
                                    await screenshotController.capture();
                                if (image == null) return;
                                await saveAndShare(image);
                              },
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: const <Widget>[
                                  Icon(
                                    Icons.share,
                                    color: Pallete.primary,
                                  ),
                                  SizedBox(width: 4),
                                  Text(
                                    "Bagikan",
                                    style: TextStyle(color: Pallete.primary),
                                  )
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                )
              : widget.transactionGroup == 'OPENINGACCOUNT'
                  ? Column(
                      children: <Widget>[
                        const SizedBox(height: 8),
                        Screenshot(
                          controller: screenshotController,
                          child: Container(
                            color: Colors.white,
                            // height: MediaQuery.of(context).size.height * 0.1,
                            child: Padding(
                              padding: const EdgeInsets.only(top: 8),
                              child: Column(
                                children: <Widget>[
                                  Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: const <Widget>[
                                      Expanded(
                                        flex: 1,
                                        child: Center(
                                          child: Image(
                                            image: AssetImage(
                                                'assets/images/bank-logo-green.png'),
                                            height: 40,
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        flex: 1,
                                        child: Center(
                                          child: Image(
                                            image: AssetImage(
                                                'assets/images/logo-app-green.png'),
                                            // color: Pallete.primary,
                                            height: 25,
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                  const SizedBox(height: 16),
                                  Container(
                                    alignment: Alignment.center,
                                    child: const Text(
                                      'PEMBUATAN REKENING BARU',
                                      style: TextStyle(
                                          color: Pallete.primary,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                  Container(
                                    alignment: Alignment.center,
                                    child: const Text(
                                      'BERHASIL DILAKUKAN',
                                      style: TextStyle(
                                          color: Pallete.primary,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                  // Center(
                                  //   child: new Image.memory(_imageTabungan),
                                  // ),
                                  const SizedBox(height: 16),

                                  Container(
                                    padding: const EdgeInsets.only(
                                        left: 8, right: 8),
                                    child: Stack(
                                        alignment: Alignment.bottomCenter,
                                        children: <Widget>[
                                          Container(
                                            alignment: Alignment.center,
                                            child: Image.memory(_imageTabungan),
                                          ),
                                          Column(children: <Widget>[
                                            Container(
                                              alignment: Alignment.center,
                                              child: Text(
                                                StringUtils.getValueAsString(
                                                    widget.receiptItemTitle!),
                                                style: const TextStyle(
                                                  fontSize: 10,
                                                ),
                                                textAlign: TextAlign.center,
                                              ),
                                            ),
                                            const SizedBox(
                                              height: 8,
                                            ),
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  left: 16.0,
                                                  right: 16,
                                                  bottom: 16),
                                              child: Column(
                                                children: _buildResiItemsTab(),
                                              ),
                                            ),
                                            Container(
                                                padding: const EdgeInsets.only(
                                                    left: 16, bottom: 8),
                                                alignment: Alignment.bottomLeft,
                                                // padding: const EdgeInsets.all(16),
                                                child: Text(
                                                  StringUtils.getValueAsString(
                                                      widget.memo!),
                                                  style: const TextStyle(
                                                    fontSize: 6,
                                                  ),
                                                ))
                                          ]),
                                        ]),
                                  ),

                                  const SizedBox(height: 8),
                                  widget.status ==
                                              ISTReceiptStatusInbox.suspect &&
                                          widget.type == 'QRPAYMENT'
                                      ? Padding(
                                          padding: EdgeInsets.symmetric(
                                              horizontal: MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.35),
                                          child: ISTOutlineButton(
                                            color: Pallete.warning,
                                            text: 'Cek Status',
                                            onPressed:
                                                // _cekStatusQR();
                                                // ignore: unnecessary_statements
                                                widget.onCheck as void
                                                    Function()?,
                                          ),
                                        )
                                      : _changeStatus(),
                                  // FlatButton(
                                  //     onPressed: null,
                                  //     child: Text(
                                  //       "Cek Status",
                                  //       style: TextStyle(color: Pallete.WARNING),
                                  //     )),
                                  const SizedBox(height: 8),
                                  Container(
                                    alignment: Alignment.center,
                                    child: const Text(
                                      'BUKTI SETORAN AWAL',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                          color: Pallete.primary,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16),
                                    ),
                                  ),
                                  // Text(
                                  //   widget.amount,
                                  //   style: TextStyle(
                                  //       fontSize:
                                  //           Theme.of(context).textTheme.headline4.fontSize,
                                  //       fontWeight: FontWeight.w600),
                                  // ),
                                  const SizedBox(height: 8),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 16.0),
                                    child: Column(
                                      children: _buildItems(),
                                    ),
                                  ),
                                  // SizedBox(height: 8),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 16.0),
                                    child: widget.footer1,
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 16.0),
                                    child: widget.footer2,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.all(0),
                          width: double.maxFinite,
                          height: 50,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Expanded(
                                child: TextButton(
                                  onPressed: () {
                                    _saveImage();
                                  },
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: const <Widget>[
                                      Icon(
                                        Icons.file_download,
                                        color: Pallete.primary,
                                      ),
                                      SizedBox(width: 4),
                                      Text(
                                        "Unduh",
                                        style:
                                            TextStyle(color: Pallete.primary),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        // SizedBox(height: 16),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16.0),
                          child: ISTOutlineButton(
                            text: 'Selesai',
                            onPressed: widget.onFinished as void Function()?,
                          ),
                        ),
                        const SizedBox(height: 16),
                      ],
                    )
                  : Column(
                      children: <Widget>[
                        const SizedBox(height: 8),
                        Screenshot(
                          controller: screenshotController,
                          child: Container(
                            color: Colors.white,
                            // height: MediaQuery.of(context).size.height * 0.1,
                            child: Padding(
                              padding: const EdgeInsets.only(top: 8),
                              child: Column(
                                children: <Widget>[
                                  Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: const <Widget>[
                                      Expanded(
                                        flex: 1,
                                        child: Center(
                                          child: Image(
                                            image: AssetImage(
                                                'assets/images/bank-logo-green.png'),
                                            height: 40,
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        flex: 1,
                                        child: Center(
                                          child: Image(
                                            image: AssetImage(
                                                'assets/images/logo-app-green.png'),
                                            // color: Pallete.primary,
                                            height: 25,
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                  const SizedBox(height: 8),
                                  widget.transactionGroup ==
                                          'DISBURSEMENTDEPOSITO'
                                      ? Text(
                                          widget.titledepo!,
                                          style: const TextStyle(
                                              color: Pallete.primary,
                                              fontWeight: FontWeight.bold),
                                        )
                                      : const Text(
                                          'Status Transaksi',
                                          style:
                                              TextStyle(color: Pallete.primary),
                                        ),
                                  Center(
                                    child: Image(
                                      image: AssetImage(widget.status ==
                                              ISTReceiptStatusInbox.suspect
                                          ? "assets/images/icon-warning.png"
                                          : widget.status ==
                                                  ISTReceiptStatusInbox.failed
                                              ? "assets/images/icon-failed.png"
                                              : 'assets/images/icon-success.png'),
                                      height: 100,
                                    ),
                                  ),
                                  Container(
                                      child: widget.status ==
                                              ISTReceiptStatusInbox.suspect
                                          ? const Text('Sedang diproses',
                                              style: TextStyle(
                                                  color: Colors.orange))
                                          : widget.status ==
                                                  ISTReceiptStatusInbox.failed
                                              ? const Text('Gagal',
                                                  style: TextStyle(
                                                      color: Colors.red))
                                              : const Text('Berhasil',
                                                  style: TextStyle(
                                                      color: Pallete.primary))),
                                  const SizedBox(height: 8),
                                  widget.status ==
                                              ISTReceiptStatusInbox.suspect &&
                                          widget.titleresi == "Qris Issuer"
                                      ? Padding(
                                          padding: EdgeInsets.symmetric(
                                              horizontal: MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.35),
                                          child: ISTOutlineButton(
                                            color: Pallete.warning,
                                            text: 'Cek Status',
                                            onPressed: widget.onCheck as void
                                                Function()?,
                                          ),
                                        )
                                      : _changeStatus(),
                                  const SizedBox(height: 8),
                                  // Text(widget.title),
                                  widget.transactionGroup == 'CLOSINGACCOUNT' &&
                                          widget.title == null &&
                                          widget.titleresi == null &&
                                          widget.titleresi1 == null
                                      ? const Text(
                                          'PENUTUPAN REKENING TABUNGAN',
                                          textAlign: TextAlign.center,
                                        )
                                      : widget.title == null
                                          ? widget.titleresi == "Qris Issuer"
                                              ? Text(
                                                  widget.titleresi1!,
                                                  textAlign: TextAlign.center,
                                                )
                                              : Text(
                                                  widget.titleresi!,
                                                  textAlign: TextAlign.center,
                                                )
                                          : Text(
                                              widget.title!,
                                              textAlign: TextAlign.center,
                                            ),
                                  // Text(
                                  //   widget.title,
                                  //   textAlign: TextAlign.center,
                                  // ),
                                  // widget.titleresi == 'QR Issuer'
                                  // ? Text(
                                  //  widget.titleresi1,
                                  //  textAlign: TextAlign.center,
                                  // ) : Text(
                                  //   widget.title,
                                  //   textAlign: TextAlign.center,
                                  // ),
                                  Text(
                                    widget.amount!,
                                    style: TextStyle(
                                        fontSize: Theme.of(context)
                                            .textTheme
                                            .headline4!
                                            .fontSize,
                                        fontWeight: FontWeight.w600),
                                  ),

                                  // widget.title == null
                                  //     ? widget.titleresi == "Qris Issuer"
                                  //         ? widget.transactionGroup ==
                                  //                 'CLOSINGACCOUNT'
                                  //             ? Text(
                                  //                 widget.titleresi1,
                                  //                 textAlign: TextAlign.center,
                                  //               )
                                  //             : Text(
                                  //                 widget.titleresi,
                                  //                 textAlign: TextAlign.center,
                                  //               )
                                  //         : Text(
                                  //             widget.jenistabungan,
                                  //             textAlign: TextAlign.center,
                                  //           )
                                  //     : Text(
                                  //         widget.title,
                                  //         textAlign: TextAlign.center,
                                  //       ),
                                  // // widget.titleresi == 'QR Issuer'
                                  // // ? Text(
                                  // //  widget.titleresi1,
                                  // //  textAlign: TextAlign.center,
                                  // // ) : Text(
                                  // //   widget.title,
                                  // //   textAlign: TextAlign.center,
                                  // // ),
                                  // widget.amount != null &&
                                  //         widget.amount == 'IDR O.00'
                                  //     ? Text(
                                  //         widget.amount,
                                  //         style: TextStyle(
                                  //             fontSize: Theme.of(context)
                                  //                 .textTheme
                                  //                 .headline4
                                  //                 .fontSize,
                                  //             fontWeight: FontWeight.w600),
                                  //       )
                                  //     : Container(),
                                  const SizedBox(height: 8),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 16.0),
                                    child: Column(
                                      children: _buildItems(),
                                    ),
                                  ),
                                  widget.listdetail != null &&
                                          widget.titleresi == 'PDAM'
                                      ? Padding(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 16.0),
                                          child: Container(
                                              alignment: Alignment.topLeft,
                                              child: const Text(
                                                  'Rincian Periode',
                                                  textAlign: TextAlign.left)))
                                      : Container(),
                                  widget.listdetail != null &&
                                          widget.titleresi == 'PDAM'
                                      ? const SizedBox(height: 8)
                                      : Container(),

                                  widget.listdetail != null &&
                                          widget.listdetail!.length == 1
                                      ? SizedBox(
                                          height: 110,
                                          child: buildItemtest(),
                                        )
                                      : Container(),
                                  widget.listdetail != null &&
                                          widget.listdetail!.length == 2
                                      ? SizedBox(
                                          height: 224,
                                          child: buildItemtest(),
                                        )
                                      : Container(),
                                  widget.listdetail != null &&
                                          widget.listdetail!.length == 3
                                      ? SizedBox(
                                          height: 340,
                                          child: buildItemtest(),
                                        )
                                      : Container(),

                                  // const SizedBox(height: 8),
                                  widget.listtotalbayar != null
                                      ? Padding(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 16.0),
                                          child: Column(
                                              children: _buildResitotal()),
                                        )
                                      : const SizedBox.shrink(),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 16.0, vertical: 0),
                                    child: Column(
                                      children: _generatedList(),
                                    ),
                                  ),
                                  // Container(
                                  //   height: 150,
                                  //   child: buildItemtest()),
                                  // Padding(
                                  //   padding: const EdgeInsets.symmetric(
                                  //       horizontal: 16.0),
                                  //   child: widget.footer1,
                                  // ),
                                  widget.footer1 != null
                                      ? Container(child: widget.footer1)
                                      : const SizedBox.shrink(),
                                  widget.titleresi == "LinkAja"
                                      ? const SizedBox.shrink()
                                      : Container(child: widget.footer2)
                                  // Padding(
                                  //   padding: const EdgeInsets.symmetric(
                                  //       horizontal: 16.0),
                                  //   child: widget.footer2,
                                  // )
                                ],
                              ),
                            ),
                          ),
                        ),
                        widget.titleresi == "Pesawat Garuda Indonesia" ||
                                widget.titleresi == "Kereta Api Indonesia" ||
                                widget.titleresi == "Samsat Aceh" ||
                                widget.titleresi ==
                                    "e-Setor Pemkot Banda Aceh" ||
                                widget.titleresi == "Universitas Teuku Umar" ||
                                widget.titleresi == "Citilink" ||
                                widget.titleresi == "UIN AR Raniry" ||
                                widget.titleresi == "Lion" ||
                                widget.transactionGroup ==
                                    "DISBURSEMENTDEPOSITO" ||
                                widget.transactionGroup == "CLOSINGACCOUNT"
                            // widget.titleresi == "Qris Issuer"
                            ? const SizedBox.shrink()
                            : widget.titleresi == "Qris Issuer"
                                ? const SizedBox.shrink()
                                : ISTFlatButton(
                                    onPressed: () {
                                      const DialogBox().showImageDialog(
                                          message:
                                              "Apakah anda yakin akan di simpan ke favorit",
                                          buttonOk: 'Setuju',
                                          buttonCancel: "Batal",
                                          isError: false,
                                          image: const Image(
                                            image: AssetImage(
                                                'assets/images/icon-warning.png'),
                                          ),
                                          onOk:
                                              widget.onTap as void Function()?,
                                          context: context);
                                      // ignore: todo
                                      //TODO FAVORITE
                                    },
                                    text: 'Simpan ke favorit',
                                    color: Pallete.primary,
                                  ),
                        const SizedBox(height: 4),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16.0),
                          child: ISTOutlineButton(
                            text: 'Selesai',
                            onPressed: widget.onFinished as void Function()?,
                          ),
                        ),
                        const SizedBox(height: 16),
                        Container(
                          padding: const EdgeInsets.all(0),
                          width: double.maxFinite,
                          height: 50,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Expanded(
                                child: TextButton(
                                  onPressed: () {
                                    if (_firstPress == true) {
                                      _saveImage();
                                    }
                                    setState(() {
                                      _firstPress = false;
                                    });
                                  },
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: const <Widget>[
                                      Icon(
                                        Icons.file_download,
                                        color: Pallete.primary,
                                      ),
                                      SizedBox(width: 4),
                                      Text(
                                        "Unduh",
                                        style:
                                            TextStyle(color: Pallete.primary),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                              Expanded(
                                child: TextButton(
                                  onPressed: () async {
                                    final image =
                                        await screenshotController.capture();
                                    if (image == null) return;
                                    await saveAndShare(image);
                                  },
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: const <Widget>[
                                      Icon(
                                        Icons.share,
                                        color: Pallete.primary,
                                      ),
                                      SizedBox(width: 4),
                                      Text(
                                        "Bagikan",
                                        style:
                                            TextStyle(color: Pallete.primary),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    )),
    );
  }
}
