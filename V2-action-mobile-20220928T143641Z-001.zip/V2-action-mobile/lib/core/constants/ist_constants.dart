import 'package:bpd_aceh/core/crypto/ist_crypto.dart';
import 'package:flutter_masked_text2/flutter_masked_text2.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum IST_ENDPOINT { uat, sit }

class ISTConstants {
   static const appVersion = '0.22.3';  //DEV/SITANDRO///30DEC2020/
  static const buildVersion = '27';

  // static const appVersion = '0.21.3';  //DEV/SITIOS///16DEC2020//

  // static const appVersion = '0.9.0'; //UAT//TESTFLIGHT/25SEP2020
  // static const appVersion = '0.9.1'; //PROD//.AAB//.IPA //25SEP2020

  // static const appVersion = '1.1.0'; //PROD AAB+16 IPA+1 14DES2021
  // static const buildVersion = '17';

  // static const appVersion = '1.0.3'; //PROD AAB IPA 14DES2021
  // static const buildVersion = '1';

  // static const appVersion = '1.0.2'; //UAT//TESTFLIGHT/12APR2021/BUILD6/PROD
  // static const appVersion = '1.0.3'; //preTO

  static const version = 'M4Uo74WjguQb/123678vvvEgId0pvGPxlW4IuHec=';
  static const hasRegistered = 'M4Uo74WjguQb/123678gfbhgVEgId0pvGPxlW4IuHec=';
  static const authCookie = 'M4Uo74WjguQb/8m6u8BAaAkgVEgId0pvGPxlW4IuHec=';
  static const agreeTermsAndCondition =
      'YdzfZXxv67gTybP+snjdghrtygfB9HD1PeRhfUu/GK5zDz0=';
  static const authWasLoggedIn = 'YdzfZXxHyn41Pc+YCj0/0kfB9HD1PeRhfUu/GK5zDz0=';
  static const loggedInKey = 'HygwejlPc+YCj0/0kfB9HD1PeRhfUu/GK5zDz0=';
  static const nominalMaxLength = 13;
  static const biometricsTermsAndCondition =
      'YdzfZXxHyn41Pc+YCasJKONNkfB9HD1PeRhfUu/GK5zDz0=';
  static const biometricStatus =
      'YdzfZXxvnjt587c+YCasJKONNkfB9HD1PeRhfUu/GK5zDz0=';
  static const handphoneMaxLength = 14;
  static const acctToMaxLength = 20;
  static const refPelangganMaxLength = 16;
  static const catatanMaxLength = 25;
  static const passwordMaxLength = 25;
  static const catatanTrfMaxLength = 100;

  static const mpinCreate = '56gtYXxvnjt587c+YCasJKONNkfB9HD1PeRhfUu/GK5zDz0=';
  static const mpinForgot = 'YdzfZXxv67gTybP+YCasJKONNkfB9HD1PeRhfUu/GK5zDz0=';
  static const mpinChange = 'YdzfZXxvnjt587c+YCasJKONNkfB9HD176YhgIOGK5zDz0=';
  static const acctNumber = 'YdzfZXxvnjt587cyUhbNjYkfB9HD176YhgIOGK5zDz0=';
  static const acctName = 'YdzfZXxvnjt587c+YCasJKOJL)98Uhjdh6YhgIOGK5zDz0=';
  static const showBalance = 'false';

  final MoneyMaskedTextController moneyMaskedController =
      MoneyMaskedTextController(
    thousandSeparator: ',',
    decimalSeparator: '',
    initialValue: 0,
    precision: 0,
  );

  Future<SharedPreferences> instance() async {
    var pref = await SharedPreferences.getInstance();
    return pref;
  }

  dynamic getConstants(dynamic key) async {
    Object? ret;
    var pref = await SharedPreferences.getInstance();
    ret = pref.get(key);
    return ret;
  }

  setConstants(dynamic key, dynamic value) {
    if (value.runtimeType.toString() == 'String') {
      instance().then((pref) {
        pref.setString(key, value);
      });
      return;
    }
    if (value.runtimeType.toString() == 'bool') {
      instance().then((pref) {
        pref.setBool(key, value);
      });
      return;
    }
    if (value.runtimeType.toString() == 'double') {
      instance().then((pref) {
        pref.setDouble(key, value);
      });
      return;
    }
    if (value.runtimeType.toString() == 'int') {
      instance().then((pref) {
        pref.setInt(key, value);
      });
      return;
    }
  }

  setString(dynamic key, String? value) async {
    instance().then((pref) async {
      if (value!.isNotEmpty) {
        String enc = await ISTCrypto.encryptAES(value);
        pref.setString(key, enc);
      } else {
        pref.setString(key, value);
      }
    });
  }

  Future<String?> getString(dynamic key) async {
    String clear = "";
    var pref = await SharedPreferences.getInstance();
    var val = pref.getString(key);
    if (val != null && val.isNotEmpty) {
      clear = await ISTCrypto.decryptAES(val);
      return clear;
    } else {
      return val;
    }
  }
}
