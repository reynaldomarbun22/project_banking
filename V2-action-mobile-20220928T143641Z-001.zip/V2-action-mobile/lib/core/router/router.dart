import 'package:bpd_aceh/features/home/home_page.dart';
import 'package:bpd_aceh/features/home/widgets/home_widget.dart';
import 'package:bpd_aceh/features/home/widgets/other_widget.dart';
import 'package:bpd_aceh/features/inbox/page/inbox.dart';
import 'package:bpd_aceh/features/inbox/page/resi_inbox.dart';
import 'package:bpd_aceh/features/inboxinformasi/page/tab_bar_information.dart';
import 'package:bpd_aceh/features/jadwalsholat/page/jadwal_sholat.dart';
import 'package:bpd_aceh/features/landing/landing.dart';
import 'package:bpd_aceh/features/login/afterUnlinkDevice/afterunlinkpage1.dart';
import 'package:bpd_aceh/features/login/afterUnlinkDevice/otp_afterunlink.dart';
import 'package:bpd_aceh/features/login/creatempin/confirm_mpin.dart';
import 'package:bpd_aceh/features/login/creatempin/create_mpin.dart';
import 'package:bpd_aceh/features/login/forgotUsername/forgot_username.dart';
import 'package:bpd_aceh/features/login/forgotUsername/otp_forgot_username.dart';
import 'package:bpd_aceh/features/login/forgotmpin/confirm_new_mpin.dart';
import 'package:bpd_aceh/features/login/forgotmpin/forgot_mpin.dart';
import 'package:bpd_aceh/features/login/forgotmpin/new_mpin.dart';
import 'package:bpd_aceh/features/login/forgotmpin/otp_forgot_mpin.dart';
import 'package:bpd_aceh/features/login/forgotpassword/forgot_password.dart';
import 'package:bpd_aceh/features/login/forgotpassword/new_password.dart';
import 'package:bpd_aceh/features/login/forgotpassword/otp_forgot_pass.dart';
import 'package:bpd_aceh/features/login/linkNewDevice/link_new_device_step1.dart';
import 'package:bpd_aceh/features/login/linkNewDevice/link_new_device_step2.dart';
import 'package:bpd_aceh/features/login/login.dart';
import 'package:bpd_aceh/features/onboarding/pages/onboarding_page.dart';
import 'package:bpd_aceh/features/other/ChangeMPIN/pages/change_mpin.dart';
import 'package:bpd_aceh/features/other/ChangeMPIN/pages/confirm_change_mpin.dart';
import 'package:bpd_aceh/features/other/ChangeMPIN/pages/input_new_mpin.dart';
import 'package:bpd_aceh/features/other/ChangePassword/change_password.dart';
import 'package:bpd_aceh/features/other/FAQ/pages/faq.dart';
import 'package:bpd_aceh/features/other/biometric/pages/biometric_snk.dart';
import 'package:bpd_aceh/features/other/contactUS/pages/contact_us.dart';
import 'package:bpd_aceh/features/other/daftarFavorit/pages/daftar_favorit.dart';
import 'package:bpd_aceh/features/other/rekeningku/page/home_rekeningku.dart';
import 'package:bpd_aceh/features/other/rekeningku/pembukaanRekening/new_rekening_screen.dart';
import 'package:bpd_aceh/features/other/rekeningku/pembukaanRekening/PembukaanDeposito/confirm_deposito.dart';
import 'package:bpd_aceh/features/other/rekeningku/pembukaanRekening/PembukaanDeposito/deposito_mpin.dart';
import 'package:bpd_aceh/features/other/rekeningku/pembukaanRekening/PembukaanDeposito/pembukaan_deposito.dart';
import 'package:bpd_aceh/features/other/rekeningku/pembukaanRekening/PembukaanDeposito/snk_deposito.dart';
import 'package:bpd_aceh/features/other/rekeningku/pembukaanRekening/PembukaanTabungan/confirm_page.dart';
import 'package:bpd_aceh/features/other/rekeningku/pembukaanRekening/PembukaanTabungan/mpin_pembukaan_tabungan.dart';
import 'package:bpd_aceh/features/other/rekeningku/pembukaanRekening/PembukaanTabungan/pembukaan_tabungan.dart';
import 'package:bpd_aceh/features/other/rekeningku/pembukaanRekening/PembukaanTabungan/receipt_pembukaan.dart';
import 'package:bpd_aceh/features/other/rekeningku/pembukaanRekening/PembukaanTabungan/snk_pembukaan_tabungan.dart';
import 'package:bpd_aceh/features/other/rekeningku/pencairanDeposito/mpin_pencairan_deposito.dart';
import 'package:bpd_aceh/features/other/rekeningku/pengaturanRekening/page/setting_rekening.dart';
import 'package:bpd_aceh/features/other/rekeningku/pengaturanRekening/page/input_rekening.dart';
import 'package:bpd_aceh/features/other/rekeningku/pengaturanRekening/page/rekening_input.dart';
import 'package:bpd_aceh/features/other/rekeningku/pengaturanRekening/page/rekeningku_mpin.dart';
import 'package:bpd_aceh/features/other/rekeningku/pengaturanRekening/remove_mpin.dart';
import 'package:bpd_aceh/features/other/rekeningku/penutupanRekening/confirm_penutupan_rek.dart';
import 'package:bpd_aceh/features/other/rekeningku/penutupanRekening/mpin_penutupan_rek.dart';
import 'package:bpd_aceh/features/other/rekeningku/penutupanRekening/receipt_penutupan_rek.dart';
import 'package:bpd_aceh/features/other/snk/syaratketentuan.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/asuransi_page.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/emoney_page.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/internet_page.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PBB/confirm_item_pbb.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PBB/page_tahun.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PBB/confirm_pbb.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PBB/inquiri_pbb.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PBB/mpin_pbb.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PBB/receipt_pbb.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PDAM/pdam.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PDAM/tirtadaroy/pdam_confirmation.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PDAM/tirtadaroy/confirm_tirtadaroy.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PDAM/tirtadaroy/confirm_new_tirtadaroy.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PDAM/tirtadaroy/inq_tirtadaroy.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PDAM/tirtadaroy/mpin_tirtadaroy.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PDAM/tirtadaroy/receipt_tirtadaroy.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PLN/pascabayarPLN/plnmpin.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PLN/pascabayarPLN/pln_receipt.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PLN/pascabayarPLN/plnconfirm.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PLN/pascabayarPLN/plninqury.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PLN/pln_screen.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PLN/prabayarPLN.dart/pln_mpin.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PLN/prabayarPLN.dart/pln_receipt.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PLN/prabayarPLN.dart/plnconfirm.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PLN/prabayarPLN.dart/plninqury.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/telepon_page.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/Telkom/IndiHome/confirmation_page_indihome.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/Telkom/IndiHome/indihome_mpin.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/Telkom/IndiHome/indihome_page.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/Telkom/IndiHome/indihome_receipt.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/Telkom/Telepon_Rumah/confirmation_page_telepon_rumah.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/Telkom/Telepon_Rumah/telepon_rumah_mpin.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/Telkom/Telepon_Rumah/telepon_rumah_page.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/Telkom/Telepon_Rumah/telepon_rumah_receipt.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/Universitas/ArRaniry/ar_raniry_receipt.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/Universitas/ArRaniry/ar_raniry_mpin.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/Universitas/ArRaniry/ar_raniry_page.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/Universitas/ArRaniry/confirmation_page_ar_raniry.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/Universitas/TeukurUmar/confirmation_page_teuku_umar.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/Universitas/TeukurUmar/teuku_umar_mpin.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/Universitas/TeukurUmar/teuku_umar_page.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/Universitas/TeukurUmar/teuku_umar_receipt.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/Universitas/universitas_screen.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/zis_page.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/asuransi/asuransi.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/asuransi/bpjs/confirmation_bpjs.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/asuransi/bpjs/inq_bpjs.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/asuransi/bpjs/mpin_bpjs.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/asuransi/bpjs/receipt_bpjs.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/favorite/favoritepayment.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/infaq/Infaq_BaitulMalAceh/confirmation_page_infaq_baitul_mall.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/infaq/Infaq_BaitulMalAceh/infaq_baitul_mal_aceh_mpin.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/infaq/Infaq_BaitulMalAceh/infaq_baitul_mal_aceh_receipt.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/infaq/Infaq_BaitulMalAceh/infaq_baitul_mal_aceh.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/infaq/infaq_screen.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/pajakretribusi.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/pembayaran_screen.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/pemda/e_setor.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/pemda/e_setor_confirm.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/pemda/e_setor_mpin.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/pemda/e_setor_receipt.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/pemda/pemkotscreen.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/pendidikan.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/pulsa_pascabayar/pascabayar_confirm.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/pulsa_pascabayar/pascabayar_mpin.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/pulsa_pascabayar/pascabayar_page.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/pulsa_pascabayar/pascabayar_receipt.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/samsat/confirmsamsat.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/samsat/mpinsamsat.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/samsat/receiptsamsat.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/samsat/samsat.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/keretaapi/kai/confirm_kai.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/keretaapi/kai/inq_kai.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/keretaapi/kai/mpin_kai.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/keretaapi/kai/receipt_kai.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/keretaapi/keretaapi.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/keretaapi/railink/confirm_railink.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/keretaapi/railink/inq_railink.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/keretaapi/railink/mpin_railink.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/keretaapi/railink/receipt_railink.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/pesawat/citilink/confirm_citilink.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/pesawat/citilink/inq_citilink.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/pesawat/citilink/mpin_citilink.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/pesawat/citilink/receipt_citilink.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/pesawat/garuda/confirm_garuda.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/pesawat/garuda/inq_garuda.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/pesawat/garuda/mpin_garuda.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/pesawat/garuda/receipt_garuda.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/pesawat/lion/confirmation_lion.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/pesawat/lion/inqury_lion.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/pesawat/lion/mpin_lion.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/pesawat/lion/receipt_lion.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/pesawat/pesawat.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/transportasipage.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/tvberlangganan/mnc%20vision/confirm_mnc.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/tvberlangganan/mnc%20vision/inquiry_mnc.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/tvberlangganan/mnc%20vision/mpin_mnc.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/tvberlangganan/mnc%20vision/receipt_mnc.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/tvberlangganan/transvision/confirmationtransvision.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/tvberlangganan/transvision/transvision.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/tvberlangganan/transvision/transvisionmpin.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/tvberlangganan/transvision/transvisionreceipt.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/tvberlangganan/tvberlanggananscreen.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/zakat/Baitul/confirmZakatBaitul/confirmation_page_zakat_baitul_mall.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/zakat/Baitul/mpinBaitul/mpin_baitul.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/zakat/Baitul/zakatBaitulReceipt/receipt_baitul.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/zakat/Baitul/zakat_baitul_mall_aceh.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/zakat/zakat_screen.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/Paket_Data/confirmation_page_paketdata.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/Paket_Data/inq_paketdata/confirmpaket.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/Paket_Data/inq_paketdata/datapaket.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/Paket_Data/inq_paketdata/inquiripaket.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/Paket_Data/inq_paketdata/mpinpaket.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/Paket_Data/inq_paketdata/receiptpaket.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/Paket_Data/pembelian_paket_data.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/Pulsa/TSEL/pulsa_mpin_page.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/Pulsa/TSEL/pulsa_receipt.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/Pulsa/TSEL/confirmation_page_pulsa.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/Pulsa/TSEL/pembelian_pulsa_fix.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/topup/gopay/confirm_gopay.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/topup/gopay/inqury_gopay.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/topup/gopay/mpin_gopay.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/topup/gopay/receipt_gopay.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/topup/linkAja/confirm_link_aja.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/topup/linkAja/inqury_link_aja.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/topup/linkAja/mpin_link_aja.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/topup/linkAja/receipt_link_aja.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/topup/ovo/confirm_ovo.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/topup/ovo/inqury_ovo.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/topup/ovo/mpin_ovo.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/topup/ovo/receipt_ovo.dart';
import 'package:bpd_aceh/features/promo/promo.dart';
import 'package:bpd_aceh/features/qrpayment/confirm_merchant_page.dart';
import 'package:bpd_aceh/features/qrpayment/mpin_payment_qr.dart';
import 'package:bpd_aceh/features/qrpayment/payment_qr.dart';
import 'package:bpd_aceh/features/qrpayment/receipt_payment_qr.dart';
import 'package:bpd_aceh/features/qrtransfer/qrcode.dart';
import 'package:bpd_aceh/features/qrtransfer/qrimages.dart';
import 'package:bpd_aceh/features/qrtransfer/scanqrtransfer.dart';
import 'package:bpd_aceh/features/qrtransfer/transferqrbas.dart';
import 'package:bpd_aceh/features/statements/statements.dart';
import 'package:bpd_aceh/features/termcondition/terms_condition.dart';

import 'package:bpd_aceh/features/register/reg_step1/reg_step1.dart';
import 'package:bpd_aceh/features/register/reg_step1/register_step1.dart';
import 'package:bpd_aceh/features/register/reg_step2/reg_step2.dart';
import 'package:bpd_aceh/features/register/reg_step3/reg_step3.dart';

import 'package:bpd_aceh/features/register/reg_step3/register_step3.dart';
import 'package:bpd_aceh/features/register/reg_step4/reg_step4.dart';
import 'package:bpd_aceh/features/register/reg_step4/register_step4.dart';
import 'package:bpd_aceh/features/register/registration.dart';
import 'package:bpd_aceh/features/transfer/favorite/favorite_page.dart';
import 'package:bpd_aceh/features/transfer/transferAntarBAS/confrimBAS/transfer_confirm_bas.dart';
import 'package:bpd_aceh/features/transfer/transferAntarBAS/inquiryBAS/transferinq_bas.dart';
import 'package:bpd_aceh/features/transfer/transferAntarBAS/mpinBAS/transfer_mpin_bas.dart';
import 'package:bpd_aceh/features/transfer/transferAntarBAS/receiptBAS.dart/transfer_receipt_bas.dart';
import 'package:bpd_aceh/features/transfer/transferBankLain/confirmBL/transfer_confirm_bl.dart';
import 'package:bpd_aceh/features/transfer/transferBankLain/inquiryBL/transfer_bank_lain.dart';
import 'package:bpd_aceh/features/transfer/transferBankLain/mpinBL/transfer_mpin_bank_lain.dart';
import 'package:bpd_aceh/features/transfer/transferBankLain/receiptBL/transfer_receipt.dart';
import 'package:bpd_aceh/features/transfer/transferRTGS/confirmRTGS/transfer_confirm_rtgs.dart';
import 'package:bpd_aceh/features/transfer/transferRTGS/inquiryRTGS/transfer_rtgs.dart';
import 'package:bpd_aceh/features/transfer/transferRTGS/mpinRTGS/transfer_mpin_rtgs.dart';
import 'package:bpd_aceh/features/transfer/transferRTGS/receiptRTGS/transfer_receipt_rtgs.dart';
import 'package:bpd_aceh/features/transfer/transferSKN/confirmSKN/transfer_confirm_skn.dart';
import 'package:bpd_aceh/features/transfer/transferSKN/inquirySKN/transfer_skn.dart';
import 'package:bpd_aceh/features/transfer/transferSKN/jenisPenerima/jenis_penerima.dart';
import 'package:bpd_aceh/features/transfer/transferSKN/mpinSKN/transfer_mpin_skn.dart';
import 'package:bpd_aceh/features/transfer/transferSKN/receiptSKN/transfer_receipt.dart';
import 'package:bpd_aceh/features/transfer/transferSKN/statusPenduduk/status_penduduk.dart';
import 'package:bpd_aceh/features/transfer/transferSKN/tujuanTransaksi/tujuan_transaksi.dart';

import 'package:flutter/material.dart';

class RouteGenerator {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case TermsAndCondition.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: TermsAndCondition.routeName),
            builder: (_) => const TermsAndCondition());
      case OnBoarding.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: OnBoarding.routeName),
            builder: (_) => const OnBoarding());
      case LandingPageScreen.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: LandingPageScreen.routeName),
            builder: (_) => const LandingPageScreen());
      case LoginPage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: LoginPage.routeName),
            builder: (_) => const LoginPage());
      case HomePage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: HomePage.routeName),
            builder: (_) => const HomePage());
      case DashBoardHomePage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: DashBoardHomePage.routeName),
            builder: (_) => const DashBoardHomePage());

      // Registration
      case Registration.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: Registration.routeName),
            builder: (_) => const Registration());
      case RegStep1.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: RegStep1.routeName),
            builder: (_) => const RegStep1());
      case Reg2.routeName:
        Map<String, Object>? param = settings.arguments as Map<String, Object>?;
        return MaterialPageRoute(
            settings: const RouteSettings(name: Reg2.routeName),
            builder: (_) => Reg2(param: param));
      case Reg3.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: Reg3.routeName),
            builder: (_) => const Reg3());
      case Reg4.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: Reg4.routeName),
            builder: (_) => const Reg4());
      case RegisterStep1.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: RegisterStep1.routeName),
            builder: (_) => const RegisterStep1());
      case RegisterStep3.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: RegisterStep3.routeName),
            builder: (_) => const RegisterStep3());
      case RegisterStep4.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: RegisterStep4.routeName),
            builder: (_) => const RegisterStep4());

      // After Unlink
      case AfterUnlinkStep1.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: AfterUnlinkStep1.routeName),
            builder: (_) => const AfterUnlinkStep1());
      case AfterUnlinkOTP.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: AfterUnlinkOTP.routeName),
            builder: (_) => const AfterUnlinkOTP());

      // Informasi Terkini
      case TabBarInform.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: TabBarInform.routeName),
            builder: (_) => const TabBarInform());

      // Jadwal Sholat
      case SchedulePray.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: SchedulePray.routeName),
            builder: (_) => const SchedulePray());

      // Telepon
      case TeleponScreen.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: TeleponScreen.routeName),
            builder: (_) => const TeleponScreen());

      // Pulsa
      case PembelianPulsa.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: PembelianPulsa.routeName),
            builder: (_) => const PembelianPulsa());
      case ConfirmationPagePulsa.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: ConfirmationPagePulsa.routeName),
            builder: (_) => const ConfirmationPagePulsa());
      case PulsaMpinPage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: PulsaMpinPage.routeName),
            builder: (_) => const PulsaMpinPage());
      case PulsaReceiptPage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: PulsaReceiptPage.routeName),
            builder: (_) => const PulsaReceiptPage());

      // Pascabayar
      case PascaBayarPage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: PascaBayarPage.routeName),
            builder: (_) => const PascaBayarPage());
      case PascaBayarConfirmation.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: PascaBayarConfirmation.routeName),
            builder: (_) => const PascaBayarConfirmation());
      case PascaBayarMPIN.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: PascaBayarMPIN.routeName),
            builder: (_) => const PascaBayarMPIN());
      case PascaBayarReceipt.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: PascaBayarReceipt.routeName),
            builder: (_) => const PascaBayarReceipt());

      // Rekeningku
      case HomeRekeningKU.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: HomeRekeningKU.routeName),
            builder: (_) => const HomeRekeningKU());

      // Pembukaan Deposito
      case ConfirmPembukaanDeposito.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: ConfirmPembukaanDeposito.routeName),
            builder: (_) => const ConfirmPembukaanDeposito());
      case MpinDeposito.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: MpinDeposito.routeName),
            builder: (_) => const MpinDeposito());
      case SnKDeposito.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: SnKDeposito.routeName),
            builder: (_) => const SnKDeposito());
      case PembukaanDeposito.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: PembukaanDeposito.routeName),
            builder: (_) => const PembukaanDeposito());

      // Pembukaan Rekening
      case ConfirmPembukaanRekening.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: ConfirmPembukaanRekening.routeName),
            builder: (_) => const ConfirmPembukaanRekening());
      case MpinPembukaanRekening.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: MpinPembukaanRekening.routeName),
            builder: (_) => const MpinPembukaanRekening());

      // Pembukaan Tabungan
      case PembukaanTabungan.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: PembukaanTabungan.routeName),
            builder: (_) => const PembukaanTabungan());
      case ReceiptPembukaanRekenig.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: ReceiptPembukaanRekenig.routeName),
            builder: (_) => const ReceiptPembukaanRekenig());
      case SnKTabungan.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: SnKTabungan.routeName),
            builder: (_) => const SnKTabungan());
      case PembukaanRekeningPage.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: PembukaanRekeningPage.routeName),
            builder: (_) => const PembukaanRekeningPage());
      case MpinPencairanDeposito.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: MpinPencairanDeposito.routeName),
            builder: (_) => const MpinPencairanDeposito());
      case RemoveMPIN.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: RemoveMPIN.routeName),
            builder: (_) => const RemoveMPIN());
      case InputRek.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: InputRek.routeName),
            builder: (_) => const InputRek());
      case RekeningInput.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: RekeningInput.routeName),
            builder: (_) => const RekeningInput());
      case RekeningKUMPIN.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: RekeningKUMPIN.routeName),
            builder: (_) => const RekeningKUMPIN());
      case SettingRek.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: SettingRek.routeName),
            builder: (_) => const SettingRek());

      // Penutupan Rekening
      case ConfirmationPenutupanRek.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: ConfirmationPenutupanRek.routeName),
            builder: (_) => const ConfirmationPenutupanRek());
      case MPINPenutupanRekening.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: MPINPenutupanRekening.routeName),
            builder: (_) => const MPINPenutupanRekening());
      case ReceiptPenutupanRekening.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: ReceiptPenutupanRekening.routeName),
            builder: (_) => const ReceiptPenutupanRekening());

      // Inbox
      case Inbox.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: Inbox.routeName),
            builder: (_) => const Inbox());
      case ResiInbox.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: ResiInbox.routeName),
            builder: (_) => const ResiInbox());

      // Promo
      case Promo.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: Promo.routeName),
            builder: (_) => const Promo());

      //PLN Listrik Pascabayar
      case ListrikScreen.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: ListrikScreen.routeName),
            builder: (_) => const ListrikScreen());
      case ListrikPascaBayarPage.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: ListrikPascaBayarPage.routeName),
            builder: (_) => const ListrikPascaBayarPage());
      case ListrikConfirmationPascabayar.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(
                name: ListrikConfirmationPascabayar.routeName),
            builder: (_) => const ListrikConfirmationPascabayar());
      case ListrikMpinPascaBayar.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: ListrikMpinPascaBayar.routeName),
            builder: (_) => const ListrikMpinPascaBayar());
      case ListrikReceiptPascaBayar.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: ListrikReceiptPascaBayar.routeName),
            builder: (_) => const ListrikReceiptPascaBayar());

      //PLN Listrik Prabayar
      case ListrikPrabayarPage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: ListrikPrabayarPage.routeName),
            builder: (_) => const ListrikPrabayarPage());
      case ListrikConfirmationPrabayar.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(
                name: ListrikConfirmationPrabayar.routeName),
            builder: (_) => const ListrikConfirmationPrabayar());
      case ListrikMpinPrabayar.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: ListrikMpinPrabayar.routeName),
            builder: (_) => const ListrikMpinPrabayar());
      case ListrikReceiptPrabayar.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: ListrikReceiptPrabayar.routeName),
            builder: (_) => const ListrikReceiptPrabayar());

      // Favorite
      case DaftarFavoriteFull.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: DaftarFavoriteFull.routeName),
            builder: (_) => const DaftarFavoriteFull());

      // Asuransi
      case AsuransiPage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: AsuransiPage.routeName),
            builder: (_) => const AsuransiPage());

      // BPJS
      case InquiryBPJS.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: InquiryBPJS.routeName),
            builder: (_) => const InquiryBPJS());
      case BPJSConfirmation.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: BPJSConfirmation.routeName),
            builder: (_) => const BPJSConfirmation());
      case BPJSMPIN.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: BPJSMPIN.routeName),
            builder: (_) => const BPJSMPIN());
      case BPJSReceipt.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: BPJSReceipt.routeName),
            builder: (_) => const BPJSReceipt());

      // Infaq Baitul Aceh
      case ConfirmationPageMallBaitul.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: ConfirmationPageMallBaitul.routeName),
            builder: (_) => const ConfirmationPageMallBaitul());
      case InfaqMalBaitulAceh.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: InfaqMalBaitulAceh.routeName),
            builder: (_) => const InfaqMalBaitulAceh());
      case InfaqBaitulMallAcehMpinPage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(
                name: InfaqBaitulMallAcehMpinPage.routeName),
            builder: (_) => const InfaqBaitulMallAcehMpinPage());
      case InfaqBaitulMallAcehReceiptPage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(
                name: InfaqBaitulMallAcehReceiptPage.routeName),
            builder: (_) => const InfaqBaitulMallAcehReceiptPage());

      // PBB
      case InquiryPBB.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: InquiryPBB.routeName),
            builder: (_) => const InquiryPBB());
      case ConfirmationPBB.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: ConfirmationPBB.routeName),
            builder: (_) => const ConfirmationPBB());
      case PBBConfirmation.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: PBBConfirmation.routeName),
            builder: (_) => const PBBConfirmation());
      case PBBMPIN.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: PBBMPIN.routeName),
            builder: (_) => const PBBMPIN());
      case PBBReceipt.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: PBBReceipt.routeName),
            builder: (_) => const PBBReceipt());
      case PageTahun.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: PageTahun.routeName),
            builder: (_) => const PageTahun());

      // PDAM
      case PDAMPage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: PDAMPage.routeName),
            builder: (_) => const PDAMPage());
      case PageConfirmPDAM.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: PageConfirmPDAM.routeName),
            builder: (_) => const PageConfirmPDAM());
      case ListConfirmPDAM.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: ListConfirmPDAM.routeName),
            builder: (_) => const ListConfirmPDAM());

      // TirtaDaroy
      case InquiryTirtaDaroy.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: InquiryTirtaDaroy.routeName),
            builder: (_) => const InquiryTirtaDaroy());
      case TirtaDaroyConfirm.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: TirtaDaroyConfirm.routeName),
            builder: (_) => const TirtaDaroyConfirm());
      case TirtaDaroyMPIN.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: TirtaDaroyMPIN.routeName),
            builder: (_) => const TirtaDaroyMPIN());
      case TirtaDaroyReceipt.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: TirtaDaroyReceipt.routeName),
            builder: (_) => const TirtaDaroyReceipt());

      // Pemda
      case EsetorPemda.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: EsetorPemda.routeName),
            builder: (_) => const EsetorPemda());
      case ESetorConfirmation.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: ESetorConfirmation.routeName),
            builder: (_) => const ESetorConfirmation());
      case ESetorMPIN.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: ESetorMPIN.routeName),
            builder: (_) => const ESetorMPIN());
      case ESetorReceipt.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: ESetorReceipt.routeName),
            builder: (_) => const ESetorReceipt());
      case PemkotPage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: PemkotPage.routeName),
            builder: (_) => const PemkotPage());

      // Samsat
      case Samsat.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: Samsat.routeName),
            builder: (_) => const Samsat());
      case SamsatConfirmation.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: SamsatConfirmation.routeName),
            builder: (_) => const SamsatConfirmation());
      case SamsatMPIN.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: SamsatMPIN.routeName),
            builder: (_) => const SamsatMPIN());
      case SamsatReceipt.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: SamsatReceipt.routeName),
            builder: (_) => const SamsatReceipt());

      // Indihome
      case IndiHome.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: IndiHome.routeName),
            builder: (_) => const IndiHome());
      case ConfirmationPageIndihome.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: ConfirmationPageIndihome.routeName),
            builder: (_) => const ConfirmationPageIndihome());
      case IndihomeMpinPage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: IndihomeMpinPage.routeName),
            builder: (_) => const IndihomeMpinPage());
      case IndihomeReceiptPage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: IndihomeReceiptPage.routeName),
            builder: (_) => const IndihomeReceiptPage());

      // Telepon Rumah
      case TeleponRumah.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: TeleponRumah.routeName),
            builder: (_) => const TeleponRumah());
      case ConfirmationPageTeleponRumah.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(
                name: ConfirmationPageTeleponRumah.routeName),
            builder: (_) => const ConfirmationPageTeleponRumah());
      case TeleponRumahMpinPage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: TeleponRumahMpinPage.routeName),
            builder: (_) => const TeleponRumahMpinPage());
      case TeleponRumahReceiptPage.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: TeleponRumahReceiptPage.routeName),
            builder: (_) => const TeleponRumahReceiptPage());

      // Transportasi
      case TransportasiPage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: TransportasiPage.routeName),
            builder: (_) => const TransportasiPage());

      // Kereta
      case KeretaPage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: KeretaPage.routeName),
            builder: (_) => const KeretaPage());

      // KAI
      case KeretaKAI.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: KeretaKAI.routeName),
            builder: (_) => const KeretaKAI());
      case KeretaKAIConfirmation.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: KeretaKAIConfirmation.routeName),
            builder: (_) => const KeretaKAIConfirmation());
      case KeretaKAIMPIN.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: KeretaKAIMPIN.routeName),
            builder: (_) => const KeretaKAIMPIN());
      case KeretaKAIReceipt.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: KeretaKAIReceipt.routeName),
            builder: (_) => const KeretaKAIReceipt());

      // Railink
      case KeretaRailink.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: KeretaRailink.routeName),
            builder: (_) => const KeretaRailink());
      case KeretaRailinkConfirmation.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: KeretaRailinkConfirmation.routeName),
            builder: (_) => const KeretaRailinkConfirmation());
      case KeretaRailinkMPIN.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: KeretaRailinkMPIN.routeName),
            builder: (_) => const KeretaRailinkMPIN());
      case KeretaRailinkReceipt.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: KeretaRailinkReceipt.routeName),
            builder: (_) => const KeretaRailinkReceipt());

      // Garuda
      case InquiryGaruda.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: InquiryGaruda.routeName),
            builder: (_) => const InquiryGaruda());
      case GarudaReceipt.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: GarudaReceipt.routeName),
            builder: (_) => const GarudaReceipt());
      case GarudaMPIN.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: GarudaMPIN.routeName),
            builder: (_) => const GarudaMPIN());
      case GarudaConfirmation.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: GarudaConfirmation.routeName),
            builder: (_) => const GarudaConfirmation());

      // Pesawat
      case PesawatPage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: PesawatPage.routeName),
            builder: (_) => const PesawatPage());

      // Citilink
      case InquiryCitilink.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: InquiryCitilink.routeName),
            builder: (_) => const InquiryCitilink());
      case CitilinkMPIN.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: CitilinkMPIN.routeName),
            builder: (_) => const CitilinkMPIN());
      case CitilinkConfirmation.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: CitilinkConfirmation.routeName),
            builder: (_) => const CitilinkConfirmation());
      case CitilinkReceipt.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: CitilinkReceipt.routeName),
            builder: (_) => const CitilinkReceipt());

      // Lion
      case LionPage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: LionPage.routeName),
            builder: (_) => const LionPage());
      case LionConfirmation.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: LionConfirmation.routeName),
            builder: (_) => const LionConfirmation());
      case LionMpin.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: LionMpin.routeName),
            builder: (_) => const LionMpin());
      case LionReceipt.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: LionReceipt.routeName),
            builder: (_) => const LionReceipt());

      // Tv
      case TVBerlanggananPage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: TVBerlanggananPage.routeName),
            builder: (_) => const TVBerlanggananPage());

      // Transvision
      case Transvision.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: Transvision.routeName),
            builder: (_) => const Transvision());
      case TransvisionConfirmation.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: TransvisionConfirmation.routeName),
            builder: (_) => const TransvisionConfirmation());
      case TransvisionMPIN.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: TransvisionMPIN.routeName),
            builder: (_) => const TransvisionMPIN());
      case TransvisionReceipt.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: TransvisionReceipt.routeName),
            builder: (_) => const TransvisionReceipt());

      // MNC
      case InquiryMNCVision.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: InquiryMNCVision.routeName),
            builder: (_) => const InquiryMNCVision());
      case ConfirmationMNCVision.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: ConfirmationMNCVision.routeName),
            builder: (_) => const ConfirmationMNCVision());
      case MNCVisionMPIN.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: MNCVisionMPIN.routeName),
            builder: (_) => const MNCVisionMPIN());
      case MNCVisionReceipt.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: MNCVisionReceipt.routeName),
            builder: (_) => const MNCVisionReceipt());

      //Universitas
      case UniversitasScreen.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: UniversitasScreen.routeName),
            builder: (_) => const UniversitasScreen());

      // ArRaniry
      case ArRaniry.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: ArRaniry.routeName),
            builder: (_) => const ArRaniry());
      case ConfirmationPageArRaniry.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: ConfirmationPageArRaniry.routeName),
            builder: (_) => const ConfirmationPageArRaniry());
      case ArRaniryMpinPage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: ArRaniryMpinPage.routeName),
            builder: (_) => const ArRaniryMpinPage());
      case ArRaniryReceiptPage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: ArRaniryReceiptPage.routeName),
            builder: (_) => const ArRaniryReceiptPage());

      // Teuku Umar
      case TeukurUmar.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: TeukurUmar.routeName),
            builder: (_) => const TeukurUmar());
      case ConfirmationPageTeukuUmar.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: ConfirmationPageTeukuUmar.routeName),
            builder: (_) => const ConfirmationPageTeukuUmar());
      case TeukuUmarMpinPage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: TeukuUmarMpinPage.routeName),
            builder: (_) => const TeukuUmarMpinPage());
      case TeukuUmarReceiptPage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: TeukuUmarReceiptPage.routeName),
            builder: (_) => const TeukuUmarReceiptPage());

      // Zakat Baitul
      case ZakatMalBaitulAceh.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: ZakatMalBaitulAceh.routeName),
            builder: (_) => const ZakatMalBaitulAceh());
      case ConfirmationPageMallZakatBaitul.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(
                name: ConfirmationPageMallZakatBaitul.routeName),
            builder: (_) => const ConfirmationPageMallZakatBaitul());
      case ZakatBaitulMpinPage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: ZakatBaitulMpinPage.routeName),
            builder: (_) => const ZakatBaitulMpinPage());
      // ignore: no_duplicate_case_values
      case ZakatBaitulReceiptPage.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: ZakatBaitulReceiptPage.routeName),
            builder: (_) => const ZakatBaitulReceiptPage());

      // Paket Data
      case ConfirmationPagePaketData.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: ConfirmationPagePaketData.routeName),
            builder: (_) => const ConfirmationPagePaketData());
      case PembelianPaketData.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: PembelianPaketData.routeName),
            builder: (_) => const PembelianPaketData());
      case DaftarPaket.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: DaftarPaket.routeName),
            builder: (_) => const DaftarPaket());
      case InquiryPaketData.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: InquiryPaketData.routeName),
            builder: (_) => const InquiryPaketData());
      case PaketDataReceipt.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: PaketDataReceipt.routeName),
            builder: (_) => const PaketDataReceipt());
      case ConfirmationPaketData.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: ConfirmationPaketData.routeName),
            builder: (_) => const ConfirmationPaketData());
      case PaketDataMPINPage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: PaketDataMPINPage.routeName),
            builder: (_) => const PaketDataMPINPage());
      // case ViewContact.routeName:
      //   return MaterialPageRoute(
      //       settings: const RouteSettings(name: ViewContact.routeName),
      //       builder: (_) => ViewContact());

      //GOPAY
      case GopayPage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: GopayPage.routeName),
            builder: (_) => const GopayPage());
      case Gopayconfirmasi.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: Gopayconfirmasi.routeName),
            builder: (_) => const Gopayconfirmasi());
      case GopayMPIN.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: GopayMPIN.routeName),
            builder: (_) => const GopayMPIN());
      case GopayReceipt.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: GopayReceipt.routeName),
            builder: (_) => const GopayReceipt());

      //LINK AJA
      case LinkAjaPage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: LinkAjaPage.routeName),
            builder: (_) => const LinkAjaPage());
      case LinkAjaconfirmasi.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: LinkAjaconfirmasi.routeName),
            builder: (_) => const LinkAjaconfirmasi());
      case LinkAjaMPIN.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: LinkAjaMPIN.routeName),
            builder: (_) => const LinkAjaMPIN());
      case LinkAjaReceipt.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: LinkAjaReceipt.routeName),
            builder: (_) => const LinkAjaReceipt());

      //OVO
      case OvoPage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: OvoPage.routeName),
            builder: (_) => const OvoPage());
      case Ovoconfirmasi.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: Ovoconfirmasi.routeName),
            builder: (_) => const Ovoconfirmasi());
      case OvoMPIN.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: OvoMPIN.routeName),
            builder: (_) => const OvoMPIN());
      case OvoReceipt.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: OvoReceipt.routeName),
            builder: (_) => const OvoReceipt());

      // Transfer
      case FavoriteTransferPage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: FavoriteTransferPage.routeName),
            builder: (_) => const FavoriteTransferPage());

      // Transfer Bas
      case TransferConfirmPageBAS.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: TransferConfirmPageBAS.routeName),
            builder: (_) => const TransferConfirmPageBAS());
      case TransferBas.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: TransferBas.routeName),
            builder: (_) => const TransferBas());
      case TransferMpinPage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: TransferMpinPage.routeName),
            builder: (_) => const TransferMpinPage());
      // ignore: no_duplicate_case_values
      case TransferReceiptPageBas.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: TransferReceiptPageBas.routeName),
            builder: (_) => const TransferReceiptPageBas());

      // Transfer BL
      case TransferConfirmPageBL.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: TransferConfirmPageBL.routeName),
            builder: (_) => const TransferConfirmPageBL());
      case TransferBankLain.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: TransferBankLain.routeName),
            builder: (_) => const TransferBankLain());
      case TransferMpinPageBankLain.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: TransferMpinPageBankLain.routeName),
            builder: (_) => const TransferMpinPageBankLain());
      case TransferReceiptBLPage.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: TransferReceiptBLPage.routeName),
            builder: (_) => const TransferReceiptBLPage());

      // Transfer RTGS
      case TransferRTGS.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: TransferRTGS.routeName),
            builder: (_) => const TransferRTGS());
      // ignore: no_duplicate_case_values
      case TransferConfirmPageRTGS.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: TransferConfirmPageRTGS.routeName),
            builder: (_) => const TransferConfirmPageRTGS());
      case TransferMpinPageRTGS.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: TransferMpinPageRTGS.routeName),
            builder: (_) => const TransferMpinPageRTGS());
      case TransferReceiptRTGSPage.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: TransferReceiptRTGSPage.routeName),
            builder: (_) => const TransferReceiptRTGSPage());

      // Transfer SKN
      case TransferSKN.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: TransferSKN.routeName),
            builder: (_) => const TransferSKN());
      case TransferConfirmPageSKN.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: TransferConfirmPageSKN.routeName),
            builder: (_) => const TransferConfirmPageSKN());
      case TransferMpinPageSKN.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: TransferMpinPageSKN.routeName),
            builder: (_) => const TransferMpinPageSKN());
      // ignore: no_duplicate_case_values
      case TransferReceiptSKNPage.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: TransferReceiptSKNPage.routeName),
            builder: (_) => const TransferReceiptSKNPage());
      case TujuanTransaksi.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: TujuanTransaksi.routeName),
            builder: (_) => const TujuanTransaksi());
      case JenisPenerima.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: JenisPenerima.routeName),
            builder: (_) => const JenisPenerima());
      case StatusPenduduk.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: StatusPenduduk.routeName),
            builder: (_) => const StatusPenduduk());

      // Favorite Layanan
      case FavoritePaymentPage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: FavoritePaymentPage.routeName),
            builder: (_) => const FavoritePaymentPage());

      // Statements
      case Statements.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: Statements.routeName),
            builder: (_) => const Statements());

      // QR
      case TransferQR.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: TransferQR.routeName),
            builder: (_) => const TransferQR());
      case Qrcode.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: Qrcode.routeName),
            builder: (_) => const Qrcode());
      case Qrimages.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: Qrimages.routeName),
            builder: (_) => const Qrimages());
      case TransferBasQR.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: TransferBasQR.routeName),
            builder: (_) => const TransferBasQR());
      case PaymentQr.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: PaymentQr.routeName),
            builder: (_) => const PaymentQr());
      case ConfirmPaymentQRPage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: ConfirmPaymentQRPage.routeName),
            builder: (_) => const ConfirmPaymentQRPage());
      case QrPaymentMpin.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: QrPaymentMpin.routeName),
            builder: (_) => const QrPaymentMpin());
      case PaymentQRreceipt.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: PaymentQRreceipt.routeName),
            builder: (_) => const PaymentQRreceipt());

      // Layanan
      case AsuransiScreen.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: AsuransiScreen.routeName),
            builder: (_) => const AsuransiScreen());
      case ZisScreen.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: ZisScreen.routeName),
            builder: (_) => const ZisScreen());
      case EmoneyScreen.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: EmoneyScreen.routeName),
            builder: (_) => const EmoneyScreen());
      case InternetScreen.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: InternetScreen.routeName),
            builder: (_) => const InternetScreen());
      case PajakRetribusiScreen.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: PajakRetribusiScreen.routeName),
            builder: (_) => const PajakRetribusiScreen());
      case PendidikaScreen.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: PendidikaScreen.routeName),
            builder: (_) => const PendidikaScreen());
      case InfaqScreen.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: InfaqScreen.routeName),
            builder: (_) => const InfaqScreen());
      case ZakatScreen.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: ZakatScreen.routeName),
            builder: (_) => const ZakatScreen());
      case PembayaranPage.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: PembayaranPage.routeName),
            builder: (_) => const PembayaranPage());

      // Other
      case OtherWidget.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: OtherWidget.routeName),
            builder: (_) => const OtherWidget());
      case SnKBiometric.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: SnKBiometric.routeName),
            builder: (_) => const SnKBiometric());
      case ChangePass.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: ChangePass.routeName),
            builder: (_) => const ChangePass());
      case OLDMPIN.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: OLDMPIN.routeName),
            builder: (_) => const OLDMPIN());
      case ConfirmChangeMPIN.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: ConfirmChangeMPIN.routeName),
            builder: (_) => const ConfirmChangeMPIN(
                  context: null,
                ));
      case NewMPIN.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: NewMPIN.routeName),
            builder: (_) => const NewMPIN());
      case NewPassword.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: NewPassword.routeName),
            builder: (_) => const NewPassword());
      case ForgotPassword.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: ForgotPassword.routeName),
            builder: (_) => const ForgotPassword());
      case ContactUs.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: ContactUs.routeName),
            builder: (_) => const ContactUs());
      case FAQ.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: FAQ.routeName),
            builder: (_) => const FAQ());
      case TermsAndConditionOthers.routeName:
        return MaterialPageRoute(
            settings:
                const RouteSettings(name: TermsAndConditionOthers.routeName),
            builder: (_) => const TermsAndConditionOthers());

      // Login
      case OTPforgotPassword.routeName:
        Map<String, Object>? param = settings.arguments as Map<String, Object>?;
        return MaterialPageRoute(
            settings: const RouteSettings(name: OTPforgotPassword.routeName),
            builder: (_) => OTPforgotPassword(param: param));
      case ForgotMPIN.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: ForgotMPIN.routeName),
            builder: (_) => const ForgotMPIN());
      case OTPforgotMPIN.routeName:
        Map<String, Object>? param = settings.arguments as Map<String, Object>?;
        return MaterialPageRoute(
            settings: const RouteSettings(name: OTPforgotMPIN.routeName),
            builder: (_) => OTPforgotMPIN(param: param));
      case CreateNewMPIN.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: CreateNewMPIN.routeName),
            builder: (_) => const CreateNewMPIN());
      case ConfirmNewMpin.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: ConfirmNewMpin.routeName),
            builder: (_) => const ConfirmNewMpin());
      case CreateMpin.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: CreateMpin.routeName),
            builder: (_) => const CreateMpin());
      case ConfirmMpin.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: ConfirmMpin.routeName),
            builder: (_) => const ConfirmMpin());
      case ForgotUsername.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: ForgotUsername.routeName),
            builder: (_) => const ForgotUsername());
      case OTPforgotUsername.routeName:
        Map<String, Object>? param = settings.arguments as Map<String, Object>?;
        return MaterialPageRoute(
            settings: const RouteSettings(name: OTPforgotUsername.routeName),
            builder: (_) => OTPforgotUsername(param: param));
      case LinkNewDeviceStep1.routeName:
        return MaterialPageRoute(
            settings: const RouteSettings(name: LinkNewDeviceStep1.routeName),
            builder: (_) => const LinkNewDeviceStep1());
      case LinkNewDeviceStep2.routeName:
        Map<String, Object>? param = settings.arguments as Map<String, Object>?;
        return MaterialPageRoute(
            settings: const RouteSettings(name: LinkNewDeviceStep2.routeName),
            builder: (_) => LinkNewDeviceStep2(param: param));

      default:
        return _errorRoute();
    }
  }

  static Route<dynamic> _errorRoute() {
    return MaterialPageRoute(builder: (_) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Error'),
        ),
        body: const Center(
          child: Text('ERROR'),
        ),
      );
    });
  }
}
