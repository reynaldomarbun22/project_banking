import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'dart:ui';

import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/core/crypto/ist_crypto.dart';
import 'package:bpd_aceh/features/landing/landing.dart';
import 'package:bpd_aceh/features/login/login.dart';
import 'package:bpd_aceh/features/splash/splash.dart';
import 'package:device_info/device_info.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:platform_device_id/platform_device_id.dart';
import 'package:http/http.dart' as http;

enum Environment { prod, dev, uat }

class API {
  static const Environment _env = Environment.dev;

  static const _constBaseUrl = "http://bankaceh.ist.id:7071";
  static const _constBaseUrlUAT = "https://d3v.bankaceh.co.id";
  static const _constBaseUrlPROD = "https://mbanking.bankaceh.co.id";

  ///overriden to true if end not in dev
  static const _enabledEncryption = true;

  static const _post = "post";
  static const _get = "get";
  static const _timeout = 300;

  static Future postNoLoading(
      BuildContext? context, String path, Map<String, Object?> reqBody) async {
    return await _fetch(context, _post, path, reqBody, false, true);
  }

  static Future post(
      BuildContext context, String path, Map<String, Object?> reqBody) async {
    return await _fetch(context, _post, path, reqBody, true, true);
  }

  static Future postNoCookies(
      BuildContext context, String path, Map<String, Object> reqBody) async {
    return await _fetch(context, _post, path, reqBody, true, false);
  }

  static Future get(
      BuildContext context, String path, Map<String, Object> reqBody) async {
    return await _fetch(context, _get, path, reqBody, true, true);
  }

  static Future postNoLoadingNoCookies(
      BuildContext context, String path, Map<String, Object> reqBody) async {
    return await _fetch(context, _post, path, reqBody, false, false);
  }

  static Future _fetch(BuildContext? context, String method, String path,
      Map<String, Object?> reqBodyMap, bool loading, bool cookies) async {
    final bool _encryption =
        _env == Environment.dev ? _enabledEncryption : true;
    bool _error = false;
    if (loading) await _showLoading(context!);
    http.Response response;
    Map<String, String> headers = {};
    headers['content-type'] = "application/json";

    if (cookies) {
      String _cookie = await _getCookie();
      if (_cookie.isNotEmpty) {
        headers['cookie'] = _cookie;
      }
    }

    DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
    var deviceInfoParam = "";
    if (Platform.isIOS) {
      IosDeviceInfo iosInfo = await deviceInfo.iosInfo;
      deviceInfoParam = iosInfo.utsname.machine;
    } else {
      AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
      deviceInfoParam = androidInfo.model;
    }

    reqBodyMap['deviceId'] = await PlatformDeviceId.getDeviceId;
    reqBodyMap['deviceInfo'] = deviceInfoParam;

    var reqBody = json.encode(reqBodyMap);
    final String url = getBaseUrl() + path;
    var logStr = "";
    logStr += "Request Begin -- [$method] $url";
    logStr += "\t\n[Request Body Raw] : \n\t$reqBody";
    if (_encryption) {
      reqBody = await _doEncrypt(reqBody, path);
    }
    logStr += "\t\n[Request Headers] : \n\t$headers";
    logStr += "\t\n[Request Body] : \n\t$reqBody";
    var start = DateTime.now().millisecondsSinceEpoch;
    try {
      if (method == _post) {
        response = await http
            .post(Uri.parse(url), headers: headers, body: reqBody)
            .timeout(const Duration(seconds: _timeout), onTimeout: () {
          _error = true;
          if (loading) Navigator.pop(context!);
          _showErrorDialog(context, 'Server Timeout');
          logStr += ("\n:: PROCESS TIME OUT! ::");
          // ignore: null_argument_to_non_null_type
          return Future.value();
        });
      } else {
        response = await http
            .get(Uri.parse(url))
            .timeout(const Duration(seconds: _timeout));
      }
      // ignore: unnecessary_null_comparison
      if (response != null) {
        logStr += "\t\n[Response Code] : \n\t${response.statusCode}";
        _updateCookie(response);
        if (response.statusCode == 200) {
          // ignore: unnecessary_null_comparison
          if (response.body != null) {
            logStr +=
                "\t\n[Response Headers] : \n\t${response.headers.toString()}";
            // log += "\t\n[Response Raw] : \n\t${response.body.toString()}";
            // ignore: prefer_typing_uninitialized_variables
            var respDecode;
            if (_encryption) {
              String body = await _doDecrypt(response, path);
              logStr += "\t\n[Response Body] : \n\t${body.toString()}";
              respDecode = json.decode(body);
            } else {
              respDecode = json.decode(response.body);
              logStr += "\t\n[Response Body] : \n\t${response.body.toString()}";
            }
            // if (respDecode['code'] == -9102 ||
            //     respDecode['code'] == -7101 ||
            //     respDecode['code'] == -7102 ||
            //     respDecode['code'] == -9999) {
            //   _error = true;
            //   if (loading) Navigator.pop(context);
            //   _showSessionTimeout(context, respDecode);
            // } else {
            // if (loading) Navigator.pop(context);
            return respDecode;
            // }
          } else {
            _error = true;
            if (loading) Navigator.pop(context!);
            _showErrorDialog(context, "Server Bermasalah");
          }
        } else if (response.statusCode == 401) {
          _error = true;
          await ISTConstants().setString(ISTConstants.authCookie, '');
          await ISTConstants().setString(ISTConstants.loggedInKey, '');
          _showSessionTimeout(context);
          return null;
        } else if (response.statusCode == 403) {
          _error = true;
          await ISTConstants().setString(ISTConstants.loggedInKey, '');
          await ISTConstants().setString(ISTConstants.authCookie, '');
          _showSessionTimeout(context);
          return null;
        } else if (response.statusCode == 503) {
          _error = true;
          await ISTConstants().setString(ISTConstants.authCookie, '');
          await ISTConstants().setString(ISTConstants.loggedInKey, '');
          // _showSessionTimeout(context);
          // _showErrorDialog(
          //   context,
          //   'Server tidak dapat dijangkau',
          // )
          const DialogBox().showImageDialog(
              message: 'Server tidak dapat dijangkau',
              isError: true,
              buttonCancel: 'OK',
              onCancel: () {
                Navigator.pushNamedAndRemoveUntil(
                    context!,
                    LandingPageScreen.routeName,
                    ModalRoute.withName(Splash.routeName));
              },
              onOk: () {},
              context: context);

          return null;
        } else if (response.statusCode == 502) {
          _error = true;

          const DialogBox().showImageDialog(
              message: 'Layanan tidak dapat dijangkau',
              isError: true,
              buttonCancel: 'OK',
              onCancel: () {
                Navigator.pop(context!);
                Navigator.pop(context);
              },
              onOk: () {},
              context: context);
        } else {
          _error = true;
          if (loading) Navigator.pop(context!);
          _showErrorDialog(context, '(${response.statusCode})');
          logStr +=
              "\nERROR : ${response.reasonPhrase} (${response.statusCode})";
          return null;
        }
      } else {
        _error = true;
        if (loading) Navigator.pop(context!);
        _showErrorDialog(context, 'Tidak ada respon dari server');
        logStr += "\nERROR : ${response.toString()}";
      }
    } on FormatException catch (_) {
      _error = true;
      if (loading) Navigator.pop(context!);
      _showErrorDialog(context, 'Response Error from system');
    } on http.ClientException catch (_) {
      _error = true;
      if (loading) Navigator.pop(context!);
    } on HttpException catch (_) {
      _error = true;
      if (loading) Navigator.pop(context!);
    } on SocketException catch (_) {
      _error = true;
      if (loading) Navigator.pop(context!);
      _showErrorDialog(context, 'Server tidak dapat dijangkau');
    } finally {
      if (!_error && loading) Navigator.pop(context!);
      var end = DateTime.now().millisecondsSinceEpoch;
      logStr += "\n--> ${end - start}ms";
      if (kDebugMode) {
        log(logStr);
      }
    }
  }

  static String getBaseUrl() {
    String _baseUrl = "";
    switch (_env) {
      case Environment.dev:
        _baseUrl = _constBaseUrl;
        break;
      case Environment.uat:
        _baseUrl = _constBaseUrlUAT;
        break;
      case Environment.prod:
        _baseUrl = _constBaseUrlPROD;
        break;
      default:
        _baseUrl = _constBaseUrl;
    }
    return _baseUrl;
  }
}

Future<String> _doEncrypt(reqBody, String path) async {
  final String? key =
      await ISTConstants().getConstants(ISTConstants.loggedInKey);
  if (path.startsWith("/login") && path.startsWith("/util/version")) {
    String enc = await ISTCrypto.encryptAES(reqBody);
    return enc;
  } else if (key != null &&
      key.isNotEmpty &&
      !path.startsWith("/login") &&
      !path.startsWith("/util/version")) {
    String enc = await ISTCrypto.encryptAESBody(reqBody, key);
    return enc;
  } else {
    String enc = await ISTCrypto.encryptAES(reqBody);
    return enc;
  }
}

Future<String> _doDecrypt(http.Response response, String path) async {
  final String? key =
      await ISTConstants().getConstants(ISTConstants.loggedInKey);
  if (key != null &&
      key.isNotEmpty &&
      path.startsWith("/login") &&
      path.startsWith("/util/version")) {
    String enc = await ISTCrypto.encryptAES(response.body);
    return enc;
  } else if (key != null &&
      key.isNotEmpty &&
      !path.startsWith("/login") &&
      !path.startsWith("/util/version")) {
    String respBody = await ISTCrypto.decryptAESBody(response.body, key);
    return respBody;
  } else {
    String respBody = await ISTCrypto.decryptAES(response.body);
    return respBody;
  }
}

_updateCookie(http.Response response) async {
  String? rawCookie = response.headers['set-cookie'];
  if (rawCookie != null && rawCookie.isNotEmpty) {
    final String raw = (rawCookie);
    await ISTConstants().setString(ISTConstants.authCookie, raw);
  }
}

_getCookie() async {
  String? encCookie = await ISTConstants().getString(ISTConstants.authCookie);
  return encCookie;
}

// _replace(rawCookie) {
//   RegExp regExp = RegExp(
//     r"(.*?)(;)",
//     caseSensitive: false,
//     multiLine: false,
//   );

//   var matches = regExp.allMatches(rawCookie);
//   var match = matches.elementAt(0);
//   return match.group(1).toString();
// }

_showErrorDialog(context, String message) {
  const DialogBox().showErrorDialog(
    image: Image.asset(
      'assets/images/icon-failed.png',
      width: 100,
    ),
    context: context,
    message: message,
  );
}

_showSessionTimeout(context) {
  const DialogBox().showImageDialog(
      message: "Sesi Anda telah habis. Silakan login kembali.",
      buttonOk: 'Keluar',
      isError: true,
      image: Image.asset(
        'assets/images/icon-failed.png',
        width: 100,
      ),
      onOk: () {
        _onLogout();
        Navigator.pushNamedAndRemoveUntil(context, LandingPageScreen.routeName,
            ModalRoute.withName(Splash.routeName));
        Navigator.pushNamed(context, LoginPage.routeName);
      },
      context: context);
}

_onLogout() async {
  await ISTConstants().setString(ISTConstants.authCookie, '');
  await ISTConstants().setString(ISTConstants.loggedInKey, "");
}

_showLoading(BuildContext context) {
  showDialog(
    context: context,
    barrierDismissible: false,
    builder: (context) {
      return WillPopScope(
        onWillPop: () async => false,
        child: Stack(
          children: [
            Positioned.fill(
                child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                    child: Container(
                      color: Colors.white12,
                    ))),
            const Center(
                child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Pallete.primary),
            ))
          ],
        ),
      );
    },
  );
}
