import 'dart:convert';
import 'package:encrypt/encrypt.dart';

class ISTCrypto {
  static String ivDefault = "0000000000000000";
  static String keyDefault = "bankAcehM4st3rKy";

  static Future<String> decryptAES(String body) async {
    return await decryptAESBody(body, keyDefault);
  }

  static Future<String> encryptAES(String body) async {
    return await encryptAESBody(body, keyDefault);
  }

  static Future<String> encryptAESBody(String? body, String keyRaw) async {
    if (body == null || body.isEmpty) return "";
    final key = Key.fromUtf8(keyRaw);
    final iv = IV.fromUtf8(ivDefault);
    final encrypter = Encrypter(AES(key, mode: AESMode.ecb));
    // final encrypted = encrypter.encrypt(body);
    final encrypted = encrypter.encrypt(body, iv: iv);
    return (encrypted.base64);
  }

  static Future<String> decryptAESBody(String body, String keyRaw) async {
    if (body.isEmpty) return "";
    final key = Key.fromUtf8(keyRaw);
    final iv = IV.fromUtf8(ivDefault);
    final encrypter = Encrypter(AES(key, mode: AESMode.ecb));
    final encrypted = encrypter.decrypt(Encrypted(base64.decode(body)), iv: iv);
    // final encrypted = encrypter.decrypt(Encrypted(base64.decode(body)));
    // final encrypted = encrypter.decrypt(Encrypted(utf8.encode(body)), iv: iv);
    return encrypted;
  }
}
