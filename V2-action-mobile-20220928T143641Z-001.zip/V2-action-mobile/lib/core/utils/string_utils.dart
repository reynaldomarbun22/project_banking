import 'package:flutter/services.dart';

class StringUtils {
  static noSpace() {
    return FilteringTextInputFormatter.deny(RegExp(' '));
  }

  static String getValueAsString(String str) {
    return str.replaceAll("\\n", "\n");
  }

  static alphaNumeric() {
    return FilteringTextInputFormatter.allow(RegExp('[a-z A-Z 0-9]'));
  }
}
