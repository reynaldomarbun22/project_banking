import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:package_info_plus/package_info_plus.dart';

class PackageUtils {
  static Future<PackageInfo> getPackageInfo() async {
    return await PackageInfo.fromPlatform();
  }

  static Future<String> getVersion() async {
    PackageInfo ret = await PackageInfo.fromPlatform();
    ISTConstants().setString(ISTConstants.version, ret.version);
    return ret.version;
  }
}
