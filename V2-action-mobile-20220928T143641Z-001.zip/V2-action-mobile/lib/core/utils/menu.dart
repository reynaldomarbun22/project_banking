import 'dart:convert';

class ISTMenuWidget {
  final String? key;
  final String? value;

  ISTMenuWidget({this.key, this.value});

  String toJson() => json.encode({
        'key': key,
        'value': value,
      });

  factory ISTMenuWidget.fromJson(dynamic json) {
    return ISTMenuWidget(key: json['key'], value: json['value']);
  }
}
