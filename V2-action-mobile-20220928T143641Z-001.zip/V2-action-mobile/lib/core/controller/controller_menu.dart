import 'package:collection/collection.dart' show IterableExtension;
import 'package:get/get.dart';
import 'package:bpd_aceh/core/utils/menu.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:flutter/material.dart';

class MenuController extends GetxController {
  List<ISTMenuWidget> resultMenu = [];
  BuildContext? context;
  bool inboxVisible = false;

  @override
  void onReady() {
    checkMenu();
    super.onReady();
  }

  checkMenu() async {
    final resp = await API.postNoLoading(context, '/list/menu', {});
    print(resp);
    if (resp != null && resp['code'] == 0) {
      List<ISTMenuWidget> listItemsMenu = [];
      var listResp = resp['items'];
      print(listResp[0]);
      List<dynamic> listRespDyn = (listResp);
      for (var item in listRespDyn) {
        ISTMenuWidget itemMenuParam = ISTMenuWidget(
          key: item['key'],
          value: item['name'],
        );
        listItemsMenu.add(itemMenuParam);

        resultMenu = listItemsMenu;
        print(resultMenu);
      }
      print(listItemsMenu);
    }
    inboxVisible = getVisibilityInbox();
    update();
  }

  // Menu Global ---

  // Position : Beranda, Transfer, Layanan, Lainnya
  // Role : Main Menu
  getVisibilityFavorite() {
    String keyToCheck = "favorit";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Position : Beranda, Lainnya
  // Role : Main Menu
  getVisibilityRekening() {
    String keyToCheck = "rekeningku";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Sub Menu
  getVisibilityBukaRekening() {
    String keyToCheck = "rekeningku.bukaRekeningBaru";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Next Sub Menu
  getVisibilityTabungan() {
    String keyToCheck = "rekeningku.bukaRekeningBaru.tabungan";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Next Sub Menu
  getVisibilityDeposito() {
    String keyToCheck = "rekeningku.bukaRekeningBaru.deposito";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Sub Menu
  getVisibilityPengaturanRekening() {
    String keyToCheck = "rekeningku.pengaturanRekening";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Sub Menu
  getVisibilityPencairanDeposito() {
    String keyToCheck = "rekeningku.pencairanDeposito";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Sub Menu
  getVisibilityPenutupanTabungan() {
    String keyToCheck = "rekeningku.penutupanTabungan";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Position : Beranda, Layanan
  // Role : Main Menu
  getVisibilityListrik() {
    String keyToCheck = "listrik";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Sub Menu
  getVisibilityPrepaid() {
    String keyToCheck = "listrik.prepaid";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Sub Menu
  getVisibilityPostpaid() {
    String keyToCheck = "listrik.postpaid";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Position : Beranda, Layanan
  // Role : Main Menu
  getVisibilityTelepon() {
    String keyToCheck = "telepon";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Sub Menu
  getVisibilityPulsa() {
    String keyToCheck = "telepon.pulsa";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Sub Menu
  getVisibilityPascaBayar() {
    String keyToCheck = "telepon.pascabayar";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Sub Menu
  getVisibilityTeleponRumah() {
    String keyToCheck = "telepon.pstn";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Menu Beranda ---

  // Role : Main Menu
  getVisibilityPray() {
    String keyToCheck = "jadwalSholat";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Main Menu / Sub Menu (Rekening)
  getVisibilityMutasiRekening() {
    String keyToCheck = "mutasiRekening";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Main Menu
  getVisibilityPromo() {
    String keyToCheck = "promo";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  getVisibilityInbox() {
    String keyToCheck = "inbox";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Main Menu
  getVisibilityTransaksi() {
    String keyToCheck = "transaksiTerakhir";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Menu Transfer ---

  // Role : Main Menu
  getVisibilityBAS() {
    String keyToCheck = "transferAntarBAS";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Main Menu
  getVisibilityAntarBank() {
    String keyToCheck = "transferAntarBankLain";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Main Menu
  getVisibilitySKN() {
    String keyToCheck = "transferSKN";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Main Menu
  getVisibilityRTGS() {
    String keyToCheck = "transferRTGS";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Menu Layanan ---

  // Role : Main Menu
  getVisibilityMPNG2() {
    String keyToCheck = "mpnG2";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Main Menu
  getVisibilityEMoney() {
    String keyToCheck = "e-Money";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Sub Menu
  getVisibilityLinkAja() {
    String keyToCheck = "e-Money.linkAja";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Sub Menu
  getVisibilityGopay() {
    String keyToCheck = "e-Money.gopay";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Sub Menu
  getVisibilityOvo() {
    String keyToCheck = "e-Money.ovo";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Main Menu
  getVisibilityPDAM() {
    String keyToCheck = "pdam";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Main Menu
  getVisibilityInternet() {
    String keyToCheck = "internet";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Sub Menu
  getVisibilityDataInternet() {
    String keyToCheck = "internet.dataInternet";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Main Menu
  getVisibilityAsuransi() {
    String keyToCheck = "asuransi";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Sub Menu
  getVisibilityBPJS() {
    String keyToCheck = "asuransi.bpjsKesehatan";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Main Menu
  getVisibilityTransportasi() {
    String keyToCheck = "transportasi";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Sub Menu
  getVisibilityPesawat() {
    String keyToCheck = "transportasi.pesawat";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Next Sub Menu
  getVisibilityGaruda() {
    String keyToCheck = "transportasi.pesawat.garudaIndonesia";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Next Sub Menu
  getVisibilityCitiLink() {
    String keyToCheck = "transportasi.pesawat.citilink";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Next Sub Menu
  getVisibilityLion() {
    String keyToCheck = "transportasi.pesawat.lionAir";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Sub Menu
  getVisibilityKereta() {
    String keyToCheck = "transportasi.keretaApi";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Next Sub Menu
  getVisibilityKAI() {
    String keyToCheck = "transportasi.keretaApi.kai";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Next Sub Menu
  getVisibilityRailink() {
    String keyToCheck = "transportasi.keretaApi.railink";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Main Menu
  getVisibilityTVBerlangganan() {
    String keyToCheck = "tvBerlangganan";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Sub Menu
  getVisibilityMnc() {
    String keyToCheck = "tvBerlangganan.mncVision";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Sub Menu
  getVisibilityTransvision() {
    String keyToCheck = "tvBerlangganan.transvision";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Sub Menu
  getVisibilityIndihome() {
    String keyToCheck = "tvBerlangganan.indiHome";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Main Menu
  getVisibilityZIS() {
    String keyToCheck = "zis";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Sub Menu
  getVisibilityZakat() {
    String keyToCheck = "zis.zakat";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Next Sub Menu
  getVisibilityZakatBMA() {
    String keyToCheck = "zis.zakat.bma";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Sub Menu
  getVisibilityInfak() {
    String keyToCheck = "zis.infak";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Next Sub Menu
  getVisibilityInfakBMA() {
    String keyToCheck = "zis.infak.bma";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Main Menu
  getVisibilityPajak() {
    String keyToCheck = "pajakRetribusi";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Sub Menu
  getVisibilityRetribusi() {
    String keyToCheck = "pajakRetribusi.retribusi";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Next Sub Menu
  getVisibilityRetribusiPemkot() {
    String keyToCheck = "pajakRetribusi.retribusi.pemkotBandaAceh";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Sub Menu
  getVisibilitySamsat() {
    String keyToCheck = "pajakRetribusi.samsatAceh";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Sub Menu
  getVisibilityPBB() {
    String keyToCheck = "pajakRetribusi.pbb";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Main Menu
  getVisibilityPendidikan() {
    String keyToCheck = "pendidikan";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Sub Menu
  getVisibilityKursus() {
    String keyToCheck = "pendidikan.kursus";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Sub Menu
  getVisibilitySekolah() {
    String keyToCheck = "pendidikan.sekolah";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Sub Menu
  getVisibilityPerguruanTinggi() {
    String keyToCheck = "pendidikan.perguruanTinggi";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Next Sub Menu
  getVisibilityUinRaniry() {
    String keyToCheck = "pendidikan.perguruanTinggi.uinArRaniry";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Next Sub Menu
  getVisibilityTeukuUmar() {
    String keyToCheck = "pendidikan.perguruanTinggi.universitasTeukuUmar";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Menu Lainnya ---

  // Role : Main Menu
  getVisibilityGantiPassword() {
    String keyToCheck = "ubahPassword";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Main Menu
  getVisibilityBiometric() {
    String keyToCheck = "aturBiometric";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Main Menu
  getVisibilityGantiMpin() {
    String keyToCheck = "gantiMPIN";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Main Menu
  getVisibilityGantiPerangkat() {
    String keyToCheck = "gantiPerangkatBaru";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Main Menu
  getVisibilityHubungiKami() {
    String keyToCheck = "hubungiKami";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Main Menu
  getVisibilityFAQ() {
    String keyToCheck = "faq";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }

  // Role : Main Menu
  getVisibilitySyarat() {
    String keyToCheck = "syaratKetentuan";
    bool visible;

    if ((resultMenu.singleWhereOrNull((it) => it.key == keyToCheck)) != null) {
      visible = true;
    } else {
      visible = false;
    }
    return visible;
  }
}
