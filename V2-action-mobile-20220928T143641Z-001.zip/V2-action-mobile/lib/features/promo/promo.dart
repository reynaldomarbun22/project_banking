import 'package:bpd_aceh/components/palete.dart';
import 'package:flutter/material.dart';
import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';

class Promo extends StatefulWidget {
  static const routeName = '/promo';
  final String? url;

  const Promo({Key? key, this.url}) : super(key: key);

  @override
  _PromoState createState() => _PromoState();
}

// http://action.bankaceh.co.id/faq.html
// https://youtube.com/
class _PromoState extends State<Promo> {
  final flutterWebViewPlugin = FlutterWebviewPlugin();
  bool isLoading = true;
  // final String url = "https://www.youtube.com/";
  @override
  void initState() {
    super.initState();
    widget.url;
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        onWillPop: () async => false,
        child: Scaffold(
            appBar: AppBar(
              title: const Text(
                "Promo",
                style: TextStyle(color: Colors.white),
              ),
              centerTitle: true,
              backgroundColor: Pallete.primary,
              leading: IconButton(
                  icon: const Icon(
                    Icons.arrow_back_ios,
                    color: Colors.white,
                  ),
                  // onPressed: () => Navigator.r,
                  onPressed: () {
                    Navigator.of(context).pop();
                    // Navigator.pushNamedAndRemoveUntil(context, HomePage.routeName,
                    //     ModalRoute.withName(Splash.routeName));
                  }),
            ),
            body: Stack(
              children: <Widget>[
                WebviewScaffold(
                  url: widget.url!,
                  mediaPlaybackRequiresUserGesture: false,
                  withZoom: true,
                  withLocalStorage: true,
                  hidden: true,
                  withJavascript: true,
                  scrollBar: true,
                  clearCookies: true,
                //   // initialChild: false,
                //   // Container(
                //   //   color: Colors.red,
                //   //   child: const Center(
                //   //     child: CircularProgressIndicator(),
                //   //     // Text('Waiting.....'),
                //   //   ),
                //   // ),
                ),
                isLoading
                    ? const Center(
                        child: CircularProgressIndicator(),
                      )
                    : Stack(),
              ],
            )));
  }
}
