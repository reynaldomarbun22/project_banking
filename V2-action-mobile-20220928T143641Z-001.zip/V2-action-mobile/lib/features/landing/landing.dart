import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';

import 'package:bpd_aceh/features/login/login.dart';
import 'package:bpd_aceh/features/register/reg_step1/reg_step1.dart';
import 'package:flutter/material.dart';
import 'dart:async';

class LandingPageScreen extends StatelessWidget {
  static const routeName = '/landing';

  const LandingPageScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
//    final Geolocator geolocator = Geolocator()..forceAndroidLocationManager;
//  Position _currentPosition;
//  String _currentAddress;
//  String first;
//
//   _getCurrentLocation() {
//    geolocator
//        .getCurrentPosition(desiredAccuracy: LocationAccuracy.best)
//        .then((Position position) {
//      // setState(() {
//        _currentPosition = position;
//      // });
//
//      // _getAddressFromLatLng();
//    }).catchError((e) {
//      print(e);
//    });
//  }
//
//   _getAddressFromLatLng() async {
//    try {
//      List<Placemark> p = await geolocator.placemarkFromCoordinates(
//          _currentPosition.latitude, _currentPosition.longitude);
//      Placemark place = p[0];
//
//
//        _currentAddress =
//            "${place.administrativeArea},${place.locality},${place.name},${place.position},${place.subLocality},${place.subThoroughfare},${place.thoroughfare},";
//            print(_currentAddress);
//
//
//
//    } catch (e) {
//      print(e);
//    }
//  }
    return WillPopScope(
        onWillPop: () async {
          return Future.value(
              true); //return a `Future` with false value so this route cant be popped or closed.
        },
        child: Scaffold(
          backgroundColor: Pallete.primary,
          body: SafeArea(
            child: Container(
              padding: const EdgeInsets.only(right: 8, left: 8),
              alignment: Alignment.center,
              child: Column(children: <Widget>[
                const SizedBox(height: 8),
                const Spacer(),
                Image.asset(
                  'assets/images/vector-landing.png',
                  height: MediaQuery.of(context).size.height * 0.3,
                ),
                const Spacer(),
                Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    alignment: Alignment.topLeft,
                    child: const Text('SELAMAT DATANG',
                        style: TextStyle(
                            fontSize: 18,
                            color: Colors.white,
                            fontWeight: FontWeight.bold))),
                const SizedBox(
                  height: 8,
                ),
                Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    alignment: Alignment.topLeft,
                    child: const Text(
                      'SATU APLIKASI BERBAGAI TRANSAKSI',
                      style: TextStyle(
                          color: Colors.white, fontWeight: FontWeight.bold),
                    )),
                Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    // alignment: Alignment.topLeft,
                    // ignore: prefer_const_literals_to_create_immutables
                    child: Row(children: <Widget>[
                      const Text(
                        'Segera klik ',
                        style: TextStyle(color: Colors.white),
                      ),
                      const Text(
                        'Daftar.',
                        style: TextStyle(
                            color: Colors.white, fontWeight: FontWeight.bold),
                      ),
                    ])),
                const SizedBox(
                  height: 8,
                ),
                Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    alignment: Alignment.topLeft,
                    child: const Text(
                      'Nikmati beragam layanan dalam genggaman',
                      style: TextStyle(color: Colors.white),
                    )),
                Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    alignment: Alignment.topLeft,
                    child: const Text(
                      'info lebih lanjut dapat mengakses website action.bankaceh.co.id',
                      style: TextStyle(color: Colors.white),
                    )),
                //           Container(
                //             padding: EdgeInsets.symmetric(horizontal: 8),
                //             alignment: Alignment.topLeft,
                //             child: Linkify(

                //   onOpen: _onOpen,
                //   text: "http://action.bankaceh.co.id",
                //   linkStyle: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                //   style: TextStyle(color: Colors.white),
                // ),
                // ),
                // Container(
                //     padding: EdgeInsets.symmetric(horizontal: 8),
                //     alignment: Alignment.topLeft,
                //     child: Text(
                //       'info lebih lanjut klik action.bankaceh.co.id',
                //       style: TextStyle(color: Colors.white),
                //     )),

                const Spacer(),
                //  SizedBox(
                //   height: 16,
                // ),
                // Container(
                //   padding: const EdgeInsets.symmetric(horizontal: 16.0),
                //   child: Row(
                //     mainAxisAlignment: MainAxisAlignment.center,
                //     children: <Widget>[
                //       ISTMenuContainer.white(
                //         image: Image.asset(
                //             'assets/images/icon-promo.png',
                //             width: 50,
                //             color: Colors.white,
                //         ),
                //         onTap: () {},
                //         text: 'Promo & Edukasi',
                //       ),
                //       ISTMenuContainer.white(
                //         image: Image.asset(
                //             'assets/images/icon-jadwal.png',
                //             width: 50,
                //             color: Colors.white,
                //         ),
                //         onTap: () {
                //             Navigator.pushNamed(context, SchedulePray.routeName);
                //         },
                //         text: 'Jadwal Sholat',
                //       ),
                //     ],
                //   ),
                // ),
                const SizedBox(
                  height: 16,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    const SizedBox(
                      width: 8,
                    ),
                    Expanded(
                      flex: 7,
                      child: ISTOutlineButton.secondary(
                        onPressed: () {
                          Navigator.of(context).pushNamed(RegStep1.routeName);
                        },
                        text: "Daftar",
                      ),
                    ),
                    const SizedBox(
                      width: 16,
                    ),
                    Expanded(
                      flex: 7,
                      child: ISTOutlineButton.white(
                        onPressed: () {
                          Navigator.of(context).pushNamed(LoginPage.routeName);
                        },
                        text: 'Login',
                      ),
                    ),
                    const SizedBox(
                      width: 8,
                    )
                  ],
                ),
                const SizedBox(
                  height: 16,
                )
              ]),
            ),
          ),
        ));
  }
}

// Future<void> _onOpen(LinkableElement link) async {
//   if (await canLaunch(link.url)) {
//     await launch(link.url);
//   } else {
//     throw 'Could not launch $link';
//   }
// }
