// import '/components/Pallete.dart';
// import '/features/login/login.dart';
// import '/features/register/reg_step1/register_step1.dart';
// import '/features/register/stepper.dart';
// import 'package:flutter/material.dart';

// class LandingPage extends StatefulWidget {
//   static const routeName = '/landingpage';
//   @override
//   _LandingPageState createState() => _LandingPageState();
// }

// class _LandingPageState extends State<LandingPage> {
//   @override
//   Widget build(BuildContext context) {
//     var orange = Pallete.thirdy;
//     return Scaffold(
//       backgroundColor: Colors.white,
//       body: SafeArea(
        
//           child: Container(
//             padding: EdgeInsets.only(bottom: 10),
//         alignment: Alignment.topCenter,
//         child: Column(children: <Widget>[
//           Stack(
//             children: <Widget>[
//               Image.asset('assets/images/Landingbackground.png'),
//               Positioned(
//                   left: 40,
//                   top: 360,
//                   child: Text(
//                     'Assalamualaikum',
//                     style: TextStyle(
//                         color: Colors.green[300],
//                         fontSize: 24,
//                         fontWeight: FontWeight.bold),
//                   )),
//               Positioned(
//                   left: 40,
//                   top: 400,
//                   child: Text(
//                     'Mari mulai harimu dengan mengucap Bismillah',
//                     style: TextStyle(color: Colors.green[300], fontSize: 16),
//                   )),
//               Positioned(
//                   left: 40,
//                   top: 420,
//                   child: Text(
//                     'dan ingat selalu bersyukur',
//                     style: TextStyle(color: Colors.green[300], fontSize: 16),
//                   ))
//             ],
//           ),
//           Spacer(),
//           Padding(
//             padding: const EdgeInsets.only(left: 10.0),
//             child: Row(
//               mainAxisAlignment: MainAxisAlignment.center,
//               children: <Widget>[
//                 Container(
//                   margin: EdgeInsets.all(10),
//                   child: Column(
//                     children: <Widget>[
//                       InkWell(
                        
//                           onTap: () {},
//                           child: Container(
                            
//                             child: Column(
//                               children: <Widget>[
//                                 Image.asset(
//                                   'assets/images/Group1246.png',
//                                   width: 50,
//                                 ),
//                                 Text(
//                                   'Promo & Edukasi',
//                                   style: TextStyle(
//                                       color: Pallete.thirdy,
                                      
//                                       fontWeight: FontWeight.w100),
//                                 ),
//                               ],
//                             ),
//                           )),
//                     ],
//                   ),
//                 ),
              
//                 Container(
//                   margin: EdgeInsets.all(10),
//                   child: Column(
//                     children: <Widget>[
//                       InkWell(
//                           onTap: () {},
//                           child: Container(
//                             child: Column(
//                               children: <Widget>[
//                                 Image.asset(
//                                   'assets/images/Group1245.png',
//                                   width: 50,
//                                 ),
//                                 Text(
//                                   'Jadwal Sholat',
//                                   style: TextStyle(
//                                       color: Pallete.thirdy,
                                   
//                                       fontWeight: FontWeight.w100),
//                                 ),
//                               ],
//                             ),
//                           )),
//                     ],
//                   ),
//                 ),
//               ],
//             ),
//           ),
//           SizedBox(
//             height: 8,
//           ),
//           Container(
//             width: 360,
//             child: Row(
//               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               children: <Widget>[
//                 Expanded(
//                   flex: 7,
//                   child: new OutlineButton(
//                     onPressed: () { Navigator.of(context).pushNamed(RegisterStep1.routeName);},
//                     splashColor: orange,
//                     color: orange,
//                     highlightedBorderColor: orange,
//                     focusColor: orange,
//                     shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.all(Radius.circular(50))),
//                     hoverColor: orange,
//                     borderSide: BorderSide(color: orange),
//                     padding: EdgeInsets.all(10),
//                     child: Text(
//                       'DAFTAR',
//                       style: TextStyle(fontSize: 20, color: orange),
//                     ),
//                   ),
//                 ),
//                 SizedBox(
//                   width: 8,
//                 ),
//                 Expanded(
//                   flex: 7,
//                   // fit: FlexFit.tight,
//                   child: new OutlineButton(
//                     onPressed: () {  Navigator.of(context)
//                                 .pushNamed(LoginPage.routeName);
                      
//                     },
//                     splashColor: orange,
//                     color: orange,
//                     highlightedBorderColor: orange,
//                     focusColor: orange,
//                     shape: RoundedRectangleBorder(
//                         borderRadius: BorderRadius.all(Radius.circular(50))),
//                     hoverColor: orange,
//                     borderSide: BorderSide(color: orange),
//                     padding: EdgeInsets.all(10),
//                     child: Text(
//                       'LOGIN',
//                       style: TextStyle(fontSize: 20, color: orange),
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           )
//         ]),
//       )),
//     );
//   }
// }
