import 'dart:convert';

import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_receipt.dart';
import 'package:bpd_aceh/components/ist_receipt_repo.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/features/inbox/inbox_db.dart';
import 'package:bpd_aceh/features/inbox/model/inbox_model.dart';
import 'package:bpd_aceh/features/inbox/page/inbox.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PDAM/tirtadaroy/widgets/list_detail.dart';
import 'package:flutter/material.dart';

class ResiInbox extends StatefulWidget {
  static const routeName = 'resiInbox';
  final List<ISTReceiptItemInbox>? lists;

  final List<ISTReceiptItem>? list;

  final String? amount;
  final ISTReceiptStatusInbox? status;
  // final status1;

  final String? noRef;
  final String? img;
  final int? id;
  final String? title;
  final String? subtitle;
  final String? imagetab;
  final String? type;
  final String? receiptItemTitle;
  final String? jenistabungan;
  final String? detail;
  final String? time;
  final String? date;
  final String? waktu;
  final String? srcAcc;
  final String? srcAccount;
  final String? transactionGroup;
  final String? nameBank;
  final String? titledepo;
  final String? memo;
  final String? bilyet;
  final String? titleresi;
  final String? titleresi1;

  final String? keterangan1;
  final String? keterangan2;
  final List<ISTReceiptItemInbox>? listinfo;
  final List<ISTReceiptItemInbox>? receiptItemImage;
  final List<DetailItem>? detailresi;
  final List<ISTReceiptItemInbox>? listTOTALBAYAR;

  // final String listinfo;

  const ResiInbox({
    Key? key,
    this.srcAcc,
    this.waktu,
    this.list,
    this.lists,
    this.date,
    this.time,
    this.detail,
    this.amount,
    this.status,
    this.noRef,
    this.nameBank,
    this.img,
    this.title,
    this.srcAccount,
    this.id,
    this.jenistabungan,
    // this.status1,
    this.titleresi,
    this.memo,
    this.titleresi1,
    this.receiptItemImage,
    this.receiptItemTitle,
    this.subtitle,
    this.imagetab,
    this.type,
    this.bilyet,
    this.keterangan1,
    this.transactionGroup,
    this.keterangan2,
    this.detailresi,
    this.listTOTALBAYAR,
    this.titledepo,
    this.listinfo,
  }) : super(key: key);

  @override
  _ResiInboxState createState() => _ResiInboxState();
}

class _ResiInboxState extends State<ResiInbox> {
  List<ISTReceiptItem>? list;
  List<ISTReceiptItemInbox>? lists;
  List<DetailItem>? listDetailResi;
  List<ISTReceiptItemInbox>? listinfo;
  List<ISTReceiptItemInbox>? listDetailTotal;
  // String keterangan3;
  String? amount;
  ISTReceiptStatusInbox? status;
  String? noRef;
  String? img;
  int? id;
  String? bilyet;
  String? title;
  String? detail;
  bool? _success;
  String? time;
  String? jenistabungan;
  String? date;
  String? waktu;
  String? srcAccount;
  String? memo;
  String? imgTab;
  String? subtitle; //
  String? titleresi;
  String? titleresi1;
  String? nameBank;
  bool? isLoading;
  String? type;
  String? titledepo;

  @override
  initState() {
    _success = false;
    print(widget.transactionGroup);
    imgTab = widget.imagetab;
    status = widget.status;
    nameBank = widget.nameBank;
    titleresi = widget.titleresi;
    titleresi1 = widget.titleresi1;
    subtitle = widget.subtitle;
    listDetailTotal = widget.listTOTALBAYAR;
    srcAccount = widget.srcAccount;
    listDetailResi = widget.detailresi;
    waktu = widget.waktu;
    noRef = widget.noRef;
    lists = widget.lists;
    list = widget.list;
    amount = widget.amount;
    bilyet = widget.bilyet;
    img = widget.img;
    id = widget.id;
    title = widget.title;
    detail = widget.detail;
    time = widget.time;
    date = widget.date;
    titledepo = widget.titledepo;
    listinfo = widget.listinfo;
    jenistabungan = widget.jenistabungan;
    type = 'QRPAYMENT';
    print(_success);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    _doFinish() {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => const Inbox()));
    }

    _cekStatusQR() async {
      print('object');
      print(_success);

      Map<String, Object?> param = {};
      param['idresi'] = widget.noRef;
      final resp = await API.post(context, "/qr/issuer/cekstatus", param);
      if (resp != null && resp['code'] != null && resp['code'] == 0) {
        if (resp['status'] != null && resp['status'] == 'success') {
          status = ISTReceiptStatusInbox.success;
          img = "assets/images/icon-payments-active.png";
        }
        if (resp['status'] != null && resp['status'] == 'suspect') {
          status = ISTReceiptStatusInbox.suspect;
          img = "assets/images/icon-payments-warning.png";
        }
        if (resp['status'] != null && resp['status'] == 'failed') {
          status = ISTReceiptStatusInbox.failed;
          img = "assets/images/icon-payments-failed.png";
        }
        setState(() {
          _success = true;
          id = id;
          subtitle = "QR Payment";
          amount = widget.amount;
          titleresi = widget.titleresi;
          title = widget.title;
          noRef = widget.noRef;
          waktu = widget.waktu;
          list = list;
          lists = lists;
          img = widget.img;
          date = widget.date;
        });
        print(_success);
      } else {
        const DialogBox().showImageDialog(
            message: resp['message'],
            isError: true,
            buttonCancel: 'OK',
            onCancel: () {
              Navigator.pop(context);
            },
            onOk: () {},
            context: context);
      }
    }

    _saveInbox() async {
      InboxDBRepository repo = InboxDBRepository();
      await repo.open();
      InboxModel model = InboxModel();
      model.id = widget.id;
      model.subtitle = widget.subtitle;
      model.listresi = jsonEncode(lists);
      model.listinfo = jsonEncode(listinfo);

      model.amount = amount;
      model.time = time;
      model.date = date;
      model.detail = detail;
      model.image = "assets/images/icon-payments-active.png";
      model.status = status!.index.toString();
      // model.status = widget.status.index.toString();
      model.titleresi = titleresi;
      model.transactionType = "QRPAYMENT";
      model.title = title;
      // model.srcAcc = srcAccount;
      model.noRef = noRef;
      await repo.update(model);

      await repo.close();
    }

    _doAddFav() async {
      Map<String, Object?> param = {};
      param['idresi'] = widget.noRef;
      final resp = await API.post(context, '/favorite/add', param);
      if (resp != null && resp['code'] == 0) {
        showDialog(
          context: context,
          barrierDismissible: false,
          useRootNavigator: true,
          builder: (BuildContext context) {
            return AlertDialog(
              // contentPadding: EdgeInsets.all(8),
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(20.0)),
              ),
              content: SingleChildScrollView(
                child: Column(
                  children: <Widget>[
                    const Text(
                      'Berhasil',
                      style: TextStyle(color: Pallete.primary, fontSize: 20),
                    ),
                    const SizedBox(
                      height: 4,
                    ),
                    Image(
                      height: MediaQuery.of(context).size.width * 0.25,
                      image: const AssetImage('assets/images/icon-success.png'),
                    ),
                    const SizedBox(
                      height: 4,
                    ),
                    const Text('Favorit berhasil di tambahkan',
                        textAlign: TextAlign.center),
                    const SizedBox(
                      height: 8,
                    ),
                    Container(
                      alignment: Alignment.center,
                      child: OutlinedButton(
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(
                            color: Pallete.primary,
                          ),
                          primary: Pallete.primary,
                          shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.all(Radius.circular(18)),
                          ),
                        ),
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: Text(
                          "Ok",
                          style: Theme.of(context)
                              .textTheme
                              .bodyText1!
                              .copyWith(
                                  fontWeight: FontWeight.w600,
                                  color: Pallete.primary),
                        ),
                      ),
                    )
                  ],
                ),
              ),
              //actions: _checkbutton(context),
            );
          },
        );
      } else {
        showDialog(
          context: context,
          barrierDismissible: false,
          useRootNavigator: true,
          builder: (BuildContext context) {
            return AlertDialog(
              // contentPadding: EdgeInsets.all(8),
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(20.0)),
              ),
              content: SingleChildScrollView(
                child: Column(
                  children: <Widget>[
                    const Text(
                      'Peringatan',
                      style: TextStyle(
                        color: Colors.red,
                        fontSize: 20,
                      ),
                    ),
                    const SizedBox(
                      height: 4,
                    ),
                    Image(
                      height: MediaQuery.of(context).size.width * 0.25,
                      image: const AssetImage('assets/images/icon-warning.png'),
                    ),
                    const SizedBox(
                      height: 4,
                    ),
                    Text(resp['message'], textAlign: TextAlign.center),
                    const SizedBox(
                      height: 8,
                    ),
                    Container(
                      alignment: Alignment.center,
                      child: OutlinedButton(
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(
                            color: Colors.red,
                          ),
                          // splashColor: Colors.red,
                          shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.all(Radius.circular(18)),
                          ),
                        ),
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: Text(
                          "Ok",
                          style: Theme.of(context)
                              .textTheme
                              .bodyText1!
                              .copyWith(
                                  fontWeight: FontWeight.w600,
                                  color: Colors.red),
                        ),
                      ),
                    )
                  ],
                ),
              ),
              //actions: _checkbutton(context),
            );
          },
        );
      }

      // Navigator.pop(context);
    }

    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
          backgroundColor: Colors.white,
          body: _success!
              ? ISTReceiptInbox(
                  titledepo: widget.titledepo,
                  imageTab: widget.imagetab,
                  detail: widget.detail,
                  transactionGroup: widget.transactionGroup,
                  receiptItemImage: widget.receiptItemImage,
                  receiptItemTitle: widget.receiptItemTitle,
                  type: widget.subtitle,
                  id: id,
                  titleresi: titleresi,
                  titleresi1: titleresi1,
                  memo: widget.memo,
                  noRef: noRef,
                  dstAcc: time,
                  srcNOAcc: detail,
                  additional: widget.keterangan1,
                  time: date,
                  srcAcc: srcAcc,
                  bilyet: widget.bilyet,
                  onTap: () {
                    Navigator.pop(context);
                    _doAddFav();
                  },
                  items: lists,
                  listdetail: widget.detailresi,
                  onFinished: () {
                    _saveInbox();
                    _doFinish();
                  },
                  onCheck: () {
                    _cekStatusQR();
                  },
                  // listdetail: widget.listDETAIL,
                  jenistabungan: widget.jenistabungan,
                  listtotalbayar: widget.listTOTALBAYAR,
                  // title: widget.title,
                  amount: amount,
                  footer1: widget.keterangan1 == null
                      ? Container()
                      : Text(
                          widget.keterangan1!,
                          style: const TextStyle(fontSize: 11),
                          textAlign: TextAlign.center,
                        ),
                  footer2: widget.keterangan2 == null
                      ? Container()
                      : Text(
                          widget.keterangan2!,
                          style: const TextStyle(fontSize: 11),
                          textAlign: TextAlign.center,
                        ),
                  footer3: listinfo,
                  // footer3: widget.listinfo == null
                  //     ? Container()
                  //     : Column(
                  //         mainAxisAlignment: MainAxisAlignment.center,
                  //         children: _generatedList()),
                  // footer3: widget.listinfo == null
                  //     ? Container()
                  //     : Text(
                  //         widget.listinfo,
                  //         style: TextStyle(fontSize: 11),
                  //         textAlign: TextAlign.center,
                  //       ),
                  status: status)
              : ISTReceiptInbox(
                  type: "QRPAYMENT",
                  jenistabungan: widget.jenistabungan,
                  imageTab: widget.imagetab,
                  detail: widget.detail,
                  titledepo: widget.titledepo,
                  transactionGroup: widget.transactionGroup,
                  receiptItemImage: widget.receiptItemImage,
                  receiptItemTitle: widget.receiptItemTitle,
                  id: widget.id,
                  titleresi: widget.titleresi,
                  titleresi1: widget.titleresi1,
                  additional: widget.keterangan1,
                  memo: widget.memo,
                  bilyet: widget.bilyet,
                  noRef: widget.noRef,
                  dstAcc: widget.time,
                  srcNOAcc: widget.detail,
                  time: widget.date,
                  srcAcc: widget.srcAcc,
                  onTap: () {
                    Navigator.pop(context);
                    _doAddFav();
                  },
                  items: widget.lists,
                  onFinished: () {
                    _doFinish();
                    // _saveInbox();
                  },
                  onCheck: () {
                    _cekStatusQR();
                  },
                  listdetail: widget.detailresi,
                  listtotalbayar: widget.listTOTALBAYAR,
                  // title: widget.title,
                  amount: widget.amount,
                  footer1: widget.keterangan1 == null
                      ? Container()
                      : Text(
                          widget.keterangan1!,
                          style: const TextStyle(fontSize: 11),
                          textAlign: TextAlign.center,
                        ),
                  footer2: widget.keterangan2 == null
                      ? Container()
                      : Text(
                          widget.keterangan2!,
                          style: const TextStyle(fontSize: 11),
                          textAlign: TextAlign.center,
                        ),
                  footer3: widget.listinfo,
                  //     ? Container()
                  //     : Text(
                  //         widget.listinfo,
                  //         style: TextStyle(fontSize: 11),
                  //         textAlign: TextAlign.center,
                  //       ),
                  status: status)),
    );
  }
}
