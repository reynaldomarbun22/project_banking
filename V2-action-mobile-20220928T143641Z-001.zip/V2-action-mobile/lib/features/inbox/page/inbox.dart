import 'dart:convert';
import 'dart:ui';

import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_receipt_repo.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/utils/string_utils.dart';
import 'package:bpd_aceh/features/inbox/page/resi_inbox.dart';
import 'package:bpd_aceh/features/inbox/widget/inbox_widget.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PDAM/tirtadaroy/widgets/list_detail.dart';

import 'package:flutter/material.dart';

class Inbox extends StatefulWidget {
  static const routeName = '/Inbox';

  const Inbox({Key? key}) : super(key: key);

  @override
  _InboxState createState() => _InboxState();
}

class _InboxState extends State<Inbox> {
  @override
  void initState() {
    // _showLoading(context);
    _getInbox();
    super.initState();
  }

  String tfgroup = "";
  bool loading = true;
  bool isLoading = false;
  bool delete = false;
  Color? color;

  _getInbox() async {
    final resp = await API.postNoLoading(context, '/inbox/list', {});
    if (resp != null && resp['code'] == 0) {
      List<InboxItem> _listitems = [];
      var listResp = resp['inboxItemList'];
      List<dynamic> listRespDyn = (listResp);
      for (var item in listRespDyn) {
        String status;
        var responseCode = item['srcSystemErrorCode'];

        // ignore: unused_local_variable
        List<ISTReceiptItemInbox> _dataitem = [];
        ISTReceiptStatusInbox status1;

        if ("00" == responseCode) {
          color = Pallete.primary;
          status = "Berhasil";
          status1 = ISTReceiptStatusInbox.success;
        } else if ("68" == responseCode) {
          color = Pallete.warning;
          status = "Sedang diproses";
          status1 = ISTReceiptStatusInbox.suspect;
        } else {
          color = Pallete.error;
          status = "Gagal";
          status1 = ISTReceiptStatusInbox.failed;
        }
        // List<ISTReceiptItemInbox> listParam2 = [];
        // // print(item['tranAdditionalData1']);
        // var info = item['tranAdditionalData1'];
        // // print(info);

        // dynamic infoFlightMap = json.decode(info);
        // for (var itemInbox in infoFlightMap) {
        //   ISTReceiptItemInbox itemParam = ISTReceiptItemInbox(
        //       key: itemInbox['key'], value: itemInbox['value']);
        //   listParam2.add(itemParam);
        // }
        // print(item['bpName']);
        var transactionGroup = item['transactionGroup'];
        var transactionCode = item['transactionCode'];
        var accountname = item['srcAccountOwnerName'];
        var accountno = item['srcAccountNo'];
        String image = "";
        String subtitle = "";
        String? bankName = "";

        if (transactionGroup != "TRANSFER") {
          image = "assets/images/icon-payments-active.png";
          subtitle = "Layanan";
          bankName = item['bpName'];
        } else if (transactionCode == "5501") {
          image = "assets/images/icon-tranfer-active.png";
          subtitle = "Transfer SKN";
          bankName = item['dstBankName'];
        } else if (transactionCode == "5502") {
          image = "assets/images/icon-tranfer-active.png";
          subtitle = "Transfer RTGS";
          bankName = item['dstBankName'];
        } else {
          image = "assets/images/icon-tranfer-active.png";
          subtitle = "Transfer";
          bankName = item['dstBankName'];
        }

        List<DetailItem> listDetail = [];
        String? itemDetail = item['recaiptItemDetail'];

        List<DetailItem> _listitemdetail = [];
        if (itemDetail != null) {
          dynamic itemReceiptMapDetail = json.decode(itemDetail);
          for (var item in itemReceiptMapDetail) {
            _listitemdetail.add(DetailItem(
                periode: item['periode'],
                pemakaian: item['pemakaian'],
                denda: item['denda'],
                biaya: item['biaya'],
                tagihan: item['tagihan'],
                noReff: item['noReff'],
                noReffStr: item['noReffStr']));
          }
          setState(() {
            listDetail = _listitemdetail;
            print(listDetail);
          });
        }

        List<ISTReceiptItemInbox> listParam = [];

        String? itemReceipt = item['recaiptItem'];
        if (itemReceipt != null) {
          dynamic itemReceiptMap = json.decode(itemReceipt);
          for (var itemInbox in itemReceiptMap) {
            ISTReceiptItemInbox itemParam = ISTReceiptItemInbox(
                key: itemInbox['key'], value: itemInbox['value']);
            listParam.add(itemParam);
          }
        }

        List<ISTReceiptItemInbox> listParamImage = [];

        String? itemReceiptImage = item['recaiptItemImage'];
        if (itemReceiptImage != null) {
          dynamic itemReceiptImageMap = json.decode(itemReceiptImage);

          for (var item in itemReceiptImageMap) {
            ISTReceiptItemInbox itemParamImage =
                ISTReceiptItemInbox(key: item['key'], value: item['value']);
            listParamImage.add(itemParamImage);
          }
        }

        List<ISTReceiptItemInbox> listParam2 = [];
        String? itemReceipt2 = item['tranAdditionalData'];
        if (itemReceipt2 != null) {
          dynamic itemReceiptMap2 = json.decode(itemReceipt2);
          for (var itemInbox2 in itemReceiptMap2) {
            ISTReceiptItemInbox itemParam2 = ISTReceiptItemInbox(
                key: itemInbox2['key'], value: itemInbox2['value']);
            listParam2.add(itemParam2);
          }
        }

        List<ISTReceiptItemInbox> listTotal = [];
        String? itemReceiptTotal = item['recaiptItemTotalBayar'];
        if (itemReceiptTotal != null) {
          dynamic itemReceiptMapTotal = json.decode(itemReceiptTotal);
          for (var item in itemReceiptMapTotal) {
            ISTReceiptItemInbox itemParamTotal =
                ISTReceiptItemInbox(key: item['key'], value: item['value']);
            listTotal.add(itemParamTotal);
          }
        }

        _listitems.add(InboxItem(
          bilyet: item['bilyetNumber'],
          imgTab: item['imageOpenAccount'],
          jangkaWaktu: item['titleJangkaWaktu'],
          memo: item['recaiptItemContentImage'],
          receiptItemTitle: item['recaiptItemTitleImage'],
          detail: item['recaiptItemTitle'],
          receiptItemImage: listParamImage,
          transactionCode: item['transactionCode'],
          detailResi: listDetail,
          transactionGroup: item['transactionGroup'],
          // sctAccountNumber: item['dstAcctNo'],
          keterangan1: item['additionalInfo'],
          keterangan2: item['additionalInfo1'],
          textStatus: status,
          noRef: item['transactionId'],
          colorStatus: color,
          listresi: listParam,
          listinfo: listParam2,
          listTotalbayar: listTotal,
          subtitle: subtitle,
          titledepo: item['title'],
          titleresi: item['bpCustomerName'],
          titleresi1: item['merchant'],
          id: item['id'],
          jenistabungan: item['bpServiceNo'],
          amount: item['transactionAmount'].toString(),
          date: item['transactionDateTime'].toString(),
          status1: status1,
          image: image,
          nameBank: bankName,
          srcAcc: accountname,
          sctAccountNumber: accountno,

          // title: item['srcBankName'],
        ));
      }
      setState(() {
        _listitem = _listitems;
      });
    } else {}
    setState(() {
      loading = false;
    });
  }

  // ignore: unused_element
  _loading() {
    if (isLoading = true) {
      _showLoading(context);
    } else {
      isLoading = false;
    }
    return isLoading;
  }

  // ignore: unused_field
  final List<InboxItem> _deleteditem = [];
  List<InboxItem> _listitem = [];
  _doDelete(int? id) async {
    // await Future.delayed(Duration(seconds: 3));
    if (delete) {
      Map<String, Object?> param = {};
      param['id'] = id;
      // ignore: unused_local_variable
      final resp = await API.post(context, '/inbox/delete', param);
      await Future.delayed(const Duration(seconds: 0));

      // if (resp != null && resp['code'] == 0) {
      //   // callback(this.nameBank, this.noRek, this.ownerName, this.destcode,
      //   //     this.id); // buat rfresh screen sesudah didelete
      // }
    }
    Navigator.pop(context);
    await _getInbox();
  }

  // ignore: unused_element
  _doUndo() {
    setState(() {
      delete = false;
    });
  }

  void _showSnack(BuildContext context, InboxItem item, index) async {
    setState(() {
      delete = true;
    });
    // _listitem.removeAt(index);
    // Scaffold.of(context).showSnackBar(
    //   SnackBar(
    //     duration: Duration(seconds: 4),
    //     content: Text('Item dihapus'),
    //     action: SnackBarAction(
    //       label: 'Urungkan?',
    //       onPressed: () {
    //         _doUndo();
    //       },
    //     ),
    //   ),
    // );
    // await _doDelete(item.id);
  }

  final Widget _appBarTitle = const Text(
    'Pesan',
    style: TextStyle(
        fontFamily: 'Poppins',
        //fontWeight: FontWeight.bold,
        color: Colors.white
        // fontSize: FontSize.TITLE,
        ),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Pallete.primary,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios,
            color: Colors.white,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: _appBarTitle,
      ),
      backgroundColor: Colors.white,
      body: Stack(children: [
        Container(
            padding: const EdgeInsets.only(right: 16, bottom: 16),
            alignment: Alignment.bottomRight,
            child: _listitem.isEmpty
                ? Container()
                : Text(
                    "Geser ke kiri untuk menghapus",
                    style: TextStyle(
                        color: Colors.grey,
                        fontSize:
                            Theme.of(context).textTheme.caption!.fontSize),
                  )),
        Column(
          children: <Widget>[
            Expanded(
              child: Container(
                child: loading
                    ? Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: const <Widget>[
                          Center(child: Text("Memuat transaksi")),
                        ],
                      )
                    : _listitem.isEmpty
                        ? Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: const <Widget>[
                              Center(child: Text("Tidak ada transaksi")),
                            ],
                          )
                        : ListView.separated(
                            separatorBuilder: (ctx, index) {
                              return const Divider(
                                height: 0,
                              );
                            },
                            itemCount: _listitem.length,
                            itemBuilder: (context, index) {
                              final item = _listitem[index];
                              return Dismissible(
                                onDismissed: (direction) {
                                  _showSnack(context, item, index);
                                  const DialogBox().showImageDialog(
                                      message:
                                          "Apakah Anda yakin akan menghapus Pesan",
                                      context: context,
                                      buttonCancel: "Tidak",
                                      buttonOk: "Hapus",
                                      image: Image.asset(
                                        'assets/images/icon-warning.png',
                                        scale: 3,
                                      ),
                                      isError: true,
                                      onOk: () {
                                        _doDelete(item.id);
                                        // _listitem.removeAt(index);

                                        // _doremoveT();
                                      });
                                },
                                background: Container(
                                  alignment: Alignment.centerRight,
                                  color: Colors.red,
                                  child: IconButton(
                                    icon: const Icon(Icons.restore_from_trash),
                                    color: Colors.white,
                                    onPressed: () {},
                                  ),
                                ),
                                key: UniqueKey(),
                                direction: DismissDirection.endToStart,
                                child: InkWell(
                                  onTap: () {
                                    Navigator.pushReplacement(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) => ResiInbox(
                                                  img: '',
                                                  nameBank: '',
                                                  srcAccount: '',
                                                  waktu: '',
                                                  titledepo: item.titledepo,
                                                  jenistabungan:
                                                      item.jenistabungan,
                                                  imagetab: item.imgTab,
                                                  transactionGroup:
                                                      item.transactionGroup,
                                                  receiptItemImage:
                                                      item.receiptItemImage,
                                                  receiptItemTitle:
                                                      item.receiptItemTitle,
                                                  detailresi: item.detailResi,
                                                  type: item.subtitle,
                                                  subtitle: item.subtitle,
                                                  id: item.id,
                                                  status: item.status1,
                                                  title: item.title,
                                                  amount: item.amount,
                                                  srcAcc: "item.srcAcc",
                                                  date: item.date,
                                                  detail: item.detail,

                                                  time: "item.time",
                                                  noRef: item.noRef,
                                                  memo: item.memo,
                                                  list: item.lists,
                                                  lists: item.listresi,
                                                  titleresi1: item.titleresi1,
                                                  listinfo: item.listinfo,
                                                  bilyet: item.bilyet,
                                                  listTOTALBAYAR:
                                                      item.listTotalbayar,
                                                  titleresi: item.titleresi ??
                                                      item.nameBank,
                                                  keterangan1: StringUtils
                                                      .getValueAsString(
                                                          item.keterangan1!),
                                                  keterangan2: StringUtils
                                                      .getValueAsString(
                                                          item.keterangan2!),

                                                  // srcAcc: item.srcAcc,
                                                  // date: item.date,
                                                  // detail: item.detail,
                                                  // time: item.time,
                                                  // noRef: item.noRef,
                                                  // memo: item.memo,
                                                  // lists: item.listresi,
                                                  // list: item.lists,
                                                  // titleresi: item.titleresi,
                                                  // keterangan1:
                                                  //     item.keterangan1,
                                                  // keterangan2:
                                                  //     item.keterangan2,
                                                )));
                                  },
                                  child: Container(
                                    padding: const EdgeInsets.only(
                                        top: 16,
                                        right: 16,
                                        left: 8,
                                        bottom: 16),
                                    child: Column(
                                      children: <Widget>[
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: <Widget>[
                                            item.transactionCode == 'DAO' ||
                                                    item.transactionCode ==
                                                        'DISBURSEMENT_DEPOSITO' ||
                                                    item.transactionCode ==
                                                        'DDO' ||
                                                    item.transactionCode ==
                                                        'CLOSE_ACCOUNT'
                                                ? Expanded(
                                                    child: SizedBox(
                                                      child: Image.asset(
                                                          "assets/images/tabunganinbox.png"),
                                                      width:
                                                          // height: 35,
                                                          MediaQuery.of(context)
                                                                  .size
                                                                  .width /
                                                              5,
                                                    ),
                                                  )
                                                : Expanded(
                                                    child: SizedBox(
                                                      child: Image.asset(
                                                          "${item.image}"),
                                                      width:
                                                          // height: 35,
                                                          MediaQuery.of(context)
                                                                  .size
                                                                  .width /
                                                              5,
                                                    ),
                                                  ),
                                            const SizedBox(
                                              width: 4,
                                            ),
                                            Expanded(
                                              flex: 7,
                                              child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: <Widget>[
                                                    Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceBetween,
                                                      children: [
                                                        item.transactionCode ==
                                                                'DISBURSEMENT_DEPOSITO'
                                                            ? const Text(
                                                                'Pencairan Deposito',
                                                                style:
                                                                    TextStyle(
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold,
                                                                ))
                                                            : item.transactionGroup ==
                                                                    "CLOSINGACCOUNT"
                                                                ? const Text(
                                                                    'Penutupan Tabungan',
                                                                    style:
                                                                        TextStyle(
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .bold,
                                                                    ))
                                                                : item.transactionCode ==
                                                                        'DDO'
                                                                    ? const Text(
                                                                        'Pembukaan Deposito',
                                                                        style:
                                                                            TextStyle(
                                                                          fontWeight:
                                                                              FontWeight.bold,
                                                                        ))
                                                                    : item.transactionCode ==
                                                                            'DAO'
                                                                        ? const Text(
                                                                            'Pembukaan Tabungan',
                                                                            style:
                                                                                TextStyle(
                                                                              fontWeight: FontWeight.bold,
                                                                            ))
                                                                        :
                                                                        // item.transactionCode == 'CLOSE_ACCOUNT' ?
                                                                        // Text(
                                                                        //   'Penutupan Rekening',
                                                                        //   style:
                                                                        //         TextStyle(
                                                                        //       fontWeight:
                                                                        //           FontWeight.bold,
                                                                        //     )
                                                                        // ) :
                                                                        Text(
                                                                            item
                                                                                .subtitle!,
                                                                            style:
                                                                                const TextStyle(
                                                                              fontWeight: FontWeight.bold,
                                                                            )),
                                                        item.date == ""
                                                            ? Container()
                                                            : Text(
                                                                item.date!,
                                                                style: TextStyle(
                                                                    fontSize: Theme.of(
                                                                            context)
                                                                        .textTheme
                                                                        .caption!
                                                                        .fontSize),
                                                              ),
                                                      ],
                                                    ),
                                                    // Row(
                                                    //   children:[
                                                    item.transactionGroup ==
                                                            'OPENINGDEPOSITO'
                                                        ? Text(
                                                            item.jangkaWaktu!)
                                                        : item.transactionGroup ==
                                                                'DISBURSEMENTDEPOSITO'
                                                            ? Text(item
                                                                .jangkaWaktu!)
                                                            :
                                                            // item.transactionGroup ==
                                                            //         'OPENINGACCOUNT'
                                                            //     ? Text(item
                                                            //         .receiptItemTitle)
                                                            //     :
                                                            item.transactionGroup ==
                                                                    'OPENINGACCOUNT'
                                                                ? Text(item
                                                                    .titledepo!)
                                                                : item.transactionGroup ==
                                                                        'CLOSINGACCOUNT'
                                                                    ? Text(item
                                                                        .jenistabungan!)
                                                                    : item.title ==
                                                                            null
                                                                        ? Container()
                                                                        : Text(item
                                                                            .title!),
                                                    item.nameBank == null
                                                        ? Container()
                                                        : Text(
                                                            item.nameBank!,
                                                          ),
                                                    item.transactionGroup ==
                                                            'OPENINGDEPOSITO'
                                                        ? Text(
                                                            'Nomor Rekening ${item.sctAccountNumber}')
                                                        : Container(),
                                                    item.transactionGroup ==
                                                            'DISBURSEMENTDEPOSITO'
                                                        ? Text(
                                                            'Nomor Rekening ${item.sctAccountNumber}')
                                                        : Container(),
                                                    item.amount == "" ||
                                                            item.amount ==
                                                                'IDR 0.00' ||
                                                            item.transactionGroup ==
                                                                'OPENINGACCOUNT'
                                                        ? Container()
                                                        : Text(item.amount!,
                                                            style:
                                                                const TextStyle(
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                            )),

                                                    Text(
                                                      item.textStatus!,
                                                      style: TextStyle(
                                                          color:
                                                              item.colorStatus),
                                                    ),
                                                  ]),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              );
                            }),
              ),
            ),
            const SizedBox(
              height: 8,
            )
          ],
        ),
      ]),
    );
  }
}

_showLoading(BuildContext context) {
  showDialog(
    context: context,
    barrierDismissible: false,
    builder: (context) {
      return WillPopScope(
        onWillPop: () async => false,
        child: Stack(
          children: [
            Positioned.fill(
                child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                    child: Container(
                      color: Colors.white12,
                    ))),
            const Center(
                child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Pallete.primary),
            ))
          ],
        ),
      );
    },
  );
}
