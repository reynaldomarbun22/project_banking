import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'dart:async';
import 'package:bpd_aceh/features/inbox/model/inbox_model.dart';

const String tableName = "inbox";
const String id = 'id';
const String image = 'image';
const String title = 'title';
const String detail = 'detail';
const String amount = 'amount';
const String date = 'date';
const String time = 'time';
const String status = 'status';
const String srcAcc = 'srcAcc';
const String noRef = 'noRef';
const String memo = 'memo';
const String listresi = 'listresi';
const String subtitle = 'subtitle';
const String nameBank = 'nameBank';
const String titleresi = 'titleresi';
const String keterangan1 = 'keterangan1';
const String keterangan2 = 'keterangan2';
const String sctAccountNumber = 'sctAccountNumber';
const String transaksiDate = 'transaksiDate';
const String transactionType = 'transactionType';

class InboxDBRepository {
  late Database db;

  Future open() async {
    var dbPath = await getDatabasesPath();
    db = await openDatabase(
      join(dbPath, 'inbox.db'),
      onCreate: (db, version) {
        return db.execute(
          "CREATE TABLE $tableName($id INTEGER PRIMARY KEY AUTOINCREMENT, $image TEXT, $title TEXT, $detail TEXT, $amount TEXT, $date TEXT, $time TEXT, $status TEXT, $srcAcc TEXT, $noRef TEXT, $memo TEXT, $listresi TEXT, $subtitle TEXT, $nameBank TEXT, $titleresi TEXT, $keterangan1 TEXT, $keterangan2 TEXT, $sctAccountNumber TEXT, $transaksiDate TEXT,$transactionType TEXT)",
        );
      },
      version: 1,
    );
  }

  Future<void> insert(InboxModel inbox) async {
    if (inbox.id == null) {
      String sql = "SELECT last_insert_rowid()";
      var res = await db.rawQuery(sql);
      inbox.id = res[0]['id'] as int?;
    }
    await db.insert(
      tableName,
      inbox.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<InboxModel?> getReceipt(int id) async {
    List<Map> maps =
        await db.query(tableName, where: '$id = ?', whereArgs: [id]);
    if (maps.isNotEmpty) {
      return InboxModel.fromMap(maps.first as Map<String, dynamic>);
    }
    return null;
  }

  Future<List<InboxModel>?> getAll() async {
    List<Map> maps = await db.query(tableName, orderBy: "$id DESC");
    if (maps.isNotEmpty) {
      List<InboxModel> ret = [];
      for (var map in maps) {
        InboxModel model = InboxModel();
        model.subtitle = map['subtitle'];
        model.listresi = map['listresi'];
        model.amount = map['amount'];
        model.date = map['date'];
        model.detail = map['detail'];
        model.id = map['id'];
        model.image = map['image'];
        model.status = map['status'];
        model.time = map['time'];
        model.title = map['title'];
        model.srcAcc = map['srcAcc'];
        model.noRef = map['noRef'];
        model.memo = map['memo'];
        model.nameBank = map['nameBank'];
        model.titleresi = map['titleresi'];
        model.keterangan1 = map['keterangan1'];
        model.keterangan2 = map['keterangan2'];
        model.sctAccountNumber = map['sctAccountNumber'];
        model.transaksiDate = map['transaksiDate'];
        model.transactionType = map['transactionType'];

        ret.add(model);
      }
      return ret;
    } else {
      return null;
    }
  }

  Future<int> delete(int ids) async {
    return await db.delete(tableName, where: '$id = ?', whereArgs: [ids]);
  }

  Future<int> deleteAll() async {
    return await db.delete(tableName);
  }

  Future<int> update(InboxModel model) async {
    return await db.update(tableName, model.toMap(),
        where: '$id = ?', whereArgs: [model.id]);
  }

  Future close() async => db.close();
}
