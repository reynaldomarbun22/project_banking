import 'package:bpd_aceh/components/ist_receipt.dart';
import 'package:bpd_aceh/components/ist_receipt_repo.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PDAM/tirtadaroy/widgets/list_detail.dart';
import 'package:flutter/material.dart';

class InboxItem {
  final String? jenistabungan;
  final int? id;
  final String? image;
  final String? title;
  final String? detail;
  final String? jangkaWaktu;
  final String? transactionCode;
  final String? transactionGroup;
  final String? amount;
  final String? date;
  final String? receiptItemTitle;
  final String? time;
  final String? status;
  final String? srcAcc;
  final String? imgTab;
  final String? noRef;
  final String? noRefCek;
  final String? memo;
  final String? subtitle;
  final String? nameBank;
  final String? titleresi;
  final String? titleresi1;
  final String? titledepo;
  final String? bilyet;
  final List<ISTReceiptItemInbox>? listresi;
  final List<ISTReceiptItemInbox>? receiptItemImage;
  final List<ISTReceiptItem>? lists;
  final List<DetailItem>? detailResi;
  final List<ISTReceiptItemInbox>? listinfo;
  final List<ISTReceiptItemInbox>? listDetail;

  final List<ISTReceiptItemInbox>? listTotalbayar;

  // final String listinfo;

  final ISTReceiptStatusInbox? status1;
  final Color? colorStatus;
  final String? textStatus;
  final String? statusStr;

  final String? keterangan1;
  final String? keterangan2;
  final String? sctAccountNumber;
  final String? transaksiDate;

  //

  InboxItem({
    this.jenistabungan,
    this.status1,
    this.imgTab,
    this.statusStr,
    this.jangkaWaktu,
    this.receiptItemImage,
    this.detailResi,
    this.receiptItemTitle,
    this.transactionGroup,
    this.transactionCode,
    this.transaksiDate,
    this.sctAccountNumber,
    this.textStatus,
    this.colorStatus,
    this.image,
    this.id,
    this.listresi,
    this.lists,
    this.title,
    this.detail,
    this.amount,
    this.date,
    this.time,
    this.status,
    this.srcAcc,
    this.noRef,
    this.noRefCek,
    this.memo,
    this.subtitle, //
    this.nameBank,
    this.titleresi,
    this.titleresi1,
    this.bilyet,
    this.listinfo,
    this.listDetail,
    this.listTotalbayar,
    this.keterangan1,
    this.keterangan2,
    this.titledepo,
  });
}

class Notice {
  final String? text;

  Notice({this.text});
}
