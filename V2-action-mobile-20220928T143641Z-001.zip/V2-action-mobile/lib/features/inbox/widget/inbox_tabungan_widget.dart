import 'package:bpd_aceh/components/ist_receipt_tabungan.dart';
import 'package:bpd_aceh/components/ist_receipt_tabungan_inbox.dart';
import 'package:flutter/material.dart';

class InboxItemTabungan {
  final int? id;
  final String? image;
  final String? title;
  final String? detail;
  final String? amount;
  final String? date;
  final String? time;
  final String? status;
  final String? srcAcc;
  final String? noRef;
  final String? noRefCek;
  final String? memo;
  final String? subtitle;
  final String? nameBank;
  final String? titleresi;
  final String? titleresi1;
  final List<ISTReceiptItemTabunganInbox>? listresi;
  final List<ISTReceiptItemTabungan>? lists;
  final List<ISTReceiptItemTabunganInbox>? listinfo;
  // final String listinfo;

  final ISTReceiptStatusTabunganInbox? status1;
  final Color? colorStatus;
  final String? textStatus;
  final String? statusStr;

  final String? keterangan1;
  final String? keterangan2;
  final String? sctAccountNumber;
  final String? transaksiDate;

  //

  InboxItemTabungan({
    this.status1,
    this.statusStr,
    this.transaksiDate,
    this.sctAccountNumber,
    this.textStatus,
    this.colorStatus,
    this.image,
    this.id,
    this.listresi,
    this.lists,
    this.title,
    this.detail,
    this.amount,
    this.date,
    this.time,
    this.status,
    this.srcAcc,
    this.noRef,
    this.noRefCek,
    this.memo,
    this.subtitle, //
    this.nameBank,
    this.titleresi,
    this.titleresi1,
    this.listinfo,
    this.keterangan1,
    this.keterangan2,
  });
}

class Notice {
  final String? text;

  Notice({this.text});
}
