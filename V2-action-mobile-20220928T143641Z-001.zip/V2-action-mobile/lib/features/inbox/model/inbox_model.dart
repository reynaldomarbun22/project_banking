class InboxModel {
  int? id;
  String? image;
  String? title;
  String? subtitle;
  String? detail;
  String? amount;
  String? date;
  String? time;
  String? status;
  String? srcAcc;
  String? noRef;
  String? memo;
  String? listresi;
  String? listinfo;
  String? nameBank;
  String? titleresi;
  String? keterangan1;
  String? keterangan2;
  String? sctAccountNumber;
  String? transaksiDate;
  String? transactionType;

  //

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'image': image,
      'title': title,
      'subtitle': subtitle,
      'detail': detail,
      'amount': amount,
      'date': date,
      'time': time,
      'status': status,
      'srcAcc': srcAcc,
      'noRef': noRef,
      'memo': memo,
      'listresi': listresi,
      'nameBank': nameBank,
      'titleresi': titleresi,
      'keterangan1': keterangan1,
      'keterangan2': keterangan2,
      'sctAccountNumber': sctAccountNumber,
      'transaksiDate': transaksiDate,
      'transactionType': transactionType,
      'listinfo': listinfo,

      //
    };
  }

  InboxModel();

  InboxModel.fromMap(Map<String, dynamic> map) {
    id = map[id as String];
    image = map[image!];
    title = map[title!];
    subtitle = map[subtitle!];
    detail = map[detail!];
    amount = map[amount!];
    date = map[date!];
    time = map[time!];
    status = map[status!];
    srcAcc = map[srcAcc!];
    noRef = map[noRef!];
    memo = map[memo!];
    listresi = map[listresi!];
    nameBank = map[nameBank!];
    keterangan1 = map[keterangan1!];
    keterangan2 = map[keterangan2!];
    sctAccountNumber = map[sctAccountNumber!];
    transaksiDate = map[transaksiDate!];
    transactionType = map[transactionType!];
    listinfo = map[listinfo!];

    //
  }
}
