import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_receipt.dart';
import 'package:bpd_aceh/components/ist_receipt_repo.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/features/home/home_page.dart';
import 'package:bpd_aceh/features/splash/splash.dart';
import 'package:flutter/material.dart';

class PaymentQRreceipt extends StatefulWidget {
  static const routeName = '/paymentQR/receiptQRpayment';
  final List<ISTReceiptItem>? list;
  final List<ISTReceiptItemInbox>? lists;
  final String? amount;
  final ISTReceiptStatus? status;
  final String? noRef;
  final String? img;
  final int? id;
  final String? title;
  final String? detail;
  final String? time;
  final String? date;
  final String? waktu;
  final String? srcAccount;
  final String? memo;
  final String? subtitle; //
  final String? titleresi;
  final String? nameBank;

  const PaymentQRreceipt(
      {Key? key,
      this.subtitle,
      this.lists,
      this.memo,
      this.srcAccount, //
      this.waktu,
      this.list,
      this.date,
      this.time,
      this.detail,
      this.amount,
      this.status,
      this.noRef,
      this.img,
      this.title,
      this.titleresi,
      this.id,
      this.nameBank})
      : super(key: key);

  @override
  _PaymentQRreceiptState createState() => _PaymentQRreceiptState();
}

class _PaymentQRreceiptState extends State<PaymentQRreceipt> {
  List<ISTReceiptItem>? list;
  List<ISTReceiptItemInbox>? lists;
  String? amount;
  ISTReceiptStatus? status;
  String? noRef;
  String? img;
  int? id;
  String? title;
  String? detail;
  bool? _success;
  String? time;
  String? date;
  String? waktu;
  String? srcAccount;
  String? memo;
  String? subtitle; //
  String? titleresi;
  String? nameBank;
  bool? isLoading;

  @override
  initState() {
    _success = false;
    status = widget.status;
    nameBank = widget.nameBank;
    titleresi = widget.titleresi;
    subtitle = widget.subtitle;
    srcAccount = widget.srcAccount;
    waktu = widget.waktu;
    noRef = widget.noRef;
    lists = widget.lists;
    list = widget.list;
    amount = widget.amount;
    img = widget.img;
    title = widget.title;
    detail = widget.detail;
    time = widget.time;
    date = widget.date;
    print(_success);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    _cekStatusQR() async {
      print('object');
      print(_success);

      Map<String, Object?> param = {};
      param['idresi'] = widget.noRef;
      final resp = await API.post(context, "/qr/issuer/cekstatus", param);
      if (resp != null && resp['code'] != null && resp['code'] == 0) {
        if (resp['status'] != null && resp['status'] == 'success') {
          status = ISTReceiptStatus.success;
          img = "assets/images/icon-payments-active.png";
        }
        if (resp['status'] != null && resp['status'] == 'suspect') {
          status = ISTReceiptStatus.suspect;
          img = "assets/images/icon-payments-warning.png";
        }
        if (resp['status'] != null && resp['status'] == 'failed') {
          status = ISTReceiptStatus.failed;
          img = "assets/images/icon-payments-failed.png";
        }
        setState(() {
          _success = true;
          id = id;
          subtitle = "QR Payment";
          amount = widget.amount;
          titleresi = widget.titleresi;
          title = widget.title;
          noRef = widget.noRef;
          waktu = widget.waktu;
          list = list;
          lists = lists;
          img = widget.img;
          date = widget.date;
        });
        print(_success);
      } else {
        const DialogBox().showImageDialog(
            message: resp['message'],
            isError: true,
            buttonCancel: 'OK',
            onCancel: () {
              Navigator.pop(context);
            },
            onOk: () {},
            context: context);
      }
    }
    //   print('object');
    //   print(_success);

    //   Map<String, Object> param = new Map();
    //   param['idresi'] = widget.noRef;
    //   final resp = await API.post(context, "/qr/issuer/cekstatus", param);
    //   if (resp != null && resp['code'] != null && resp['code'] == 0) {
    //     List<ISTReceiptItem> listParam = [];
    //     List<ISTReceiptItemInbox> listParams = [];
    //     List<dynamic> listMap = resp['resi'];

    //     for (var item in listMap) {
    //       ISTReceiptItem itemParam =
    //           ISTReceiptItem(key: item['key'], value: item['value']);
    //       listParam.add(itemParam);
    //     }
    //     for (var item in listMap) {
    //       ISTReceiptItemInbox itemParams =
    //           ISTReceiptItemInbox(key: item['key'], value: item['value']);
    //       listParams.add(itemParams);
    //     }
    //     // List<ISTReceiptItemInbox> listMerchant = [];
    //     //  String itemMerchant = resp['merchant'];
    //     // dynamic itemMerchantMap = json.decode(itemMerchant);
    //     // for (var merchant in itemMerchantMap) {
    //     //   ISTReceiptItemInbox itemParam2 = ISTReceiptItemInbox(
    //     //       key: merchant['key'], value: merchant['value']);
    //     //   listMerchant.add(itemParam2);}
    //     //   List<ISTReceiptItem> listMerchant1 = [];
    //     //  String itemMerchant1 = resp['merchant'];
    //     // dynamic itemMerchantMap1 = json.decode(itemMerchant1);
    //     // for (var merchant in itemMerchantMap1) {
    //     //   ISTReceiptItem itemParams2 = ISTReceiptItem(
    //     //       key: merchant['key'], value: merchant['value']);
    //     //   listMerchant1.add(itemParams2);}

    //     print(listMap);

    //     if (resp['status'] != null && resp['status'] == 'success') {
    //       status = ISTReceiptStatus.success;
    //     }
    //     if (resp['status'] != null && resp['status'] == 'suspect') {
    //       status = ISTReceiptStatus.suspect;
    //     }
    //     if (resp['status'] != null && resp['status'] == 'failed') {
    //       status = ISTReceiptStatus.failed;
    //     }

    //     setState(() {
    //       _success = true;
    //       id = id;
    //       status = status;
    //       subtitle = "QR Payment";
    //       amount = resp['amountStr'];
    //       titleresi = resp['merchant'];
    //       title = resp['merchant'];
    //       noRef = resp['idresi'];
    //       waktu = resp['waktu'];
    //       list = listParam;
    //       lists = listParams;
    //       img = "assets/images/icon-payments-active.png";
    //       date = resp['waktu'];
    //     });
    //     print(_success);
    //   } else {
    //     DialogBox().showImageDialog(
    //         message: resp['message'],
    //         isError: true,
    //         buttonCancel: 'OK',
    //         onCancel: () {
    //           Navigator.pop(context);
    //         },
    //         onOk: () {},
    //         context: context);
    //   }
    // }

    // _saveInbox() async {
    //   InboxDBRepository repo = InboxDBRepository();
    //   await repo.open();
    //   InboxModel model = InboxModel();
    //   model.id = id;
    //   model.subtitle = subtitle;
    //   model.title = title;
    //   model.listresi = jsonEncode(lists);
    //   model.amount = amount;
    //   model.time = time;
    //   model.date = date;
    //   model.detail = detail;
    //   model.image = img;
    //   model.status = status.index.toString();
    //   model.titleresi = titleresi;
    //   model.transactionType = "QRPAYMENT";
    //   model.noRef = noRef;

    //   await repo.insert(model);
    //   await repo.close();
    // }

    _doFinish() {
      print('selesaiii');
      Navigator.pushNamedAndRemoveUntil(
          context, HomePage.routeName, ModalRoute.withName(Splash.routeName));
    }

    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
          backgroundColor: Colors.white,
          body: _success!
              ? ISTReceipt(
                  id: id,
                  noRef: noRef,
                  idresi: noRef,
                  type: "QRPAYMENT",
                  amount: amount,
                  status: status,
                  date: waktu,
                  title: title,
                  detail: nameBank,
                  items: list,
                  onFinished: () {
                    // _saveInbox();
                    _doFinish();
                  },
                  onCheck: () {
                    _cekStatusQR();
                  },
                )
              : ISTReceipt(
                  id: widget.id,
                  noRef: widget.noRef,
                  idresi: widget.noRef,
                  type: "QRPAYMENT",
                  amount: widget.amount,
                  status: widget.status,
                  date: widget.waktu,
                  title: widget.title,
                  items: widget.list,
                  onFinished: () {
                    // _saveInbox();
                    _doFinish();
                  },
                  onCheck: () {
                    _cekStatusQR();
                  },
                )),
    );
  }
}
