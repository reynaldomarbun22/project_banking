import 'dart:io';

import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_card_account.dart';
import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/ist_style.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/features/qrpayment/confirm_merchant_page.dart';
import 'package:bpd_aceh/features/qrtransfer/scanqrtransfer.dart';
import 'package:currency_text_input_formatter/currency_text_input_formatter.dart';
import 'package:flutter/material.dart';
import 'package:qr_code_scanner/qr_code_scanner.dart';

class PaymentQr extends StatefulWidget {
  static const routeName = '/paymentQR';
  final String? nameMerchant;
  final String? placeMerchant;
  final String? amountString;
  final String? feeString;

  final num? amount;
  final String? fee;
  final bool? flagInputFee;
  final bool? flagInputNominal;

  const PaymentQr({
    Key? key,
    this.placeMerchant,
    this.nameMerchant,
    this.amount,
    this.amountString,
    this.feeString,
    this.fee,
    this.flagInputFee,
    this.flagInputNominal,
  }) : super(key: key);

  @override
  _PaymentQrState createState() => _PaymentQrState();
}

class _PaymentQrState extends State<PaymentQr> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  QRViewController? controller;

  @override
  void initState() {
    print(widget.nameMerchant);
    print(widget.fee);
    print(widget.amount);

    if (widget.nameMerchant != null ||
        widget.placeMerchant != null ||
        widget.amount != 0 ||
        widget.fee != null) {
      _nameMerchantcontroller.text = widget.nameMerchant!.trim();
      _placeMerchantcontroller.text = widget.placeMerchant!.trim();
      // _nominalMerchantcontroller.text = widget.amount.toString();
      // if (int.parse(widget.fee) != 0) {
      //   _nominalFeecontroller.text = widget.fee.toString();
      // }
      if (widget.fee != '') {
        _nominalFeecontroller.text = widget.fee.toString();
      }
      if (widget.amount != 0) {
        _nominalMerchantcontroller.text = widget.amount.toString();
      }

      setState(() {});
    }

    super.initState();
  }

  _doTransfer() async {
    if (_doValidate()) {
      Map<String, Object> param = {};
      if (_nominalFeecontroller.text != "") {
        param['fee'] = _nominalFeecontroller.text.replaceAll(',', '');
        // param['fee'] =
        //     int.parse(_nominalFeecontroller.text.replaceAll(",", ""));
      } else {
        param['fee'] = '0';
      }
      param['transactionAmount'] =
          int.parse(_nominalMerchantcontroller.text.replaceAll(".", ""));
      final resp = await API.post(context, '/qr/issuer/inquiry', param);
      if (resp == null) return;
      if (resp['code'] == 0) {
        List<ISTConfirmationItem> listParam = [];
        List<dynamic> listMap = resp['resi'];
        for (var item in listMap) {
          ISTConfirmationItem itemParam =
              ISTConfirmationItem(key: item['key'], value: item['value']);
          listParam.add(itemParam);
        }
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => ConfirmPaymentQRPage(
                      list: listParam,
                    )));
      } else {
        const DialogBox().showImageDialog(
            message: resp['message'],
            isError: true,
            image: const Image(
              image: AssetImage('assets/images/icon-failed.png'),
            ),
            buttonCancel: 'OK',
            onOk: () {},
            context: context);
      }
    }
  }

  final _nameMerchantcontroller = TextEditingController();
  final _placeMerchantcontroller = TextEditingController();
  final TextEditingController _nominalFeecontroller = TextEditingController();

  // final _nominalMerchantcontroller = ISTConstants().moneyMaskedController;
  final TextEditingController _nominalMerchantcontroller = TextEditingController();

  // ignore: unused_field
  final _nominalMerchantStrcontroller = TextEditingController();

  // ignore: unused_field
  bool _autoValidate = false;
  bool fromFee = false;

  bool _doValidate() {
    if (_formKey.currentState!.validate()) {
      return true;
    } else {
      setState(() {
        _autoValidate = true;
      });
      return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: GestureDetector(
          onTap: () async {
            FocusScope.of(context).requestFocus(FocusNode());
            await Future.delayed(const Duration(milliseconds: 500));
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => const TransferQR(),
              ),
            );
          },
          child: const IconButton(
            icon: Icon(Icons.arrow_back_ios, color: Colors.white),
            onPressed: null,
          ),
        ),
        centerTitle: true,
        title: const Text(
          'Pembayaran QR',
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'Poppins',
          ),
        ),
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      body: GestureDetector(
        onTap: () {
          if (Platform.isIOS) hideKeyboard(context);
        },
        child: Container(
          color: Colors.white,
          child: SingleChildScrollView(
            child: Column(
              children: <Widget>[
                ISTCardAccount(
                  context: context,
                  menu: ISTMenu.qr,
                ),
                const SizedBox(
                  height: 16,
                ),
                Container(
                  padding: const EdgeInsets.only(left: 16, right: 16),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Form(
                          // ignore: deprecated_member_use
                          autovalidateMode: AutovalidateMode.always,
                          key: _formKey,
                          child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: <Widget>[
                                Container(
                                  alignment: Alignment.topLeft,
                                  child: const Text(
                                    'Merchant :',
                                  ),
                                ),
                                Container(
                                  alignment: Alignment.topLeft,
                                  padding: const EdgeInsets.only(bottom: 8),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(widget.nameMerchant!),
                                      Text(widget.placeMerchant!),
                                    ],
                                  ),
                                ),
                                const SizedBox(
                                  height: 8,
                                ),
                                Container(
                                  alignment: Alignment.topLeft,
                                  child: const Text(
                                    'Nominal :',
                                  ),
                                ),
                                !widget.flagInputNominal!
                                    ? Container(
                                        alignment: Alignment.topLeft,
                                        padding: const EdgeInsets.only(bottom: 8),
                                        child: Column(
                                          children: [
                                            Text(
                                              widget.amountString!,
                                            ),
                                          ],
                                        ))
                                    : Container(
                                        alignment: Alignment.topLeft,
                                        child: TextFormField(
                                          validator: (val) {
                                            if (val!.isEmpty || val == '0') {
                                              return "Mohon diisi";
                                            } else {
                                              return null;
                                            }
                                          },
                                          inputFormatters: [
                                            CurrencyTextInputFormatter(
                                              decimalDigits: 0,
                                              locale: 'id_ID',
                                              name: '',
                                            )
                                          ],
                                          // inputFormatters: [
                                          //   // ignore: deprecated_member_use
                                          //   WhitelistingTextInputFormatter
                                          //       .digitsOnly
                                          // ],
                                          controller:
                                              _nominalMerchantcontroller,
                                          maxLength: 13,
                                          // ISTConstants.NOMINAL_MAX_LENGTH,
                                          onChanged: (value) {
                                            if (_nominalMerchantcontroller.text
                                                .trim()
                                                .isEmpty) {
                                              _nominalMerchantcontroller.text =
                                                  '';
                                            }
                                          },
                                          keyboardType: TextInputType.number,
                                          decoration: InputDecoration(
                                            counterText: '',
                                            prefixIcon: Text(
                                              "IDR ",
                                              style: TextStyle(
                                                  fontSize: Theme.of(context)
                                                      .textTheme
                                                      .subtitle1!
                                                      .fontSize),
                                            ),
                                            prefixIconConstraints:
                                                const BoxConstraints(
                                                    minWidth: 0, minHeight: 0),
                                            // prefixText: 'IDR ',
                                            // prefixStyle: TextStyle(
                                            //   color: Colors.black,
                                            // ),
                                            hintText: 'Masukkan nominal',
                                            hintStyle: ISTStyle.hintStyle,
                                          ),
                                        ),
                                      ),
                                const SizedBox(
                                  height: 8,
                                ),
                                widget.flagInputFee!
                                    ? Container(
                                        alignment: Alignment.topLeft,
                                        child: Column(
                                          children: [
                                            Container(
                                              alignment: Alignment.topLeft,
                                              child: const Text(
                                                'Tip :',
                                                style: TextStyle(
                                                    color: Colors.black87),
                                              ),
                                            ),
                                            TextFormField(
                                              // validator: (val) {
                                              //   if (val.isEmpty ||
                                              //       val == null) {
                                              //     return "Mohon diisi";
                                              //   } else {
                                              //     return null;
                                              //   }
                                              // },
                                              inputFormatters: [
                                                CurrencyTextInputFormatter(
                                                  decimalDigits: 0,
                                                )
                                              ],
                                              // inputFormatters: [
                                              //   // ignore: deprecated_member_use
                                              //   WhitelistingTextInputFormatter
                                              //       .digitsOnly
                                              // ],
                                              controller: _nominalFeecontroller,
                                              maxLength: 13,
                                              // ISTConstants
                                              //     .NOMINAL_MAX_LENGTH,
                                              onChanged: (value) {
                                                if (_nominalFeecontroller.text
                                                    .trim()
                                                    .isEmpty) {
                                                  _nominalFeecontroller.text =
                                                      '';
                                                }
                                              },
                                              keyboardType:
                                                  TextInputType.number,
                                              decoration: InputDecoration(
                                                counterText: '',
                                                prefixIcon: Text(
                                                  "IDR ",
                                                  style: TextStyle(
                                                      fontSize:
                                                          Theme.of(context)
                                                              .textTheme
                                                              .subtitle1!
                                                              .fontSize),
                                                ),
                                                prefixIconConstraints:
                                                    const BoxConstraints(
                                                        minWidth: 0,
                                                        minHeight: 0),
                                                // prefixText: 'IDR ',
                                                // prefixStyle: TextStyle(
                                                //   color: Colors.black,
                                                // ),
                                                hintText: 'Masukkan tip',
                                                hintStyle: ISTStyle.hintStyle,
                                              ),
                                            ),
                                          ],
                                        ),
                                      )
                                    : widget.fee == "0"
                                        ? const Text(
                                          "",
                                          style: TextStyle(
                                              color: Colors.white),
                                        )
                                        : Container(
                                            alignment: Alignment.topLeft,
                                            padding: const EdgeInsets.only(bottom: 8),
                                            child: Column(
                                              children: [
                                                Container(
                                                  alignment: Alignment.topLeft,
                                                  child: const Text(
                                                    'Tip :',
                                                    style: TextStyle(
                                                        color: Colors.black87),
                                                  ),
                                                ),
                                                Container(
                                                  alignment: Alignment.topLeft,
                                                  padding: const EdgeInsets.only(
                                                      bottom: 8),
                                                  child: Text(
                                                    widget.feeString.toString(),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                const SizedBox(
                                  height: 16,
                                ),
                              ]),
                        ),
                      ]),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: ISTOutlineButton(
                    onPressed: () {
                      _doTransfer();
                    },
                    text: 'Lanjut',
                  ),
                ),
                const SizedBox(
                  height: 16,
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  void hideKeyboard(BuildContext context) {
    FocusScopeNode currentFocus = FocusScope.of(context);
    if (!currentFocus.hasPrimaryFocus && currentFocus.focusedChild != null) {
      FocusManager.instance.primaryFocus!.unfocus();
    }
  }
}
