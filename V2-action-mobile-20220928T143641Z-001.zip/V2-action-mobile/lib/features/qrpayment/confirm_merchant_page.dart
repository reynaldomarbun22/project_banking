import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/qrpayment/mpin_payment_qr.dart';
import 'package:flutter/material.dart';

class ConfirmPaymentQRPage extends StatefulWidget {
  static const routeName = '/transferQR/confirmQRpayment';

  final List<ISTConfirmationItem>? list;

  const ConfirmPaymentQRPage({Key? key, this.list}) : super(key: key);

  @override
  State<ConfirmPaymentQRPage> createState() => _ConfirmPaymentQRPageState();
}

class _ConfirmPaymentQRPageState extends State<ConfirmPaymentQRPage> {
  @override
  Widget build(BuildContext context) {
    _doTransfer() {
      Navigator.pushNamed(context, QrPaymentMpin.routeName);
    }

    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Pallete.primary,
          leading: IconButton(
              icon: const Icon(
                Icons.arrow_back_ios,
                color: Colors.white,
              ),
              onPressed: () {
                Navigator.pop(context);
              }),
          title: const Text(
            'Pembayaran QR',
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'Poppins',
            ),
          ),
          centerTitle: true,
          elevation: 0.0,
        ),
        body: ISTConfirmation(
            items: widget.list,
            title: 'Konfirmasi Pembayaran QR',
            onFinished: () {
              _doTransfer();
            }));
  }
}
