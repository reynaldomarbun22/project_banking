import 'package:bpd_aceh/components/ist_menu_container.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/core/controller/controller_menu.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/asuransi_page.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/emoney_page.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/internet_page.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PDAM/tirtadaroy/inq_tirtadaroy.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PLN/pln_screen.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/telepon_page.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/zis_page.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/favorite/favoritepayment.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/pajakretribusi.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/pembayaran_screen.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/pendidikan.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/transportasipage.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/tvberlangganan/tvberlanggananscreen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

final controllerMenu = Get.put(MenuController());
Widget belibayarPage(context) {
  return SafeArea(
    child: Theme(
      data: ThemeData(colorScheme: const ColorScheme.light(secondary: Pallete.primary)),
      child: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                    child: Center(
                      child: Text(
                        // "Menu Pembayaran",
                        "Menu Layanan",
                        style: TextStyle(
                          color: Pallete.primary,
                          // color: Colors.white,
                          fontSize:
                              Theme.of(context).textTheme.headline4!.fontSize,
                        ),
                      ),
                    ),
                  ),
                  // SizedBox(height: 8),
                  // buildMenuBeliBayar(context),
                  buildMenuLayananBaru(context),
                ],
              ),
            ),
          ),
        ],
      ),
    ),
  );
}

buildMenuLayanan(context) {
  return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      child: Wrap(
        crossAxisAlignment: WrapCrossAlignment.center,
        children: <Widget>[
          // ISTMenuContainer(
          //   onTap: () {
          //     Navigator.pushNamed(context, Pembelian.routeName);
          //   },
          //   image: Image.asset(
          //     'assets/images/icon-wallet.png',
          //     width: 50,
          //   ),
          //   // color: Colors.grey,
          //   text: 'Pembelian',
          // ),
          ISTMenuContainer(
            onTap: () {
              Navigator.pushNamed(context, PembayaranPage.routeName);
            },
            image: Image.asset(
              'assets/images/icon-payments.png',
              width: 50,
            ),
            text: 'Pembayaran',
          ),
        ],
      ));
}

buildMenuLayananBaru(context) {
  return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      child: Wrap(
        crossAxisAlignment: WrapCrossAlignment.center,
        children: <Widget>[
          Visibility(
            visible: controllerMenu.getVisibilityFavorite(),
            child: ISTMenuContainer.none(
              onTap: () {
                Navigator.pushNamed(context, FavoritePaymentPage.routeName);
              },
              image: Image.asset(
                'assets/images/Favorite11.png',
                width: 50,
              ),
              // color: Colors.grey,
              text: 'Favorit\n',
            ),
          ),
          Visibility(
            visible: controllerMenu.getVisibilityTelepon(),
            child: ISTMenuContainer.none(
              onTap: () {
                // Navigator.pushNamed(context, TelkomScreen.routeName);
                Navigator.pushNamed(context, TeleponScreen.routeName);
              },
              image: Image.asset(
                'assets/images/newTelepon.png',
                width: 50,
              ),
              // color: Colors.grey,
              text: 'Telepon\n',
            ),
          ),
          Visibility(
            visible: controllerMenu.getVisibilityListrik(),
            child: ISTMenuContainer.none(
              onTap: () {
                Navigator.pushNamed(context, ListrikScreen.routeName);
              },
              image: Image.asset(
                'assets/images/newTokenListrik.png',
                width: 50,
              ),
              // color: Colors.grey,
              text: 'Listrik\n',
            ),
          ),
          Visibility(
            visible: controllerMenu.getVisibilityEMoney(),
            child: ISTMenuContainer.none(
              onTap: () {
                Navigator.pushNamed(context, EmoneyScreen.routeName);
              },
              image: Image.asset(
                'assets/images/newTopup.png',
                width: 50,
              ),
              // color: Colors.grey,
              text: 'E-Money\n',
            ),
          ),
          Visibility(
            visible: controllerMenu.getVisibilityPDAM(),
            child: ISTMenuContainer.none(
              onTap: () {
                Navigator.pushNamed(context, InquiryTirtaDaroy.routeName);
              },
              image: Image.asset(
                'assets/images/newPAM.png',
                width: 50,
              ),
              // color: Colors.grey,
              text: 'PDAM\n',
            ),
          ),
          Visibility(
            visible: controllerMenu.getVisibilityInternet(),
            child: ISTMenuContainer.none(
              onTap: () {
                Navigator.pushNamed(context, InternetScreen.routeName);
              },
              image: Image.asset(
                'assets/images/newInternet.png',
                width: 50,
              ),
              // color: Colors.grey,
              text: 'Internet\n',
            ),
          ),
          Visibility(
            visible: controllerMenu.getVisibilityAsuransi(),
            child: ISTMenuContainer.none(
              onTap: () {
                Navigator.pushNamed(context, AsuransiScreen.routeName);
              },
              image: Image.asset(
                'assets/images/newAsuransi.png',
                width: 50,
              ),
              // color: Colors.grey,
              text: 'Asuransi\n',
            ),
          ),
          Visibility(
            visible: controllerMenu.getVisibilityTransportasi(),
            child: ISTMenuContainer.none(
              onTap: () {
                Navigator.pushNamed(context, TransportasiPage.routeName);
              },
              image: Image.asset(
                'assets/images/newkapal.png',
                width: 50,
              ),
              // color: Colors.grey,
              text: 'Transportasi\n',
            ),
          ),
          Visibility(
            visible: controllerMenu.getVisibilityTVBerlangganan(),
            child: ISTMenuContainer.none(
              onTap: () {
                Navigator.pushNamed(context, TVBerlanggananPage.routeName);
              },
              image: Image.asset(
                'assets/images/newTVL.png',
                width: 50,
              ),
              // color: Colors.grey,
              text: 'TV Berlangganan\n',
            ),
          ),
          Visibility(
            visible: controllerMenu.getVisibilityZIS(),
            child: ISTMenuContainer.none(
              onTap: () {
                Navigator.pushNamed(context, ZisScreen.routeName);
              },
              image: Image.asset(
                'assets/images/newzakatinf.png',
                width: 50,
              ),
              text: 'ZIS\n',
            ),
          ),
          Visibility(
            visible: controllerMenu.getVisibilityPajak(),
            child: ISTMenuContainer.none(
              onTap: () {
                Navigator.pushNamed(context, PajakRetribusiScreen.routeName);
              },
              image: Image.asset(
                'assets/images/newPajak.png',
                width: 50,
              ),
              // color: Colors.grey,
              text: 'Pajak & Retribusi\n',
            ),
          ),
          Visibility(
            visible: controllerMenu.getVisibilityPendidikan(),
            child: ISTMenuContainer.none(
              onTap: () {
                Navigator.pushNamed(context, PendidikaScreen.routeName);
              },
              image: Image.asset(
                'assets/images/newUniversitas.png',
                width: 50,
              ),
              // color: Colors.grey,
              text: 'Pendidikan\n',
            ),
          ),
        ],
      ));
}
