import 'package:bpd_aceh/components/ist_menu_container.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/core/controller/controller_menu.dart';
import 'package:bpd_aceh/features/transfer/favorite/favorite_page.dart';
import 'package:bpd_aceh/features/transfer/transferAntarBAS/inquiryBAS/transferinq_bas.dart';
import 'package:bpd_aceh/features/transfer/transferBankLain/inquiryBL/transfer_bank_lain.dart';
import 'package:bpd_aceh/features/transfer/transferRTGS/inquiryRTGS/transfer_rtgs.dart';
import 'package:bpd_aceh/features/transfer/transferSKN/inquirySKN/transfer_skn.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

final controllerMenu = Get.put(MenuController());
Widget transferPage(BuildContext context) {
  return SafeArea(
    child: Theme(
      data: ThemeData(colorScheme: const ColorScheme.light(secondary: Pallete.primary)),
      // child: RefreshIndicator(
      //   onRefresh: () {
      //     return _onRefresh();
      //   },
      child: Column(
        children: [
          Expanded(
            child: Column(
              children: <Widget>[
                // Stack(
                //   children: <Widget>[
                //     // Container(
                //     //   height: 70,
                //     //   decoration: BoxDecoration(
                //     //       color: Pallete.PRIMARY,
                //     //       borderRadius: BorderRadius.only(
                //     //           bottomLeft: Radius.circular(20),
                //     //           bottomRight: Radius.circular(20))),
                //     // ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                  child: Center(
                    child: Text(
                      "Menu Transfer",
                      style: TextStyle(
                        color: Pallete.primary,
                        // color: Colors.white,
                        fontSize:
                            Theme.of(context).textTheme.headline4!.fontSize,
                      ),
                    ),
                  ),
                ),
                // ISTCardAccount(
                //   context: context,
                //   menu: ISTMenu.transfer,
                // ),

                // SizedBox(height: 16),
                buildMenuTrf(
                  context,
                )

                // Padding(
                //   padding: const EdgeInsets.symmetric(horizontal: 8.0),
                //   child: Divider(thickness: 1),
                // ),
                // SizedBox(height: 8),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}

// ignore: unused_element
Future<bool> _onRefresh() async {
  await Future.delayed(const Duration(seconds: 2));
  return true;
}

buildMenuTrf(context) {
  return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      child: Wrap(
        crossAxisAlignment: WrapCrossAlignment.center,
        children: <Widget>[
          Visibility(
            visible: controllerMenu.getVisibilityFavorite(),
            child: ISTMenuContainer.none(
              onTap: () {
                Navigator.pushNamed(context, FavoriteTransferPage.routeName);
              },
              image: Image.asset(
                'assets/images/Favorite11.png',
                width: 50,
              ),
              text: 'Favorit',
            ),
          ),
          Visibility(
            visible: controllerMenu.getVisibilityBAS(),
            child: ISTMenuContainer.none(
              onTap: () {
                Navigator.pushNamed(context, TransferBas.routeName);
              },
              image: Image.asset(
                'assets/images/NewIconBAS.png',
                width: 50,
              ),
              text: 'Antar BAS',
            ),
          ),
          Visibility(
            visible: controllerMenu.getVisibilityAntarBank(),
            child: ISTMenuContainer.none(
              onTap: () {
                Navigator.pushNamed(context, TransferBankLain.routeName);
              },
              image: Image.asset(
                'assets/images/NewIconBank Lain.png',
                width: 50,
              ),
              text: 'Antar Bank Lain',
            ),
          ),
          Visibility(
            visible: controllerMenu.getVisibilitySKN(),
            child: ISTMenuContainer.none(
              onTap: () {
                Navigator.pushNamed(context, TransferSKN.routeName);
              },
              image: Image.asset(
                'assets/images/SKN.png',
                width: 50,
              ),
              // color: Colors.grey,
              text: 'SKN',
            ),
          ),
          Visibility(
            visible: controllerMenu.getVisibilityRTGS(),
            child: ISTMenuContainer.none(
              onTap: () {
                Navigator.pushNamed(context, TransferRTGS.routeName);
              },
              image: Image.asset(
                'assets/images/RTGS.png',
                width: 50,
              ),
              // color: Colors.grey,
              text: 'RTGS',
            ),
          ),
          // ISTMenuContainer(
          //   onTap: () {
          //     Navigator.pushNamed(context, TransferBankLain.routeName);
          //   },
          //   image: Image.asset(
          //     'assets/images/icon-transfer-other.png',
          //     width: 50,
          //   ),
          //   color: Colors.grey,
          //   text: 'Antar Bank Lain',
          // ),
        ],
      ));
}
