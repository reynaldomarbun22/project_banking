import 'dart:convert';
import 'dart:typed_data';

import 'package:bpd_aceh/components/ist_promo_container.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/features/promo/promo.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class HomeWidgetController extends GetxController {
  var listedPromo = false;
  List<ISTPromoContainer> listPromo = [];

  getListPromo(BuildContext context) async {
    listedPromo = false;
    update();
    final resp = await API.postNoLoading(context, '/promo', {});
    if (resp != null && resp['code'] == 0) {
      listedPromo = true;
      var listResp = resp['promoList'];
      List<ISTPromoContainer> listParam = [];
      // print(listResp);
      for (var item in listResp) {
        // print(item['imagePromo']);
        var substr = item['imagePromo'].split(',');
        // print('substr =' + substr[1]);
        Uint8List images = base64Decode(substr[1]);
        // print(images);

        ISTPromoContainer miniItem = ISTPromoContainer(
          onTap: () => {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => Promo(
                  url: item['linkPromo'],
                ),
              ),
            )
          },
          widget: Image.memory(
            images,
            fit: BoxFit.fitWidth,
          ),
        );
        listParam.add(miniItem);
      }
      listPromo = listParam;
    }
    update();
    return true;
  }
}
