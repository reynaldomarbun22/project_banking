import 'dart:io';
import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_menu_container.dart';
import 'package:bpd_aceh/components/ist_style.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/core/controller/controller_menu.dart';
import 'package:bpd_aceh/core/crypto/ist_crypto.dart';
import 'package:bpd_aceh/core/utils/string_utils.dart';
import 'package:bpd_aceh/features/inbox/inbox_db.dart';
import 'package:bpd_aceh/features/landing/landing.dart';
import 'package:bpd_aceh/features/other/ChangeMPIN/pages/change_mpin.dart';
import 'package:bpd_aceh/features/other/ChangePassword/change_password.dart';
import 'package:bpd_aceh/features/other/FAQ/pages/faq.dart';
import 'package:bpd_aceh/features/other/biometric/pages/biometric_snk.dart';
import 'package:bpd_aceh/features/login/login.dart';
import 'package:bpd_aceh/features/other/contactUS/pages/contact_us.dart';
import 'package:bpd_aceh/features/other/rekeningku/page/home_rekeningku.dart';
import 'package:bpd_aceh/features/other/snk/syaratketentuan.dart';
import 'package:bpd_aceh/features/splash/splash.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:local_auth/auth_strings.dart';
import 'package:local_auth/local_auth.dart';

import '../../other/daftarFavorit/pages/daftar_favorit.dart';

class OtherWidget extends StatefulWidget {
  static const routeName = '/OtherWidget';

  const OtherWidget({Key? key}) : super(key: key);

  @override
  _OtherWidgetState createState() => _OtherWidgetState();
}

class _OtherWidgetState extends State<OtherWidget> {
  final controllerMenu = Get.put(MenuController());
  bool switchControl = false;
  bool checklist = false;

  // ignore: unused_element
  Future<bool> _onRefresh() async {
    await Future.delayed(const Duration(seconds: 2));
    return true;
  }

  @override
  void initState() {
    _getStatusBiometrics();
    super.initState();
  }

  _goToSnkBiometrics() async {
    var result = await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (BuildContext context) => const SnKBiometric(),
        ));
    if (result == null) {
      return;
    }
    if (result == true) {
      setState(() {
        switchControl = true;
      });
    } else {
      setState(() {
        switchControl = false;
      });
    }
  }

  _getStatusBiometrics() async {
    final _bioStatus =
        await ISTConstants().getConstants(ISTConstants.biometricStatus);
    if (_bioStatus != null && _bioStatus == false) {
      setState(() {
        switchControl = false;
      });
    } else if (_bioStatus != null && _bioStatus == true) {
      setState(() {
        switchControl = true;
      });
    } else {
      setState(() {
        switchControl = false;
      });
    }
  }

  _checkBiometrics() async {
    var localAuth = LocalAuthentication();

    final _bioStatus =
        await ISTConstants().getConstants(ISTConstants.biometricStatus);
    if (_bioStatus != null && _bioStatus == true) {
      setState(() {
        switchControl = true;
      });
    } else {
      setState(() {
        switchControl = false;
      });
    }

    List<BiometricType> availableBiometrics =
        await localAuth.getAvailableBiometrics();

    bool auth = false;
    if (Platform.isIOS) {
      if (availableBiometrics.contains(BiometricType.face)) {
        // Face ID.
        const iosStrings = IOSAuthMessages(
            cancelButton: 'cancel',
            goToSettingsButton: 'settings',
            goToSettingsDescription: 'Please set up your Touch ID.',
            lockOut: 'Please reenable your Touch ID');
        auth = await localAuth.authenticate(
            localizedReason: 'Please authenticate to show account balance',
            useErrorDialogs: false,
            biometricOnly: true,
            iOSAuthStrings: iosStrings);
      } else if (availableBiometrics.contains(BiometricType.fingerprint)) {
        // Touch ID.
        auth = await localAuth.authenticate(
          biometricOnly: true,
          useErrorDialogs: false,
          localizedReason: 'Please authenticate your Biometrics.',
        );
      }
    } else {
      const androStrings = AndroidAuthMessages(
        cancelButton: 'cancel',
        goToSettingsButton: 'settings',
        goToSettingsDescription: 'Please set up your Biometrics.',
      );

      auth = await localAuth.authenticate(
          biometricOnly: true,
          useErrorDialogs: false,
          androidAuthStrings: androStrings,
          localizedReason: 'Please set up your Biometrics.'
          // sensitiveTransaction: false
          );
    }
    if (auth) {
      _doSetBiometrics();
    }
    Navigator.pop(context);
  }

  _doSetBiometrics() async {
    final api = !switchControl ? "/biometric/enable" : "/biometric/disable";
    final resp = await API.post(context, api, {});
    if (resp['code'] != null && resp['code'] == 0) {
      await ISTConstants()
          .setConstants(ISTConstants.biometricStatus, !switchControl);
      setState(() {
        switchControl = !switchControl;
      });
    } else if (resp['code'] != null && resp['code'] != 0) {
      const DialogBox().showImageDialog(
          message: resp['message'],
          isError: true,
          buttonCancel: 'OK',
          onOk: () {},
          context: context);
    }
  }

  _dologout() async {
    const api = "/logout";
    final resp = await API.post(context, api, {});
    if (resp != null && resp['code'] == 0) {
      await ISTConstants().setString(ISTConstants.authCookie, '');
      await ISTConstants().setString(ISTConstants.loggedInKey, "");
      // Navigator.pushNamedAndRemoveUntil(context, LandingPageScreen.routeName,
      //     ModalRoute.withName(Splash.routeName));
      // Navigator.pushNamed(context, LoginPage.routeName);
      // SystemNavigator.pop();
      // SystemChannels.platform.invokeMethod('SystemNavigator.pop');
      if (Platform.isAndroid) {
        SystemNavigator.pop();
      } else if (Platform.isIOS) {
        exit(0);
      }
      // Future.delayed(const Duration(milliseconds: 1000), () {
      //   SystemChannels.platform.invokeMethod('SystemNavigator.pop');
      // });
      // exit(0);
    } else if (resp != null && resp['code'] != 0) {
      const DialogBox().showImageDialog(
          message: resp['message'],
          isError: true,
          buttonCancel: 'OK',
          onOk: () {},
          context: context);
    }
  }

  _showMyDialog(BuildContext context) async {
    showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          content: const Text(
            'Atur Biometric',
          ),
          actions: <Widget>[
            Switch(
              onChanged: (bool bool) {
                _checkBiometrics();
              },
              value: switchControl,
              activeColor: Pallete.primary,
            ),
          ],
        );
      },
    );
  }

  _doUnlinkDevice() {
    const DialogBox().showImageDialog(
      image: const Image(
        image: AssetImage('assets/images/icon-warning.png'),
      ),
      message:
          "Apakah Anda yakin akan menghubungkan akun ini ke perangkat lain?",
      context: context,
      isError: true,
      onOk: () {
        Navigator.pop(context);
        _doUnlinkDeviceInput();
      },
      onCancel: () {
        Navigator.pop(context);
      },
      buttonOk: 'Ya',
      buttonCancel: 'Tidak',
    );
  }

  _doUnlinkDeviceInput() async {
    bool _showPassword = true;
    await showDialog(
      context: context,
      barrierDismissible: false,
      useRootNavigator: true,
      builder: (BuildContext context) {
        return AlertDialog(
          // contentPadding: EdgeInsets.all(8),
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(20.0)),
          ),
          content: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
            return SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.only(left: 8, right: 8),
                child: Form(
                  key: _formKey,
                  // ignore: deprecated_member_use
                  autovalidateMode: AutovalidateMode.always,
                  child: Column(
                    children: <Widget>[
                      const Image(
                        height: 100,
                        image: AssetImage('assets/images/icon-warning.png'),
                      ),
                      const SizedBox(
                        height: 4,
                      ),
                      Container(
                          alignment: Alignment.topLeft,
                          child: const Text('Masukkan password Anda')),
                      TextFormField(
                        validator: (val) {
                          if (val!.isEmpty || val == '0') {
                            return "Isi password anda";
                          } else {
                            return null;
                          }
                        },
                        expands: false,
                        obscureText: _showPassword,
                        keyboardType: TextInputType.text,
                        inputFormatters: [
                          // StringUtils.alphaNumeric(),
                          StringUtils.noSpace()
                        ],
                        //
                        decoration: InputDecoration(
                          hintText: 'Masukkan Password Anda',
                          hintStyle: ISTStyle.hintStyle,
                          suffixIcon: IconButton(
                            icon: Icon(_showPassword
                                ? Icons.visibility
                                : Icons.visibility_off),
                            onPressed: () {
                              setState(() => _showPassword = !_showPassword);
                            },
                          ),
                        ),
                        controller: _passwordController,
                      ),
                      const SizedBox(height: 24),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: <Widget>[
                          OutlinedButton(
                            style: OutlinedButton.styleFrom(
                              shape: const RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(18)),
                              ),
                              primary: Pallete.primary,
                              side: const BorderSide(
                                color: Colors.red,
                              ),
                            ),
                            onPressed: () {
                              _passwordController.clear();
                              Navigator.pop(context);
                            },
                            child: Text(
                              "Batal",
                              style: Theme.of(context)
                                  .textTheme
                                  .bodyText1!
                                  .copyWith(
                                      fontWeight: FontWeight.w600,
                                      color: Colors.red),
                            ),
                          ),
                          OutlinedButton(
                              style: OutlinedButton.styleFrom(
                                side: const BorderSide(
                                  color: Pallete.primary,
                                ),
                                primary: Pallete.primary,
                                // color: Colors.green,
                                shape: const RoundedRectangleBorder(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(18)),
                                ),
                              ),
                              onPressed: () {
                                _doUnlinkPressed();
                              },
                              child: Text(
                                'Ya',
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyText1!
                                    .copyWith(
                                      fontWeight: FontWeight.w600,
                                      color: Pallete.primary,
                                    ),
                              )),
                        ],
                        //children: _checkbutton(context),
                      )
                    ],
                  ),
                ),
              ),
            );
          }),
          //actions: _checkbutton(context),
        );
      },
    ).then((val) {
      _passwordController.clear();
    });
  }

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  // ignore: unused_field
  bool _autoValidate = false;

  final _passwordController = TextEditingController();
  bool isLoading = false;
  bool showPass = true;

  // ignore: unused_field
  bool _passError = false;

  // ignore: unused_element
  _showPassword() {
    print(showPass);
    setState(() {
      showPass = !showPass;
    });
  }

  bool _validateInputs() {
    if (_formKey.currentState!.validate()) {
      // _formKey.currentState.save();
      return true;
    } else {
      setState(() {
        _autoValidate = true;
      });
      return false;
    }
  }

  // ignore: unused_element
  bool _doValidate() {
    if (_validateInputs() != true) return false;
    bool _success = true;
    if (_passwordController.text.isEmpty) {
      setState(() {
        _passError = true;
      });
      _success = false;
    } else {
      setState(() {
        _passError = false;
      });
    }

    return _success;
  }

  _deleteInbox() async {
    // print(item.id);
    InboxDBRepository repo = InboxDBRepository();
    await repo.open();
    await repo.deleteAll();

    await repo.close();
  }

  _doUnlinkPressed() async {
    if (_validateInputs()) {
      Map<String, Object> param = {};

      final password = await ISTCrypto.encryptAES(_passwordController.text);
      param['password'] = password;
      final resp = await API.post(context, '/unlink', param);
      if (resp != null && resp['code'] != null && resp['code'] == 0) {
        ISTConstants().setConstants(ISTConstants.authWasLoggedIn, false);
        if (!_validateInputs()) return;
        ISTConstants().setConstants(ISTConstants.loggedInKey, resp['authKey']);
        const DialogBox().showImageDialog(
            title: "Berhasil",
            image: const Image(
              image: AssetImage('assets/images/icon-success.png'),
            ),
            message:
                'Berhasil mengganti perangkat\nAkun Anda akan keluar otomatis dari perangkat ini. Silakan masuk ke perangkat baru anda',
            isError: false,
            buttonOk: 'selesai',
            onOk: () async {
              await ISTConstants().setConstants(ISTConstants.authCookie, '');
              await ISTConstants().setConstants(ISTConstants.loggedInKey, '');
              _deleteInbox();
              Navigator.pushNamedAndRemoveUntil(
                  context,
                  LandingPageScreen.routeName,
                  ModalRoute.withName(Splash.routeName));
              Navigator.pushNamed(context, LoginPage.routeName);
            },
            context: context);
      } else if (resp != null && resp['code'] != 0) {
        const DialogBox().showImageDialog(
            message: resp['message'],
            isError: true,
            image: const Image(
              image: AssetImage('assets/images/icon-failed.png'),
            ),
            buttonCancel: 'OK',
            onCancel: () {
              if (resp['code'] == -1007) {
                setState(() {
                  Navigator.pushNamedAndRemoveUntil(
                      context,
                      LandingPageScreen.routeName,
                      ModalRoute.withName(Splash.routeName));
                  Navigator.pushNamed(context, LoginPage.routeName);
                });
              } else {
                Navigator.pop(context);
              }
            },
            onOk: () {},
            context: context);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Theme(
        data: ThemeData(colorScheme: const ColorScheme.light(secondary: Pallete.primary)),
        // child: RefreshIndicator(
        //   onRefresh: () {
        //     return _onRefresh();
        //   },
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: <Widget>[
                    // ISTCardAccount(
                    //   context: context,
                    //   menu: ISTMenu.other,
                    // ),
                    // SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 16),
                      child: Center(
                        child: Text(
                          "Menu Lainnya",
                          style: TextStyle(
                            color: Pallete.primary,
                            // color: Colors.white,
                            fontSize:
                                Theme.of(context).textTheme.headline4!.fontSize,
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8.0),
                      child: Wrap(
                        crossAxisAlignment: WrapCrossAlignment.center,
                        children: <Widget>[
                          Visibility(
                            visible: controllerMenu.getVisibilityRekening(),
                            child: ISTMenuContainer.none(
                              onTap: () {
                                Navigator.pushNamed(
                                    context, HomeRekeningKU.routeName);
                              },
                              image: Image.asset(
                                'assets/images/NewIconRekeningku.png',
                                width: 50,
                              ),
                              text: 'Rekeningku\n',
                            ),
                          ),
                          // dfsd
                          Visibility(
                            visible:
                                controllerMenu.getVisibilityGantiPassword(),
                            child: ISTMenuContainer.none(
                              onTap: () {
                                Navigator.pushNamed(
                                    context, ChangePass.routeName);
                              },
                              image: Image.asset(
                                'assets/images/NewIconUbah Pass.png',
                                width: 50,
                              ),
                              text: 'Ganti Password\n',
                            ),
                          ),
                          Visibility(
                            visible: controllerMenu.getVisibilityBiometric(),
                            child: ISTMenuContainer.none(
                              onTap: () async {
                                final _bioSNKVisited = await ISTConstants()
                                    .getConstants(ISTConstants
                                        .biometricsTermsAndCondition);
                                if (_bioSNKVisited == null ||
                                    _bioSNKVisited == false) {
                                  _goToSnkBiometrics();
                                } else {
                                  _showMyDialog(context);
                                  // _goToSnkBiometrics();
                                }
                              },
                              image: Image.asset(
                                'assets/images/NewIconBiometrik.png',
                                width: 50,
                              ),
                              // ignore: unnecessary_null_comparison
                              text: switchControl == null
                                  ? 'Atur Biometric\n'
                                  : switchControl
                                      ? 'Atur Biometric \n(ON)'
                                      : 'Atur Biometric \n(OFF)',
                            ),
                          ),
                          Visibility(
                            visible: controllerMenu.getVisibilityGantiMpin(),
                            child: ISTMenuContainer.none(
                              onTap: () {
                                Navigator.pushNamed(context, OLDMPIN.routeName);
                              },
                              image: Image.asset(
                                'assets/images/NewIconGanti MPIN.png',
                                width: 50,
                              ),
                              text: 'Ganti MPIN\n',
                            ),
                          ),
                          Visibility(
                            visible: controllerMenu.getVisibilityFavorite(),
                            child: ISTMenuContainer.none(
                              onTap: () {
                                Navigator.pushNamed(
                                    context, DaftarFavoriteFull.routeName);
                              },
                              image: Image.asset(
                                'assets/images/Favorite11.png',
                                width: 50,
                              ),
                              // color: Colors.grey,
                              text: 'Daftar Favorit\n',
                            ),
                          ),
                          Visibility(
                            visible:
                                controllerMenu.getVisibilityGantiPerangkat(),
                            child: ISTMenuContainer.none(
                              onTap: () {
                                _doUnlinkDevice();
                              },
                              image: Image.asset(
                                'assets/images/NewIconGanti Perangkat.png',
                                width: 50,
                              ),
                              text: 'Ganti Perangkat\nBaru',
                            ),
                          ),
                          Visibility(
                            visible: controllerMenu.getVisibilityHubungiKami(),
                            child: ISTMenuContainer.none(
                              onTap: () {
                                Navigator.pushNamed(
                                    context, ContactUs.routeName);
                              },
                              image: Image.asset(
                                'assets/images/NewIconHubungi.png',
                                width: 50,
                              ),
                              // color: Colors.grey,
                              text: 'Hubungi Kami\n',
                            ),
                          ),
                          Visibility(
                            visible: controllerMenu.getVisibilityFAQ(),
                            child: ISTMenuContainer.none(
                              onTap: () {
                                Navigator.pushNamed(context, FAQ.routeName);
                              },
                              image: Image.asset(
                                'assets/images/NewIconFAQ.png',
                                width: 50,
                              ),
                              text: 'FAQ\n',
                            ),
                          ),
                          Visibility(
                            visible: controllerMenu.getVisibilitySyarat(),
                            child: ISTMenuContainer.none(
                              onTap: () {
                                Navigator.pushNamed(
                                    context, TermsAndConditionOthers.routeName);
                              },
                              image: Image.asset(
                                'assets/images/NewIconSK.png',
                                width: 50,
                              ),
                              text: 'Syarat &\n Ketentuan',
                            ),
                          ),
                          ISTMenuContainer.none(
                            onTap: () {
                              const DialogBox().showImageDialog(
                                  message: "Apakah Anda yakin akan keluar?",
                                  context: context,
                                  buttonOk: "Keluar",
                                  isError: false,
                                  buttonCancel: "Tidak",
                                  onCancel: () {
                                    Navigator.pop(context);
                                  },
                                  onOk: () {
                                    _dologout();
                                  });
                            },
                            image: Image.asset(
                              'assets/images/NewIconLogout.png',
                              width: 50,
                            ),
                            text: 'Keluar\n',
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 8),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      // )
    );
  }
}
