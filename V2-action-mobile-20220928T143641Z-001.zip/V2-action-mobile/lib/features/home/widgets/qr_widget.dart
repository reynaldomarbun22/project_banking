import 'package:bpd_aceh/components/ist_menu_container.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/qrtransfer/scanqrtransfer.dart';
import 'package:flutter/material.dart';

Widget qrPage(context) {
  return SafeArea(
    child: Theme(
      data: ThemeData(
          colorScheme: const ColorScheme.light(secondary: Pallete.primary)),
      child: Column(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                // ISTCardAccount(
                //   context: context,
                //   menu: ISTMenu.qr,
                //   showBalance: false,
                // ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                  child: Center(
                    child: Text(
                      "Menu QR",
                      style: TextStyle(
                        color: Pallete.primary,
                        // color: Colors.white,
                        fontSize:
                            Theme.of(context).textTheme.headline4!.fontSize,
                      ),
                    ),
                  ),
                ),
                buildMenuTrf(
                  context,
                )
              ],
            ),
          ),
        ],
      ),
    ),
  );
}

// ignore: unused_element
Future<bool> _onRefresh() async {
  await Future.delayed(const Duration(seconds: 2));
  return true;
}

buildMenuTrf(context) {
  return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      child: Wrap(
        crossAxisAlignment: WrapCrossAlignment.center,
        // crossAxisAlignment: MainAxisAlignment.spaceAround,
        children: <Widget>[
          ISTMenuContainer(
            onTap: () {
              Navigator.pushNamed(context, TransferQR.routeName);
            },
            image: Image.asset(
              'assets/images/icon-qr.png',
              width: 50,
            ),
            // color: Colors.grey,
            text: 'QR Transfer',
          ),
          ISTMenuContainer(
            onTap: () {
              // Navigator.pushNamed(context, TransferQR.routeName);
            },
            // color: Colors.grey,
            image: Image.asset(
              'assets/images/icon-qr.png',
              width: 50,
            ),
            color: Colors.grey,
            text: 'QR Payment',
          ),
        ],
      ));
}
