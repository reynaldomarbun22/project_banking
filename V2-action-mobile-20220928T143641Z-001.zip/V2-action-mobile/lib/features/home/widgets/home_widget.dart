import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_card_account.dart';
import 'package:bpd_aceh/components/ist_card_statement.dart';
import 'package:bpd_aceh/components/ist_menu_container.dart';
import 'package:bpd_aceh/components/ist_promo_container.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/utils/string_utils.dart';
import 'package:bpd_aceh/features/home/widgets/controller/home_widget_controller.dart';
import 'package:bpd_aceh/features/jadwalsholat/page/jadwal_sholat.dart';
import 'package:bpd_aceh/features/other/daftarFavorit/pages/daftar_favorit.dart';
import 'package:bpd_aceh/features/other/rekeningku/page/home_rekeningku.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PLN/pln_screen.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/telepon_page.dart';
import 'package:bpd_aceh/features/statements/statements.dart';
import 'package:flutter/material.dart';
import 'package:app_settings/app_settings.dart';
import 'package:get/get.dart';
import 'package:bpd_aceh/core/controller/controller_menu.dart';
import 'package:permission_handler/permission_handler.dart';

class DashBoardHomePage extends StatefulWidget {
  static const routeName = '/dashboard';
  const DashBoardHomePage({Key? key}) : super(key: key);

  @override
  _DashBoardHomePageState createState() => _DashBoardHomePageState();
}

class _DashBoardHomePageState extends State<DashBoardHomePage>
    with SingleTickerProviderStateMixin {
  final controller = Get.put(HomeWidgetController());
  final controllerMenu = Get.put(MenuController());

  List<ISTCardStatement> listStatement = [];

  @override
  void initState() {
    controllerMenu.checkMenu();
    controllerMenu.getVisibilityInbox();
    _getMiniStatement(context);
    if (!controller.listedPromo) controller.getListPromo(context);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<HomeWidgetController>(builder: (controller) {
      return RefreshIndicator(
        color: Pallete.primary,
        onRefresh: () {
          setState(() {
            _getMiniStatement(context);
          });
          return controller.getListPromo(context);
        },
        child: Column(
          children: <Widget>[
            ISTCardAccount(
              showName: false,
              context: context,
              menu: ISTMenu.home,
              callback: () {
                _getMiniStatement(context);
              },
            ),
            Expanded(
              child: Theme(
                data: ThemeData(
                  colorScheme: const ColorScheme.light(secondary: Colors.white),
                  highlightColor: Colors.transparent,
                ),
                child: ListView(
                  children: <Widget>[
                    const SizedBox(height: 8),
                    buildMenu(context),
                    const SizedBox(height: 8),
                    const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 16.0),
                      child: Divider(thickness: 1),
                    ),
                    buildPromo(controller, context),
                    buildTransactionHistoryHome(),
                  ],
                ),
              ),
            ),
          ],
          // ),
        ),
      );
    });
  }

  // ignore: unused_element
  Future<bool> _onRefresh() async {
    await Future.delayed(const Duration(seconds: 2));
    return true;
  }

  buildMenu(context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      child: Wrap(
        crossAxisAlignment: WrapCrossAlignment.center,
        children: <Widget>[
          Visibility(
            visible: controllerMenu.getVisibilityPray(),
            child: ISTMenuContainer.none(
              onTap: () {
                _checkPermission();
                // Navigator.pushNamed(context, SchedulePray.routeName);
              },
              image: Image.asset(
                'assets/images/NewIconJadwal Sholat.png',
                width: 50,
              ),
              text: 'Jadwal Sholat',
            ),
          ),
          Visibility(
            visible: controllerMenu.getVisibilityMutasiRekening(),
            child: ISTMenuContainer.none(
              text: 'Mutasi Rekening',
              onTap: () async {
                final resp = await API.post(context, '/acct/cekfeatures', {});
                if (resp['code'] == 0) {
                  Navigator.pushNamed(context, Statements.routeName);
                } else if (resp['code'] != 0 || resp['code'] == null) {
                  const DialogBox().showImageDialog(
                      message: resp['message'],
                      isError: true,
                      buttonCancel: 'OK',
                      onCancel: () {
                        Navigator.pop(context);
                      },
                      onOk: () {},
                      context: context);
                }
              },
              image: Image.asset(
                'assets/images/NewIconMutasi.png',
                width: 50,
              ),
            ),
          ),
          Visibility(
            visible: controllerMenu.getVisibilityRekening(),
            child: ISTMenuContainer.none(
              onTap: () {
                Navigator.pushNamed(context, HomeRekeningKU.routeName);
              },
              image: Image.asset(
                'assets/images/NewIconRekeningku.png',
                width: 50,
              ),
              text: 'Rekeningku',
            ),
          ),
          Visibility(
            visible: controllerMenu.getVisibilityFavorite(),
            child: ISTMenuContainer.none(
              onTap: () {
                Navigator.pushNamed(context, DaftarFavoriteFull.routeName);
              },
              image: Image.asset(
                'assets/images/Favorite11.png',
                width: 50,
              ),
              text: 'Daftar Favorit',
            ),
          ),
          Visibility(
            visible: controllerMenu.getVisibilityTelepon(),
            child: ISTMenuContainer.none(
              onTap: () {
                // Navigator.pushNamed(context, TelkomScreen.routeName);
                Navigator.pushNamed(context, TeleponScreen.routeName);
              },
              image: Image.asset(
                'assets/images/newTelepon.png',
                width: 50,
              ),
              // color: Colors.grey,
              text: 'Telepon',
            ),
          ),
          Visibility(
            visible: controllerMenu.getVisibilityListrik(),
            child: ISTMenuContainer.none(
              onTap: () {
                Navigator.pushNamed(context, ListrikScreen.routeName);
              },
              image: Image.asset(
                'assets/images/newTokenListrik.png',
                width: 50,
              ),
              // color: Colors.grey,
              text: 'Listrik',
            ),
          ),
          // ISTMenuContainer.none(
          //   onTap: () {
          //     Navigator.pushNamed(context, ZisScreen.routeName);
          //   },
          //   image: Image.asset(
          //     'assets/images/newzakatinf.png',
          //     width: 50,
          //   ),
          //   text: 'ZIS',
          // ),
          // ISTMenuContainer.none(
          //   onTap: () {
          //     Navigator.pushNamed(context, FAQ.routeName);
          //   },
          //   image: Image.asset(
          //     'assets/images/NewIconFAQ.png',
          //     width: 50,
          //   ),
          //   text: 'FAQ',
          // ),
        ],
      ),
    );
  }

  // ignore: unused_element
  Future<void> _checkPermission() async {
    final serviceStatus = await Permission.location.serviceStatus;
    final isGpsOn = serviceStatus == ServiceStatus.enabled;
    // final isGpsoff = serviceStatus == ServiceStatus.disabled;
    if (serviceStatus.isDisabled) {
       const DialogBox().showImageDialog(
            isError: false,
            onOk: () {
               AppSettings.openLocationSettings();
              // openAppSettings();
              Navigator.pop(context);
            },
            // image: Icon(
            //   Icons.camera_alt,
            //   color: Pallete.PRIMARY,
            // ),
            onCancel: () => Navigator.pop(context),
            title: "Perhatian",
            buttonOk: "OK",
            buttonCancel: "Batal",
            context: context,
            message: "Untuk menggunakan fitur ini, mohon aktifkan lokasi pada pengaturan perangkat anda",
          );
          return;
    }
    if (!isGpsOn) {
      
      print('Turn on location services before requesting permission.');
      return;
    }
    
    final status = await Permission.location.request();
    if (status == PermissionStatus.granted) {
      print('Permission granted');
                Navigator.pushNamed(context, SchedulePray.routeName);

    } else if (status == PermissionStatus.denied) {
      print('Permission denied. Show a dialog and again ask for the permission');
       const DialogBox().showImageDialog(
            isError: false,
            onOk: () {
              openAppSettings();
              //  AppSettings.openLocationSettings();
              Navigator.pop(context);
            },
            // image: Icon(
            //   Icons.camera_alt,
            //   color: Pallete.PRIMARY,
            // ),
            buttonCancel:'Batal', 
            onCancel: () => Navigator.pop(context),
            title: "Perhatian",
            buttonOk: "OK",
            context: context,
            message: "Fitur ini membutuhkan akses lokasi anda",
          );

    } else if (status == PermissionStatus.permanentlyDenied) {
      print('Take the user to the settings page.');
      // await openAppSettings();
       const DialogBox().showImageDialog(
            isError: false,
            onOk: () {
              openAppSettings();
              Navigator.pop(context);
            },
            // image: Icon(
            //   Icons.camera_alt,
            //   color: Pallete.PRIMARY,
            // ),
            buttonCancel:'Batal', 
            onCancel: () => Navigator.pop(context),
            title: "Perhatian",
            buttonOk: "OK",
            context: context,
            message: "Fitur ini membutuhkan akses lokasi anda",
          );
    }
  }

  buildPromo(HomeWidgetController controller, context) {
    return !controller.listedPromo
        ? Container()
        : Visibility(
            visible: controllerMenu.getVisibilityPromo(),
            child: Column(
              children: <Widget>[
                const SizedBox(height: 8),
                Container(
                    // padding: EdgeInsets.symmetric(horizontal: 16),
                    padding: const EdgeInsets.only(left: 16, right: 14),
                    // alignment: Alignment.topLeft,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: const <Widget>[
                        Text(
                          'Promo',
                          style: TextStyle(
                            color: Pallete.primary,
                            fontFamily: 'Poppins',
                          ),
                        ),
                      ],
                    )),
                const SizedBox(
                  height: 8,
                ),
                !controller.listedPromo
                    ? const SkeletonCardPromo()
                    : Visibility(
                        visible: controllerMenu.getVisibilityPromo(),
                        child: SizedBox(
                          // padding: EdgeInsets.symmetric(horizontal: 4),
                          // padding: EdgeInsets.only(left: 16),
                          height: 150,
                          width: 500,
                          child: ListView(
                              // padding: EdgeInsets.symmetric(horizontal: 4),
                              padding: const EdgeInsets.only(right: 8, left: 8),
                              scrollDirection: Axis.horizontal,
                              children: controller.listPromo),
                        ),
                      ),
                const SizedBox(height: 8),
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16.0),
                  child: Divider(thickness: 1),
                ),
              ],
            ),
          );
  }

  // bool listedPromo = true;
  // ignore: unused_field
  final bool _textTransacsion = false;
  String? messageTransaction = "";

  _getMiniStatement(context) async {
    final resp = await API.postNoLoading(context, '/acct/accountstatement', {});
    if (resp != null && resp['code'] == 0) {
      var listResp = resp['accounts'];
      List<dynamic> listRespMini = (listResp);
      List<ISTCardStatement> listParam = [];
      for (var item in listRespMini) {
        ISTCardStatement miniItem = ISTCardStatement(
          debit: item['transactionDbCr'],
          transactionAmt: item['transactionAmt'],
          transactionDateTime: item['transactionDateTime'],
          transactionMemo: item['transactionMemo'],
          // transactionType: item['transactionType'],
        );
        listParam.add(miniItem);
      }

      if (mounted) {
        setState(() {
          listStatement = listParam;
        });
      }

      // setState(() {
      //   listStatement = listParam;
      // });
    } else if (resp != 0) {
      var message = resp['message'];
      messageTransaction = message;
    }
  }

  buildTransactionHistoryHome() {
    return Visibility(
      visible: controllerMenu.getVisibilityTransaksi(),
      child: Column(
        children: <Widget>[
          const SizedBox(height: 8),
          Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              alignment: Alignment.topLeft,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: const <Widget>[
                  Text(
                    'Transaksi Terakhir',
                    style: TextStyle(
                      color: Pallete.primary,
                      fontFamily: 'Poppins',
                    ),
                  ),

                  // Text(
                  //   'Lihat semua',
                  //   style: TextStyle(
                  //       color: Pallete.primary,
                  //       fontSize: Theme.of(context).textTheme.caption.fontSize),
                  // )
                ],
              )),
          const SizedBox(
            height: 8,
          ),
          Container(
            alignment: Alignment.center,
            child: messageTransaction != null
                ? Text(
                    StringUtils.getValueAsString(messageTransaction!),
                    style: const TextStyle(fontSize: 12, color: Colors.grey),
                  )
                : const SizedBox.shrink(),
          ),
          Column(
            children: listStatement,
          )
        ],
      ),
    );
  }
}
