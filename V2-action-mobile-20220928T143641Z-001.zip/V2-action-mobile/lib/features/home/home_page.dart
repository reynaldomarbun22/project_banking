import 'dart:io';

import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/core/controller/controller_menu.dart';
import 'package:bpd_aceh/features/home/widgets/home_widget.dart';
// import 'package:bpd_aceh/features/home/widgets/notificationPage/notificationPage.dart';
import 'package:bpd_aceh/features/home/widgets/other_widget.dart';
import 'package:bpd_aceh/features/home/widgets/paybill_widget.dart';
import 'package:bpd_aceh/features/home/widgets/transfer_widget.dart';
import 'package:bpd_aceh/features/inbox/page/inbox.dart';
import 'package:bpd_aceh/features/qrtransfer/scanqrtransfer.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';

class HomePage extends StatefulWidget {
  static const routeName = '/home';

  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final controllerMenu = Get.put(MenuController());
  int _selectedIndex = 0;
  String title = "";

  @override
  void initState() {
    super.initState();
  }

  void _onItemTapped(int index) {
    // String _title = "";
    if (index == 2) {
      return;
    } else {
      setState(() {
        // title = _title;
        _selectedIndex = index;
      });
    }
  }

  // _doNotification() async {
  //   Navigator.pushNamed(context, NotificationPage.routeName);
  // }

  _dologout() async {
    const api = "/logout";
    final resp = await API.post(context, api, {});
    if (resp != null && resp['code'] == 0) {
      await ISTConstants().setString(ISTConstants.authCookie, '');
      await ISTConstants().setString(ISTConstants.loggedInKey, "");
      // Navigator.pushNamedAndRemoveUntil(context, LandingPageScreen.routeName,
      //     ModalRoute.withName(Splash.routeName));
      // Navigator.pushNamed(context, LoginPage.routeName);
      if (Platform.isAndroid) {
        SystemNavigator.pop();
      } else if (Platform.isIOS) {
        exit(0);
      }
    } else if (resp != null && resp['code'] != 0) {
      const DialogBox().showImageDialog(
          message: resp['message'],
          isError: true,
          buttonCancel: 'OK',
          onOk: () {},
          context: context);
    }
  }

  _logout() {
    const DialogBox().showImageDialog(
        message: "Anda yakin akan keluar ?",
        isError: true,
        image: const Image(
          image: AssetImage('assets/images/icon-failed.png'),
        ),
        buttonCancel: 'Tidak',
        buttonOk: 'Keluar',
        onOk: () {
          _dologout();
        },
        context: context);
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      // onWillPop: () async => false,
      onWillPop: () {
        _logout();
        return Future.value(false);
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          leading: const Text(""),
          centerTitle: true,
          title:
              // title == ""
              // ?
              Image(
            image: const AssetImage('assets/images/logo-app.png'),
            width: MediaQuery.of(context).size.width / 6,
          ),
          // : Text(title, style: TextStyle(
          // color: Colors.white
          // ),
          // ),
          actions: <Widget>[
            GetBuilder<MenuController>(
              builder: (controller) {
                return Visibility(
                  visible: controller.getVisibilityInbox(),
                  child: IconButton(
                    icon: const Icon(
                      Icons.notifications,
                      color: Colors.white,
                      // color: Pallete.primary,
                    ),
                    onPressed: () {
                      Navigator.pushNamed(context, Inbox.routeName);
                      // _doLogout();
                      // _doNotification();
                    },
                  ),
                );
              }
            )
          ],
          elevation: 0.0,
          backgroundColor: Pallete.primary,
          // backgroundColor: Colors.white,
        ),
        body: showPage(context),

        // floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
        // bottomNavigationBar: BottomAppBar(
        //   child: Row(
        //     mainAxisAlignment: MainAxisAlignment.spaceAround,
        //     children: <Widget>[
        //       //We shall add two IconButtons here
        //       Padding(
        //         padding: const EdgeInsets.symmetric(horizontal: 16),
        //         child: IconButton(
        //             icon: Image(
        //               color:
        //                   _selectedIndex == 0 ? Pallete.primary : Colors.grey,
        //               image: AssetImage('assets/images/icon-home.png'),
        //             ),
        //             // color: Colors.white,
        //             onPressed: () {
        //               Navigator.push(
        //                   context,
        //                   MaterialPageRoute(
        //                       builder: (BuildContext context) =>
        //                           DashBoardHomePage()));
        //             }),
        //       ),
        //       Padding(
        //         padding: const EdgeInsets.symmetric(horizontal: 16),
        //         child: IconButton(
        //             icon: Image(
        //               color:
        //                   _selectedIndex == 1 ? Pallete.primary : Colors.grey,
        //               image: AssetImage('assets/images/icon-transfer.png'),
        //             ),
        //             // color: Colors.white,
        //             onPressed: () {
        //               // Navigator.pushNamed(context, TransferQR.routeName);
        //             }),
        //       ),
        //       Padding(
        //         padding: const EdgeInsets.symmetric(horizontal: 16),
        //         child: IconButton(
        //             icon: Image(
        //               color:
        //                   _selectedIndex == 1 ? Pallete.primary : Colors.grey,
        //               image: AssetImage('assets/images/icon-payment.png'),
        //             ),
        //             // color: Colors.white,
        //             onPressed: () {
        //               Navigator.pushNamed(context, TransferQR.routeName);
        //             }),
        //       ),
        //       Padding(
        //         padding: const EdgeInsets.symmetric(horizontal: 16),
        //         child: IconButton(
        //             icon: Image(
        //               color: Pallete.primary,
        //               image: AssetImage('assets/images/icon-other.png'),
        //             ),
        //             // color: Colors.white,
        //             onPressed: () {
        //               Navigator.pushNamed(context, OtherWidget.routeName);
        //             }),
        //       ),
        //     ],
        //   ),
        //   shape: CircularNotchedRectangle(),
        // ),
        // bottomNavigationBar: Theme(
        //   data: ThemeData(
        //     splashColor: Colors.transparent,
        //     highlightColor: Colors.transparent,
        //   ),
        //   child: BottomAppBar(
        //     elevation: 8,
        //     notchMargin: 8,
        //     shape: CircularNotchedRectangle(),
        //     clipBehavior: Clip.antiAlias,
        //     child: BottomNavigationBar(
        //       backgroundColor: Colors.white,
        //       type: BottomNavigationBarType.fixed,
        //       unselectedItemColor: Colors.grey,
        //       items: [
        //         BottomNavigationBarItem(
        //           icon: Image(
        //             image: AssetImage('assets/images/newiconhome.png'),
        //             width: 30,
        //           ),
        //           title: Text(
        //             'Beranda',
        //             style: TextStyle(
        //               fontSize: 11,
        //               fontFamily: 'Poppins',
        //             ),
        //           ),
        //         ),
        //         BottomNavigationBarItem(
        //           icon: Image(
        //             image: AssetImage('assets/images/newicontransfer.png'),
        //             width: 30,
        //           ),
        //           title: Text(
        //             'Transfer',
        //             style: TextStyle(
        //               fontSize: 11,
        //               fontFamily: 'Poppins',
        //             ),
        //           ),
        //         ),
        //         BottomNavigationBarItem(
        //           icon: Image(
        //             image: AssetImage('assets/images/icon-transfer.png'),
        //             width: 30,
        //           ),
        //           title: Text(
        //             '',
        //           ),
        //         ),
        //         BottomNavigationBarItem(
        //           icon: Image(
        //             image: AssetImage('assets/images/newiconlayanan1.png'),
        //             width: 30,
        //           ),
        //           title: Text(
        //             'Layanan',
        //             style: TextStyle(
        //               fontSize: 11,
        //               fontFamily: 'Poppins',
        //             ),
        //           ),
        //         ),
        //         BottomNavigationBarItem(
        //           icon: Image(
        //             image: AssetImage('assets/images/newiconlainnya.png'),
        //             width: 30,
        //           ),
        //           title: Text(
        //             'Lainnya',
        //             style: TextStyle(
        //               fontSize: 11,
        //               fontFamily: 'Poppins',
        //             ),
        //           ),
        //         )
        //       ],
        //       currentIndex: _selectedIndex,
        //       selectedItemColor: Pallete.primary,
        //       onTap: _onItemTapped,
        //     ),
        //   ),
        // ),

        bottomNavigationBar: Theme(
          data: ThemeData(
            splashColor: Colors.transparent,
            highlightColor: Colors.transparent,
          ),
          child: BottomAppBar(
            elevation: 8,
            notchMargin: 8,
            shape: const CircularNotchedRectangle(),
            clipBehavior: Clip.antiAlias,
            child: BottomNavigationBar(
              backgroundColor: Colors.white,
              type: BottomNavigationBarType.fixed,
              unselectedItemColor: Colors.grey,
              items: [
                BottomNavigationBarItem(
                  icon: Image(
                    image: _selectedIndex == 0
                        ? const AssetImage('assets/images/icon-newhome.png')
                        : const AssetImage('assets/images/unGroup 2020.png'),
                    width: 30,
                    // color: _selectedIndex == 0 ? Pallete.primary : Colors.grey,
                  ),
                  label: 'Beranda',
                ),
                BottomNavigationBarItem(
                  icon: Image(
                    image: _selectedIndex == 1
                        ? const AssetImage('assets/images/icon-newTransfer.png')
                        : const AssetImage('assets/images/unTransfer.png'),
                    width: 30,
                    // color: _selectedIndex == 1 ? Pallete.primary : Colors.grey,
                  ),
                  label: 'Transfer',
                ),
                // controllerMenu.getVisibilityQRR() ?
                BottomNavigationBarItem(
                  icon: _selectedIndex == 2 ? Container() : Container(),
                  label: '',
                  // icon: Image(
                  //   image: _selectedIndex == 2
                  //       ? AssetImage('assets/images/icon-transfer.png')
                  //       : AssetImage('assets/images/unGroup 2040.png'),
                  //   width: 30,
                  //   // color: _selectedIndex == 2 ? Pallete.primary : Colors.grey,
                  // ),
                  // title: Text(
                  //   '',
                  // ),
                ),
                BottomNavigationBarItem(
                  icon: Image(
                    image: _selectedIndex == 3
                        ? const AssetImage('assets/images/Layanan11.png')
                        : const AssetImage('assets/images/unGroup 2040.png'),
                    width: 30,
                    // color: _selectedIndex == 3 ? Pallete.primary : Colors.grey,
                  ),
                  label: 'Layanan',
                ),
                BottomNavigationBarItem(
                  icon: Image(
                    image: _selectedIndex == 4
                        ? const AssetImage('assets/images/icon-newLainnya.png')
                        : const AssetImage('assets/images/unLainnya.png'),
                    width: 30,
                    // color: _selectedIndex == 4 ? Pallete.primary : Colors.grey,
                  ),
                  label: 'Lainnya',
                )
              ],
              currentIndex: _selectedIndex,
              selectedItemColor: Pallete.primary,
              onTap: _onItemTapped,
            ),
          ),
        ),
        // floatingActionButtonLocation: controllerMenu.visibleBgQRIS == true
        //     ? FloatingActionButtonLocation.centerDocked
        //     : null,
        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
        floatingActionButton: SizedBox(
          height: 60,
          width: 60,
          child: FittedBox(
            // fit: BoxFit.fill,
            child: FloatingActionButton(
              elevation: 3,
              backgroundColor: Colors.white,
              child: const Image(
                alignment: Alignment.center,
                image: AssetImage('assets/images/qris2.png'),
                width: 100,
                height: 100,
                // color: Colors.transparent,
              ),
              onPressed: () {
                Navigator.pushNamed(context, TransferQR.routeName);
              },
            ),
          ),
        ),
      ),
    );
  }

  showPage(context) {
    switch (_selectedIndex) {
      case 0:
        return const DashBoardHomePage();
      case 1:
        return transferPage(context);
      // // case 2:
      // // return qrPage(context);
      case 2:
        return Container();
      case 3:
        return belibayarPage(context);
      case 4:
        return const OtherWidget();
    }
    return widget;
  }
}
