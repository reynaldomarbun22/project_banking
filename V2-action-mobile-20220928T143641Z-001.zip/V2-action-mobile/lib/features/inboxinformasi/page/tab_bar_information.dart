import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/inbox/page/inbox.dart';
import 'package:flutter/material.dart';

class TabBarInform extends StatefulWidget {
  static const routeName = '/TabBarInform';

  const TabBarInform({Key? key}) : super(key: key);

  @override
  _TabBarInformState createState() => _TabBarInformState();
}

class _TabBarInformState extends State<TabBarInform> {
  String notifikasiPage = "";
  String pesanPage = "";

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          centerTitle: true,
          title: const Text(
            'Informasi',
            style: TextStyle(
                color: Colors.white, fontSize: 16, fontFamily: 'Poppins'),
          ),
          elevation: 0.0,
          backgroundColor: Pallete.primary,
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(48.0),
            child: Column(children: <Widget>[
              Container(
                color: Colors.white,
                child: TabBar(
                  indicatorColor: Pallete.primary,
                  indicatorSize: TabBarIndicatorSize.tab,
                  indicatorWeight: 3,
                  labelColor: Colors.black,
                  unselectedLabelColor: Colors.grey[400],
                  tabs: const [
                    Tab(
                      // text: notifikasiPage,
                      child: Text(
                        "Inbox",
                        style: TextStyle(
                            color: Pallete.primary,
                            // fontSize: 14,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Poppins'),
                      ),
                    ),
                    Tab(
                      // text: notifikasiPage,
                      child: Text(
                        "Informasi Terkini",
                        style: TextStyle(
                            color: Pallete.primary,
                            // fontSize: 14,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Poppins'),
                      ),
                    ),

                    // Tab(
                    //   // text: pesanPage,
                    //   child: Text(
                    //     "Pesan",
                    //     style: TextStyle(
                    //       // color: Colors.black,
                    //       // fontSize: 14,
                    //       fontWeight: FontWeight.bold,
                    //     ),
                    //   ),
                    // ),
                  ],
                ),
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 8.0),
                child: Divider(
                  height: 1,
                  color: Pallete.primary,
                ),
              ),
            ]),
          ),
        ),
        body: Container(
          // padding: EdgeInsets.only(
          //   bottom: 5,
          // ),
          decoration: const BoxDecoration(
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(50.0)),
          ),
          child: TabBarView(
            children: [
              const Inbox(),
              Container(),
            ],
          ),
        ),
      ),
      length: 2,
    );
  }
}
