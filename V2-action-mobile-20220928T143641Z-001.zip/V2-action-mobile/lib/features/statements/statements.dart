import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_card_account.dart';
import 'package:bpd_aceh/components/ist_card_statement.dart';
import 'package:bpd_aceh/components/ist_style.dart';
import 'package:bpd_aceh/components/loading_screen.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:flutter/material.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:intl/intl.dart';

class Statements extends StatefulWidget {
  static const routeName = '/Mutasi';

  const Statements({Key? key}) : super(key: key);

  @override
  _StatementsState createState() => _StatementsState();
}

class ListMutasi {
  final String? icon;
  final String? content;
  final String? money;
  final String? dateTime;

  ListMutasi({
    this.icon,
    this.content,
    this.money,
    this.dateTime,
  });
}

class _StatementsState extends State<Statements> {
  TextEditingController fromDateController = TextEditingController();
  TextEditingController untilDateController = TextEditingController();
  bool miniStatement = true;
  List<ISTCardStatement> listStatement = [];
  String _statementText = "Pilih periode mutasi";

  // List<ListMutasi> listMutasi = List();
  _getMiniStatement() async {
    setState(() {
      miniStatement = true;
    });
    final resp = await API.postNoLoading(context, '/acct/accountstatement', {});
    if (resp['code'] == 0) {
      var listResp = resp['accounts'];
      // List<dynamic> listRespMini = (listResp);
      List<ISTCardStatement> listParam = [];
      if (listResp == null) {
        // ISTCardStatement miniItem = ISTCardStatement(
        //   transactionAmt: "Tidak Ada Transaksi",
        //   transactionDateTime: "",
        //   transactionMemo: "",
        // );
        // Container();
        // listParam.add(miniItem);
        setState(() {
          listStatement = listParam;
        });
      } else {
        List<dynamic> listRespMini = (listResp);

        for (var item in listRespMini) {
          ISTCardStatement miniItem = ISTCardStatement(
            transactionAmt: item['transactionAmt'],
            debit: item['transactionDbCr'],
            transactionDateTime: item['transactionDateTime'],
            transactionMemo: item['transactionMemo'],
          );
          listParam.add(miniItem);
        }
        setState(() {
          listStatement = listParam;
        });
      }
    }
  }

  String messageMutation = "";
  _getRangeStatement() async {
    setState(() {
      miniStatement = false;
    });
    Map<String, Object> param = {};
    print("DIFF = ${fromDate!.difference(untilDate!).inDays}");

    if (fromDate!.difference(untilDate!).inDays.abs() <= 31) {
      param['startDate'] = fParam.format(fromDate!);
      param['endDate'] = fParam.format(untilDate!);
      final resp =
          await API.post(context, '/acct/accountstatementbydate', param);
      if (resp['code'] == 0) {
        var listResp = resp['accounts'];
        List<ISTCardStatement> listParam = [];
        if (listResp == null) {
          // listParam.add(miniItem);
          setState(() {
            listStatement = listParam;
            if (listParam.isEmpty) _statementText = "Tidak ada transaksi";
          });
        } else {
          List<dynamic> listRespMini = (listResp);

          for (var item in listRespMini) {
            ISTCardStatement miniItem = ISTCardStatement(
              transactionAmt: item['transactionAmt'],
              debit: item['transactionDbCr'],
              transactionDateTime: item['transactionDateTime'],
              transactionMemo: item['transactionMemo'],
            );
            listParam.add(miniItem);
          }
          setState(() {
            listStatement = listParam;
            if (listParam.isEmpty) _statementText = "Tidak ada transaksi";
          });
        }
      } else if (resp['code'] != 0) {
        setState(() {
          var messageMutations = resp['message'];
          _statementText =
              messageMutations == "-" ? "Tidak ada transaksi" : messageMutation;
        });
      } else {
        const DialogBox().showImageDialog(
            message: resp['message'],
            isError: true,
            image: const Image(
              image: AssetImage('assets/images/icon-failed.png'),
            ),
            buttonCancel: 'OK',
            onOk: () {},
            context: context);
      }
    } else {
      _showErrorMaxDate();
    }
  }

  _showErrorMaxDate() {
    const DialogBox().showImageDialog(
        message: 'Periode mutasi hanya dapat dipilih 31 hari',
        isError: true,
        image: const Image(
          image: AssetImage('assets/images/icon-failed.png'),
        ),
        buttonCancel: 'OK',
        onOk: () {},
        context: context);
  }

  DateTime? fromDate;
  DateTime? untilDate;

  DateFormat f = DateFormat('dd-MMM-yyyy');
  final fParam = DateFormat('yyyy-MM-dd');
  // ignore: unused_field
  final _oneDay = 60 * 60 * 24 * 1000;

  _fromDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: fromDate == null ? DateTime.now() : fromDate!,
        builder: (BuildContext context, Widget? child) {
          return Theme(
            data: ThemeData(
              primarySwatch: ISTStyle.buttonTextColor,
              primaryColor: Pallete.primary,
              colorScheme: const ColorScheme.light(secondary: Pallete.primary),
              buttonTheme:
                  const ButtonThemeData(textTheme: ButtonTextTheme.primary),
            ),
            child: child!,
          );
        },
        firstDate: DateTime.now().subtract(const Duration(days: 90)),
        lastDate: DateTime.now());

    if (picked != null) {
      setState(() {
        fromDate = picked;
        fromDateController.text = f.format(picked);
      });
      if (untilDate != null && fromDate!.isAfter(untilDate!)) {
        setState(() {
          untilDate = picked;
          untilDateController.text = f.format(picked);
        });
      }
    } else {
      return;
    }
    if (untilDate != null) {
      _getRangeStatement();
    }
  }

  _untilDate(BuildContext context) async {
    final lastDate = fromDate!.difference(DateTime.now()).inDays >= 0
        ? DateTime.now()
        : fromDate!.add(Duration(
            days: fromDate!.difference(DateTime.now()).inDays.abs() > 31
                ? 31
                : fromDate!.difference(DateTime.now()).inDays.abs()));
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: untilDate == null
            ? fromDate!
            : untilDate!.isAfter(lastDate)
                ? lastDate
                : untilDate!,
        initialDatePickerMode: DatePickerMode.day,
        firstDate: fromDate!,
        builder: (BuildContext context, Widget? child) {
          return Theme(
            data: ThemeData(
              primarySwatch: ISTStyle.buttonTextColor,
              primaryColor: Pallete.primary,
              colorScheme: const ColorScheme.light(secondary: Pallete.primary),
              buttonTheme:
                  const ButtonThemeData(textTheme: ButtonTextTheme.primary),
            ),
            child: child!,
          );
        },
        lastDate: lastDate);
    print("DIFF = ${fromDate!.difference(DateTime.now()).inDays}");
    if (picked != null) {
      setState(() {
        untilDate = picked;
        untilDateController.text = f.format(picked);
      });
      if (fromDate != null) {
        _getRangeStatement();
      }
    } else {
      return;
    }
  }

  @override
  void initState() {
    initializeDateFormatting('id', '');
    setState(() {
      f = DateFormat.yMMMd('id');
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Pallete.primary,
        title: const Text(
          "Mutasi Rekening",
          style: TextStyle(color: Colors.white, fontFamily: 'Poppins'),
        ),
        centerTitle: true,
        leading: IconButton(
            color: Colors.white,
            icon: const Icon(Icons.arrow_back_ios),
            onPressed: () {
              Navigator.pop(context);
            }),
        // s
      ),
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: <Widget>[
            ISTCardAccount(
              context: context,
              menu: ISTMenu.statements,
              callback: () {
                _getMiniStatement();
              },
            ),
            const SizedBox(
              height: 8,
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                'Maksimal periode 31 (Tiga Puluh Satu) hari kalender',
                style: TextStyle(
                    fontSize: Theme.of(context).textTheme.overline!.fontSize),
              ),
            ),
            Container(
              padding: const EdgeInsets.only(left: 16, right: 16),
              child: Row(
                children: <Widget>[
                  Expanded(
                    flex: 4,
                    child: SizedBox(
                      width: 50,
                      child: TextField(
                          controller: fromDateController,
                          readOnly: true,
                          showCursor: false,
                          onTap: () => _fromDate(context),
                          decoration: InputDecoration(
                            suffixIcon: IconButton(
                                iconSize: 20,
                                onPressed: () {},
                                icon: const Icon(Icons.calendar_today)),
                          )),
                    ),
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  const SizedBox(
                      height: 25,
                      child: Image(
                          image: AssetImage(
                              "assets/images/icon-arrow-right.png"))),
                  const SizedBox(
                    width: 10,
                  ),
                  Expanded(
                    flex: 4,
                    child: SizedBox(
                      width: 50,
                      child: TextField(
                          controller: untilDateController,
                          cursorColor: Colors.grey,
                          readOnly: true,
                          showCursor: false,
                          onTap: () => _untilDate(context),
                          decoration: InputDecoration(
                            suffixIcon: IconButton(
                                iconSize: 20,
                                onPressed: () {},
                                icon: const Icon(Icons.calendar_today)),
                          )),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            const SizedBox(
              height: 8,
            ),
            Expanded(
                child: Theme(
              data: ThemeData(
                  colorScheme:
                      const ColorScheme.light(secondary: Colors.white)),
              child: ListView(
                children: [
                  Column(
                    children: [
                      listStatement.isEmpty
                          ? Container(
                              alignment: Alignment.center,
                              height: 300,
                              width: 200,
                              child: Text(
                                _statementText,
                                style: const TextStyle(
                                  color: Colors.grey,
                                ),
                              ),
                            )
                          : Column(
                              children: listStatement,
                            ),
                      // : _statementText.isNotEmpty
                      //     ? Container(
                      //         alignment: Alignment.center,
                      //         height: 300,
                      //         width: 200,
                      //         child: Text(
                      //           StringUtils.getValueAsString(
                      //               _statementText),
                      //           style: const TextStyle(
                      //               fontSize: 12, color: Colors.grey),
                      //         ),
                      //       )
                      //     : listStatement.isNotEmpty
                      //         ? Column(
                      //             children: listStatement,
                      //           )
                      //         : Container()
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                ],
              ),
            )),
          ],
        ),
      ),
    );
  }
}

class SkeletonCard extends StatefulWidget {
  final double height;
  final double width;

  const SkeletonCard({Key? key, this.height = 20, this.width = 200})
      : super(key: key);

  @override
  createState() => SkeletonCardState();
}

class SkeletonCardState extends State<SkeletonCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    _controller = AnimationController(
        duration: const Duration(milliseconds: 1500), vsync: this);
    _controller.repeat();
    super.initState();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var _childrenLoad = <Widget>[];
    // for (var i = 0; i < 7; i++) {
    _childrenLoad.add(
      SizedBox(
        height: 128,
        child: Stack(
          children: <Widget>[
            Container(
              height: 70,
              decoration: const BoxDecoration(
                  color: Pallete.primary,
                  borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(10),
                      bottomRight: Radius.circular(10))),
            ),
            Positioned(
              top: 8,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0),
                child: Container(
                  height: 118,
                  width: MediaQuery.of(context).size.width - 16,
                  decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Pallete.primary.withOpacity(0.3),
                        spreadRadius: 0.2,
                        blurRadius: 5,
                      )
                    ],
                    color: Colors.white,
                    borderRadius: const BorderRadius.all(Radius.circular(10)),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      Expanded(
                        flex: 7,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            LoadAnimation(
                              child: Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  color: const Color.fromRGBO(0, 0, 0, .06),
                                ),
                                height: 88,
                                width: 88,
                              ),
                            )
                          ],
                        ),
                      ),
                      Expanded(
                          flex: 9,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: <Widget>[
                              Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(100),
                                  color: const Color.fromRGBO(0, 0, 0, .06),
                                ),
                                height: 12,
                              ),
                              const SizedBox(
                                height: 8,
                              ),
                              Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(100),
                                  color: const Color.fromRGBO(0, 0, 0, .06),
                                ),
                                height: 12,
                              ),
                              const SizedBox(
                                height: 8,
                              ),
                              Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(100),
                                  color: const Color.fromRGBO(0, 0, 0, .06),
                                ),
                                height: 12,
                              ),
                              const SizedBox(
                                height: 8,
                              ),
                              Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(100),
                                  color: const Color.fromRGBO(0, 0, 0, .06),
                                ),
                                height: 12,
                              ),
                            ],
                          )),
                      Expanded(flex: 2, child: Container())
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );

    return LoadAnimation(
      child: Column(
        children: _childrenLoad,
      ),
    );
  }
}

class SkeletonMutation extends StatefulWidget {
  final double height;
  final double width;

  const SkeletonMutation({Key? key, this.height = 20, this.width = 200})
      : super(key: key);

  @override
  createState() => SkeletonMutationState();
}

class SkeletonMutationState extends State<SkeletonMutation>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    _controller = AnimationController(
        duration: const Duration(milliseconds: 1500), vsync: this);
    _controller.repeat();
    super.initState();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var _childrenLoad = <Widget>[];
    for (var i = 0; i < 5; i++) {
      _childrenLoad.add(Container(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        child: Card(
          child: Container(
            height: 100,
            padding: const EdgeInsets.all(8),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                const SizedBox(width: 8),
                Expanded(
                  flex: 5,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Container(
                        padding: const EdgeInsets.only(right: 10),
                        child: Container(
                          height: 12,
                          width: 36,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(100),
                            color: const Color.fromRGBO(0, 0, 0, .06),
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 8,
                      ),
                      Container(
                        padding: const EdgeInsets.only(right: 32),
                        child: Container(
                          height: 12,
                          // width: 42,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(100),
                            color: const Color.fromRGBO(0, 0, 0, .06),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                    flex: 3,
                    child: Container(
                      padding: const EdgeInsets.only(left: 18),
                      child: Container(
                        height: 12,
                        width: 42,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(100),
                          color: const Color.fromRGBO(0, 0, 0, .06),
                        ),
                      ),
                    ))
              ],
            ),
          ),
        ),
      ));
    }
    return LoadAnimation(
      child: Column(
        children: _childrenLoad,
      ),
    );
  }
}
