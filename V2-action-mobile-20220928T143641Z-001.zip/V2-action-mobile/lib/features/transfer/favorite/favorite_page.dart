import 'package:bpd_aceh/components/ist_list_fav.dart';
import 'package:flutter/material.dart';

class FavoriteTransferPage extends StatefulWidget {
  static const routeName = '/favoritePage';

  const FavoriteTransferPage({Key? key}) : super(key: key);

  @override
  _FavoriteTransferPageState createState() => _FavoriteTransferPageState();
}

class _FavoriteTransferPageState extends State<FavoriteTransferPage> {
  @override
  Widget build(BuildContext context) {
    return ISTListFav(menu: const [ISTFavoritEnum.transfer], context: context);
  }
}
