import 'package:flutter/material.dart';

class KewarganegaraanItem {
  final String? kewarganegaraan;
  final String? kewarganegaraanKey;
  final int? kewarganegaraanIndex;


  KewarganegaraanItem(
      {Key? key,
     this.kewarganegaraan,
     this.kewarganegaraanKey,
     this.kewarganegaraanIndex,
     });
}