class InquiryTransferIHEntity{
  final String? srcAcctNo;
  final String? bnfAcctNo;
  final String? bnfBankCode;
  final String? amount;
  final String? memo;

  InquiryTransferIHEntity(this.srcAcctNo, this.bnfAcctNo, this.bnfBankCode, this.amount, this.memo);
}

class InquiryTransferIHResponseEntity{
  final Map? detail;
  final int? code;
  final String? inqReff;

  InquiryTransferIHResponseEntity(this.detail, this.code, this.inqReff);

  
}

class PostTransferIHEntity{
  final String? inqReff;
  final String? mpin;

  PostTransferIHEntity(this.inqReff, this.mpin);

}