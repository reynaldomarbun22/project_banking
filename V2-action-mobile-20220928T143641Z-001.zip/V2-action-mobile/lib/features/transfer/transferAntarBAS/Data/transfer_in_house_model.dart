import 'dart:convert';

import 'package:bpd_aceh/features/transfer/transferAntarBAS/Domain/transfer_in_house_entity.dart';

// import 'package:bima/screens/afterLogin/Transfer/TransferAntarBankJateng/domain/entities/transferInHouseEntity.dart';

class InquiryTransferIH extends InquiryTransferIHEntity {
  InquiryTransferIH(
      {String? srcAcctNo,
      String? bnfAcctNo,
      String? bnfBankCode,
      String? amount,
      String? memo})
      : super(srcAcctNo, bnfAcctNo, bnfBankCode, amount, memo);

  factory InquiryTransferIH.fromJson(Map<String, dynamic> json) {
    return InquiryTransferIH(
      srcAcctNo: json['src_acct_no'],
      bnfAcctNo: json['bnf_acct_no'],
      bnfBankCode: json['bnf_bank_code'],
      amount: json['amount'],
      memo: json['memo'],
    );
  }

  String toJson() => json.encode({
        'src_acct_no': srcAcctNo,
        'bnf_acct_no': bnfAcctNo,
        'bnf_bank_code': bnfBankCode,
        'amount': amount,
        'memo': memo,
      });
}

class InquiryTransferIHResponse extends InquiryTransferIHResponseEntity {
  InquiryTransferIHResponse({Map? detail, int? code, String? inqReff})
      : super(detail, code, inqReff);

  factory InquiryTransferIHResponse.fromJson(Map<String, dynamic> json) {
    return InquiryTransferIHResponse(
        detail: json['detail'], code: json['code'], inqReff: json['inq_reff']);
  }

  String toJson() => json.encode(
      {'detail': detail, 'code': code, 'inq_reff': inqReff});
}

class PostTransferIH extends PostTransferIHEntity {
  PostTransferIH({String? inqReff, String? mpin}) : super(inqReff, mpin);

  String toJson() => json.encode({'inq_reff': inqReff, 'mpin': mpin});
}
