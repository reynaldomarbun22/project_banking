import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_card_account.dart';
import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/ist_style.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/core/utils/string_utils.dart';
import 'package:bpd_aceh/features/transfer/transferAntarBAS/confrimBAS/transfer_confirm_bas.dart';
import 'package:currency_text_input_formatter/currency_text_input_formatter.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class TransferBas extends StatefulWidget {
  static const routeName = '/transferBAS';
  final String? bnfAcctNo;
  final String? bnfAcctName;

  const TransferBas({
    Key? key,
    this.bnfAcctNo,
    this.bnfAcctName,
  }) : super(key: key);

  @override
  _TransferBasState createState() =>
      // ignore: no_logic_in_create_state
      _TransferBasState(bnfAcctNo, bnfAcctName);
}

class _TransferBasState extends State<TransferBas> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final String? bnfAcctNo;
  final String? bnfAcctName;

  _TransferBasState(this.bnfAcctNo, this.bnfAcctName);

  @override
  void initState() {
    if (bnfAcctNo != null) {
      _noRekBAScontroller.text = bnfAcctNo!;
      fromQR = true;
    }
    super.initState();
  }

  _doTransfer() async {
    if (_doValidate()) {
      Map<String, Object> param = {};

      param['destAcctNo'] = _noRekBAScontroller.text.replaceAll("-", "");
      param['amount'] =
          int.parse(_nominalBAScontroller.text.replaceAll(".", ""));
      param['memo'] = _catatanBAScontroller.text;

      final resp = await API.post(context, '/transfer/inquiry', param);
      if (resp == null) return;
      if (resp['code'] == 0) {
        List<ISTConfirmationItem> listParam = [];
        List<dynamic> listMap = resp['resi'];
        for (var item in listMap) {
          ISTConfirmationItem itemParam =
              ISTConfirmationItem(key: item['key'], value: item['value']);
          listParam.add(itemParam);
        }
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => TransferConfirmPageBAS(
                      list: listParam,
                    )));
      } else {
        const DialogBox().showImageDialog(
            message: resp['message'],
            isError: true,
            image: const Image(
              image: AssetImage('assets/images/icon-failed.png'),
            ),
            buttonCancel: 'OK',
            onOk: () {},
            context: context);
      }
    }
  }

  final _noRekBAScontroller = TextEditingController();
  final _catatanBAScontroller = TextEditingController();
  // ignore: unused_field
  final _noRefBAScontroller = TextEditingController();

  // final _nominalBAScontroller = ISTConstants().moneyMaskedController;

  final _nominalBAScontroller = TextEditingController();

  // ignore: unused_field
  bool _autoValidate = false;
  bool fromQR = false;

  bool _doValidate() {
    if (_formKey.currentState!.validate()) {
      return true;
    } else {
      setState(() {
        _autoValidate = true;
      });
      return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text(
          'Transfer antar BAS',
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'Poppins',
          ),
        ),
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      body: Container(
        color: Colors.white,
        child: Column(
          children: <Widget>[
            ISTCardAccount(
              context: context,
              menu: ISTMenu.transfer,
            ),
            Expanded(
              child: SingleChildScrollView(
                child: Container(
                  padding: const EdgeInsets.only(left: 16, right: 16),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        const SizedBox(
                          height: 16,
                        ),
                        Form(
                          // ignore: deprecated_member_use
                          autovalidateMode: AutovalidateMode.always,
                          key: _formKey,
                          child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: <Widget>[
                                Container(
                                    alignment: Alignment.topLeft,
                                    // padding: EdgeInsets.only(left: 16, right: 16, top: 8),
                                    child:
                                        // ? Text(
                                        //     'Ke Rekening: $bnfAcctNo',
                                        //   )
                                        const Text(
                                      'Ke Rekening :',
                                    )),
                                fromQR
                                    ? Container(
                                        alignment: Alignment.topLeft,
                                        padding: const EdgeInsets.only(bottom: 8),
                                        child: Text(
                                          '$bnfAcctNo - $bnfAcctName',
                                        ))
                                    : Container(
                                        alignment: Alignment.topLeft,
                                        child: TextFormField(
                                          keyboardType: TextInputType.number,
                                          validator: (val) {
                                            if (val!.isEmpty || val == '0') {
                                              return "Mohon diisi";
                                            } else {
                                              return null;
                                            }
                                          },
                                          inputFormatters: [
                                            // ignore: deprecated_member_use
                                            FilteringTextInputFormatter
                                                .digitsOnly,
                                          ],
                                          controller: _noRekBAScontroller,
                                          maxLength: 15,
                                          decoration: const InputDecoration(
                                            counterText: '',
                                            hintText:
                                                'Masukkan no. rekening tujuan',
                                            hintStyle: ISTStyle.hintStyle,
                                          ),
                                        ),
                                      ),
                                const SizedBox(
                                  height: 8,
                                ),
                                Container(
                                  alignment: Alignment.topLeft,
                                  child: const Text(
                                    'Nominal :',
                                    style: TextStyle(color: Colors.black87),
                                  ),
                                ),
                                Container(
                                  alignment: Alignment.topLeft,
                                  child: TextFormField(
                                    validator: (val) {
                                      if (val!.isEmpty || val == '0') {
                                        return "Mohon diisi";
                                      } else {
                                        return null;
                                      }
                                    },
                                    inputFormatters: [
                                      CurrencyTextInputFormatter(
                                        decimalDigits: 0,
                                        locale: 'id_ID',
                                        name: '',
                                      )
                                    ],
                                    controller: _nominalBAScontroller,
                                    maxLength: ISTConstants.nominalMaxLength,
                                    keyboardType: TextInputType.number,
                                    decoration: InputDecoration(
                                      counterText: '',
                                      prefixStyle: const TextStyle(
                                        color: Colors.black,
                                      ),
                                      hintText: 'Masukkan nominal',
                                      hintStyle: ISTStyle.hintStyle,
                                      isDense: true,
                                      prefixIcon: Text(
                                        "IDR ",
                                        style: TextStyle(
                                            fontSize: Theme.of(context)
                                                .textTheme
                                                .subtitle1!
                                                .fontSize),
                                      ),
                                      prefixIconConstraints: const BoxConstraints(
                                          minWidth: 0, minHeight: 0),
                                    ),
                                  ),
                                ),
                                const SizedBox(
                                  height: 8,
                                ),
                                Container(
                                  alignment: Alignment.topLeft,
                                  child: const Text(
                                    'Catatan :',
                                    style: TextStyle(color: Colors.black87),
                                  ),
                                ),
                                Container(
                                  alignment: Alignment.topLeft,
                                  child: TextField(
                                    controller: _catatanBAScontroller,
                                    inputFormatters: [
                                      StringUtils.alphaNumeric(),
                                    ],
                                    maxLength: ISTConstants.catatanTrfMaxLength,
                                    decoration: const InputDecoration(
                                      hintText: 'Masukkan catatan',
                                      hintStyle: ISTStyle.hintStyle,
                                    ),
                                  ),
                                ),
                                const SizedBox(
                                  height: 16,
                                ),
                              ]),
                        ),
                        ISTOutlineButton(
                          onPressed: () {
                            _doTransfer();
                          },
                          text: 'Lanjut',
                        ),
                        const SizedBox(
                          height: 16,
                        )
                      ]),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
