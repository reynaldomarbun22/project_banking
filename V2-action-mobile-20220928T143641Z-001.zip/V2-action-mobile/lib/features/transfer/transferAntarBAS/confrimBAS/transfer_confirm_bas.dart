import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/transfer/transferAntarBAS/mpinBAS/transfer_mpin_bas.dart';
// import 'package:bpd_aceh/features/transfer/mpin/transfer_mpin.dart';
import 'package:flutter/material.dart';

class TransferConfirmPageBAS extends StatefulWidget {
  static const routeName = '/transfer/confirmBAS';

  final List<ISTConfirmationItem>? list;

  const TransferConfirmPageBAS({Key? key, this.list}) : super(key: key);

  @override
  State<TransferConfirmPageBAS> createState() => _KonfirmasiFormState();
}

class _KonfirmasiFormState extends State<TransferConfirmPageBAS> {
  @override
  Widget build(BuildContext context) {
    _doTransfer() {
      Navigator.pushNamed(context, TransferMpinPage.routeName);
    }

    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Pallete.primary,
          leading: IconButton(
              icon: const Icon(
                Icons.arrow_back_ios,
                color: Colors.white,
              ),
              onPressed: () {
                Navigator.pop(context);
              }),
          title: const Text(
            'Transfer Antar BAS',
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'Poppins',
            ),
          ),
          // actions: <Widget>[
          //   IconButton(
          //     icon: Icon(
          //       Icons.notifications,
          //       color: Colors.white,
          //     ),
          //     onPressed: () {
          //       // _doLogout();
          //     },
          //   )
          // ],
          centerTitle: true,
          elevation: 0.0,
        ),
        body: ISTConfirmation(
            items: widget.list,
            title: 'Konfirmasi Transfer',
            onFinished: () {
              _doTransfer();
            }));
  }
}
