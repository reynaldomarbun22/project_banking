import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_mpin.dart';
import 'package:bpd_aceh/components/ist_receipt.dart';
import 'package:bpd_aceh/components/ist_receipt_repo.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/crypto/ist_crypto.dart';
import 'package:bpd_aceh/features/home/home_page.dart';
import 'package:bpd_aceh/features/splash/splash.dart';
import 'package:bpd_aceh/features/transfer/transferBankLain/receiptBL/transfer_receipt.dart';
import 'package:flutter/material.dart';

class TransferMpinPageBankLain extends StatelessWidget {
  static const routeName = '/transfer/mpinBL';

  const TransferMpinPageBankLain({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return ISTMPIN(
      onFinishedVal: (value) async {
        Map<String, Object> param = {};
        final String pinEnc = await ISTCrypto.encryptAES(value);
        param['mpin'] = pinEnc;

        final resp =
            await API.post(context, '/transfer/other/online/request', param);
        if (resp['code'] != null && resp['code'] == 0) {
          List<ISTReceiptItem> listParam = [];
          List<ISTReceiptItemInbox> listParams = [];
          List<dynamic> listMap = resp['resi'];
          for (var item in listMap) {
            ISTReceiptItem itemParam =
                ISTReceiptItem(key: item['key'], value: item['value']);
            listParam.add(itemParam);
          }
          for (var item in listMap) {
            ISTReceiptItemInbox itemParams =
                ISTReceiptItemInbox(key: item['key'], value: item['value']);
            listParams.add(itemParams);
          }
          print(listMap);

          // ISTReceiptStatus status = ISTReceiptStatus.suspect;

          // if (resp['status'] != null && resp['status'] == 'success') {
          //   status = ISTReceiptStatus.success;
          // }
          ISTReceiptStatus? status;

          if (resp['message'] != null && resp['message'] == 'success') {
            status = ISTReceiptStatus.success;
          }
          if (resp['message'] != null && resp['message'] == 'suspect') {
            status = ISTReceiptStatus.suspect;
          }
          if (resp['message'] != null && resp['message'] == 'failed') {
            status = ISTReceiptStatus.failed;
          }

          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => TransferReceiptBLPage(
                        noRef: resp['idresi'],
                        date: resp['waktu'],
                        detail: resp['dstAccountOwnerName'],
                        nameBank: resp['destBankName'],
                        time: resp['dstAccountNo'],
                        img: "assets/images/icon-tranfer-active.png",
                        // title: "Transfer Antar Bank Lain",
                        subtitle: "Transfer",
                        list: listParam,
                        lists: listParams,
                        amount: resp['amountStr'],
                        status: status,
                        titleresi: resp['titel'],
                      )));
        } else if (resp['code'] != null && resp['code'] != 0) {
          if (resp['code'] == -1002) {
            //Salah MPIN
            const DialogBox().showImageDialog(
                message: resp['message'],
                isError: true,
                buttonCancel: 'OK',
                onCancel: () {
                  Navigator.pop(context);
                },
                onOk: () {},
                context: context);
          } else if (resp['code'] == -4901) {
            //Saldo Tidak Cukup
            const DialogBox().showImageDialog(
                message: resp['message'],
                isError: true,
                buttonCancel: 'OK',
                onCancel: () {
                  Navigator.pushNamedAndRemoveUntil(context, HomePage.routeName,
                      ModalRoute.withName(Splash.routeName));
                },
                onOk: () {},
                context: context);
          } else if (resp['code'] == -1108) {
            //MPIN Ke Blokir
            const DialogBox().showImageDialog(
                message: resp['message'],
                isError: true,
                buttonCancel: 'OK',
                onCancel: () {
                  Navigator.pushNamedAndRemoveUntil(context, HomePage.routeName,
                      ModalRoute.withName(Splash.routeName));
                },
                onOk: () {},
                context: context);
          } else if (resp['code'] == -9999) {
            const DialogBox().showImageDialog(
                message: resp['message'],
                isError: true,
                buttonCancel: 'OK',
                onCancel: () {
                  Navigator.pushNamedAndRemoveUntil(context, HomePage.routeName,
                      ModalRoute.withName(Splash.routeName));
                },
                onOk: () {},
                context: context);
          } else {
            const DialogBox().showImageDialog(
                message: resp['message'],
                isError: true,
                buttonCancel: 'OK',
                onCancel: () {
                  Navigator.pop(context);
                },
                onOk: () {},
                context: context);
          }
          // DialogBox().showImageDialog(
          //     message: resp['message'],
          //     isError: true,
          //     buttonCancel: 'OK',
          //   //   onCancel: (){
          //   //     Navigator.pushNamedAndRemoveUntil(
          //   // context, TransferBankLain.routeName, ModalRoute.withName(HomePage.routeName));
          //   //   },

          //     onOk: (){},
          //     onCancel: () {
          //       Navigator.pop(context);
          //       // Navigator.pop(context);
          //       // Navigator.pop(context);
          //     },

          //     context: context);
        }
      },
    );
  }
}

// return Scaffold(
//   backgroundColor: Colors.white,
//   appBar: AppBar(
//     title: Text(
//       'Transfer',
//       style: TextStyle(color: Colors.black),
//     ),
//     centerTitle: true,
//     elevation: 0.0,
//     iconTheme: IconThemeData(color: Colors.black),
//     backgroundColor: Colors.transparent,
//   ),
//   body: ISTMPIN(
//     onFinishedVal: (value) {
//       Navigator.pushNamed(context, TransferReceiptBLPage.routeName);
//     },
//   ),
// );

// class PinForm extends StatefulWidget {
//   @override
//   State<PinForm> createState() => _PinFormState();
// }

// class _PinFormState extends State<PinForm> {
//   final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
//   bool _autoValidate = false;

//   final _pinController = TextEditingController();

//   bool showPass = true;
//   bool isLoading = false;

//   @override
//   Widget build(BuildContext context) {
//     final loginText = Text(
//       'OK',
//       style: TextStyle(
//           fontWeight: FontWeight.w100, color: Colors.white, fontSize: 20),
//     );

// bool _validateInputs() {
//   if (_formKey.currentState.validate()) {
//     _formKey.currentState.save();
//     return true;
//   } else {
//     setState(() {
//       _autoValidate = true;
//     });
//     return false;
//   }
// }

// _doValidateMPIN() async {
//   if (_validateInputs()) {
//     Map param = new Map();
//     param['mpin'] = _pinController.text;
//     final reqBody = json.encode(param);
//     final resp = await API.post(context, '/transfer', reqBody);
//     if (resp['code'] == 0) {
//       Navigator.pushNamedAndRemoveUntil(
//           context,
//           TransferReceiptPage.routeName,
//           ModalRoute.withName(Splash.routeName));
//       Navigator.push(
//           context,
//           new MaterialPageRoute(
//               builder: (context) => new TransferReceiptPage(
//                 date: resp['tranDate'],
//                 destAcctNum: resp['destAccountNumber'],
//                 from: "${resp['sourceAccountNumber']} - ${resp['sourceAccountName']}" ,
//                 idReceipt: resp['tranId'],
//                 nominal: resp['amountStr'] ,
//                 note: resp['memo'],
//                 to:"${resp['destAccountName']}" ,
//               )));
//     } else {
//       DialogBox().showImageDialog(
//           message: resp['message'],
//           isError: true,
//           image: Image(
//             image: AssetImage('assets/images/icon-failed.png'),
//           ),
//           buttonCancel: 'OK',
//           onOk: () {},
//           context: context);
//     }
//   }
// }

//     return SafeArea(
//       child: Form(
//         autovalidateMode: AutovalidateMode.always,
//         key: _formKey,
//         child: Center(
//           child: Stack(children: <Widget>[
//             Padding(
//               padding: const EdgeInsets.all(20.0),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.center,
//                 children: <Widget>[
//                   Text('Silakan Masukkan MPIN Anda'),
//                   SizedBox(height: 20),
//                   TextField(
//                     maxLength: 6,
//                     expands: false,
//                     obscureText: true,
//                     textAlign: TextAlign.center,
//                     keyboardType: TextInputType.number,
//                     style: TextStyle(fontSize: 20),
//                     decoration: InputDecoration(
//                       hintText: 'PIN',
//                     ),
//                     controller: _pinController,
//                   ),
//                   Spacer(),
//                   Padding(
//                     padding: const EdgeInsets.only(top: 30.0),
//                     child: Column(children: <Widget>[
//                       Row(children: <Widget>[
//                         Expanded(
//                           flex: 1,
//                           child: RaisedButton(
//                               padding: EdgeInsets.all(10),
//                               shape: RoundedRectangleBorder(
//                                   borderRadius:
//                                       BorderRadius.all(Radius.circular(50))),
//                               splashColor: Pallete.primary,
//                               color: Pallete.primary,
//                               focusColor: Pallete.primary,
//                               hoverColor: Pallete.primary,
//                               onPressed: () {
//                                 // _doValidateMPIN();
//                                 Navigator.pushNamed(
//                                     context, TransferReceiptBLPage.routeName);
//                               },
//                               child: loginText),
//                         ),
//                       ]),
//                     ]),
//                   ),
//                 ],
//               ),
//             ),
//             // login.getStatus() == LoginProv.LOGIN_IN ?
//           ]),
//         ),
//       ),
//     );
//   }
// }
