// ignore_for_file: unnecessary_string_escapes

import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_card_account.dart';
import 'package:bpd_aceh/components/ist_card_account_item.dart';
import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/ist_style.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/core/utils/string_utils.dart';
import 'package:bpd_aceh/features/transfer/transferBankLain/confirmBL/transfer_confirm_bl.dart';
import 'package:bpd_aceh/features/transfer/transferBankLain/daftarBankLain/daftar_bl.dart';
import 'package:currency_text_input_formatter/currency_text_input_formatter.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class TransferBankLain extends StatefulWidget {
  static const routeName = '/transferBankLain';

  // ignore: non_constant_identifier_names
  final String? bnf_acct_no;
  // ignore: non_constant_identifier_names
  final String? bnf_acct_name;
  final String? namebank;
  final String? kodebank;
  final String? destcode;

  const TransferBankLain(
      {Key? key,
      // ignore: non_constant_identifier_names
      this.bnf_acct_no,
      this.namebank,
      this.kodebank,
      // ignore: non_constant_identifier_names
      this.bnf_acct_name,
      this.destcode})
      : super(key: key);

  @override
  _TransferBankLainState createState() =>
      // ignore: no_logic_in_create_state
      _TransferBankLainState(bnf_acct_no, bnf_acct_name);
}

class _TransferBankLainState extends State<TransferBankLain> {
  // ignore: non_constant_identifier_names
  String? display_acct_number = "";
  // ignore: non_constant_identifier_names
  String? display_acct_name = "";

  @override
  void initState() {
    if (widget.bnf_acct_no != null && widget.kodebank != null) {
      _noRekBLcontroller.text = bnf_acct_no!;
      _kodeBankController.text = kodebank;
      // bank=destcode;
      fromFav = true;
    }
    _setDisplaySourceAccct();
    super.initState();
  }

  _setDisplaySourceAccct() async {
    final acctName = await ISTConstants().getString(ISTConstants.acctName);
    final acctNumber = await ISTConstants().getString(ISTConstants.acctNumber);
    setState(() {
      display_acct_number = acctNumber;
      display_acct_name = acctName;
    });
  }

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final _noRekBLcontroller = TextEditingController();
  final _catatanBLcontroller = TextEditingController();
  final _noRefBLcontroller = TextEditingController();
  final _kodeBankController = TextEditingController();
  // final _nominalBLcontroller = ISTConstants().moneyMaskedController;
  final _nominalBLcontroller = TextEditingController();

  // ignore: non_constant_identifier_names
  final String? bnf_acct_no;
  // ignore: non_constant_identifier_names
  final String? bnf_acct_name;

  _TransferBankLainState(this.bnf_acct_no, this.bnf_acct_name);
  bool fromFav = false;

  // ignore: unused_field
  bool _autoValidate = false;
  bool _errorValidateKodeBank = false;
  bool _errorValidateNoRek = false;
  bool _errorValidateNominal = false;

  bool _validateInputs() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      return true;
    } else {
      setState(() {
        _autoValidate = true;
      });
      return false;
    }
  }

  bool _doValidate() {
    if (_validateInputs() != true) return false;
    bool _success = true;
    if (_kodeBankController.text.isEmpty) {
      setState(() {
        _errorValidateKodeBank = true;
      });
      _success = false;
    } else if (_noRekBLcontroller.text.isEmpty) {
      setState(() {
        _errorValidateNoRek = true;
      });
      _success = false;
    } else if (_nominalBLcontroller.text.isEmpty) {
      setState(() {
        _errorValidateNominal = true;
      });
      _success = false;
    } else {
      setState(() {
        _errorValidateKodeBank = false;
        _errorValidateNoRek = false;
        _errorValidateNominal = false;
      });
    }
    return _success;
  }

  String bank = "";
  String norek = "";
  String bankName = "";
  String nameBank = "";
  String kodebank = "";
  String destcode = "";

  ISTCardAccountItem? accountItem;

  _doTransfer() async {
    if (_doValidate()) {
      Map<String, Object?> param = {};
      param['destAcctNo'] = _noRekBLcontroller.text.replaceAll("-", "");
      param['destBankCode'] = fromFav ? widget.kodebank : bank;
      param['amount'] =
          int.parse(_nominalBLcontroller.text.replaceAll(".", ""));
      param['memo'] = _catatanBLcontroller.text;
      param['noRefPel'] = _noRefBLcontroller.text;

      final resp =
          await API.post(context, '/transfer/other/online/inquiry', param);
      print(resp);
      if (resp == null) return;
      if (resp['code'] == 0 && resp['code'] != null) {
        List<ISTConfirmationItem> listParam = [];
        List<dynamic> listMap = resp['resi'];
        for (var item in listMap) {
          ISTConfirmationItem itemParam =
              ISTConfirmationItem(key: item['key'], value: item['value']);
          listParam.add(itemParam);
        }
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => TransferConfirmPageBL(
                      list: listParam,
                    )));
      } else {
        const DialogBox().showImageDialog(
            message: resp['message'],
            isError: true,
            image: const Image(
              image: AssetImage('assets/images/icon-failed.png'),
            ),
            buttonCancel: 'OK',
            onOk: () {},
            context: context);
      }
    }
  }

  _doGoToListBank() async {
    var result = await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (BuildContext context) => const DaftarBL(),
        ));
    final res = result.toString().replaceAll("\{", "").replaceAll("\}", "");
    if (res != "null") {
      setState(() {
        List<String> resList = res.split("-");
        bank = resList[0];
        bankName = resList[1];
        _kodeBankController.text = res;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text(
          'Transfer Antar Bank Lain',
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'Poppins',
          ),
        ),
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      body: Container(
          color: Colors.white,
          child: Column(
            children: <Widget>[
              ISTCardAccount(
                // account: (value) {
                //   setState(() {
                //     accountItem = value;
                //   });
                // },
                context: context,
                menu: ISTMenu.transfer,
              ),
              // SizedBox(
              //   height: 4,
              // ),
              Expanded(
                child: Container(
                  padding: const EdgeInsets.only(
                    left: 16,
                    right: 16,
                  ),
                  child: SingleChildScrollView(
                    child: Column(
                        // crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Container(
                              padding: const EdgeInsets.only(top: 8),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: <Widget>[
                                  SizedBox(
                                    width:
                                        (((MediaQuery.of(context).size.width /
                                                    12) -
                                                5) *
                                            5),
                                    // padding: EdgeInsets.only(),
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        Image.asset(
                                          'assets/images/newBASTF.png',
                                          width: 70,
                                        ),
                                        Text('$display_acct_number'),
                                        Text('$display_acct_name'),
                                      ],
                                    ),
                                  ),
                                  Container(
                                      padding: const EdgeInsets.only(top: 16),
                                      width:
                                          (((MediaQuery.of(context).size.width /
                                                      12) -
                                                  5) *
                                              2),
                                      child: Image.asset(
                                        'assets/images/newpanah.png',
                                        width: 35,
                                        height: 35,
                                      )),
                                  SizedBox(
                                    width:
                                        (((MediaQuery.of(context).size.width /
                                                    12) -
                                                5) *
                                            5),
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: <Widget>[
                                        Image.asset(
                                          // 'assets/images/icon-relink.png',
                                          'assets/images/newTransferBL.png',
                                          width: 70,
                                        ),
                                        fromFav
                                            ? Container(
                                                alignment: Alignment.center,
                                                child: Text(
                                                  widget.namebank!,
                                                  textAlign: TextAlign.center,
                                                ),
                                              )
                                            : Text(
                                                bankName,
                                                textAlign: TextAlign.center,
                                              ),
                                        fromFav
                                            ? Container(
                                                alignment: Alignment.center,
                                                child:
                                                    // Text(norek),
                                                    Text(
                                                  widget.bnf_acct_no!,
                                                  textAlign: TextAlign.center,
                                                ),
                                              )
                                            : Text(
                                                norek,
                                                textAlign: TextAlign.center,
                                              ),
                                        // Text(''),
                                      ],
                                    ),
                                  ),
                                ],
                              )),
                          const SizedBox(
                            height: 16,
                          ),
                          Form(
                              key: _formKey,
                              // ignore: deprecated_member_use
                              autovalidateMode: AutovalidateMode.always,
                              child: Column(
                                  // mainAxisAlignment: MainAxisAlignment.spaceAround,
                                  children: <Widget>[
                                    Container(
                                      // padding: EdgeInsets.only(top: 16),
                                      alignment: Alignment.topLeft,
                                      // padding: EdgeInsets.only(top: 16),
                                      child: const Text(
                                        'Bank Penerima :',
                                      ),
                                    ),
                                    fromFav
                                        ? Container(
                                            alignment: Alignment.topLeft,
                                            child:
                                                // Text(
                                                //     widget.destcode),
                                                Text(widget.kodebank! +
                                                    widget.namebank!),
                                          )
                                        : Container(
                                            alignment: Alignment.topLeft,
                                            child: TextFormField(
                                              validator: (val) {
                                                if (val!.isEmpty ||
                                                    val == '0') {
                                                  _errorValidateKodeBank = true;
                                                } else {
                                                  _errorValidateKodeBank =
                                                      false;
                                                }
                                              },
                                              controller: _kodeBankController,
                                              onTap: () {
                                                _doGoToListBank();
                                              },
                                              readOnly: true,
                                              showCursor: false,
                                              decoration: InputDecoration(
                                                errorText:
                                                    _errorValidateKodeBank
                                                        ? "Mohon di isi"
                                                        : null,
                                                hintText: 'Pilih bank tujuan',
                                                hintStyle: ISTStyle.hintStyle,
                                                suffixIcon: const Icon(
                                                    Icons.arrow_forward_ios),
                                              ),
                                            ),
                                          ),
                                    const SizedBox(
                                      height: 8,
                                    ),
                                    Container(
                                      alignment: Alignment.topLeft,
                                      child: const Text(
                                        'Ke Rekening :',
                                        style: TextStyle(color: Colors.black87),
                                      ),
                                    ),
                                    fromFav
                                        ? Container(
                                            alignment: Alignment.topLeft,
                                            child: Text(widget.bnf_acct_no! +
                                                "-" +
                                                widget.bnf_acct_name!),
                                          )
                                        : Container(
                                            alignment: Alignment.topLeft,
                                            child: TextFormField(
                                              onChanged: (value) {
                                                setState(() {
                                                  norek =
                                                      _noRekBLcontroller.text;
                                                });
                                              },
                                              validator: (val) {
                                                if (val!.isEmpty ||
                                                    val == '0') {
                                                  _errorValidateNoRek = true;
                                                } else {
                                                  _errorValidateNoRek = false;
                                                }
                                              },
                                              keyboardType:
                                                  TextInputType.number,
                                              inputFormatters: [
                                                // ignore: deprecated_member_use
                                                FilteringTextInputFormatter
                                                    .digitsOnly,
                                              ],
                                              controller: _noRekBLcontroller,
                                              maxLength:
                                                  ISTConstants.acctToMaxLength,
                                              // maxLength: 15,
                                              decoration: InputDecoration(
                                                counterText: '',
                                                errorText: _errorValidateNoRek
                                                    ? "Mohon di isi"
                                                    : null,
                                                // errorText:_noRekBLError ? "Mohon diisi" : null,
                                                hintText:
                                                    'Masukkan no rekening tujuan',
                                                hintStyle: ISTStyle.hintStyle,
                                              ),
                                            ),
                                          ),
                                    const SizedBox(
                                      height: 8,
                                    ),
                                    Container(
                                      alignment: Alignment.topLeft,
                                      child: const Text(
                                        'Nominal :',
                                        style: TextStyle(color: Colors.black87),
                                      ),
                                    ),
                                    Container(
                                      alignment: Alignment.topLeft,
                                      child: TextFormField(
                                        validator: (val) {
                                          if (val!.isEmpty || val == '0') {
                                            _errorValidateNominal = true;
                                          } else {
                                            _errorValidateNominal = false;
                                          }
                                        },
                                        inputFormatters: [
                                          CurrencyTextInputFormatter(
                                            decimalDigits: 0,
                                            locale: 'id_ID',
                                            name: '',
                                          )
                                        ],
                                        controller: _nominalBLcontroller,
                                        maxLength:
                                            ISTConstants.nominalMaxLength,
                                        onChanged: (value) {
                                          if (_nominalBLcontroller.text
                                              .trim()
                                              .isEmpty) {
                                            _nominalBLcontroller.text = '';
                                          }
                                        },
                                        keyboardType: TextInputType.number,
                                        decoration: InputDecoration(
                                          counterText: '',
                                          errorText: _errorValidateNominal
                                              ? "Mohon di isi"
                                              : null,
                                          // errorText:_nominalBLError ? "Mohon diisi" : null,
                                          // prefixText: 'IDR ',
                                          // prefixStyle: TextStyle(),
                                          prefixIcon: Text(
                                            "IDR ",
                                            style: TextStyle(
                                                fontSize: Theme.of(context)
                                                    .textTheme
                                                    .subtitle1!
                                                    .fontSize),
                                          ),
                                          prefixIconConstraints:
                                              const BoxConstraints(
                                                  minWidth: 0, minHeight: 0),
                                          hintText: 'Masukkan nominal',
                                          hintStyle: ISTStyle.hintStyle,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 8,
                                    ),
                                    Container(
                                      alignment: Alignment.topLeft,
                                      child: const Text(
                                        'No. Referensi :',
                                        style: TextStyle(color: Colors.black87),
                                      ),
                                    ),
                                    Container(
                                      alignment: Alignment.topLeft,
                                      child: TextField(
                                        controller: _noRefBLcontroller,
                                        keyboardType: TextInputType.number,
                                        inputFormatters: [
                                          // ignore: deprecated_member_use
                                          FilteringTextInputFormatter
                                              .digitsOnly,
                                        ],
                                        maxLength:
                                            ISTConstants.refPelangganMaxLength,
                                        decoration: const InputDecoration(
                                          counterText: '',
                                          hintText: 'Masukkan no referensi',
                                          hintStyle: ISTStyle.hintStyle,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 8,
                                    ),
                                    Container(
                                      alignment: Alignment.topLeft,
                                      child: const Text(
                                        'Catatan :',
                                        style: TextStyle(color: Colors.black87),
                                      ),
                                    ),
                                    Container(
                                      alignment: Alignment.topLeft,
                                      child: TextField(
                                        controller: _catatanBLcontroller,
                                        inputFormatters: [
                                          StringUtils.alphaNumeric(),
                                        ],
                                        maxLength:
                                            ISTConstants.catatanTrfMaxLength,
                                        decoration: const InputDecoration(
                                          hintText: 'Masukkan catatan',
                                          hintStyle: ISTStyle.hintStyle,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 16,
                                    ),
                                  ])),
                          ISTOutlineButton(
                            onPressed: () {
                              _doTransfer();
                            },
                            text: 'Lanjut',
                          ),
                          const SizedBox(
                            height: 16,
                          )
                        ]),
                  ),
                ),
              ),
            ],
          )),
    );
  }
}
