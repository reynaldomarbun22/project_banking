class InquiryTransferBankLainEntity{
  final String? srcAcctNo;
  final String? bnfAcctNo;
  final String? bnfBankCode;
  final String? amount;
  final String? memo;

  InquiryTransferBankLainEntity(this.srcAcctNo, this.bnfAcctNo, this.bnfBankCode, this.amount, this.memo);
}

class InquiryTransferBankLainResponseEntity{
  final Map? detail;
  final int? code;
  final String? inqReff;

  InquiryTransferBankLainResponseEntity(this.detail, this.code, this.inqReff);

  
}

class PostTransferBankLainEntity{
  final String? inqReff;
  final String? mpin;

  PostTransferBankLainEntity(this.inqReff, this.mpin);

}

// class ListBankEntity{
//   final String bank;
//   final String code;
//   final String name;
//   final String
// }