class PilihBankRequestBase {
  final String? offset;
  // ignore: non_constant_identifier_names
  final int? max_rows;

  PilihBankRequestBase(this.offset, this.max_rows);
  

  
  
}