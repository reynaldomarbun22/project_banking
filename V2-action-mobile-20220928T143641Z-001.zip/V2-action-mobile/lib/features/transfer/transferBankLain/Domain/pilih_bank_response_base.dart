class BankresponseBase {
  // ignore: non_constant_identifier_names
  final String? item_type;
  // ignore: non_constant_identifier_names
  final List? item_data;

  BankresponseBase(this.item_type, this.item_data);
}

class PilihBankresponseBase {
  final String? code;
  final String? name;
  final List? indexing;

  PilihBankresponseBase(this.code, this.name, this.indexing);
}
