import 'package:bpd_aceh/components/ist_confirmation.dart';
// import 'package:bpd_aceh/components/ISTReceipt.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/transfer/transferBankLain/mpinBL/transfer_mpin_bank_lain.dart';
// import 'package:bpd_aceh/features/transfer/mpin/transfer_mpin.dart';
import 'package:flutter/material.dart';

class TransferConfirmPageBL extends StatefulWidget {
  static const routeName = '/transfer/confirmBL';
  final List<ISTConfirmationItem>? list;

  const TransferConfirmPageBL({Key? key, this.list}) : super(key: key);
  // final String srcAcct;
  // final String destAcct;
  // final String nominal;
  // final String note;

  // const TransferConfirmPageBL(
  //     {Key key, this.srcAcct, this.destAcct, this.nominal, this.note, List<ISTConfirmationItem> list})
  //     : super(key: key);

  @override
  State<TransferConfirmPageBL> createState() => _KonfirmasiFormState();
}

class _KonfirmasiFormState extends State<TransferConfirmPageBL> {
  // bool showPass = true;
  // bool isLoading = false;

  @override
  Widget build(BuildContext context) {
    // final loginText = Text(
    //   'Transfer',
    //   style: TextStyle(
    //       fontWeight: FontWeight.w100, color: Colors.white, fontSize: 20),
    // );

    _doTransfer() {
      Navigator.pushNamed(context, TransferMpinPageBankLain.routeName);
    }

    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Pallete.primary,
          leading: IconButton(
              icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
              onPressed: () {
                Navigator.pop(context);
              }),
          title: const Text(
            'Transfer Antar Bank Lain',
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'Poppins',
            ),
          ),
          centerTitle: true,
          elevation: 0.0,
        ),
        body: ISTConfirmation(
            items: widget.list,
            title: 'Konfirmasi Transfer',
            onFinished: () {
              _doTransfer();
            }));
  }
}
