import 'dart:convert';
import 'package:bpd_aceh/features/transfer/transferBankLain/Domain/pilih_bank_response_base.dart';

class BankResponse extends BankresponseBase {
  BankResponse({
    // ignore: non_constant_identifier_names
    String? item_type,
    // ignore: non_constant_identifier_names
    List? item_data,
  }) : super(item_type, item_data);
  factory BankResponse.fromJson(Map<String, dynamic> json) {
    return BankResponse(
      item_type: json['item_type'],
      item_data: json['item_data'],
    );
  }
  String toJson() =>
      json.encode({'item_type': item_type, 'item_data': item_data});

  // num get lenght => null;
}

class PilihBankResponse extends PilihBankresponseBase {
  PilihBankResponse({String? code, String? name, List? indexing})
      : super(code, name, indexing);
  factory PilihBankResponse.fromJson(Map<String, dynamic> json) {
    return PilihBankResponse(
        code: json['code'], name: json['name'], indexing: json['indexing']);
  }
  String toJson() => json.encode(
      {'code': code, 'name': name, 'indexing': indexing});

  // num get lenght => null;
}
