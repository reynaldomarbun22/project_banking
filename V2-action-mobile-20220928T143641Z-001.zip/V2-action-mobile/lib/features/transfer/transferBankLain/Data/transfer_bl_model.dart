import 'dart:convert';

import 'package:bpd_aceh/features/transfer/transferBankLain/Domain/transfer_bl_entity.dart';
// import 'package:bima/screens/afterLogin/Transfer/BankLain/domain/entities/transferBL.Entity.dart';
//import 'package:bima/screens/afterLogin/Transfer/TransferAntarBankJateng/domain/entities/transferInHouseEntity.dart';

class InquiryTransferBankLain extends InquiryTransferBankLainEntity {
  InquiryTransferBankLain(
      {String? srcAcctNo,
      String? bnfAcctNo,
      String? bnfBankCode,
      String? amount,
      String? memo})
      : super(srcAcctNo, bnfAcctNo, bnfBankCode, amount, memo);

  factory InquiryTransferBankLain.fromJson(Map<String, dynamic> json) {
    return InquiryTransferBankLain(
      srcAcctNo: json['src_acct_no'],
      bnfAcctNo: json['bnf_acct_no'],
      bnfBankCode: json['bnf_bank_code'],
      amount: json['amount'],
      memo: json['memo'],
    );
  }

  String toJson() => json.encode({
        'src_acct_no': srcAcctNo,
        'bnf_acct_no': bnfAcctNo,
        'bnf_bank_code': bnfBankCode,
        'amount': amount,
        'memo': memo,
      });
}

class InquiryTransferBankLainResponse
    extends InquiryTransferBankLainResponseEntity {
  InquiryTransferBankLainResponse({Map? detail, int? code, String? inqReff})
      : super(detail, code, inqReff);

  factory InquiryTransferBankLainResponse.fromJson(Map<String, dynamic> json) {
    return InquiryTransferBankLainResponse(
        detail: json['detail'], code: json['code'], inqReff: json['inq_reff']);
  }

  String toJson() => json.encode(
      {'detail': detail, 'code': code, 'inq_reff': inqReff});
}

class PostTransferBankLain extends PostTransferBankLainEntity {
  PostTransferBankLain({String? inqReff, String? mpin}) : super(inqReff, mpin);

  String toJson() => json.encode({'inq_reff': inqReff, 'mpin': mpin});
}
