import 'dart:convert';

import 'package:bpd_aceh/features/transfer/transferBankLain/Domain/pilih_bank_req_base.dart';

class PilihBankRequest extends PilihBankRequestBase {
  PilihBankRequest({
    String? offset,
    // ignore: non_constant_identifier_names
    int? max_rows,
  }) : super(offset, max_rows);
  factory PilihBankRequest.fromJson(Map<String, dynamic> json) {
    return PilihBankRequest(
      offset: json['offset'],
      max_rows: json['max_rows'],
    );
  }
  String toJson() => json.encode({
        'offset': offset,
        'max_rows': max_rows,
      });

  // num get lenght => null;
}
