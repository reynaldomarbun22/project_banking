import 'package:flutter/material.dart';

class StatusPendudukItem {
  final String? status;
  final String? statusTitle;
  final int? statusIndex;


  StatusPendudukItem(
      {Key? key,
     this.status,
     this.statusTitle,
     this.statusIndex,
     });
}