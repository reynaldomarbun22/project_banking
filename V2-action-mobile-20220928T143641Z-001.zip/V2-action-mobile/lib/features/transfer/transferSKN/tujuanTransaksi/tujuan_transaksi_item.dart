import 'package:flutter/material.dart';

class TujuanTransaksiItem {
  final String? tujuanTransaksi;
  final String? tujuanKey;
  final int? tujuanTransaksiIndex;


  TujuanTransaksiItem(
      {Key? key,
     this.tujuanTransaksi,
     this.tujuanKey,
     this.tujuanTransaksiIndex,
     });
}