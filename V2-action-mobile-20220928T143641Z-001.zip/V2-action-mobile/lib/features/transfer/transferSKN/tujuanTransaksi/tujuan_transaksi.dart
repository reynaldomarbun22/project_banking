import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:flutter/material.dart';

class TujuanTransaksi extends StatefulWidget {
  static const routeName = '/TujuanTransaksi';

  const TujuanTransaksi({Key? key}) : super(key: key);
  @override
  _TujuanTransaksiState createState() => _TujuanTransaksiState();
}

class TujuanItem {
  final String? title;
  final String? value;

  TujuanItem({this.title, this.value});
}

class _TujuanTransaksiState extends State<TujuanTransaksi> {
  List<TujuanItem> _listFiltered = [];
  List<TujuanItem> _listTujuan = [];
  TujuanItem? bank;

  @override
  void didChangeDependencies() {
    _doInquiryBank();
    super.didChangeDependencies();
  }

  @override
  void initState() {
    _doInquiryBank();
    super.initState();
  }

  _doInquiryBank() async {
    const _url = '/transaction-purposeList/list';
    var resp = await API.postNoLoading(context, _url, {});

    if (resp['code'] == 0) {
      final List<dynamic> tujuanList = resp['listTransactionPurpose'];
      List<TujuanItem> _listbuilds = [];
      for (var item in tujuanList) {
        _listbuilds.add(TujuanItem(title: item['title'], value: item['value']));
      }
      setState(() {
        _listTujuan = _listbuilds;
        _listFiltered = _listTujuan;
      });
    } else {
      const DialogBox().showErrorDialog(
        context: context,
        message: resp['message'],
      );
    }

    // catch (_) {}
  }

  onTapped(TujuanItem item) {
    Navigator.pop(context, {"${item.value}"});
  }

  // List<TujuanItem> _listbuilds = [];
  // List<TujuanItem> _buildList = [];

  // get resp =>bank;

  // _doInquiryBank(){
  //   setState(() {
  //         _listbank = _listbuilds;
  //         _listFiltered = _listbank;
  //   });

  // }

  final TextEditingController _search = TextEditingController();
  String _searchText = "";
  Icon _searchIcon = const Icon(Icons.search);
  Widget _appBarTitle = const Text(
    'Pilih Tujuan Transaksi',
    style: TextStyle(
      color: Colors.white,
      fontFamily: 'Poppins',
      // fontSize: FontSize.TITLE,
    ),
  );

  // ignore: unused_element
  void _searchPressed() {
    setState(() {
      if (_searchIcon.icon == Icons.search) {
        _searchIcon = const Icon(
          Icons.close,
          color: Colors.white,
        );
        _appBarTitle = TextField(
          style: const TextStyle(color: Colors.white),
          autofocus: true,
          controller: _search,
          onChanged: (text) {
            setState(() {
              _searchText = text;
            });
          },
          decoration: const InputDecoration(
              border: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.white)),
              // prefixIcon: Icon(Icons.search),
              hintText: 'Cari Tujuan Transaksi...',
              hintStyle: TextStyle(
                color: Colors.white,
                fontFamily: 'Poppins',
              )),
        );
      } else {
        // this._searchIcon = Icon(Icons.search);
        _appBarTitle = const Text('Pilih Tujuan Transaksi',
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'Poppins',
            ));
        _searchText = "";
        _search.clear();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          backgroundColor: Pallete.primary,
          leading: IconButton(
            icon: const Icon(
              Icons.arrow_back_ios,
              color: Colors.white,
            ),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          // actions: <Widget>[
          //   IconButton(
          //     color: Colors.white,
          //     icon: _searchIcon,
          //     onPressed: _searchPressed,
          //   ),
          // ],
          centerTitle: true,
          title: _appBarTitle),
      backgroundColor: Colors.white,
      body: Column(
        children: <Widget>[
          Expanded(
            child: Container(child: _buildList()),
          ),
          const SizedBox(
            height: 16,
          ),
        ],
      ),
    );
  }

  _buildList() {
    if (_searchText.isNotEmpty) {
      List<TujuanItem> tempList = List.empty();
      for (TujuanItem item in _listTujuan) {
        if (item.value != null) {
          if (item.value!.toLowerCase().contains(_searchText.toLowerCase())) {
            tempList.add(item);
          }
        }
      }
      _listFiltered = tempList;
    } else {
      _listFiltered = _listTujuan;
    }
    return ListView.separated(
        separatorBuilder: (context, inx) {
          return const Divider();
        },
        padding: const EdgeInsets.only(left: 16, right: 16),
        // ignore: unnecessary_null_comparison
        itemCount: _listTujuan == null ? 0 : _listFiltered.length,
        shrinkWrap: true,
        itemBuilder: (context, index) {
          final item = _listFiltered[index];
          return ListTile(
            title: Text(item.title!),
            onTap: () => onTapped(item),
          );
        });
  }
}
