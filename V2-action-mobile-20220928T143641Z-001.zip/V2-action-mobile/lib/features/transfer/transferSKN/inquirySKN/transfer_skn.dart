// ignore_for_file: unnecessary_string_escapes

import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_card_account.dart';
import 'package:bpd_aceh/components/ist_card_account_item.dart';
import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/ist_style.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/core/utils/string_utils.dart';
import 'package:bpd_aceh/features/home/home_page.dart';
// import 'package:bpd_aceh/features/transfer/TransferSKN/confirmSKN/transferConfirmSKN.dart';
import 'package:bpd_aceh/features/transfer/TransferSKN/daftarBankLain/daftar_bl.dart';
import 'package:bpd_aceh/features/transfer/transferRTGS/kewarganegaraan/kewarganegaraan_page.dart';
import 'package:bpd_aceh/features/transfer/transferSKN/confirmSKN/transfer_confirm_skn.dart';
import 'package:bpd_aceh/features/transfer/transferSKN/jenisPenerima/jenis_penerima.dart';
import 'package:bpd_aceh/features/transfer/transferSKN/jenisPenerima/jenispenerimaite.dart';
import 'package:bpd_aceh/features/transfer/transferSKN/statusPenduduk/status_penduduk.dart';
import 'package:bpd_aceh/features/transfer/transferSKN/statusPenduduk/statuspendudukitem.dart';
import 'package:bpd_aceh/features/transfer/transferSKN/tujuanTransaksi/tujuan_transaksi.dart';
import 'package:bpd_aceh/features/transfer/transferSKN/tujuanTransaksi/tujuan_transaksi_item.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class TransferSKN extends StatefulWidget {
  static const routeName = '/TransferSKN';

  // ignore: non_constant_identifier_names
  final String? bnf_acct_no;
  // ignore: non_constant_identifier_names
  final String? bnf_acct_name;
  final String? namebank;
  final String? kodebank;
  final String? destcode;

  const TransferSKN(
      {Key? key,
      // ignore: non_constant_identifier_names
      this.bnf_acct_no,
      this.namebank,
      this.kodebank,
      // ignore: non_constant_identifier_names
      this.bnf_acct_name,
      this.destcode})
      : super(key: key);

  @override
  _TransferSKNState createState() =>
      // ignore: no_logic_in_create_state
      _TransferSKNState(bnf_acct_no, bnf_acct_name);
}

class _TransferSKNState extends State<TransferSKN> {
  // ignore: non_constant_identifier_names
  String? display_acct_number = "";
  // ignore: non_constant_identifier_names
  String? display_acct_name = "";
  String? redaksiname = "";

  @override
  void initState() {
    if (widget.bnf_acct_no != null && widget.kodebank != null) {
      _noRekBLcontroller.text = bnf_acct_no!;
      _kodeBankController.text = kodebank;
      // bank=destcode;
      fromFav = true;
    }

    _setDisplaySourceAccct();
    super.initState();
    _getRedaksi();
    _getJenisPenerima();
    // _getTujuanTransaksi();
    _getStatusPenduduk();
    _getKewarganegaraan();
    _getDialog();
  }

  _setDisplaySourceAccct() async {
    final acctName = await ISTConstants().getString(ISTConstants.acctName);
    final acctNumber = await ISTConstants().getString(ISTConstants.acctNumber);
    setState(() {
      display_acct_number = acctNumber;
      display_acct_name = acctName;
    });
  }

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final _noRekBLcontroller = TextEditingController();
  final _catatanBLcontroller = TextEditingController();
  final _alamatcontroller = TextEditingController();
  final _namaPenerimacontroller = TextEditingController();
  // ignore: unused_field
  final _noRefBLcontroller = TextEditingController();
  final _kodeBankController = TextEditingController();
  final _tujuanTransaksiController = TextEditingController();
  final _statusPendudukController = TextEditingController();
  final _jenisPenerimaController = TextEditingController();
  // final _nominalBLcontroller = ISTConstants().moneyMaskedController;

  // ignore: non_constant_identifier_names
  final String? bnf_acct_no;
  // ignore: non_constant_identifier_names
  final String? bnf_acct_name;

  _TransferSKNState(this.bnf_acct_no, this.bnf_acct_name);

  bool fromFav = false;

  // ignore: unused_field
  bool _autoValidate = false;
  bool _dropError = false;
  bool _dropWarga = false;
  bool _dropStatus = false;
  bool _success = true;
  bool _validateInputs() {
    if (_formKey.currentState!.validate()) {
      return true;
    } else {
      setState(() {
        _autoValidate = true;
        _doValidate();
      });
      return false;
    }
  }

//  bool _doValidate() {
//     if (_formKey.currentState.validate()) {
//       return true;
//     } else {
//       setState(() {
//         _autoValidate = true;
//       });
//       return false;
//     }
//   }
  _doValidate() {
    if (_selectedJenisPen == null) {
      setState(() {
        _dropError = true;
      });
      _success = false;
    }
    if (_selectedStatusPen == null) {
      setState(() {
        _dropStatus = true;
      });
      _success = false;
    }
    if (_selectedNegara == null) {
      setState(() {
        _dropWarga = true;
      });
      _success = false;
    } else {
      _dropWarga = false;
      _dropStatus = false;
      _dropError = false;
      _success = true;
    }
    return _success;
  }

  String bank = "";
  String norek = "";
  String bankName = "";
  String nameBank = "";
  String kodebank = "";
  String destcode = "";
  String jenispenerima = "";
  String tujuantransaksi = "";
  String statuspenduduk = "";

  ISTCardAccountItem? accountItem;

  _doTransfer() async {
    if (_validateInputs()) {
      Map<String, Object?> param = {};
      param['beneficiary'] = _selectedJenisPen!.jenispenerima;
      param['destAcctName'] =
          fromFav ? widget.bnf_acct_name : _namaPenerimacontroller.text;
      // param['destAcctName'] = _namaPenerimacontroller.text;
      param['destAcctNo'] = _noRekBLcontroller.text.replaceAll("-", "");
      param['destBankCode'] = fromFav ? widget.kodebank : bank;
      param['destBankName'] = fromFav ? widget.namebank : bankName;
      // param['amount'] =
      //     int.parse(_nominalBLcontroller.text.replaceAll(",", ""));
      param['memo'] = _catatanBLcontroller.text;
      // param['noRefPel'] = _noRefBLcontroller.text;
      param['residentStatus'] = _selectedStatusPen!.status;
      param['residentStatusKey'] = _selectedStatusPen!.statusTitle.toString();
      param['transactionPurpose'] = _tujuanTransaksiController.text;
      param['alamat'] = _alamatcontroller.text;
      param['beneficiaryKey'] = _selectedJenisPen!.jenispenerimaKey.toString();
      param['listCitizen'] = _selectedNegara!.kewarganegaraan;
      param['listCitizenKey'] = _selectedNegara!.kewarganegaraanKey.toString();

      final resp = await API.post(context, '/skn/inquiry', param);
      print(resp);
      if (resp == null) return;
      if (resp['code'] == 0 && resp['code'] != null) {
        List<ISTConfirmationItem> listParam = [];
        List<dynamic> listMap = resp['resi'];
        for (var item in listMap) {
          ISTConfirmationItem itemParam =
              ISTConfirmationItem(key: item['key'], value: item['value']);
          listParam.add(itemParam);
        }
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => TransferConfirmPageSKN(
                      list: listParam,
                    )));
      } else {
        const DialogBox().showImageDialog(
            message: resp['message'],
            isError: true,
            image: const Image(
              image: AssetImage('assets/images/icon-failed.png'),
            ),
            buttonCancel: 'OK',
            onOk: () {},
            context: context);
      }
    }
  }

  _doGoToListBank() async {
    var result = await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (BuildContext context) => const DaftarBL(),
        ));
    final res = result.toString().replaceAll("\{", "").replaceAll("\}", "");
    if (res != "null") {
      setState(() {
        List<String> resList = res.split("-");
        bank = resList[0];
        bankName = resList[1];
        _kodeBankController.text = res;
      });
    }
  }

  _doGoToListTujuanTransaksi() async {
    var result = await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (BuildContext context) => const TujuanTransaksi(),
        ));
    final res = result.toString().replaceAll("\{", "").replaceAll("\}", "");
    if (res != "null") {
      setState(() {
        List<String> resList = res.split("-");
        tujuantransaksi = resList[0];
        // bankName = resList[1];
        _tujuanTransaksiController.text = res;
      });
    }
  }

  // ignore: unused_element
  _doGoToListJenisPenerima() async {
    var result = await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (BuildContext context) => const JenisPenerima(),
        ));
    final res = result.toString().replaceAll("\{", "").replaceAll("\}", "");
    if (res != "null") {
      setState(() {
        List<String> resList = res.split("-");
        jenispenerima = resList[0];
        // bankName = resList[1];
        _jenisPenerimaController.text = res;
      });
    }
  }

  List<TujuanTransaksiItem> _listTujuanTrx = [];
  // ignore: unused_field
  TujuanTransaksiItem? _selectedTujuanTrx;
  // ignore: unused_element
  _getTujuanTransaksi() async {
    try {
      setState(() {
        _selectedTujuanTrx = null;
      });
      if (_listTujuanTrx.isNotEmpty) {
        Future.delayed(Duration.zero);
        _listTujuanTrx.clear();
      }
      Map<String, Object> param = {};
      // param['listTransactionPurpose'] = _jenisPenerimaController.text;
      final resp = await API.postNoLoading(
          context, '/transaction-purposeList/list', param);
      if (resp['code'] == 0) {
        // print(resp);
        // print(resp['listTujuanPembukanRekening']);
        // var listResp = json.decode(resp['listTujuanPembukanRekening']);
        // List<dynamic> listRespMini = (listResp);
        // List<TujuanItem> listTujuan =
        //     listResp.map((e) => TujuanItem.fromJson(e)).toList();

        // print(listTujuan);
        // // for (var j = 0; j < datas.length; j++) {
        // //   TujuanItem items = TujuanItem(
        // //       // tujuanIndex: item["value"],
        // //       // tujuan: resp[i].toString(),
        // //       tujuan: datas[j].toString());
        // //   listTujuan.add(items);
        // // }
        // // print(listTujuan);
        // setState(() {
        //   _list = listTujuan;
        // });
        var listResp = resp['listTransactionPurpose'];
        List<dynamic> listRespMini = (listResp);
        List<TujuanTransaksiItem> listTujuanTrx = [];
        //for (var item in listRespMini) {
        for (var i = 0; i < listRespMini.length; i++) {
          TujuanTransaksiItem items = TujuanTransaksiItem(
            tujuanTransaksiIndex: i,
            tujuanTransaksi: listRespMini[i]['value'],
            tujuanKey: listRespMini[i]['title'],
          );

          listTujuanTrx.add(items);
        }

        setState(() {
          _listTujuanTrx = listTujuanTrx;
        });
      }
    } catch (_) {}
  }

  List<JenisPenerimaItem> _listJenisPen = [];
  JenisPenerimaItem? _selectedJenisPen;
  _getJenisPenerima() async {
    try {
      setState(() {
        _selectedJenisPen = null;
      });
      if (_listJenisPen.isNotEmpty) {
        Future.delayed(Duration.zero);
        _listJenisPen.clear();
      }
      Map<String, Object> param = {};
      // param['listBeneficiary'] = _jenisPenerimaController.text;
      final resp = await API.postNoLoading(context, '/beneficiary/list', param);
      if (resp['code'] == 0) {
        // print(resp);
        // print(resp['listTujuanPembukanRekening']);
        // var listResp = json.decode(resp['listTujuanPembukanRekening']);
        // List<dynamic> listRespMini = (listResp);
        // List<TujuanItem> listTujuan =
        //     listResp.map((e) => TujuanItem.fromJson(e)).toList();

        // print(listTujuan);
        // // for (var j = 0; j < datas.length; j++) {
        // //   TujuanItem items = TujuanItem(
        // //       // tujuanIndex: item["value"],
        // //       // tujuan: resp[i].toString(),
        // //       tujuan: datas[j].toString());
        // //   listTujuan.add(items);
        // // }
        // // print(listTujuan);
        // setState(() {
        //   _list = listTujuan;
        // });
        var listResp = resp['listBeneficiary'];
        List<dynamic> listRespMini2 = (listResp);
        List<JenisPenerimaItem> listPenerima = [];
        //for (var item in listRespMini) {
        for (var i = 0; i < listRespMini2.length; i++) {
          JenisPenerimaItem items = JenisPenerimaItem(
            jenispenerimaIndex: i,
            jenispenerima: listRespMini2[i]['value'],
            jenispenerimaKey: listRespMini2[i]['title'],
          );

          listPenerima.add(items);
        }

        setState(() {
          _listJenisPen = listPenerima;
        });
      }
    } catch (_) {}
  }

  List<StatusPendudukItem> _listStatusPen = [];
  StatusPendudukItem? _selectedStatusPen;
  _getStatusPenduduk() async {
    try {
      setState(() {
        _selectedStatusPen = null;
      });
      if (_listStatusPen.isNotEmpty) {
        Future.delayed(Duration.zero);
        _listStatusPen.clear();
      }
      Map<String, Object> param = {};
      // param['listTransactionPurpose'] = _jenisPenerimaController.text;
      final resp =
          await API.postNoLoading(context, '/resident-status/list', param);
      if (resp['code'] == 0) {
        // print(resp);
        // print(resp['listTujuanPembukanRekening']);
        // var listResp = json.decode(resp['listTujuanPembukanRekening']);
        // List<dynamic> listRespMini = (listResp);
        // List<TujuanItem> listTujuan =
        //     listResp.map((e) => TujuanItem.fromJson(e)).toList();

        // print(listTujuan);
        // // for (var j = 0; j < datas.length; j++) {
        // //   TujuanItem items = TujuanItem(
        // //       // tujuanIndex: item["value"],
        // //       // tujuan: resp[i].toString(),
        // //       tujuan: datas[j].toString());
        // //   listTujuan.add(items);
        // // }
        // // print(listTujuan);
        // setState(() {
        //   _list = listTujuan;
        // });
        var listResp = resp['listResidentStatus'];
        List<dynamic> listRespMini = (listResp);
        List<StatusPendudukItem> listStatusPen = [];
        //for (var item in listRespMini) {
        for (var i = 0; i < listRespMini.length; i++) {
          StatusPendudukItem items = StatusPendudukItem(
            statusIndex: i,
            status: listRespMini[i]['value'],
            statusTitle: listRespMini[i]['title'],
          );

          listStatusPen.add(items);
        }

        setState(() {
          _listStatusPen = listStatusPen;
        });
      }
    } catch (_) {}
  }

  List<KewarganegaraanItem> _listKewarganegaraan = [];
  KewarganegaraanItem? _selectedNegara;
  _getKewarganegaraan() async {
    try {
      setState(() {
        _selectedNegara = null;
      });
      if (_listKewarganegaraan.isNotEmpty) {
        Future.delayed(Duration.zero);
        _listKewarganegaraan.clear();
      }
      Map<String, Object> param = {};
      // param['listTransactionPurpose'] = _jenisPenerimaController.text;
      final resp = await API.postNoLoading(context, '/citizen/list', param);
      if (resp['code'] == 0) {
        // print(resp);
        // print(resp['listTujuanPembukanRekening']);
        // var listResp = json.decode(resp['listTujuanPembukanRekening']);
        // List<dynamic> listRespMini = (listResp);
        // List<TujuanItem> listTujuan =
        //     listResp.map((e) => TujuanItem.fromJson(e)).toList();

        // print(listTujuan);
        // // for (var j = 0; j < datas.length; j++) {
        // //   TujuanItem items = TujuanItem(
        // //       // tujuanIndex: item["value"],
        // //       // tujuan: resp[i].toString(),
        // //       tujuan: datas[j].toString());
        // //   listTujuan.add(items);
        // // }
        // // print(listTujuan);
        // setState(() {
        //   _list = listTujuan;
        // });
        var listResp = resp['listCitizen'];
        List<dynamic> listRespMini = (listResp);
        List<KewarganegaraanItem> listKewarganegaraan = [];
        //for (var item in listRespMini) {
        for (var i = 0; i < listRespMini.length; i++) {
          KewarganegaraanItem items = KewarganegaraanItem(
            kewarganegaraanIndex: i,
            kewarganegaraan: listRespMini[i]['value'],
            kewarganegaraanKey: listRespMini[i]['title'],
          );

          listKewarganegaraan.add(items);
        }

        setState(() {
          _listKewarganegaraan = listKewarganegaraan;
        });
      }
    } catch (_) {}
  }

  // ignore: unused_element
  _doGoToListStatusPenduduk() async {
    var result = await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (BuildContext context) => const StatusPenduduk(),
        ));
    final res = result.toString().replaceAll("\{", "").replaceAll("\}", "");
    if (res != "null") {
      setState(() {
        List<String> resList = res.split("-");
        statuspenduduk = resList[0];
        // bankName = resList[1];
        _statusPendudukController.text = res;
      });
    }
  }

  _getRedaksi() async {
    final resp = await API.postNoLoading(context, '/redaksi/skn', {});
    if (resp['code'] == 0) {
      setState(() {
        redaksiname = resp['redaksi'];
      });
    }
  }

  _getDialog() async {
    Map<String, Object> param = {};
    param['fitur'] = 'SKN';
    final resp = await API.postNoLoading(context, '/cek/fitur', param);
    if (resp['code'] != 0) {
      setState(() {
        const DialogBox().showImageDialog(
            message: resp['message'],
            isError: true,
            image: const Image(
              image: AssetImage('assets/images/icon-warning.png'),
            ),
            buttonCancel: 'OK',
            onOk: () {},
            onCancel: () {
              Navigator.pushNamed(context, HomePage.routeName);
            },
            context: context);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text(
          'SKN',
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'Poppins',
          ),
        ),
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      body: Container(
          color: Colors.white,
          child: Column(
            children: <Widget>[
              ISTCardAccount(
                // account: (value) {
                //   setState(() {
                //     accountItem = value;
                //   });
                // },
                context: context,
                menu: ISTMenu.transfer,
              ),
              // SizedBox(
              //   height: 4,
              // ),
              Expanded(
                child: Container(
                  padding: const EdgeInsets.only(
                    left: 16,
                    right: 16,
                  ),
                  child: SingleChildScrollView(
                    child: Column(
                        // crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Container(
                              padding: const EdgeInsets.only(top: 8),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: <Widget>[
                                  SizedBox(
                                    width:
                                        (((MediaQuery.of(context).size.width /
                                                    12) -
                                                5) *
                                            5),
                                    // padding: EdgeInsets.only(),
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        Image.asset(
                                          'assets/images/newBASTF.png',
                                          width: 70,
                                        ),
                                        Text('$display_acct_number'),
                                        Text('$display_acct_name'),
                                      ],
                                    ),
                                  ),
                                  SizedBox(
                                      width:
                                          (((MediaQuery.of(context).size.width /
                                                      12) -
                                                  5) *
                                              2),
                                      child: Image.asset(
                                        'assets/images/panahh.png',
                                        width: 70,
                                      )),
                                  SizedBox(
                                    width:
                                        (((MediaQuery.of(context).size.width /
                                                    12) -
                                                5) *
                                            5),
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: <Widget>[
                                        Image.asset(
                                          'assets/images/newTransferBL.png',
                                          width: 70,
                                        ),
                                        fromFav
                                            ? Container(
                                                alignment: Alignment.center,
                                                child: Text(
                                                  widget.namebank!,
                                                  textAlign: TextAlign.center,
                                                ),
                                              )
                                            : Text(
                                                bankName,
                                                textAlign: TextAlign.center,
                                              ),
                                        fromFav
                                            ? Container(
                                                alignment: Alignment.center,
                                                child:
                                                    // Text(norek),
                                                    Text(
                                                  widget.bnf_acct_no!,
                                                  textAlign: TextAlign.center,
                                                ),
                                              )
                                            : Text(
                                                norek,
                                                textAlign: TextAlign.center,
                                              ),
                                        // Text(''),
                                      ],
                                    ),
                                  ),
                                ],
                              )),
                          const SizedBox(
                            height: 16,
                          ),
                          Form(
                              key: _formKey,
                              // ignore: deprecated_member_use
                              autovalidateMode: AutovalidateMode.always,
                              child: Column(
                                  // mainAxisAlignment: MainAxisAlignment.spaceAround,
                                  children: <Widget>[
                                    Container(
                                      // padding: EdgeInsets.only(top: 16),
                                      alignment: Alignment.topLeft,
                                      // padding: EdgeInsets.only(top: 16),
                                      child: const Text(
                                        'Bank Penerima :',
                                      ),
                                    ),
                                    fromFav
                                        ? Container(
                                            alignment: Alignment.topLeft,
                                            child:
                                                // Text(
                                                //     widget.destcode),
                                                Text(widget.kodebank! +
                                                    " - " +
                                                    widget.namebank!),
                                          )
                                        : Container(
                                            alignment: Alignment.topLeft,
                                            child: TextFormField(
                                              validator: (val) {
                                                if (val!.isEmpty) {
                                                  return "Mohon pilih bank tujuan";
                                                } else {
                                                  return null;
                                                }
                                              },
                                              controller: _kodeBankController,
                                              onTap: () {
                                                _doGoToListBank();
                                              },
                                              readOnly: true,
                                              showCursor: false,
                                              decoration: const InputDecoration(
                                                // errorText:
                                                //     _kodeBankError ? "Mohon diisi" : null,
                                                hintText: 'Pilih bank tujuan',
                                                hintStyle: ISTStyle.hintStyle,
                                                suffixIcon: Icon(
                                                    Icons.arrow_forward_ios),
                                              ),
                                            ),
                                          ),

                                    const SizedBox(
                                      height: 8,
                                    ),
                                    Container(
                                      alignment: Alignment.topLeft,
                                      child: const Text(
                                        'Ke Rekening :',
                                        style: TextStyle(color: Colors.black87),
                                      ),
                                    ),
                                    fromFav
                                        ? Container(
                                            alignment: Alignment.topLeft,
                                            child: Text(widget.bnf_acct_no!),
                                          )
                                        : Container(
                                            alignment: Alignment.topLeft,
                                            child: TextFormField(
                                              onChanged: (value) {
                                                setState(() {
                                                  norek =
                                                      _noRekBLcontroller.text;
                                                });
                                              },
                                              validator: (val) {
                                                if (val!.isEmpty) {
                                                  return "Mohon masukkan nomor rekening";
                                                } else {
                                                  return null;
                                                }
                                              },
                                              keyboardType:
                                                  TextInputType.number,
                                              inputFormatters: [
                                                // ignore: deprecated_member_use
                                                FilteringTextInputFormatter
                                                    .digitsOnly,
                                              ],
                                              controller: _noRekBLcontroller,
                                              maxLength: ISTConstants
                                                  .acctToMaxLength,
                                              // maxLength: 15,
                                              decoration: const InputDecoration(
                                                counterText: '',
                                                // errorText:_noRekBLError ? "Mohon diisi" : null,
                                                hintText:
                                                    'Masukkan no rekening tujuan',
                                                hintStyle: ISTStyle.hintStyle,
                                              ),
                                            ),
                                          ),

                                    const SizedBox(
                                      height: 8,
                                    ),
                                    Container(
                                      alignment: Alignment.topLeft,
                                      child: const Text(
                                        'Nama Penerima:',
                                        style: TextStyle(color: Colors.black87),
                                      ),
                                    ),
                                    fromFav
                                        ? Container(
                                            alignment: Alignment.topLeft,
                                            child: Text(widget.bnf_acct_name!,
                                                style: const TextStyle(
                                                    color: Colors.black87)))
                                        : Container(
                                            alignment: Alignment.topLeft,
                                            child: TextFormField(
                                              validator: (val) {
                                                if (val!.isEmpty) {
                                                  return "Mohon masukkan nama penerima";
                                                } else {
                                                  return null;
                                                }
                                              },
                                              controller:
                                                  _namaPenerimacontroller,
                                              inputFormatters: [
                                                StringUtils.alphaNumeric(),
                                              ],
                                              decoration: const InputDecoration(
                                                hintText:
                                                    'Masukkan nama penerima',
                                                hintStyle: ISTStyle.hintStyle,
                                              ),
                                            ),
                                          ),
                                    //  _dropError
                                    //         ? Container(
                                    //             alignment:
                                    //                 Alignment.centerLeft,
                                    //             child: Text(
                                    //               'Mohon masukkan nama penerima',
                                    //               style: TextStyle(
                                    //                   color: Colors.red),
                                    //             ),
                                    //           )
                                    //         : SizedBox.shrink(),

                                    const SizedBox(
                                      height: 8,
                                    ),

                                    Container(
                                      alignment: Alignment.topLeft,
                                      child: const Text(
                                        'Alamat :',
                                        style: TextStyle(color: Colors.black87),
                                      ),
                                    ),
                                    Container(
                                      alignment: Alignment.topLeft,
                                      child: TextFormField(
                                        validator: (val) {
                                          if (val!.isEmpty) {
                                            return "Mohon masukkan alamat";
                                          } else {
                                            return null;
                                          }
                                        },
                                        controller: _alamatcontroller,
                                        inputFormatters: [
                                          StringUtils.alphaNumeric(),
                                        ],
                                        decoration: const InputDecoration(
                                          hintText: 'Masukkan Alamat',
                                          hintStyle: ISTStyle.hintStyle,
                                        ),
                                      ),
                                    ),

                                    const SizedBox(
                                      height: 8,
                                    ),
                                    Container(
                                      alignment: Alignment.topLeft,
                                      child: const Text(
                                        'Nominal :',
                                        style: TextStyle(color: Colors.black87),
                                      ),
                                    ),
                                    Container(
                                      alignment: Alignment.topLeft,
                                      child: TextFormField(
                                        validator: (val) {
                                          if (val!.isEmpty || val == '0') {
                                            return "Mohon masukkan nominal";
                                          } else {
                                            return null;
                                          }
                                        },
                                        inputFormatters: [
                                          // ignore: deprecated_member_use
                                          FilteringTextInputFormatter
                                              .digitsOnly,
                                        ],
                                        // controller: _nominalBLcontroller,
                                        maxLength:
                                            ISTConstants.nominalMaxLength,
                                        onChanged: (value) {
                                          // if (_nominalBLcontroller.text
                                          //     .trim()
                                          //     .isEmpty) {
                                          //   _nominalBLcontroller.text = '';
                                          // }
                                        },
                                        keyboardType: TextInputType.number,
                                        decoration: const InputDecoration(
                                          counterText: '',
                                          // errorText:_nominalBLError ? "Mohon diisi" : null,
                                          prefixText: 'IDR ',
                                          prefixStyle: TextStyle(),
                                          hintText: 'Masukkan nominal',
                                          hintStyle: ISTStyle.hintStyle,
                                        ),
                                      ),
                                    ),

                                    const SizedBox(
                                      height: 8,
                                    ),
                                    Container(
                                      // padding: EdgeInsets.only(top: 16),
                                      alignment: Alignment.topLeft,
                                      // padding: EdgeInsets.only(top: 16),
                                      child: const Text(
                                        'Tujuan Transaksi :',
                                      ),
                                    ),
                                    // fromFav
                                    //     ? Container(
                                    //         alignment: Alignment.topLeft,
                                    //         child:
                                    //             // Text(
                                    //             //     widget.destcode),
                                    //             Text(widget.kodebank +
                                    //                 widget.namebank),
                                    //       )
                                    //     :
                                    Container(
                                      alignment: Alignment.topLeft,
                                      child: TextFormField(
                                        validator: (val) {
                                          if (val!.isEmpty) {
                                            return "Mohon pilih tujuan transaksi";
                                          } else {
                                            return null;
                                          }
                                        },
                                        controller: _tujuanTransaksiController,
                                        onTap: () {
                                          _doGoToListTujuanTransaksi();
                                        },
                                        readOnly: true,
                                        showCursor: false,
                                        decoration: const InputDecoration(
                                          // errorText:
                                          //     _kodeBankError ? "Mohon diisi" : null,
                                          hintText: 'Pilih tujuan transaksi',
                                          hintStyle: ISTStyle.hintStyle,
                                          suffixIcon:
                                              Icon(Icons.arrow_forward_ios),
                                        ),
                                      ),
                                    ),

                                    const SizedBox(
                                      height: 8,
                                    ),
                                    Container(
                                      alignment: Alignment.center,
                                      // padding: EdgeInsets.only(left: 16, right: 16),
                                      color: Colors.white,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: <Widget>[
                                          const Text(
                                            "Jenis Penerima",
                                          ),
                                          Container(
                                            // padding: EdgeInsets.only(right: 8),
                                            alignment: Alignment.topLeft,
                                            child: DropdownButton<
                                                JenisPenerimaItem>(
                                              // value: dropdownValue,
                                              // iconEnabledColor: Pallete.primary,
                                              value: _listJenisPen.isEmpty
                                                  ? null
                                                  : _selectedJenisPen,
                                              hint: const Text("Pilih jenis penerima",
                                                  style: ISTStyle.hintStyle),
                                              isExpanded: true,

                                              // iconSize: 38,
                                              icon: const Icon(
                                                Icons.keyboard_arrow_down,
                                                size: 38,
                                              ),
                                              // iconSize: 30,
                                              // style: TextStyle(color: Colors.black),
                                              underline: Container(
                                                height: 1,
                                                color: Colors.grey,
                                              ),
                                              // onChanged: (TujuanItem newValue) {
                                              //   setState(() {
                                              //     _selected = newValue;
                                              //   });
                                              // },
                                              onChanged: (JenisPenerimaItem?
                                                  valueJenis) {
                                                setState(() {
                                                  _selectedJenisPen =
                                                      valueJenis;
                                                });
                                              },
                                              // items: <String>['sdasda', 'sadasda', 'asdasdasdas']
                                              //     .map<DropdownMenuItem<String>>((value) {
                                              //   return DropdownMenuItem<String>(
                                              //     value: value,
                                              //     child: Text(value),
                                              //   );
                                              // }).toList(),
                                              items: _listJenisPen.map(
                                                  (JenisPenerimaItem
                                                      _listJenisPen) {
                                                return DropdownMenuItem<
                                                    JenisPenerimaItem>(
                                                  value: _listJenisPen,
                                                  child: Row(
                                                    children: <Widget>[
                                                      Text(_listJenisPen
                                                          .jenispenerima!),
                                                    ],
                                                  ),
                                                );
                                              }).toList(),
                                              isDense: false,
                                            ),
                                          ),
                                          _dropError
                                              ? Container(
                                                  alignment:
                                                      Alignment.centerLeft,
                                                  child: const Text(
                                                    'Mohon pilih jenis penerima',
                                                    style: TextStyle(
                                                        color: Colors.red,
                                                        fontSize: 12),
                                                  ),
                                                )
                                              : const SizedBox.shrink(),
                                        ],
                                      ),
                                    ),
                                    // // Container(
                                    // //   // padding: EdgeInsets.only(top: 16),
                                    // //   alignment: Alignment.topLeft,
                                    // //   // padding: EdgeInsets.only(top: 16),
                                    // //   child: Text(
                                    // //     'Jenis Penerima :',
                                    // //   ),
                                    // // ),
                                    // // // fromFav
                                    // // //     ? Container(
                                    // // //         alignment: Alignment.topLeft,
                                    // // //         child:
                                    // // //             // Text(
                                    // // //             //     widget.destcode),
                                    // // //             Text(widget.kodebank +
                                    // // //                 widget.namebank),
                                    // // //       )
                                    // // //     :
                                    // //      Container(
                                    // //         alignment: Alignment.topLeft,
                                    // //         child: TextFormField(
                                    // //           validator: (val) {
                                    // //             if (val.isEmpty) {
                                    // //               return "Mohon diisi";
                                    // //             } else {
                                    // //               return null;
                                    // //             }
                                    // //           },
                                    // //           controller:
                                    // //               _jenisPenerimaController,
                                    // //           onTap: () {
                                    // //             _doGoToListJenisPenerima();
                                    // //           },
                                    // //           readOnly: true,
                                    // //           showCursor: false,
                                    // //           decoration: InputDecoration(
                                    // //             // errorText:
                                    // //             //     _kodeBankError ? "Mohon diisi" : null,
                                    // //             hintText:
                                    // //                 'Pilih jenis penerima',
                                    // //             hintStyle: ISTStyle.HINT_STYLE,
                                    // //             suffixIcon: Icon(
                                    // //                 Icons.arrow_forward_ios),
                                    // //           ),
                                    // //         ),
                                    // //       ),
                                    // SizedBox(
                                    //   height: 8,
                                    // ),
                                    // Container(
                                    //   // padding: EdgeInsets.only(top: 16),
                                    //   alignment: Alignment.topLeft,
                                    //   // padding: EdgeInsets.only(top: 16),
                                    //   child: Text(
                                    //     'Status Penduduk :',
                                    //   ),
                                    // ),
                                    // // fromFav
                                    // //     ? Container(
                                    // //         alignment: Alignment.topLeft,
                                    // //         child:
                                    // //             // Text(
                                    // //             //     widget.destcode),
                                    // //             Text(widget.kodebank +
                                    // //                 widget.namebank),
                                    // //       )
                                    // //     :
                                    //     Container(
                                    //         alignment: Alignment.topLeft,
                                    //         child: TextFormField(
                                    //           validator: (val) {
                                    //             if (val.isEmpty) {
                                    //               return "Mohon diisi";
                                    //             } else {
                                    //               return null;
                                    //             }
                                    //           },
                                    //           controller:
                                    //               _statusPendudukController,
                                    //           onTap: () {
                                    //             _doGoToListStatusPenduduk();
                                    //           },
                                    //           readOnly: true,
                                    //           showCursor: false,
                                    //           decoration: InputDecoration(
                                    //             // errorText:
                                    //             //     _kodeBankError ? "Mohon diisi" : null,
                                    //             hintText:
                                    //                 'Pilih status penduduk',
                                    //             hintStyle: ISTStyle.HINT_STYLE,
                                    //             suffixIcon: Icon(
                                    //                 Icons.arrow_forward_ios),
                                    //           ),
                                    //         ),
                                    //       ),
                                    const SizedBox(
                                      height: 8,
                                    ),
                                    Container(
                                      alignment: Alignment.center,
                                      // padding: EdgeInsets.only(left: 16, right: 16),
                                      color: Colors.white,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: <Widget>[
                                          const Text(
                                            "Status Penduduk",
                                          ),
                                          Container(
                                            // padding: EdgeInsets.only(right: 8),
                                            alignment: Alignment.topLeft,
                                            child: DropdownButton<
                                                StatusPendudukItem>(
                                              // iconEnabledColor: Pallete.primary,
                                              // value: dropdownValue,
                                              value: _listStatusPen.isEmpty
                                                  ? null
                                                  : _selectedStatusPen,
                                              hint: const Text(
                                                  "Pilih status penduduk",
                                                  style: ISTStyle.hintStyle),
                                              isExpanded: true,
                                              // iconSize: 38,
                                              icon: const Icon(
                                                Icons.keyboard_arrow_down,
                                                size: 38,
                                              ),
                                              // iconSize: 30,
                                              // style: TextStyle(color: Colors.black),
                                              underline: Container(
                                                height: 1,
                                                color: Colors.grey,
                                              ),
                                              // onChanged: (TujuanItem newValue) {
                                              //   setState(() {
                                              //     _selected = newValue;
                                              //   });
                                              // },
                                              onChanged: (StatusPendudukItem?
                                                  valuePen) {
                                                setState(() {
                                                  _selectedStatusPen = valuePen;
                                                });
                                              },
                                              // items: <String>['sdasda', 'sadasda', 'asdasdasdas']
                                              //     .map<DropdownMenuItem<String>>((value) {
                                              //   return DropdownMenuItem<String>(
                                              //     value: value,
                                              //     child: Text(value),
                                              //   );
                                              // }).toList(),
                                              items: _listStatusPen.map(
                                                  (StatusPendudukItem
                                                      _listStatusPen) {
                                                return DropdownMenuItem<
                                                    StatusPendudukItem>(
                                                  value: _listStatusPen,
                                                  child: Row(
                                                    children: <Widget>[
                                                      Text(_listStatusPen
                                                          .status!),
                                                    ],
                                                  ),
                                                );
                                              }).toList(),
                                              isDense: false,
                                            ),
                                          ),
                                          _dropStatus
                                              ? Container(
                                                  alignment:
                                                      Alignment.centerLeft,
                                                  child: const Text(
                                                    'Mohon pilih status penduduk',
                                                    style: TextStyle(
                                                        color: Colors.red,
                                                        fontSize: 12),
                                                  ),
                                                )
                                              : const SizedBox.shrink(),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 8,
                                    ),
                                    Container(
                                      alignment: Alignment.center,
                                      // padding: EdgeInsets.only(left: 16, right: 16),
                                      color: Colors.white,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: <Widget>[
                                          const Text(
                                            "Kewarganegaraan",
                                          ),
                                          Container(
                                            // padding: EdgeInsets.only(right: 8),
                                            alignment: Alignment.topLeft,
                                            child: DropdownButton<
                                                KewarganegaraanItem>(
                                              // iconEnabledColor: Pallete.primary,
                                              // value: dropdownValue,
                                              value: _listKewarganegaraan
                                                          .isEmpty
                                                  ? null
                                                  : _selectedNegara,
                                              hint: const Text(
                                                  "Pilih kewarganegaraan",
                                                  style: ISTStyle.hintStyle),
                                              isExpanded: true,
                                              // iconSize: 38,
                                              icon: const Icon(
                                                Icons.keyboard_arrow_down,
                                                size: 38,
                                              ),
                                              // iconSize: 30,
                                              // style: TextStyle(color: Colors.black),
                                              underline: Container(
                                                height: 1,
                                                color: Colors.grey,
                                              ),
                                              // onChanged: (TujuanItem newValue) {
                                              //   setState(() {
                                              //     _selected = newValue;
                                              //   });
                                              // },
                                              onChanged: (KewarganegaraanItem?
                                                  valuewarga) {
                                                setState(() {
                                                  _selectedNegara = valuewarga;
                                                });
                                              },
                                              // items: <String>['sdasda', 'sadasda', 'asdasdasdas']
                                              //     .map<DropdownMenuItem<String>>((value) {
                                              //   return DropdownMenuItem<String>(
                                              //     value: value,
                                              //     child: Text(value),
                                              //   );
                                              // }).toList(),
                                              items: _listKewarganegaraan.map(
                                                  (KewarganegaraanItem
                                                      _listKewarganegaraan) {
                                                return DropdownMenuItem<
                                                    KewarganegaraanItem>(
                                                  value: _listKewarganegaraan,
                                                  child: Row(
                                                    children: <Widget>[
                                                      Text(_listKewarganegaraan
                                                          .kewarganegaraan!),
                                                    ],
                                                  ),
                                                );
                                              }).toList(),
                                              isDense: false,
                                            ),
                                          ),
                                          _dropWarga
                                              ? Container(
                                                  alignment:
                                                      Alignment.centerLeft,
                                                  child: const Text(
                                                    'Mohon pilih kewarganegaraan',
                                                    style: TextStyle(
                                                        color: Colors.red,
                                                        fontSize: 12),
                                                  ),
                                                )
                                              : const SizedBox.shrink(),
                                        ],
                                      ),
                                    ),
                                    // SizedBox(
                                    //   height: 8,
                                    // ),
                                    // Container(
                                    //   alignment: Alignment.topLeft,
                                    //   child: Text(
                                    //     'No. Referensi :',
                                    //     style: TextStyle(color: Colors.black87),
                                    //   ),
                                    // ),
                                    // Container(
                                    //   alignment: Alignment.topLeft,
                                    //   child: TextField(
                                    //     controller: _noRefBLcontroller,
                                    //     keyboardType: TextInputType.number,
                                    //     inputFormatters: [
                                    //       // ignore: deprecated_member_use
                                    //       WhitelistingTextInputFormatter
                                    //           // ignore: deprecated_member_use
                                    //           .digitsOnly
                                    //     ],
                                    //     maxLength: ISTConstants
                                    //         .REF_PELANGGAN_MAX_LENGTH,
                                    //     decoration: InputDecoration(
                                    //       counterText: '',
                                    //       hintText: 'Masukkan no referensi',
                                    //       hintStyle: ISTStyle.HINT_STYLE,
                                    //     ),
                                    //   ),
                                    // ),
                                    const SizedBox(
                                      height: 8,
                                    ),
                                    Container(
                                      alignment: Alignment.topLeft,
                                      child: const Text(
                                        'Catatan :',
                                        style: TextStyle(color: Colors.black87),
                                      ),
                                    ),
                                    Container(
                                      alignment: Alignment.topLeft,
                                      child: TextField(
                                        controller: _catatanBLcontroller,
                                        inputFormatters: [
                                          StringUtils.alphaNumeric(),
                                        ],
                                        maxLength:
                                            ISTConstants.catatanTrfMaxLength,
                                        decoration: const InputDecoration(
                                          hintText: 'Masukkan catatan',
                                          hintStyle: ISTStyle.hintStyle,
                                        ),
                                      ),
                                    ),
                                    Container(
                                      alignment: Alignment.topLeft,
                                      child: Text(
                                          StringUtils.getValueAsString(
                                              redaksiname!),
                                          style: const TextStyle(
                                              color: Colors.grey,
                                              fontStyle: FontStyle.italic,
                                              fontSize: 12)),
                                    ),
                                    const SizedBox(
                                      height: 16,
                                    ),
                                  ])),
                          ISTOutlineButton(
                            onPressed: () {
                              //         setState(() {});
                              // if (!_doValidate()) return;
                              _doTransfer();
                            },
                            text: 'Lanjut',
                          ),
                          const SizedBox(
                            height: 16,
                          )
                        ]),
                  ),
                ),
              ),
            ],
          )),
    );
  }
}
