import 'package:flutter/material.dart';

class JenisPenerimaItem {
  final String? jenispenerima;
  final String? jenispenerimaKey;
  final int? jenispenerimaIndex;


  JenisPenerimaItem(
      {Key? key,
     this.jenispenerima,
     this.jenispenerimaIndex,
     this.jenispenerimaKey,
     });
}