import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:flutter/material.dart';

class DaftarBankRtgs extends StatefulWidget {
  static const routeName = '/DaftarBankRtgs';

  const DaftarBankRtgs({Key? key}) : super(key: key);
  @override
  _DaftarBankRtgsState createState() => _DaftarBankRtgsState();
}

class BankItem {
  final String? code;
  final String? name;

  BankItem({this.code, this.name});
}

class _DaftarBankRtgsState extends State<DaftarBankRtgs> {
  List<BankItem> _listFiltered = [];
  List<BankItem> _listbank = [];
  BankItem? bank;

  // _doInquiryBank() async {
  //   try {
  //     // Map<String, Object> bank_list = new Map();
  //     final resp =  await API.post(context, '/transfer/getBank',null);

  //     if (resp['code'] == 0) {
  //       final List<dynamic> bankList = resp['bank_list'];
  //       List<BankItem> _listbuilds = [

  //       ];
  //       for (var item in bankList) {
  //         _listbuilds.add(BankItem(code: item['bankCode'], name: item['bankName']));
  //       }
  //       setState(() {
  //         _listbank = _listbuilds;
  //         _listFiltered = _listbank;
  //       });
  //     } else {
  //       DialogBox().showErrorDialog(
  //         context: context,
  //         message: resp['message'],
  //       );
  //     }
  //   } catch (_) {}
  // }

  @override
  void didChangeDependencies() {
    _doInquiryBank();
    super.didChangeDependencies();
  }

  @override
  void initState() {
    _doInquiryBank();
    super.initState();
  }

  _doInquiryBank() async {
    const _url = '/transfer/getBankRTGS';
    var resp = await API.postNoLoading(context, _url, {});

    if (resp['code'] == 0) {
      final List<dynamic> bankList = resp['bank_list'];
      List<BankItem> _listbuilds = [];
      for (var item in bankList) {
        _listbuilds
            .add(BankItem(code: item['bankCodeRtgs'], name: item['bankName']));
      }
      setState(() {
        _listbank = _listbuilds;
        _listFiltered = _listbank;
      });
    } else {
      const DialogBox().showErrorDialog(
        context: context,
        message: resp['message'],
      );
    }

    // catch (_) {}
  }

  onTapped(BankItem item) {
    Navigator.pop(context, {"${item.code}-${item.name}"});
  }

  // List<BankItem> _listbuilds = [];
  // List<BankItem> _buildList = [];

  // get resp =>bank;

  // _doInquiryBank(){
  //   setState(() {
  //         _listbank = _listbuilds;
  //         _listFiltered = _listbank;
  //   });

  // }

  final TextEditingController _search = TextEditingController();
  String _searchText = "";
  Icon _searchIcon = const Icon(Icons.search);
  Widget _appBarTitle = const Text(
    'Pilih Bank',
    style: TextStyle(
      color: Colors.white,
      fontFamily: 'Poppins',
      // fontSize: FontSize.TITLE,
    ),
  );

  void _searchPressed() {
    setState(() {
      if (_searchIcon.icon == Icons.search) {
        _searchIcon = const Icon(
          Icons.close,
          color: Colors.white,
        );
        _appBarTitle = TextField(
          style: const TextStyle(color: Colors.white),
          autofocus: true,
          controller: _search,
          onChanged: (text) {
            setState(() {
              _searchText = text;
            });
          },
          decoration: const InputDecoration(
              border: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.white)),
              // prefixIcon: Icon(Icons.search),
              hintText: 'Cari Nama Bank...',
              hintStyle: TextStyle(
                color: Colors.white,
                fontFamily: 'Poppins',
              )),
        );
      } else {
        _searchIcon = const Icon(Icons.search);
        _appBarTitle = const Text('Pilih Bank',
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'Poppins',
            ));
        _searchText = "";
        _search.clear();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          backgroundColor: Pallete.primary,
          leading: IconButton(
            icon: const Icon(
              Icons.arrow_back_ios,
              color: Colors.white,
            ),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          actions: <Widget>[
            IconButton(
              color: Colors.white,
              icon: _searchIcon,
              onPressed: _searchPressed,
            ),
          ],
          centerTitle: true,
          title: _appBarTitle),
      backgroundColor: Colors.white,
      body: Column(
        children: <Widget>[
          Expanded(
            child: Container(child: _buildList()),
          ),
          const SizedBox(
            height: 16,
          ),
        ],
      ),
    );
  }

  _buildList() {
    if (_searchText.isNotEmpty) {
      List<BankItem> tempList = List.empty();
      for (BankItem item in _listbank) {
        if (item.name != null) {
          if (item.name!.toLowerCase().contains(_searchText.toLowerCase())) {
            tempList.add(item);
          }
        }
      }
      _listFiltered = tempList;
    } else {
      _listFiltered = _listbank;
    }
    return ListView.separated(
        separatorBuilder: (context, inx) {
          return const Divider();
        },
        padding: const EdgeInsets.only(left: 16, right: 16),
        // ignore: unnecessary_null_comparison
        itemCount: _listbank == null ? 0 : _listFiltered.length,
        shrinkWrap: true,
        itemBuilder: (context, index) {
          final item = _listFiltered[index];
          return ListTile(
            title: Text(item.name!),
            onTap: () => onTapped(item),
          );
        });
  }
}
