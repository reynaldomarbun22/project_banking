import 'package:bpd_aceh/components/ist_confirmation.dart';
// import 'package:bpd_aceh/components/ISTReceipt.dart';
import 'package:bpd_aceh/components/palete.dart';
// import 'package:bpd_aceh/features/transfer/transferBankLain/mpinBL/transfer_mpinBankLain.dart';
import 'package:bpd_aceh/features/transfer/transferSKN/mpinSKN/transfer_mpin_skn.dart';
// import 'package:bpd_aceh/features/transfer/mpin/transfer_mpin.dart';
import 'package:flutter/material.dart';

class TransferConfirmPageSKN extends StatefulWidget {
  static const routeName = '/transfer/TransferConfirmPageSKN';
  final List<ISTConfirmationItem>? list;

  const TransferConfirmPageSKN({Key? key, this.list}) : super(key: key);
  // final String srcAcct;
  // final String destAcct;
  // final String nominal;
  // final String note;

  // const TransferConfirmPageSKN(
  //     {Key key, this.srcAcct, this.destAcct, this.nominal, this.note, List<ISTConfirmationItem> list})
  //     : super(key: key);

  @override
  State<TransferConfirmPageSKN> createState() => _KonfirmasiFormState();
}

class _KonfirmasiFormState extends State<TransferConfirmPageSKN> {
  // bool showPass = true;
  // bool isLoading = false;

  @override
  Widget build(BuildContext context) {
    // final loginText = Text(
    //   'Transfer',
    //   style: TextStyle(
    //       fontWeight: FontWeight.w100, color: Colors.white, fontSize: 20),
    // );

    _doTransfer() {
      Navigator.pushNamed(context, TransferMpinPageSKN.routeName);
    }

    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Pallete.primary,
          leading: IconButton(
              icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
              onPressed: () {
                Navigator.pop(context);
              }),
          title: const Text(
            'SKN',
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'Poppins',
            ),
          ),
          centerTitle: true,
          elevation: 0.0,
        ),
        body: ISTConfirmation(
            items: widget.list,
            title: 'Konfirmasi Transfer',
            onFinished: () {
              _doTransfer();
            }));
  }
}
