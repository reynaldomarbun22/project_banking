import 'dart:io';
import 'dart:typed_data';

import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_save/image_save.dart';
import 'package:share/share.dart';
import 'package:path_provider/path_provider.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:screenshot/screenshot.dart';

class Qrimages extends StatefulWidget {
  static const routeName = '/showqrimages';

  final String? qrStr;
  final String? qrName;
  final String? qrAcct;

  const Qrimages({
    Key? key,
    this.qrStr,
    this.qrName,
    this.qrAcct,
  }) : super(key: key);

  @override
  _QrimagesState createState() => _QrimagesState();
}

class _QrimagesState extends State<Qrimages> {
  ScreenshotController screenshotController = ScreenshotController();

  // ignore: unused_element
  // _scrshot() async {
  //   Map<Permission, PermissionStatus> statuses = await [
  //     Permission.photos,
  //     Permission.storage,
  //     Permission.camera
  //   ].request();
  //   print(statuses);
  //   if (await Permission.storage.request().isGranted &&
  //       await Permission.photos.request().isGranted &&
  //       await Permission.camera.request().isGranted) {
  //     screenshotController
  //         .capture(pixelRatio: 3, delay: const Duration(milliseconds: 100))
  //         .then((image) async {
  //       var save = await ImageGallerySaver.saveImage(
  //         image!,
  //       );
  //       if (save != null && save.toString().isNotEmpty) {
  //         const DialogBox().showImageDialog(
  //           isError: false,
  //           onOk: () {
  //             Navigator.pop(context);
  //           },
  //           title: "Perhatian",
  //           buttonOk: "OK",
  //           context: context,
  //           message: "Berhasil unduh QR",
  //         );
  //       }
  //     }).catchError((onError) {
  //       print(onError);
  //     });
  //   } else {
  //     const DialogBox().showImageDialog(
  //       isError: true,
  //       onOk: () {
  //         Navigator.pop(context);
  //       },
  //       title: "Perhatian",
  //       buttonOk: "OK",
  //       context: context,
  //       message: "Gagal unduh QR",
  //     );
  //   }
  // }

  // ignore: unused_element
  // _share() async {
  //   await [
  //     Permission.photos,
  //     Permission.storage,
  //   ].request();
  //   screenshotController
  //       .capture(
  //     pixelRatio: 3,
  //   )
  //       .then((image) async {
  //     await Share.file('${widget.qrName}.jpg', '${widget.qrAcct}.jpg',
  //         image!, 'image/jpg');
  //   });
  // }

  late String noref;
  String _result = "";
  Future<void> _saveImage() async {
    setState(() {
      noref = widget.qrName!;
    });
    bool success = false;
    screenshotController
        .capture(pixelRatio: 3, delay: const Duration(milliseconds: 10))
        .then((image) async {
      print(image);
      print("ini datsssssSSSSSSSSS");
      try {
        success = (await ImageSave.saveImage(
          image,
          "$noref.jpg",
          albumName: "Action Mobile",
        ))!;
      } on PlatformException catch (e, s) {
        print(e);
        print(s);
      }
      setState(() {
        _result = success ? "Save to album success" : "Save to album failed";
        print(_result);
        const DialogBox().showImageDialog(
          isError: false,
          onOk: () {
            Navigator.pop(context);
          },
          // image: Icon(
          //   Icons.camera_alt,
          //   color: Pallete.primary,
          // ),
          title: "Perhatian",
          buttonOk: "OK",
          context: context,
          message: "Berhasil unduh QR",
        );
        // showDialog(
        //   context: context,
        //   barrierDismissible: false,
        //   useRootNavigator: true,
        //   builder: (BuildContext context) {
        //     return AlertDialog(
        //       // contentPadding: EdgeInsets.all(8),
        //       shape: const RoundedRectangleBorder(
        //         borderRadius: BorderRadius.all(Radius.circular(20.0)),
        //       ),
        //       content: SizedBox(
        //         height: 230,
        //         child: Column(
        //           children: <Widget>[
        //             // SizedBox(
        //             //   height: 2,
        //             // ),

        //             const Text(
        //               'Resi berhasil di unduh',
        //               textAlign: TextAlign.center,
        //               style: TextStyle(
        //                 color: Pallete.primary,
        //               ),
        //             ),
        //             const SizedBox(
        //               height: 16,
        //             ),
        //             Container(
        //               alignment: Alignment.center,
        //               child: Row(
        //                 mainAxisAlignment: MainAxisAlignment.center,
        //                 children: [
        //                   SizedBox(
        //                     width: 120,
        //                     child: OutlineButton(
        //                       onPressed: () {
        //                         Navigator.pop(context);
        //                         setState(() {
        //                           // ss = false;
        //                         });
        //                       },
        //                       borderSide: const BorderSide(
        //                         color: Pallete.primary,
        //                       ),
        //                       splashColor: Pallete.primary,
        //                       shape: const RoundedRectangleBorder(
        //                         borderRadius:
        //                             BorderRadius.all(Radius.circular(18)),
        //                       ),
        //                       child: Text(
        //                         "Selesai",
        //                         style: Theme.of(context)
        //                             .textTheme
        //                             .bodyText1
        //                             ?.copyWith(
        //                                 fontWeight: FontWeight.w600,
        //                                 color: Pallete.primary),
        //                       ),
        //                     ),
        //                   ),
        //                 ],
        //               ),
        //             )
        //           ],
        //         ),
        //       ),
        //       //actions: _checkbutton(context),
        //     );
        //   },
        // );
      });
    });
  }

  Future<String> saveAndShare(Uint8List bytes) async {
    final directory = await getApplicationDocumentsDirectory();
    final image = File('${directory.path}/flutter.png');
    image.writeAsBytesSync(bytes);
    const text = 'Shared From Action Mobile';
    await Share.shareFiles([image.path], text: text);
    return directory.path;
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Screenshot(
              controller: screenshotController,
              child: Container(
                color: Colors.white,
                padding: const EdgeInsets.all(8),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Container(
                      color: Colors.white,
                      alignment: Alignment.center,
                      padding: const EdgeInsets.only(bottom: 32, top: 60),
                      child: Column(
                        children: <Widget>[
                          Text(
                            '${widget.qrName}',
                            style: const TextStyle(
                              fontWeight: FontWeight.w400,
                              fontFamily: 'Poppins',
                            ),
                          ),
                          Text(
                            '${widget.qrAcct}',
                            style: const TextStyle(
                              fontWeight: FontWeight.w400,
                              fontFamily: 'Poppins',
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                        decoration: BoxDecoration(
                            color: Colors.white,
                            border: Border.all(),
                            borderRadius: BorderRadius.circular(10)),
                        padding: const EdgeInsets.all(8),
                        height: 280,
                        width: 280,
                        child: QrImage(
                          backgroundColor: Colors.white,
                          data: widget.qrStr!,
                          version: QrVersions.auto,
                          gapless: false,
                        )),
                    Container(
                      padding: const EdgeInsets.only(bottom: 8, top: 12),
                      child: const Text(
                          'Scan Kode ini untuk Transfer Antar Bank Aceh'),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Image.asset(
                          'assets/images/bank-logo-green.png',
                          height: 50,
                        )
                      ],
                    ),
                    const SizedBox(height: 32),
                  ],
                ),
              ),
            ),
            Container(
              padding: const EdgeInsets.all(0),
              width: double.maxFinite,
              height: 50,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: TextButton(
                      onPressed: () {
                        _saveImage();
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const <Widget>[
                          Icon(
                            Icons.file_download,
                            color: Pallete.primary,
                          ),
                          SizedBox(width: 4),
                          Text(
                            "Unduh",
                            style: TextStyle(color: Pallete.primary),
                          )
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                    child: TextButton(
                      onPressed: () async {
                        final image = await screenshotController.capture();
                        if (image == null) return;
                        await saveAndShare(image);
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const <Widget>[
                          Icon(
                            Icons.share,
                            color: Pallete.primary,
                          ),
                          SizedBox(width: 4),
                          Text(
                            "Bagikan",
                            style: TextStyle(color: Pallete.primary),
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
