import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_card_account.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/features/qrpayment/payment_qr.dart';
import 'package:bpd_aceh/features/qrtransfer/qrcode.dart';
import 'package:bpd_aceh/features/qrtransfer/transferqrbas.dart';
import 'package:flutter/material.dart';
// import 'package:image_picker_saver/image_picker_saver.dart';
// import 'package:image_gallery_saver/image_gallery_saver.dart';
import 'package:permission_handler/permission_handler.dart';
// import 'package:image_picker/image_picker.dart';
import 'package:qr_code_scanner/qr_code_scanner.dart';
// import 'package:flutter_qr_reader/flutter_qr_reader.dart'; //IOS
import 'package:qrscan/qrscan.dart' as scanner; //ANDROIRD

class TransferQR extends StatefulWidget {
  static const routeName = '/transferQR';

  const TransferQR({Key? key}) : super(key: key);

  @override
  _TransferQRState createState() => _TransferQRState();
}

class _TransferQRState extends State<TransferQR> {
  QRViewController? controller;
  GlobalKey qrKey = GlobalKey();
  var qrText = '';
  String barcode = "";
  String? data;

  // ignore: unused_field
  TextEditingController? _outputController;

  @override
  void initState() {
    if (controller != null) {
      controller!.resumeCamera();
    }
    super.initState();
    _outputController = TextEditingController();
  }

  @override
  void dispose() {
    // controller?.dispose();
    super.dispose();
  }

  _showQR() async {
    Map<String, Object> param = {};
    controller!.pauseCamera();
    final resp = await API.post(context, '/generateqr', param);
    // var resp = await API.post(context, _qrUrl, null);
    await Future.delayed(Duration.zero);
    if (resp['code'] == 0) {
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => Qrcode(
            qrStr: resp['qrCode'],
            qrName: resp['userAlias'],
            qrAcct: resp['accountNumber'],
          ),
        ),
      );
      controller!.resumeCamera();
    }
  }

  _postQR(onData) async {
    Map<String, Object> param = {};
    param['qrCode'] = onData;
    print(param['qrCode']);
    final resp = await API.post(context, '/qr/issuer/scanqr', param);
    if (resp['code'] != null && resp['code'] == 0) {
      String? merchantName = resp['merchantName'];
      String? merchantCity = resp['merchantCity'];
      num? amount = resp['transactionAmount'];
      String? amountString = resp['transactionAmountStr'];
      bool? flagInputNominal = resp['flagInputNominal'];
      bool? flagInputFee = resp['flagInputFee'];
      // double fee = double.parse(resp['fee'].toString());
      String? fee = resp['fee'];
      String? feeString = resp['feeStr'];
      // double fee1 = double.parse(resp['fee'].toString());
      // String nominal_MerchantStr = resp['transactionAmountStr'];

      controller!.dispose();

      return Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => PaymentQr(
            nameMerchant: merchantName,
            amount: amount,
            amountString: amountString,
            fee: fee,
            feeString: feeString,
            flagInputFee: flagInputFee,
            flagInputNominal: flagInputNominal,
            placeMerchant: merchantCity,
          ),
        ),
      );
    } else {
      const DialogBox().showImageDialog(
        buttonCancel: "Ok",
        isError: true,
        onCancel: () {
          controller!.resumeCamera();
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => const TransferQR(),
            ),
          );
          Navigator.pop(context);
        },
        context: context,
        message: resp['message'],
        // onOk: () {}
      );
      return;
    }
  }

  Future _scanImage(String onData) async {
    return await Future.sync(() async {
      controller!.pauseCamera();
      // controller.resumeCamera();
      // ignore: unnecessary_null_comparison
      if (onData != null) {
        if (onData.contains('bankaceh')) {
          var qrData = onData.split('-');

          var bnfAcctNo = qrData[1];
          var bnfAcctName = qrData[2];
          controller!.dispose();
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => TransferBasQR(
                bnfAcctNo: bnfAcctNo,
                bnfAcctName: bnfAcctName,
              ),
            ),
          );
        } else {
          _postQR(onData);
          // DialogBox().showImageDialog(
          //   buttonCancel: "Ok",
          //   isError: true,
          //   onCancel: () {
          //     controller.resumeCamera();
          //     Navigator.pushReplacement(
          //       context,
          //       MaterialPageRoute(
          //         builder: (context) => TransferQR(),
          //       ),
          //     );
          //     Navigator.pop(context);
          //   },
          //   context: context,
          //   message: "QR Code tidak dikenali.",
          //   // onOk: () {}
          // );
          return;
        }
      } else {
        const DialogBox().showImageDialog(
            buttonCancel: "Ok",
            isError: true,
            onCancel: () {
              Navigator.pop(context);
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) => const TransferQR(),
                ),
              );
            },
            context: context,
            message: "QR Code tidak dikenali.");
        return;
      }
    });
  }

  Future _scanPhoto() async {
    // // IOS
    // this.controller.pauseCamera();
    // var image = await ImagePickerSaver.pickImage(source: ImageSource.gallery);
    // if (image == null) return;
    // final onData = await FlutterQrReader.imgScan(image);
    // return _scanImage(onData);

    // ANDROID
    await Permission.storage.request().isGranted;
    var onData = await scanner.scanPhoto();
    print('data = ' + onData.toString());
    return _scanImage(onData);
  }

  // var data;
  @override
  Widget build(BuildContext context) {
    void _onQRViewCreated(QRViewController controller) async {
      this.controller = controller;
      controller.scannedDataStream.listen((onData) async {
        // return _scanImage(onData);
      });
    }

    return Scaffold(
      backgroundColor: Theme.of(context).backgroundColor,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text(
          'Scan QR',
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'Poppins',
          ),
        ),
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      body: SafeArea(
        child: Container(
          color: Colors.white,
          child: Column(
            children: <Widget>[
              ISTCardAccount(
                context: context,
                menu: ISTMenu.qr,
              ),
              const SizedBox(height: 16),
              Expanded(
                flex: 1,
                child: SafeArea(
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    child: Stack(
                      children: <Widget>[
                        Center(
                          child: QRView(
                            key: qrKey,
                            onQRViewCreated: _onQRViewCreated,
                          ),
                        ),
                        const Center(
                          child: Padding(
                            padding: EdgeInsets.all(50.0),
                            child: Image(
                              image: AssetImage(
                                  'assets/images/vector-qr-scan.png'),
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.bottomRight,
                          child: Padding(
                            padding: const EdgeInsets.all(10.0),
                            child: InkWell(
                              autofocus: true,
                              onTap: _scanPhoto,
                              child: const Icon(
                                Icons.camera_alt,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Container(
                color: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 32),
                child: ISTOutlineButton(
                  onPressed: () {
                    controller!.pauseCamera();
                    _showQR();
                  },
                  text: 'TAMPILKAN QR',
                ),
              ),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }
}
