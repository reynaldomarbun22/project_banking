import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/qrtransfer/qrimages.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screen_wake/flutter_screen_wake.dart';

class Qrcode extends StatefulWidget {
  static const routeName = '/qrcode';
  final String? qrStr;
  final String? qrName;
  final String? qrAcct;

  const Qrcode({
    Key? key,
    this.qrStr,
    this.qrName,
    this.qrAcct,
  }) : super(key: key);

  @override
  _QrcodeState createState() => _QrcodeState();
}

class _QrcodeState extends State<Qrcode> {
  final double _brightness = 1.0;
  double? _bnow;
  bool showBalance = false;

  @override
  initState() {
    super.initState();
    initPlatformState();
  }

  initPlatformState() async {
    double brightness = await FlutterScreenWake.brightness;
    setState(() {
      _bnow = brightness;
      FlutterScreenWake.setBrightness(_brightness);
    });
  }

  @override
  void dispose() {
    FlutterScreenWake.setBrightness(_bnow!);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text(
          'Tampilkan QR',
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'Poppins',
          ),
        ),
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      body: Container(
        color: Colors.white,
        child: SingleChildScrollView(
          child: Center(
              child: Container(
                  // color: Colors.white,
                  padding: const EdgeInsets.all(8.0),
                  child: Qrimages(
                    qrStr: widget.qrStr,
                    qrName: widget.qrName,
                    qrAcct: widget.qrAcct,
                  ))),
        ),
      ),
    );
  }
}
