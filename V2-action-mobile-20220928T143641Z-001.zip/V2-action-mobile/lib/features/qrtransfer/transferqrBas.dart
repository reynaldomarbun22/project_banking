import 'dart:io';

import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_card_account.dart';
import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/ist_style.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/core/utils/string_utils.dart';
import 'package:bpd_aceh/features/qrtransfer/scanqrtransfer.dart';
import 'package:bpd_aceh/features/transfer/transferAntarBAS/confrimBAS/transfer_confirm_bas.dart';
import 'package:currency_text_input_formatter/currency_text_input_formatter.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qr_code_scanner/qr_code_scanner.dart';

class TransferBasQR extends StatefulWidget {
  static const routeName = '/transferBASQR';
  final String? bnfAcctNo;
  final String? bnfAcctName;

  const TransferBasQR({Key? key, this.bnfAcctNo, this.bnfAcctName})
      : super(key: key);

  @override
  _TransferBasQRState createState() =>
      // ignore: no_logic_in_create_state
      _TransferBasQRState(bnfAcctNo, bnfAcctName);
}

class _TransferBasQRState extends State<TransferBasQR> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final String? bnfAcctNo;
  final String? bnfAcctName;
  QRViewController? controller;

  _TransferBasQRState(this.bnfAcctNo, this.bnfAcctName);

  @override
  void initState() {
    if (bnfAcctNo != null && bnfAcctName != null) {
      _noRekBAScontroller.text = bnfAcctNo!;
      fromQR = true;
    }

    super.initState();
  }

  _doTransfer() async {
    if (_doValidate()) {
      Map<String, Object> param = {};

      param['destAcctNo'] = _noRekBAScontroller.text.replaceAll("-", "");
      param['amount'] =
          int.parse(_nominalBAScontroller.text.replaceAll(".", ""));
      param['memo'] = _catatanBAScontroller.text;

      final resp = await API.post(context, '/transfer/inquiry', param);
      if (resp == null) return;
      if (resp['code'] == 0) {
        List<ISTConfirmationItem> listParam = [];
        List<dynamic> listMap = resp['resi'];
        for (var item in listMap) {
          ISTConfirmationItem itemParam =
              ISTConfirmationItem(key: item['key'], value: item['value']);
          listParam.add(itemParam);
        }
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => TransferConfirmPageBAS(
                      list: listParam,
                    )));
      } else {
        const DialogBox().showImageDialog(
            message: resp['message'],
            isError: true,
            image: const Image(
              image: AssetImage('assets/images/icon-failed.png'),
            ),
            buttonCancel: 'OK',
            onOk: () {},
            context: context);
      }
    }
  }

  final _noRekBAScontroller = TextEditingController();
  final _catatanBAScontroller = TextEditingController();
  // ignore: unused_field
  final _noRefBAScontroller = TextEditingController();

  // final _nominalBAScontroller = ISTConstants().moneyMaskedController;
  final _nominalBAScontroller = TextEditingController();

  // ignore: unused_field
  bool _autoValidate = false;
  bool fromQR = false;

  bool _doValidate() {
    if (_formKey.currentState!.validate()) {
      return true;
    } else {
      setState(() {
        _autoValidate = true;
      });
      return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: GestureDetector(
          onTap: () async {
            FocusScope.of(context).requestFocus(FocusNode());
            await Future.delayed(const Duration(milliseconds: 500));
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => const TransferQR(),
              ),
            );
          },
          child: const IconButton(
            icon: Icon(Icons.arrow_back_ios, color: Colors.white),
            onPressed: null,
          ),
        ),
        centerTitle: true,
        title: const Text(
          'Transfer antar BAS',
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'Poppins',
          ),
        ),
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      body: GestureDetector(
        onTap: () {
          if (Platform.isIOS) hideKeyboard(context);
        },
        child: Container(
          color: Colors.white,
          child: SingleChildScrollView(
            child: Column(
              children: <Widget>[
                ISTCardAccount(
                  context: context,
                  menu: ISTMenu.transfer,
                ),
                const SizedBox(
                  height: 16,
                ),
                Container(
                  padding: const EdgeInsets.only(left: 16, right: 16),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Form(
                          // ignore: deprecated_member_use
                          autovalidateMode: AutovalidateMode.always,
                          key: _formKey,
                          child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: <Widget>[
                                Container(
                                    alignment: Alignment.topLeft,
                                    child: const Text(
                                      'Ke Rekening:',
                                    )),
                                fromQR
                                    ? Container(
                                        alignment: Alignment.topLeft,
                                        padding: const EdgeInsets.only(bottom: 8),
                                        child: Text(
                                          '$bnfAcctNo - $bnfAcctName',
                                        ))
                                    : Container(
                                        alignment: Alignment.topLeft,
                                        child: TextFormField(
                                          keyboardType: TextInputType.number,
                                          validator: (val) {
                                            if (val!.isEmpty || val == '') {
                                              return "Mohon diisi";
                                            } else {
                                              return null;
                                            }
                                          },
                                          inputFormatters: [
                                            // ignore: deprecated_member_use
                                            FilteringTextInputFormatter
                                                .digitsOnly,
                                          ],
                                          controller: _noRekBAScontroller,
                                          maxLength:
                                              ISTConstants.acctToMaxLength,
                                          decoration: const InputDecoration(
                                            counterText: '',
                                            hintText:
                                                'Masukkan no. rekening tujuan',
                                            hintStyle: ISTStyle.hintStyle,
                                          ),
                                        ),
                                      ),
                                const SizedBox(
                                  height: 8,
                                ),
                                Container(
                                  alignment: Alignment.topLeft,
                                  child: const Text(
                                    'Nominal :',
                                    style: TextStyle(color: Colors.black87),
                                  ),
                                ),
                                Container(
                                  alignment: Alignment.topLeft,
                                  child: TextFormField(
                                    validator: (val) {
                                      if (val!.isEmpty || val == '0') {
                                        return "Mohon diisi";
                                      } else {
                                        return null;
                                      }
                                    },
                                    inputFormatters: [
                                      CurrencyTextInputFormatter(
                                        decimalDigits: 0,
                                        locale: 'id_ID',
                                        name: '',
                                      )
                                    ],
                                    controller: _nominalBAScontroller,
                                    maxLength: ISTConstants.nominalMaxLength,
                                    keyboardType: TextInputType.number,
                                    decoration: InputDecoration(
                                      counterText: '',
                                      prefixStyle: const TextStyle(
                                        color: Colors.black,
                                      ),
                                      hintText: 'Masukkan nominal',
                                      hintStyle: ISTStyle.hintStyle,
                                      isDense: true,
                                      prefixIcon: Text(
                                        "IDR ",
                                        style: TextStyle(
                                            fontSize: Theme.of(context)
                                                .textTheme
                                                .subtitle1!
                                                .fontSize),
                                      ),
                                      prefixIconConstraints: const BoxConstraints(
                                          minWidth: 0, minHeight: 0),
                                    ),
                                  ),
                                ),
                                // Container(
                                //   alignment: Alignment.topLeft,
                                //   child: TextFormField(
                                //     validator: (val) {
                                //       if (val.isEmpty || val == null) {
                                //         return "Mohon diisi";
                                //       } else {
                                //         return null;
                                //       }
                                //     },
                                //     inputFormatters: [
                                //       CurrencyTextInputFormatter(
                                //         decimalDigits: 0,
                                //       )
                                //     ],
                                //     // inputFormatters: [
                                //     //   // ignore: deprecated_member_use
                                //     //   FilteringTextInputFormatter.digitsOnly,
                                //     // ],
                                //     controller: _nominalBAScontroller,
                                //     maxLength: ISTConstants.NOMINAL_MAX_LENGTH,
                                //     // onChanged: (value) {
                                //     //   if (_nominalBAScontroller.text
                                //     //       .trim()
                                //     //       .isEmpty) {
                                //     //     _nominalBAScontroller.text = '';
                                //     //   }
                                //     // },
                                //     keyboardType: TextInputType.number,
                                //     decoration: InputDecoration(
                                //       counterText: '',
                                //       prefixIcon: Text(
                                //         "IDR ",
                                //         style: TextStyle(
                                //             fontSize: Theme.of(context)
                                //                 .textTheme
                                //                 .subtitle1
                                //                 .fontSize),
                                //       ),
                                //       // prefixText: 'IDR ',
                                //       // prefixStyle: TextStyle(
                                //       //   color: Colors.black,
                                //       // ),
                                //       hintText: 'Masukkan nominal',
                                //       hintStyle: ISTStyle.HINT_STYLE,
                                //     ),
                                //   ),
                                // ),
                                const SizedBox(
                                  height: 8,
                                ),
                                Container(
                                  alignment: Alignment.topLeft,
                                  child: const Text(
                                    'Catatan :',
                                    style: TextStyle(color: Colors.black87),
                                  ),
                                ),
                                Container(
                                  alignment: Alignment.topLeft,
                                  child: TextField(
                                    controller: _catatanBAScontroller,
                                    inputFormatters: [
                                      StringUtils.alphaNumeric(),
                                    ],
                                    maxLength: ISTConstants.catatanMaxLength,
                                    decoration: const InputDecoration(
                                      hintText: 'Masukkan catatan',
                                      hintStyle: ISTStyle.hintStyle,
                                    ),
                                  ),
                                ),
                                const SizedBox(
                                  height: 16,
                                ),
                              ]),
                        ),
                      ]),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: ISTOutlineButton(
                    onPressed: () {
                      _doTransfer();
                    },
                    text: 'Lanjut',
                  ),
                ),
                const SizedBox(
                  height: 16,
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  void hideKeyboard(BuildContext context) {
    FocusScopeNode currentFocus = FocusScope.of(context);
    if (!currentFocus.hasPrimaryFocus && currentFocus.focusedChild != null) {
      FocusManager.instance.primaryFocus!.unfocus();
    }
  }
}
