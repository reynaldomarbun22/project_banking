import 'dart:io';

import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/core/utils/package_utils.dart';
import 'package:bpd_aceh/features/landing/landing.dart';
import 'package:bpd_aceh/features/login/login.dart';
import 'package:bpd_aceh/features/onboarding/pages/onboarding_page.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_jailbreak_detection/flutter_jailbreak_detection.dart';
import 'package:url_launcher/url_launcher.dart';

class Splash extends StatefulWidget {
  static const routeName = '/splash';

  const Splash({Key? key}) : super(key: key);

  @override
  _SplashState createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  String? version = '';

  // Future<String> _getVersion() async {
  //   var _version = await PackageUtils.getVersion();
  //   setState(() {
  //     version = _version;
  //   });
  //   return version;
  // }

  _getVersion() async {
    var _version = await PackageUtils.getVersion();
    setState(() {
      version = _version;
    });
    _checkVersion();
  }

  @override
  void initState() {
    _getVersion();

    super.initState();
    // _loading();
  }

  _loading() async {
    await Future.delayed(const Duration(milliseconds: 1500));

    // bool isJailBroken = await FlutterJailbreakDetection.jailbroken;
    // ignore: unused_local_variable
    // bool developerMode = await FlutterJailbreakDetection.developerMode;
    // if (isJailBroken) {
    //   const DialogBox().showErrorDialog(
    //     icon: Icons.warning,
    //     context: context,
    //     message: "Terdeteksi jailbreak / root, aplikasi akan menutup otomatis",
    //   );
    //   await Future.delayed(const Duration(milliseconds: 3000));
    //   exit(0);
    // }

    await ISTConstants().setConstants(ISTConstants.loggedInKey, "");
    //tommorow fixing this
    final _agree =
        await ISTConstants().getConstants(ISTConstants.agreeTermsAndCondition);
    // ignore: unused_local_variable
    final _wasLoggedIn =
        await ISTConstants().getConstants(ISTConstants.authWasLoggedIn);
    //tommorow fixing this
    if (_agree == null) {
      Navigator.pushReplacementNamed(context, LandingPageScreen.routeName);
      Navigator.pushNamed(context, LoginPage.routeName);
      Navigator.pushReplacementNamed(context, OnBoarding.routeName);
      return;
    }

    if (!_agree) {
      Navigator.pushReplacementNamed(context, OnBoarding.routeName);
    } else {
      // final _loggedIn =
      //     await ISTConstants().getConstants(ISTConstants.AUTH_LOGGED_IN);
      // if (_loggedIn != null && _loggedIn == true) {
      //   Navigator.pushReplacementNamed(context, HomePage.routeName);
      //   return;
      // }
      final _wasLoggedIn =
          await ISTConstants().getConstants(ISTConstants.authWasLoggedIn);
      if (_wasLoggedIn != null && _wasLoggedIn == true) {
        Navigator.pushReplacementNamed(context, LandingPageScreen.routeName);
        Navigator.pushNamed(context, LoginPage.routeName);
        return;
      }
      Navigator.pushReplacementNamed(context, LandingPageScreen.routeName);
    }
  }

  void _launchMaps(String url) async {
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw ' Could not open maps';
    }
  }

  _checkVersion() async {
    Map<String, Object> param = {};
    // String version = await PackageUtils.getVersion();
    param['appVersion'] = version ?? '';
    if (Platform.isIOS) {
      param['appDevice'] = "ios";
    } else {
      param['appDevice'] = "android";
    }

    final resp =
        await API.postNoLoadingNoCookies(context, '/util/version', param);
    if (resp != null && resp['code'] != null && resp['code'] == 0) {
      _loading();
      //  print("SUCCES");
    } else {
      const DialogBox().showImageDialog(
          message: resp['message'] ?? "-",
          isError: false,
          buttonOk: "Update",
          onOk: () {
            if (Platform.isAndroid) {
              _launchMaps(resp['linkPlayStore']);
              if (resp['linkPlayStore'] == 'null') {
                exit(0);
              }
            } else {
              _launchMaps(resp['linkAppStore']);
              if (resp['linkAppStore'] == 'null') {
                exit(0);
              }
            }
          },
          context: context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Pallete.primary,
      body: SafeArea(
        child: Stack(
          children: <Widget>[
            Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const <Widget>[
                  Image(
                    alignment: Alignment.center,
                    width: 250,
                    image: AssetImage('assets/images/logo-app.png'),
                  )
                ],
              ),
            ),
            Column(
              children: <Widget>[
                const Spacer(),
                Row(
                  children: <Widget>[
                    const Expanded(
                      flex: 1,
                      child: Image(
                        alignment: Alignment.center,
                        width: 250,
                        image: AssetImage('assets/images/bank-logo.png'),
                      ),
                    ),
                    const SizedBox(
                      width: 32,
                    ),
                    Expanded(
                      flex: 2,
                      child: Padding(
                        padding: const EdgeInsets.all(8),
                        child: Text(
                          "PT. Bank Aceh Syariah terdaftar dan diawasi oleh Otoritas Jasa Keuangan (OJK) serta dijamin oleh Lembaga Penjamin Simpanan (LPS)",
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: Theme.of(context)
                                  .textTheme
                                  .overline!
                                  .fontSize),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Text(
                  'Version ' + version!,
                  style: TextStyle(
                      color: Colors.grey,
                      fontSize: Theme.of(context).textTheme.overline!.fontSize),
                ),
                const SizedBox(height: 16)
              ],
            ),
          ],
        ),
      ),
    );
  }
}
