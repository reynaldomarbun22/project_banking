import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/onboarding/widgets/slides.dart';
import 'package:flutter/material.dart';
import 'package:card_swiper/card_swiper.dart';

class OnBoarding extends StatelessWidget {
  static const routeName = 'onboarding';

  const OnBoarding({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        return Future.value(
            true); //return a `Future` with false value so this route cant be popped or closed.
      },
      child: Scaffold(
        backgroundColor: Pallete.primary,
        extendBodyBehindAppBar: true,
        body: SafeArea(
          child: Swiper.children(
            autoplay: false,
            // index: 0,
            loop: false,
            pagination: SwiperCustomPagination(
                builder: (BuildContext context, SwiperPluginConfig? config) {
              return config == null
                  ? Container()
                  : Align(
                      alignment: Alignment.bottomCenter,
                      child: Container(
                        height: 32,
                        width: double.infinity,
                        child: Align(
                          alignment: Alignment.center,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Container(
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 4),
                                width: 24,
                                height: 8,
                                decoration: BoxDecoration(
                                    color: config.activeIndex == 0
                                        ? Colors.white
                                        : Colors.white24,
                                    borderRadius: BorderRadius.circular(10)),
                              ),
                              const SizedBox(width: 8),
                              Container(
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 4),
                                width: 24,
                                height: 8,
                                decoration: BoxDecoration(
                                    color: config.activeIndex == 1
                                        ? Colors.white
                                        : Colors.white24,
                                    borderRadius: BorderRadius.circular(10)),
                              ),
                              const SizedBox(width: 8),
                              Container(
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 4),
                                width: 24,
                                height: 8,
                                decoration: BoxDecoration(
                                    color: config.activeIndex == 2
                                        ? Colors.white
                                        : Colors.white24,
                                    borderRadius: BorderRadius.circular(10)),
                              ),
                            ],
                          ),
                        ),
                        color: Colors.transparent,
                      ),
                    );
            }),
            //  SwiperPagination(
            //   margin: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 4.0),
            //   builder: DotSwiperPaginationBuilder(
            //       color: Colors.white24,
            //       activeColor: Colors.white,
            //       size: 6.5,
            //       activeSize: 9.0),
            // ),
            children: _getPages(context, Slides.listSlide(context)),
          ),
        ),
      ),
    );
  }

  List<Widget> _getPages(context, pages) {
    List<Widget> widgets = [];
    var lengthOnBoard = pages.length;
    for (int i = 0; i < lengthOnBoard; i++) {
      Slides page = pages[i];
      widgets.add(_buildOnBoarding(context, page));
    }
    return widgets;
  }

  _buildOnBoarding(context, page) {
    return Padding(
      padding: const EdgeInsets.all(0),
      child: Container(
        color: Colors.transparent,
        child: Center(
            child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Expanded(
              flex: 16,
              child: Container(
                  alignment: Alignment.bottomCenter,
                  child: Image(image: AssetImage(page.image))),
            ),
            const Spacer(),
            Expanded(
              flex: 4,
              child: Column(children: <Widget>[
                Padding(
                  padding: const EdgeInsets.only(left: 8.0, right: 8.0),
                  child: Text(page.title,
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.white).copyWith(
                          fontSize:
                              Theme.of(context).textTheme.headline6!.fontSize)),
                ),
                const SizedBox(
                  height: 8,
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    left: 16.0,
                    right: 16.0,
                  ),
                  child: Text(page.description,
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.white).copyWith(
                          fontSize:
                              Theme.of(context).textTheme.bodyText2!.fontSize)),
                ),
                const Spacer(),
              ]),
            ),
            page.extraWidget == null
                ? Container(
                    height: 45,
                  )
                : Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: page.extraWidget,
                  ),
            const SizedBox(
              height: 32,
            )
          ],
        )),
      ),
    );
  }
}
