import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/features/termcondition/terms_condition.dart';
import 'package:flutter/material.dart';

class Slides {
  String? title;
  String? description;
  String? image;
  Widget? extraWidget;

  Slides({this.title, this.description, this.extraWidget, this.image}) {
    extraWidget ??= null;
  }

  static List<Slides> listSlide(context) {
    return [
      Slides(
        image: "assets/images/01.png",
        title: "Selamat Datang",
        description: "Aplikasi ini adalah layanan perbankan\ndari Bank Aceh",
      ),
      Slides(
        image: "assets/images/02.png",
        title: "Layanan Cepat, Mudah dan Handal",
        description: "Nikmati berbagai transaksi\nperbankan di tangan Anda",
      ),
      Slides(
        image: "assets/images/03.png",
        title: "Kepercayaan dan Kemitraan",
        description: "Bersama kami lebih amanah\n",
        extraWidget: ISTOutlineButton.white(
          onPressed: () {
            Navigator.pushReplacementNamed(
                context, TermsAndCondition.routeName);
          },
          text: 'Lanjut',
        ),
      ),
    ];
  }
}
