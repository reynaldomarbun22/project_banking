import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_pin_otp.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/features/inbox/inbox_db.dart';
import 'package:bpd_aceh/features/landing/landing.dart';
import 'package:bpd_aceh/features/login/login.dart';
import 'package:bpd_aceh/features/splash/splash.dart';
import 'package:flutter/material.dart';

class AfterUnlinkOTP extends StatefulWidget {
  static const String routeName = "/AfterUnlinkOTP";
  final Map<String, Object>? param;

  const AfterUnlinkOTP({Key? key, this.param}) : super(key: key);
  @override
  _AfterUnlinkOTPState createState() => _AfterUnlinkOTPState();
}

class _AfterUnlinkOTPState extends State<AfterUnlinkOTP> {
  _deleteInbox() async {
    // print(item.id);
    InboxDBRepository repo = InboxDBRepository();
    await repo.open();
    await repo.deleteAll();

    await repo.close();
  }

  _doOTP(value) async {
    Map<String, Object> param = {};
    param['otp'] = value;
    final resp = await API.post(context, '/login/newdevice/link', param);
    if (resp['code'] == 0) {
      const DialogBox().showImageDialog(
          title:
              'Anda berhasil menghubungkan perangkat baru Anda.\nSilakan Login.',
          buttonOk: 'Login',
          isError: false,
          image: const Image(
            image: AssetImage('assets/images/icon-success.png'),
          ),
          onOk: () {
            _deleteInbox();
            Navigator.pushNamedAndRemoveUntil(
                context,
                LandingPageScreen.routeName,
                ModalRoute.withName(Splash.routeName));
            Navigator.pushNamed(context, LoginPage.routeName);
          },
          context: context,
          message: null);
    } else {
      const DialogBox().showImageDialog(
          message: resp['message'],
          isError: true,
          image: const Image(
            image: AssetImage('assets/images/icon-failed.png'),
          ),
          buttonCancel: 'OK',
          onOk: () {},
          context: context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Pallete.primary,
      body: SafeArea(
        bottom: false,
        child: ISTOTP(
          appBarTitle: 'Perangkat Baru',
          title: 'Masukkan 6 digit Kode OTP Anda',
          onFinishedVal: (value) {
            _doOTP(value);
          },
          param: widget.param,
          state: 'OTPlinkdevice',
        ),
      ),
    );
  }
}
