import 'package:bpd_aceh/components/example/ist_forgot_mpin.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/features/login/forgotmpin/confirm_new_mpin.dart';
import 'package:flutter/material.dart';

class CreateNewMPIN extends StatefulWidget {
  static const String routeName = "/mpin/forgot/newmpin";

  const CreateNewMPIN({Key? key}) : super(key: key);
  @override
  _CreateNewMPINState createState() => _CreateNewMPINState();
}

class _CreateNewMPINState extends State<CreateNewMPIN> {
  @override
  Widget build(BuildContext context) {
    return ISTForgotMPIN(
        title: 'Masukkan 6 Digit MPIN baru Anda',
        onFinishedVal: (value) {
          ISTConstants().setString(ISTConstants.mpinForgot, value);
          Navigator.pushNamed(context, ConfirmNewMpin.routeName);
        });
  }
}
