import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_style.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/crypto/ist_crypto.dart';
import 'package:bpd_aceh/core/utils/string_utils.dart';
import 'package:bpd_aceh/features/login/forgotmpin/otp_forgot_mpin.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_masked_text2/flutter_masked_text2.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';

class ForgotMPIN extends StatefulWidget {
  static const routeName = '/mpin/forgotmpin';

  const ForgotMPIN({Key? key}) : super(key: key);

  @override
  State<ForgotMPIN> createState() => _ForgotMPINState();
}

class _ForgotMPINState extends State<ForgotMPIN> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  // ignore: unused_field
  var _autoValidate = false;
  // final _pinController = MaskedTextController(mask: ("000000"));
  // final _atmController = MaskedTextController(mask: ("0000 0000 0000 0000"));
  // final _hpController = MaskedTextController(mask: ("000000000000000"));
  final _pinController = TextEditingController();
  final _atmController = TextEditingController();
  final _hpController = TextEditingController();
  final _emailController = TextEditingController();

  var maskFormatter = MaskTextInputFormatter(
      mask: '#### #### #### ####', filter: {"#": RegExp(r'[0-9]')});

  bool showPass = true;
  bool isLoading = false;
  bool _atmError = false;
  bool _pinError = false;
  bool _hpError = false;

  @override
  Widget build(BuildContext context) {
    bool _validateInputs() {
      if (_formKey.currentState!.validate()) {
        _formKey.currentState!.save();
        return true;
      } else {
        setState(() {
          _autoValidate = true;
        });
        return false;
      }
    }

    bool _doValidate() {
      if (_validateInputs() != true) return false;
      bool _success = true;
      if (_atmController.text.isEmpty) {
        setState(() {
          _atmError = true;
        });
        _success = false;
      } else {
        setState(() {
          _atmError = false;
        });
      }

      if (_pinController.text.isEmpty) {
        setState(() {
          _pinError = true;
        });
        _success = false;
      } else {
        setState(() {
          _pinError = false;
        });
      }
      if (_hpController.text.isEmpty) {
        setState(() {
          _hpError = true;
        });
        _success = false;
      } else {
        setState(() {
          _hpError = false;
        });
      }
      return _success;
    }

    _doValidateATMPIN() async {
      if (_doValidate()) {
        Map<String, Object> param = {};

        param['cardATM'] = _atmController.text.replaceAll(" ", "");
        final String pinEnc = await ISTCrypto.encryptAES(_pinController.text);
        param['pin'] = pinEnc;
        param['noHp'] = _hpController.text;
        param['email'] = _emailController.text;

        final resp = await API.post(context, '/forgot/validation', param);
        if (resp['code'] == 0) {
          _pinController.text = "";

          Navigator.pushNamed(context, OTPforgotMPIN.routeName,
              arguments: param);
        } else {
          _pinController.text = "";

          const DialogBox().showImageDialog(
              message: resp['message'],
              isError: true,
              image: const Image(
                image: AssetImage('assets/images/icon-failed.png'),
              ),
              buttonCancel: 'OK',
              onOk: () {},
              context: context);
        }
      }
    }

    String? validateEmail(String value) {
      Pattern pattern =
          r"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]"
          r"{0,253}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]"
          r"{0,253}[a-zA-Z0-9])?)*$";
      RegExp regex = RegExp(pattern as String);
      if (!regex.hasMatch(value)) {
        return 'Masukkan alamat email dengan benar';
      } else {
        return null;
      }
    }

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
            icon: const Icon(
              Icons.arrow_back_ios,
              color: Colors.white,
            ),
            onPressed: () {
              Navigator.pop(context);
            }),
        title: const Text(
          'Lupa MPIN',
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'Poppins',
          ),
        ),
        centerTitle: true,
        elevation: 0.0,
        iconTheme: const IconThemeData(color: Colors.black),
        backgroundColor: Pallete.primary,
      ),
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(children: <Widget>[
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Form(
              key: _formKey,
              autovalidateMode: AutovalidateMode.always,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const Text(
                    'Mohon masukkan data perbankan Anda',
                    style: TextStyle(fontSize: 16),
                  ),
                  const SizedBox(height: 32),
                  const Text('NOMOR HANDPHONE ANDA'),
                  TextFormField(
                    onFieldSubmitted: (String value) {
                      Navigator.pop(context, "ok");
                    },
                    onChanged: (val) {
                      setState(() {
                        if (val.isEmpty) {
                          _hpError = true;
                        } else {
                          _hpError = false;
                        }
                      });
                    },
                    maxLength: 14,
                    validator: (val) {
                      if (val!.length < 10) {
                        return "Nomor Handphone minimal 10 digit";
                      } else {
                        return null;
                      }
                    },
                    onSaved: (String? val) {
                      _hpController.text = val!;
                    },
                    keyboardType: TextInputType.number,
                    style: const TextStyle(fontSize: 16),
                    decoration: InputDecoration(
                      counterText: '',
                      hintText: 'Masukkan nomor Handphone Anda',
                      hintStyle: ISTStyle.hintStyle,
                      errorText: _hpError ? "Mohon diisi" : null,
                    ),
                    controller: _hpController,
                  ),
                  const SizedBox(height: 8),
                  const Text('EMAIL'),
                  TextFormField(
                    // maxLength: 14,
                    inputFormatters: [
                      // EMAILFormatter,
                      // ignore: deprecated_member_use
                      // FilteringTextInputFormatter.digitsOnly,
                      StringUtils.noSpace()
                    ],
                    onChanged: (val) {
                      setState(() {
                        if (val.isEmpty) {
                          _hpError = true;
                        } else {
                          _hpError = false;
                        }
                      });
                    },
                    // maxLength: 14,
                    validator: (val) {
                      if (val!.isEmpty) {
                        return "Mohon diisi";
                      } else if (validateEmail(val) != null) {
                        return 'Masukan EMAIL dengan benar';
                      } else {
                        return null;
                      }
                    },
                    onSaved: (String? val) {
                      _emailController.text = val!;
                    },
                    expands: false,
                    obscureText: false,
                    style: const TextStyle(fontSize: 16),
                    decoration: const InputDecoration(
                      counterText: '',
                      hintText: 'Masukkan EMAIL Anda ',
                      hintStyle: ISTStyle.hintStyle,
                      // errorText: _hpError ? "Mohon diisi" : null,
                    ),
                    controller: _emailController,
                  ),
                  const SizedBox(height: 8),
                  const Text('NOMOR KARTU ATM'),
                  TextFormField(
                    inputFormatters: [maskFormatter],
                    maxLength: 20,
                    onChanged: (val) {
                      setState(() {
                        if (val.isEmpty) {
                          _atmError = true;
                        } else {
                          _atmError = false;
                        }
                      });
                    },
                    validator: (val) {
                      if (val!.length < 16) {
                        return "Nomor kartu ATM Anda kurang dari 16 digit";
                      } else {
                        return null;
                      }
                    },
                    onSaved: (String? val) {
                      _atmController.text = val!;
                    },
                    enableInteractiveSelection: false,
                    expands: false,
                    obscureText: false,
                    keyboardType: TextInputType.number,
                    style: const TextStyle(fontSize: 16),
                    decoration: InputDecoration(
                      counterText: '',
                      hintText: 'Masukkan nomor Kartu ATM Anda',
                      hintStyle: ISTStyle.hintStyle,
                      errorText: _atmError ? "Mohon diisi" : null,
                    ),
                    controller: _atmController,
                  ),
                  const SizedBox(height: 8),
                  const Text('PIN ATM'),
                  TextFormField(
                    onChanged: (val) {
                      setState(() {
                        if (val.isEmpty) {
                          _pinError = true;
                        } else {
                          _pinError = false;
                        }
                      });
                    },
                    maxLength: 6,
                    expands: false,
                    obscureText: true,
                    keyboardType: TextInputType.number,
                    style: const TextStyle(fontSize: 16),
                    decoration: InputDecoration(
                      counterText: '',
                      hintText: 'Masukkan PIN ATM Anda',
                      hintStyle: ISTStyle.hintStyle,
                      errorText: _pinError ? "Mohon diisi" : null,
                    ),
                    validator: (val) {
                      if (val!.length < 6) {
                        return "PIN ATM Anda kurang dari 6 digit";
                      } else {
                        return null;
                      }
                    },
                    onSaved: (String? val) {
                      _pinController.text = val!;
                    },
                    controller: _pinController,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 30.0),
                    child: ISTOutlineButton(
                        onPressed: () {
                          _doValidateATMPIN();
                        },
                        text: 'Lanjut'),
                  ),
                ],
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
