import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/example/ist_forgot_mpin.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/core/crypto/ist_crypto.dart';
import 'package:bpd_aceh/features/login/login.dart';
import 'package:flutter/material.dart';

import '../../landing/landing.dart';
import '../../splash/splash.dart';

class ConfirmNewMpin extends StatefulWidget {
  static const String routeName = "/mpin/forgot/confirmnewmpin";

  const ConfirmNewMpin({Key? key}) : super(key: key);

  @override
  _ConfirmNewMpinState createState() => _ConfirmNewMpinState();
}

class _ConfirmNewMpinState extends State<ConfirmNewMpin> {
  @override
  Widget build(BuildContext context) {
    return ISTForgotMPIN(
      onFinishedVal: (value) async {
        var mpin = await ISTConstants().getString(ISTConstants.mpinForgot);
        if (value != mpin) {
          const DialogBox().showImageDialog(
              message: 'MPIN Tidak sesuai',
              isError: true,
              buttonCancel: 'OK',
              onOk: () {},
              context: context);
          return;
        }
        Map<String, Object> param = {};
        final String pinEnc = await ISTCrypto.encryptAES(value);
        param['mpin'] = pinEnc;

        final resp = await API.post(context, '/forgot/mpin', param);
        if (resp['code'] != null && resp['code'] == 0) {
          const DialogBox().showImageDialog(
              title: 'Anda berhasil mengganti MPIN Anda',
              message: resp['message'],
              buttonOk: 'Selesai',
              isError: false,
              image: const Image(
                image: AssetImage('assets/images/icon-success.png'),
              ),
              onOk: () {
                // Navigator.pushReplacementNamed(context, LoginPage.routeName);
                Navigator.pushNamedAndRemoveUntil(
                    context,
                    LandingPageScreen.routeName,
                    ModalRoute.withName(Splash.routeName));
                Navigator.pushNamed(context, LoginPage.routeName);

                // Navigator.pushNamed(context, LoginPage.routeName);
              },
              context: context);
        } else if (resp['code'] != null && resp['code'] != 0) {
          if (resp['code'] == -2019) {
            const DialogBox().showImageDialog(
                message: resp['message'],
                isError: true,
                buttonCancel: 'OK',
                onCancel: () {
                  Navigator.pop(context);
                  Navigator.pop(context);
                },
                onOk: () {},
                context: context);
          } else {
            const DialogBox().showImageDialog(
                message: resp['message'],
                isError: true,
                buttonCancel: 'OK',
                onOk: () {},
                context: context);
          }
        }
      },
      title: 'Konfirmasi 6 Digit MPIN Anda',
    );
  }
}
