import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_pin_otp.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/features/landing/landing.dart';
import 'package:bpd_aceh/features/login/login.dart';
import 'package:bpd_aceh/features/splash/splash.dart';
import 'package:flutter/material.dart';

class OTPforgotUsername extends StatefulWidget {
  static const String routeName = "/username/otpforgotUsername";
  final Map<String, Object>? param;

  const OTPforgotUsername({Key? key, this.param}) : super(key: key);
  @override
  _OTPforgotUsernameState createState() => _OTPforgotUsernameState();
}

class _OTPforgotUsernameState extends State<OTPforgotUsername> {
  _doOTP(value) async {
    Map<String, Object> param = {};

    param['otp'] = value;
    final resp = await API.post(context, '/forgot/otp', param);
    // final resp = await API.post(context, '/forgot/username', {});
    if (resp['code'] != null && resp['code'] == 0) {
      final resp1 = await API.post(context, '/forgot/username', {});
      if (resp1['code'] == 0) {
        const DialogBox().showImageDialog(
            title: 'Username Berhasil Dikirim Ke E-mail Anda',
            message: resp1['email'],
            message1: resp1['additionalInfo'],
            buttonOk: 'Selesai',
            isError: false,
            image: const Image(
              image: AssetImage('assets/images/icon-success.png'),
            ),
            onOk: () {
              Navigator.pushNamedAndRemoveUntil(
                  context,
                  LandingPageScreen.routeName,
                  ModalRoute.withName(Splash.routeName));
              Navigator.pushNamed(context, LoginPage.routeName);
            },
            context: context);
      } else {
        const DialogBox().showImageDialog(
            message: resp1['message'],
            isError: true,
            image: const Image(
              image: AssetImage('assets/images/icon-failed.png'),
            ),
            buttonCancel: 'OK',
            onOk: () {},
            context: context);
      }
    } else {
      const DialogBox().showImageDialog(
          message: resp['message'],
          isError: true,
          image: const Image(
            image: AssetImage('assets/images/icon-failed.png'),
          ),
          buttonCancel: 'OK',
          onCancel: () {
            if (resp['code'] == -1013) {
              setState(() {
                Navigator.pushNamedAndRemoveUntil(
                    context,
                    LandingPageScreen.routeName,
                    ModalRoute.withName(Splash.routeName));
                Navigator.pushNamed(context, LoginPage.routeName);
              });
            } else {
              Navigator.pop(context);
            }
          },
          onOk: () {},
          context: context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Pallete.primary,
      body: SafeArea(
        bottom: false,
        child: ISTOTP(
          appBarTitle: 'Lupa Username',
          title: 'Masukkan 6 digit Kode OTP Anda',
          onFinishedVal: (value) {
            _doOTP(value);
          },
          param: widget.param,
          state: 'OTPforgotusername',
        ),
      ),
    );
  }
}
