//import 'dart:io';
import 'dart:io';

import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_style.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/core/crypto/ist_crypto.dart';
import 'package:bpd_aceh/core/utils/package_utils.dart';
import 'package:bpd_aceh/core/utils/string_utils.dart';
import 'package:bpd_aceh/features/landing/landing.dart';
import 'package:bpd_aceh/features/login/afterUnlinkDevice/afterunlinkpage1.dart';
import 'package:bpd_aceh/features/login/creatempin/create_mpin.dart';
import 'package:bpd_aceh/features/login/forgotUsername/forgot_username.dart';
import 'package:bpd_aceh/features/login/forgotmpin/forgot_mpin.dart';
import 'package:bpd_aceh/features/login/forgotpassword/forgot_password.dart';
import 'package:bpd_aceh/features/home/home_page.dart';
import 'package:bpd_aceh/features/login/linkNewDevice/link_new_device_step1.dart';
import 'package:bpd_aceh/features/splash/splash.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:local_auth/auth_strings.dart';
import 'package:local_auth/local_auth.dart';
import 'package:url_launcher/url_launcher.dart';

class LoginPage extends StatefulWidget {
  static const routeName = '/login';

  const LoginPage({Key? key}) : super(key: key);

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
//  final Geolocator geolocator = Geolocator()..forceAndroidLocationManager;
//  Position _currentPosition;
//  String _currentAddress;
//  String first;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      extendBody: true,
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pushNamed(context, LandingPageScreen.routeName);
          },
          icon: const Icon(Icons.arrow_back_ios),
        ),
        title: const Text(
          'Login',
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'Poppins',
          ),
        ),
        centerTitle: true,
        elevation: 0.0,
        iconTheme: const IconThemeData(color: Colors.white),
        backgroundColor: Pallete.primary,
        systemOverlayStyle: const SystemUiOverlayStyle(
          statusBarColor: Pallete.thirdy,
        ),
      ),
      body: Container(
          color: Colors.white,
          child: ListView(
            children: const <Widget>[
              LoginForm(),
              // Row(
              //   mainAxisAlignment: MainAxisAlignment.spaceAround,
              //   children: <Widget>[
              //     ISTMenuContainer(
              //       onTap: null,
              //       image: Image.asset(
              //         'assets/images/icon-promo.png',
              //         width: 30,
              //       ),
              //       text: 'Promo & Edukasi',
              //       color: Colors.grey,
              //     ),
              //     ISTMenuContainer(
              //       onTap: () {
              //         // Navigator.pushNamed(context, TransferQRLogin.routeName);
              //       },
              //       image: Image.asset(
              //         'assets/images/icon-qr.png',
              //         width: 30,
              //       ),
              //       text: 'QR',
              //       color: Colors.grey,
              //     ),
              //     ISTMenuContainer(
              //       onTap: () {
              //         Navigator.pushNamed(context, SchedulePray.routeName);
              //       },
              //       image: Image.asset(
              //         'assets/images/icon-jadwal.png',
              //         width: 30,
              //       ),
              //       // color: Colors.grey,
              //       text: 'Jadwal Sholat',
              //       // color: Colors.grey,
              //     ),
              //   ],
              // ),
              SizedBox(
                height: 8,
              )
            ],
          )),
      // bottomNavigationBar: BottomNavigationBar(
      //     backgroundColor: Colors.white,
      //     elevation: 0.0,
      //     type: BottomNavigationBarType.fixed,
      //     selectedLabelStyle: TextStyle(
      //         color: Colors.grey,
      //         fontSize: Theme.of(context).textTheme.caption.fontSize),
      //     unselectedLabelStyle: TextStyle(
      //         color: Colors.grey,
      //         fontSize: Theme.of(context).textTheme.caption.fontSize),
      //     unselectedItemColor: Colors.grey,
      //     items: <BottomNavigationBarItem>[
      //       BottomNavigationBarItem(
      //         icon: Image(
      //           image: AssetImage('assets/images/icon-promo.png',),
      //           width: 30,
      //         ),
      //         title: Text(
      //           'Promo & Edukasi',
      //           style: TextStyle(color: Colors.grey),
      //         ),
      //       ),
      //       BottomNavigationBarItem(
      //         icon: Image(
      //           image: AssetImage('assets/images/icon-qr.png'),
      //           width: 30,
      //         ),
      //         title: Text(
      //           'QR',
      //         ),
      //       ),
      //       BottomNavigationBarItem(
      //         icon: Image(
      //           image: AssetImage('assets/images/icon-jadwal.png'),
      //           width: 30,
      //         ),
      //         title: Text(
      //           'Jadwal Sholat',
      //         ),
      //       ),
      //     ]),
    );
  }
}

class LoginForm extends StatefulWidget {
  const LoginForm({Key? key}) : super(key: key);

  @override
  State<LoginForm> createState() => _LoginFormState();
}

class _LoginFormState extends State<LoginForm> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  // ignore: unused_field
  bool _autoValidate = false;
  bool? _biometricEnabled = false;

  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();

  bool showPass = true;
  bool isLoading = false;

  String? version = '';

  // Future<String> _getVersion() async {
  //   var _version = await PackageUtils.getVersion();
  //   setState(() {
  //     version = _version;
  //   });
  //   return version;
  // }

  _getVersion() async {
    var _version = await PackageUtils.getVersion();
    setState(() {
      version = _version;
    });
    _checkVersion();
  }

  bool _validateInputs() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      return true;
    } else {
      setState(() {
        _autoValidate = true;
      });
      return false;
    }
  }

  @override
  void initState() {
    // _getConst();
    _getVersion();

    // _getStatusBiometrics();
    // _exampleLogin();
    super.initState();
  }

  // ignore: unused_element
  _exampleLogin() {
    setState(() {
      _usernameController.text = "reynaldo";
      _passwordController.text = "password1";
    });
  }

  // ignore: unused_element
  _getStatusBiometrics() async {
    setState(() {
      isLoading = true;
    });
    final resp =
        await API.postNoLoadingNoCookies(context, "/biometric/status", {});
    if (resp['code'] != null && resp['code'] == 0 && resp['status'] != null) {
      setState(() {
        _biometricEnabled = resp['status'];
      });
    } else {
      setState(() {
        _biometricEnabled = false;
      });
    }
    final _bioSNKVisited = await ISTConstants()
        .getConstants(ISTConstants.biometricsTermsAndCondition);
    if (_bioSNKVisited == null || _bioSNKVisited == false) {
      _biometricEnabled = false;
    }
    await ISTConstants()
        .setConstants(ISTConstants.biometricStatus, _biometricEnabled);
    setState(() {
      isLoading = false;
    });
  }

  _onLoginButtonPressed() async {
    if (_validateInputs()) {
      Map<String, Object> param = {};
      param['username'] = _usernameController.text;
      // final password = await ISTCrypto.encryptAES(_passwordController.text)
      param['password'] = await ISTCrypto.encryptAES(_passwordController.text);
      // param['password'] = password;
      param['appVersion'] = version ?? '';
      if (Platform.isIOS) {
        param['appDevice'] = "ios";
      } else {
        param['appDevice'] = "android";
      }
      final resp = await API.postNoCookies(context, '/login', param);
      if (resp != null && resp['code'] != null && resp['code'] == 0) {
        ISTConstants().setConstants(ISTConstants.authWasLoggedIn, true);
        ISTConstants().setConstants(ISTConstants.loggedInKey, resp['authKey']);

        // if (!_validateInputs()) return;
        // ISTConstants()
        //     .setConstants(ISTConstants.loggedInKey, resp['authKey']);
        Navigator.pushNamedAndRemoveUntil(
            context, HomePage.routeName, ModalRoute.withName(Splash.routeName));
      } else if (resp != null && resp['code'] == 1002) {
        ISTConstants().setConstants(ISTConstants.authWasLoggedIn, true);
        const DialogBox().showImageDialog(
            message:
                'Anda belum memiliki MPIN\nsilakan tekan tombol lanjut\nuntuk membuat MPIN Anda.',
            isError: false,
            buttonOk: 'Lanjut',
            onOk: () {
              setState(() {
                _passwordController.text = "";
              });
              Navigator.pop(context);
              Navigator.pushNamed(context, CreateMpin.routeName);
            },
            context: context);
      } else if (resp != null && resp['code'] == 1003) {
        ISTConstants().setConstants(ISTConstants.authWasLoggedIn, true);
        const DialogBox().showImageDialog(
            message:
                'Pengguna masih terhubung dengan perangkat lain. Apakah anda ingin menghubungkan dengan perangkat ini ?',
            isError: false,
            buttonOk: 'Hubungkan',
            buttonCancel: 'Tidak',
            onOk: () {
              Navigator.pop(context);
              Navigator.pushNamed(context, LinkNewDeviceStep1.routeName);
            },
            context: context);
      } else if (resp != null && resp['code'] == 1005) {
        ISTConstants().setConstants(ISTConstants.authWasLoggedIn, true);
        const DialogBox().showImageDialog(
            message:
                'Pengguna masih terhubung dengan perangkat lain. Apakah anda ingin menghubungkan dengan perangkat ini ?',
            isError: false,
            buttonOk: 'Hubungkan',
            buttonCancel: 'Tidak',
            onOk: () {
              Navigator.pop(context);
              Navigator.pushNamed(context, AfterUnlinkStep1.routeName);
            },
            context: context);
      } else if (resp != null && resp['code'] == -1) {
        const DialogBox().showImageDialog(
            message: resp['message'],
            isError: false,
            buttonOk: "Update",
            onOk: () {
              if (Platform.isAndroid) {
                _launchMaps(resp['linkPlayStore']);
              } else {
                _launchMaps(resp['linkAppStore']);
              }
            },
            context: context);
      } else if (resp != null && resp['code'] != 0 && resp['code'] != 1002) {
        const DialogBox().showImageDialog(
            message: resp['message'],
            isError: true,
            image: const Image(
              image: AssetImage('assets/images/icon-failed.png'),
            ),
            buttonCancel: 'OK',
            onOk: () {},
            context: context);
      }
    }
  }

  _doLoginBiometrics() async {
    Map<String, Object> param = {};
    param['appVersion'] = version ?? '';
    if (Platform.isIOS) {
      param['appDevice'] = "ios";
    } else {
      param['appDevice'] = "android";
    }
    final resp = await API.postNoCookies(context, '/login/biometric', param);
    if (resp['code'] != null && resp['code'] == 0) {
      Navigator.pushNamed(context, HomePage.routeName);
    } else if (resp != null && resp['code'] == -1) {
      const DialogBox().showImageDialog(
          message: resp['message'],
          isError: false,
          buttonOk: "Update",
          onOk: () {
            if (Platform.isAndroid) {
              _launchMaps(resp['linkPlayStore']);
            } else {
              _launchMaps(resp['linkAppStore']);
            }
          },
          context: context);
    } else if (resp['code'] != null && resp['code'] != 0) {
      const DialogBox().showImageDialog(
          message: resp['message'],
          isError: true,
          buttonCancel: 'OK',
          onOk: () {},
          context: context);
    }
  }

  _checkBiometrics() async {
    var localAuth = LocalAuthentication();
    List<BiometricType> availableBiometrics =
        await localAuth.getAvailableBiometrics();
    if (availableBiometrics.isEmpty) {
      const DialogBox().showImageDialog(
          message:
              'Biometrik tidak ditemukan, silahkan cek pengaturan biometrik di device anda',
          isError: true,
          image: const Image(
            image: AssetImage('assets/images/icon-failed.png'),
          ),
          buttonCancel: 'OK',
          onOk: () {},
          context: context);
    }
    bool auth = false;
    if (Platform.isIOS) {
      if (availableBiometrics.contains(BiometricType.face)) {
        // Face ID.
        const iosStrings = IOSAuthMessages(
            cancelButton: 'cancel',
            goToSettingsButton: 'settings',
            goToSettingsDescription: 'Please set up your Touch ID.',
            lockOut: 'Please reenable your Touch ID');
        auth = await localAuth.authenticate(
            biometricOnly: true,
            localizedReason: 'Please authenticate your Biometrics.',
            useErrorDialogs: false,
            iOSAuthStrings: iosStrings);
      } else if (availableBiometrics.contains(BiometricType.fingerprint)) {
        // Touch ID.
        auth = await localAuth.authenticate(
          biometricOnly: true,
          useErrorDialogs: false,
          localizedReason: 'Please authenticate your Biometrics.',
        );
      }
    } else {
      const androStrings = AndroidAuthMessages(
        cancelButton: 'cancel',
        goToSettingsButton: 'settings',
        goToSettingsDescription: 'Please set up your Biometrics.',
      );
      auth = await localAuth.authenticate(
        biometricOnly: true,
        useErrorDialogs: false,
        androidAuthStrings: androStrings,
        localizedReason: 'Please authenticate your Biometrics.',
        // sensitiveTransaction: false,
      );
    }

    if (auth) {
      _doLoginBiometrics();
    }
  }

  void _launchMaps(String url) async {
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw ' Could not open maps';
    }
  }

  _checkVersion() async {
    Map<String, Object> param = {};
    param['appVersion'] = version ?? '';
    if (Platform.isIOS) {
      param['appDevice'] = "ios";
    } else {
      param['appDevice'] = "android";
    }

    final resp =
        await API.postNoLoadingNoCookies(context, '/util/version', param);
    if (resp['code'] != null && resp['code'] == 0) {
      print("SUCCES");
    } else {
      const DialogBox().showImageDialog(
          message: resp['message'],
          isError: false,
          buttonOk: "Update",
          onOk: () {
            if (Platform.isAndroid) {
              _launchMaps(resp['linkPlayStore']);
            } else {
              _launchMaps(resp['linkAppStore']);
            }
          },
          context: context);
    }
  }

  @override
  Widget build(BuildContext context) {
    _showPassword() {
      setState(() {
        showPass = !showPass;
      });
    }

    const loginText = Text(
      'Login ',
      style: TextStyle(fontWeight: FontWeight.w100, color: Colors.white),
    );

    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: <Widget>[
          Form(
            // ignore: deprecated_member_use
            autovalidateMode: AutovalidateMode.onUserInteraction,
            key: _formKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                SizedBox(height: MediaQuery.of(context).size.height * 0.075),
                Center(
                  child: SizedBox(
                    width: MediaQuery.of(context).size.width / 2,
                    child: Image.asset('assets/images/logo-app-green.png'),
                  ),
                ),
                SizedBox(height: MediaQuery.of(context).size.height * 0.075),
                const Text('USERNAME'),
                TextFormField(
                  maxLength: 25,
                  enableInteractiveSelection: false,
                  inputFormatters: [
//                    StringUtils.alphaNumeric(),
                    StringUtils.noSpace()
                  ],
                  decoration: const InputDecoration(
                    counterText: "",
                    focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(
                        color: Pallete.primary,
                      ),
                    ),
                    hintText: 'Masukkan Username Anda',
                    hintStyle: ISTStyle.hintStyle,
                  ),
                  controller: _usernameController,
                  validator: (val) {
                    if (val!.isEmpty) {
                      return "Isi username Anda";
                    } else {
                      return null;
                    }
                  },
                  enableSuggestions: true,
                  onChanged: (val) {
                    setState(() {
                      _usernameController.text;
                    });
                  },
                  keyboardType: TextInputType.visiblePassword,
                  onSaved: (String? val) {
                    _usernameController.text = val!;
                  },
                ),
                const SizedBox(height: 16),
                const Text('PASSWORD'),
                TextFormField(
                  // maxLength: ISTConstants.passwordMaxLength,
                  enableInteractiveSelection: false,
                  inputFormatters: [
                    // StringUtils.alphaNumeric(),
                    StringUtils.noSpace()
                  ],
                  decoration: InputDecoration(
                    hintText: 'Masukkan Password Anda',
                    focusedBorder: const UnderlineInputBorder(
                      borderSide: BorderSide(
                        color: Pallete.primary,
                      ),
                    ),
                    hintStyle: ISTStyle.hintStyle,
                    suffixIconColor: Pallete.primary,
                    suffixIcon: IconButton(
                      color: Pallete.primary,
                      icon: Icon(
                          showPass ? Icons.visibility : Icons.visibility_off),
                      onPressed: () {
                        _showPassword();
                      },
                    ),
                  ),
                  controller: _passwordController,
                  validator: (val) {
                    if (val!.isEmpty) {
                      return "Isi password Anda";
                    } else {
                      return null;
                    }
                  },
                  onSaved: (String? val) {
                    _passwordController.text = val!;
                  },
                  obscureText: showPass,
                ),
                const SizedBox(height: 16),
                Row(
                  children: <Widget>[
                    Expanded(
                      flex: 1,
                      child: ElevatedButton(
                          onHover: (value) => Pallete.primary,
                          onFocusChange: (value) => Pallete.primary,
                          onLongPress: () => Pallete.primary,
                          style: ElevatedButton.styleFrom(
                            padding: const EdgeInsets.all(10),
                            shape: const RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(50))),
                            primary: Pallete.primary,
                          ),
                          onPressed: isLoading
                              ? null
                              : () {
                                  _onLoginButtonPressed();
                                },
                          child: isLoading
                              ? const CupertinoActivityIndicator()
                              : loginText),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                // Row(
                //   mainAxisAlignment: MainAxisAlignment.center,
                //   children: <Widget>[
                //     FlatButton(
                //       child: Text(
                //         'Atau login dengan BIOMETRIC',
                //         style: TextStyle(color: Pallete.thirdy),
                //       ),
                //       onPressed: () {
                //         _checkBiometrics();
                //       },
                //     ),
                //   ],
                // )

                _biometricEnabled == null
                    ? Container()
                    : _biometricEnabled!
                        ? Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              TextButton(
                                child: const Text(
                                  'Atau login dengan BIOMETRIC',
                                  style: TextStyle(color: Pallete.primary),
                                ),
                                onPressed: () {
                                  _checkBiometrics();
                                },
                              ),
                            ],
                          )
                        : Container(),
              ],
            ),
          ),
          TextButton(
              onPressed: () {
                _showDialog(context);
              },
              child: const Text('Lupa Password / MPIN / Username',
                  style: TextStyle(color: Pallete.primary))),
          const SizedBox(height: 32),
          Text(
            'Version ' + version!,
            style: TextStyle(
                color: Colors.grey,
                fontSize: Theme.of(context).textTheme.overline!.fontSize),
          )
        ],
      ),
    );
  }
}

_showDialog(BuildContext context) {
  showDialog(
      context: context,
      barrierDismissible: false,
      useRootNavigator: true,
      builder: (context) {
        return AlertDialog(
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(20.0)),
          ),
          title: Column(),
          content: SingleChildScrollView(
            padding: const EdgeInsets.only(left: 4, right: 4),
            child: ListBody(
              children: <Widget>[
                Center(
                  child: SizedBox(
                      width: MediaQuery.of(context).size.width / 16 * 3,
                      child: Image.asset('assets/images/icon-warning.png')),
                ),
                const SizedBox(height: 32),
                ISTOutlineButton(
                    onPressed: () {
                      Navigator.pushNamed(context, ForgotPassword.routeName);
                    },
                    text: 'Lupa Password'),
                const SizedBox(height: 8),
                ISTOutlineButton(
                    onPressed: () {
                      Navigator.pushNamed(context, ForgotMPIN.routeName);
                    },
                    text: 'Lupa MPIN'),
                const SizedBox(height: 8),
                ISTOutlineButton(
                    onPressed: () {
                      Navigator.pushNamed(context, ForgotUsername.routeName);
                    },
                    text: 'Lupa Username'),
                const SizedBox(
                  height: 16,
                ),
                ISTFlatButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  text: 'Kembali',
                  color: Pallete.primary,
                )
              ],
            ),
          ),

          //actions: _checkbutton(context),
        );
      });
}
