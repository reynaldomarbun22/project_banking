import 'package:bpd_aceh/components/ist_mpin.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/features/login/creatempin/confirm_mpin.dart';
import 'package:flutter/material.dart';

class CreateMpin extends StatefulWidget {
  static const String routeName = "/mpin/create";

  const CreateMpin({Key? key}) : super(key: key);

  @override
  _CreateMpinState createState() => _CreateMpinState();
}

class _CreateMpinState extends State<CreateMpin> {
  @override
  Widget build(BuildContext context) {
    return ISTMPIN(onFinishedVal: (value) async {
      await ISTConstants().setString(ISTConstants.mpinCreate, value);
      Navigator.pushNamed(context, ConfirmMpin.routeName);
    });
  }
}
