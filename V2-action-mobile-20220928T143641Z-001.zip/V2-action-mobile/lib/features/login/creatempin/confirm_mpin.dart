import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_mpin.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/core/crypto/ist_crypto.dart';
import 'package:bpd_aceh/features/home/home_page.dart';
import 'package:bpd_aceh/features/landing/landing.dart';
import 'package:flutter/material.dart';

class ConfirmMpin extends StatefulWidget {
  static const String routeName = "/mpin/confirm";

  const ConfirmMpin({Key? key}) : super(key: key);

  @override
  _ConfirmMpinState createState() => _ConfirmMpinState();
}

class _ConfirmMpinState extends State<ConfirmMpin> {
  _finishedVal(value) async {
    var mpin = await ISTConstants().getString(ISTConstants.mpinCreate);
    if (value != mpin) {
      const DialogBox().showImageDialog(
          message: 'MPIN Tidak sesuai',
          isError: true,
          buttonCancel: 'OK',
          onOk: () {},
          context: context);
      return;
    }
    Map<String, Object> param = {};
    final String pinEnc = await ISTCrypto.encryptAES(value);
    param['mpin'] = pinEnc;

    final resp = await API.post(context, '/mpin/create', param);
    if (resp['code'] != null && resp['code'] == 0) {
      const DialogBox().showImageDialog(
          image: Image.asset('assets/images/icon-success.png'),
          buttonOk: 'Lanjut',
          message:
              'MPIN berhasil dibuat\nGunakan 6 digit MPIN Anda\nuntuk bertransaksi.',
          context: context,
          isError: false,
          onOk: () {
            Navigator.pushNamedAndRemoveUntil(context, HomePage.routeName,
                ModalRoute.withName(LandingPageScreen.routeName));
          });
    } else if (resp['code'] != null && resp['code'] != 0) {
      const DialogBox().showImageDialog(
          message: resp['message'],
          isError: true,
          buttonCancel: 'OK',
          onOk: () {},
          context: context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ISTMPIN(
      onFinishedVal: (value) {
        _finishedVal(value);
      },
      title: 'Konfirmasi 6 digit MPIN Anda',
    );
  }
}
