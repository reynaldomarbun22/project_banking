import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
// import 'package:bpd_aceh/features/transfer/transferAntarBAS/inquiryBAS/transferinq_bas.dart';
import 'package:flutter/material.dart';
import 'package:qr_code_scanner/qr_code_scanner.dart';

class TransferQRLogin extends StatefulWidget {
  static const routeName = '/transferQRLogin';

  const TransferQRLogin({Key? key}) : super(key: key);

  @override
  _TransferQRLoginState createState() => _TransferQRLoginState();
}

class _TransferQRLoginState extends State<TransferQRLogin> {
  QRViewController? controller;
  GlobalKey qrKey = GlobalKey();
  var qrText = '';
  String barcode = "";

  @override
  void initState() {
    if (controller != null) {
      controller!.resumeCamera();
    }
    super.initState();
  }

  @override
  void dispose() {
    // controller?.dispose();
    super.dispose();
  }

  // ignore: prefer_typing_uninitialized_variables
  var data;
  @override
  Widget build(BuildContext context) {
    void _onQRViewCreated(QRViewController controller) async {
      this.controller = controller;
      controller.scannedDataStream.listen((onData) async {
        await Future.sync(() async {
          controller.dispose();
          var qrData = onData.code;
          // ignore: unused_local_variable
          var qrCodeScan = qrData![0];
          // if (qrCodeScan != 'BJTG') {
          //   const DialogBox().showErrorDialog(
          //       context: context, message: "QR Code tidak dikenali.");
          //   return;
          // }
          // ignore: unused_local_variable
          var bnfAcctNo = qrData[0];
          // var bnfAcctName = qrData[2];
          // Navigator.push(
          //   context,
          //   MaterialPageRoute(
          //     builder: (context) => TransferBas(
          //       bnf_acct_no: bnfAcctNo,
          //     ),
          //   ),
          // MaterialPageRoute(
          //   builder: (context) => TransferBas(
          //       ),
          // ),
          // );
          try {} catch (_) {}
        });
      });
    }

    return Scaffold(
      backgroundColor: Theme.of(context).backgroundColor,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text(
          'Scan QR',
          style: TextStyle(color: Colors.white),
        ),
        // title: Image(
        //   image: AssetImage('assets/images/logo-app.png'),
        //   width: MediaQuery.of(context).size.width / 6,
        // ),
        actions: <Widget>[
          IconButton(
            icon: const Icon(
              Icons.notifications,
              color: Colors.white,
            ),
            onPressed: () {
              // _doLogout();
            },
          )
        ],
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      body: SafeArea(
        child: Container(
          color: Colors.white,
          // child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              // ISTCardAccount(
              //   context: context,
              //   menu: ISTMenu.qr,
              // ),
              const SizedBox(height: 16),
              Expanded(
                // height: 100,
                flex: 1,
                child: Stack(
                  children: <Widget>[
                    Center(
                      child: QRView(
                        key: qrKey,
                        onQRViewCreated: _onQRViewCreated,
                      ),
                    ),
                    const Center(
                      child: Padding(
                        padding: EdgeInsets.all(50.0),
                        child: Image(
                          image: AssetImage('assets/images/vector-qr-scan.png'),
                        ),
                      ),
                    ),
                    // Align(
                    //   alignment: Alignment.bottomRight,
                    //   child: Padding(
                    //     padding: const EdgeInsets.all(4.0),
                    //     child: FloatingActionButton(
                    //       onPressed: () {
                    //         controller.toggleFlash();
                    //       },
                    //       child: Icon(Icons.flash_on),
                    //       backgroundColor: Pallete.primary,
                    //     ),
                    //   ),
                    // )
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 32),
                child: ISTOutlineButton(
                  onPressed: () {
                    controller!.pauseCamera();
                    // _showQR();
                    // Navigator.pushNamed(context, Qrcode.routeName);
                  },
                  text: 'TAMPILKAN QR',
                ),
              ),
              const SizedBox(height: 16),
            ],
          ),
          // ),
        ),
      ),
    );
  }
}
