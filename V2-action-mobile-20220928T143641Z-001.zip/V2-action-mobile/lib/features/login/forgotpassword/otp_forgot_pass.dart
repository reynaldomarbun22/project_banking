import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_pin_otp.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/features/landing/landing.dart';
import 'package:bpd_aceh/features/login/forgotpassword/new_password.dart';
import 'package:bpd_aceh/features/login/login.dart';
import 'package:bpd_aceh/features/splash/splash.dart';
import 'package:flutter/material.dart';

class OTPforgotPassword extends StatefulWidget {
  static const String routeName = "/password/otpforgotpass";
  final Map<String, Object>? param;

  const OTPforgotPassword({Key? key, this.param}) : super(key: key);
  @override
  _OTPforgotPasswordState createState() => _OTPforgotPasswordState();
}

class _OTPforgotPasswordState extends State<OTPforgotPassword> {
  _doOTP(value) async {
    Map<String, Object> param = {};

    param['otp'] = value;
    final resp = await API.post(context, '/forgot/otp', param);
    if (resp['code'] != null && resp['code'] == 0) {
      Navigator.pushReplacementNamed(context, NewPassword.routeName);
    } else {
      const DialogBox().showImageDialog(
          message: resp['message'],
          isError: true,
          image: const Image(
            image: AssetImage('assets/images/icon-failed.png'),
          ),
          buttonCancel: 'OK',
          onCancel: () {
            if (resp['code'] == -1013) {
              setState(() {
                Navigator.pushNamedAndRemoveUntil(
                    context,
                    LandingPageScreen.routeName,
                    ModalRoute.withName(Splash.routeName));
                Navigator.pushNamed(context, LoginPage.routeName);
              });
            } else {
              Navigator.pop(context);
            }
          },
          onOk: () {},
          context: context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Pallete.primary,
      body: SafeArea(
        bottom: false,
        child: ISTOTP(
          appBarTitle: 'Lupa Password',
          title: 'Masukkan 6 digit Kode OTP Anda',
          onFinishedVal: (value) {
            _doOTP(value);
          },
          param: widget.param,
          state: 'OTPforgotpass',
        ),
      ),
    );
  }
}
