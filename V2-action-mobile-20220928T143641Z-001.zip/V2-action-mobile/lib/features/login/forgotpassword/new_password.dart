import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_style.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/core/crypto/ist_crypto.dart';
import 'package:bpd_aceh/core/utils/string_utils.dart';
import 'package:bpd_aceh/features/landing/landing.dart';
import 'package:bpd_aceh/features/login/login.dart';
import 'package:bpd_aceh/features/splash/splash.dart';

import 'package:flutter/material.dart';
import 'package:wc_form_validators/wc_form_validators.dart';

class NewPassword extends StatefulWidget {
  static const String routeName = "/password/forgot/createpassword";

  const NewPassword({Key? key}) : super(key: key);

  @override
  State<NewPassword> createState() => _NewPasswordState();
}

class _NewPasswordState extends State<NewPassword> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  // ignore: unused_field
  bool _autoValidate = false;

  final _passwordController = TextEditingController();
  final _passwordConfirmController = TextEditingController();

  bool showPass = true;
  bool showPassConf = true;
  bool isLoading = false;

  bool _passError = false;
  bool _passConfError = false;

  _showPassword() {
    setState(() {
      showPass = !showPass;
    });
  }

  _showPasswordConf() {
    setState(() {
      showPassConf = !showPassConf;
    });
  }

  bool _validateInputs() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      return true;
    } else {
      setState(() {
        _autoValidate = true;
      });
      return false;
    }
  }

  bool _doValidate() {
    if (_validateInputs() != true) return false;
    bool _success = true;
    if (_passwordController.text.isEmpty) {
      setState(() {
        _passError = true;
      });
      _success = false;
    } else {
      setState(() {
        _passError = false;
      });
    }

    if (_passwordConfirmController.text.isEmpty) {
      setState(() {
        _passConfError = true;
      });
      _success = false;
    } else {
      setState(() {
        _passConfError = false;
      });
    }
    return _success;
  }

  _doCreateUser() async {
    if (_doValidate()) {
      Map<String, Object> param = {};
      final password = await ISTCrypto.encryptAES(_passwordController.text);
      param['password'] = password;

      final resp = await API.post(context, '/forgot/password', param);
      if (resp['code'] == 0) {
        const DialogBox().showImageDialog(
            title: 'Anda berhasil mengganti Password Anda',
            message: resp['message'],
            buttonOk: 'Selesai',
            isError: false,
            image: const Image(
              image: AssetImage('assets/images/icon-success.png'),
            ),
            onOk: () {
              Navigator.pushNamedAndRemoveUntil(
                  context,
                  LandingPageScreen.routeName,
                  ModalRoute.withName(Splash.routeName));
              Navigator.pushNamed(context, LoginPage.routeName);
            },
            context: context);
      } else {
        const DialogBox().showImageDialog(
            message: resp['message'],
            isError: true,
            image: const Image(
              image: AssetImage('assets/images/icon-failed.png'),
            ),
            buttonCancel: 'OK',
            onOk: () {},
            context: context);
      }
    }
  }

  _exitApp(BuildContext context) {
    const DialogBox().showImageDialog(
        image: const Image(
          image: AssetImage('assets/images/icon-warning.png'),
        ),
        message: "Anda Akan Membatalkan Proses Lupa Password",
        context: context,
        isError: true,
        onOk: () {
          Navigator.pushNamedAndRemoveUntil(
              context,
              LandingPageScreen.routeName,
              ModalRoute.withName(Splash.routeName));
          Navigator.pushNamed(context, LoginPage.routeName);
        },
        buttonOk: 'Ya',
        onCancel: () {
          Navigator.pop(context);
        },
        buttonCancel: 'Tidak');
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () => _exitApp(context),
      child: Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(
            // leading: IconButton(
            //     icon: Icon(
            //       Icons.arrow_back_ios,
            //       color: Colors.white,
            //     ),
            //     onPressed: () {
            //       Navigator.pop(context);
            //     }),
            leading: Container(),
            title: const Text(
              'Lupa Password',
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'Poppins',
              ),
            ),
            centerTitle: true,
            elevation: 0.0,
            backgroundColor: Pallete.primary,
          ),
          body: SafeArea(
            child: Container(
              padding: const EdgeInsets.all(16),
              child: SingleChildScrollView(
                child: Form(
                  key: _formKey,
                  // ignore: deprecated_member_use
                  autovalidateMode: AutovalidateMode.always,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Container(
                          alignment: Alignment.topLeft,
                          child: const Text(
                            'Silakan buat Password baru Anda',
                            style: TextStyle(
                              fontFamily: 'Poppins',
                            ),
                          )),
                      const SizedBox(height: 16),
                      Container(
                          alignment: Alignment.topLeft,
                          child: const Text(
                            'PASSWORD',
                            style: TextStyle(
                              fontFamily: 'Poppins',
                            ),
                          )),
                      TextFormField(
                        enableInteractiveSelection: false,
                        maxLength: ISTConstants.passwordMaxLength,

                        inputFormatters: [
                          // StringUtils.alphaNumeric(),
                          StringUtils.noSpace()
                        ],
                        onChanged: (val) {
                          setState(() {
                            if (val.isEmpty) {
                              _passError = true;
                            } else {
                              _passError = false;
                            }
                          });
                        },
                        expands: false,
                        obscureText: showPass,
                        keyboardType: TextInputType.text,
                        style: const TextStyle(fontSize: 16),
//                      validator: (val) {
//                        if (val.length < 8) {
//                          return "*minimal 8 karakter kombinasi huruf dan angka";
//                        } else {
//                          return null;
//                        }
//                      },
                        validator: Validators.compose([
                          Validators.required('Mohon diisi'),
                          Validators.patternString(
                              // (?=.*?[!@#\$&*~])
                              r'^(?=.*?[a-z])(?=.*?[0-9]).{8,}$',
                              'Minimal 8 karakter kombinasi huruf dan angka'),
                          Validators.minLength(
                              8, 'Minimal 8 karakter kombinasi huruf dan angka')
                        ]),
                        onSaved: (String? val) {
                          _passwordController.text = val!;
                        },
                        decoration: InputDecoration(
                          hintText: 'Masukkan Password baru Anda',
                          errorText: _passError ? "Mohon diisi" : null,
                          hintStyle: ISTStyle.hintStyle,
                          suffixIcon: IconButton(
                            icon: Icon(showPass
                                ? Icons.visibility
                                : Icons.visibility_off),
                            onPressed: () {
                              _showPassword();
                            },
                          ),
                        ),
                        controller: _passwordController,
                      ),
                      const SizedBox(height: 8),
                      Container(
                          alignment: Alignment.topLeft,
                          child: const Text('KONFIRMASI PASSWORD')),
                      TextFormField(
                        onChanged: (val) {
                          setState(() {
                            if (val.isEmpty) {
                              _passConfError = true;
                            } else {
                              _passConfError = false;
                            }
                          });
                        },
                        expands: false,
                        validator: (val) {
                          if (val != _passwordController.text) {
                            return "*konfirmasi password tidak sama";
                          } else {
                            return null;
                          }
                        },
                        onSaved: (String? val) {
                          _passwordConfirmController.text = val!;
                        },
                        obscureText: showPassConf,
                        keyboardType: TextInputType.text,
                        style: const TextStyle(fontSize: 16),
                        decoration: InputDecoration(
                          hintText: 'Konfirmasi Password Anda',
                          errorText: _passConfError ? "Mohon diisi" : null,
                          hintStyle: ISTStyle.hintStyle,
                          suffixIcon: IconButton(
                            icon: Icon(showPassConf
                                ? Icons.visibility
                                : Icons.visibility_off),
                            onPressed: () {
                              _showPasswordConf();
                            },
                          ),
                        ),
                        controller: _passwordConfirmController,
                      ),
                      Padding(
                        padding:
                            const EdgeInsets.only(top: 16, right: 1, left: 1),
                        child: ISTOutlineButton(
                            onPressed: () {
                              _doCreateUser();
                            },
                            text: 'Lanjut'),
                      ),
                      const SizedBox(
                        height: 16,
                      )
                    ],
                  ),
                ),
              ),
            ),
          )),
    );
  }
}
