import 'dart:io';

import 'package:bpd_aceh/components/palete.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';
import 'package:webview_flutter/webview_flutter.dart';

class FAQ extends StatefulWidget {
  static const routeName = '/faq';

  const FAQ({Key? key}) : super(key: key);
  @override
  _FAQState createState() => _FAQState();
}

// http://action.bankaceh.co.id/faq.html
// https://youtube.com/
class _FAQState extends State<FAQ> {
  // final flutterWebViewPlugin = FlutterWebviewPlugin();
  String url = "";
  // final String url = "https://www.youtube.com/";
  @override
  void initState() {
    if (Platform.isAndroid) WebView.platform = SurfaceAndroidWebView();
    super.initState();
    if (Platform.isIOS) {
      url = "https://action.bankaceh.co.id/faq-ios.html";
    } else {
      url = "https://action.bankaceh.co.id/faq.html";
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "FAQ",
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
        backgroundColor: Pallete.primary,
        leading: IconButton(
            icon: const Icon(
              Icons.arrow_back_ios,
              color: Colors.white,
            ),
            onPressed: () {
              Navigator.pop(context);
            }),
      ),
      body: foreground(),
    );
  }

  bool isLoading = false;
  Widget foreground() {
    return SafeArea(
      child: Column(
        children: <Widget>[
          Expanded(
            child: Stack(
              children: <Widget>[
                WebView(
                  initialUrl: url,
                  // onProgress: (){},
                  javascriptMode: JavascriptMode.unrestricted,
                  onPageFinished: (finish) {
                    setState(() {
                      isLoading = false;
                    });
                  },
                ),
                isLoading
                    ? const Center(
                        child: Text('Waiting...'),
                      )
                    : Stack(),
              ],
            ),
          ),
        ],
      ),
    );
  }
}



// class FAQ extends StatelessWidget {
//   static const routeName = '/faq';
//   final flutterWebViewPlugin = FlutterWebviewPlugin();

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text("ss"),

//       ),
//       body: WebviewScaffold(url: "http://action.bankaceh.co.id/faq.html",
//      mediaPlaybackRequiresUserGesture: false,
// withZoom: true,
//             withLocalStorage: true,
//             hidden: true,
//           //  initialChild: Container(
//           //     color: Colors.redAccent,
//           //     child: const Center(
//           //       child: Text('Waiting.....'),
//           //     ),
//           //   ),

//       )
//       // routes: {
//       //   new WebviewScaffold(
//       //     url: "https://www.google.com",
//       //     appBar: new AppBar(
//       //       title: new Text("Widget webview"),
//       //     ),
//       //   ),
//       // },
//     );
//   }
// }

// class FAQ extends StatefulWidget {
//   static const routeName = '/faq';
//   @override
//   _FAQState createState() => _FAQState();
// }

// class _FAQState extends State<FAQ> {
//   final Completer<WebViewController> _controller = Completer<WebViewController>();
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(leading: IconButton(
//             icon: Icon(Icons.arrow_back_ios, color: Colors.white,),
//             onPressed: () {
//               Navigator.pop(context);
//             }),
//             title: Text("FAQ",style: TextStyle(color: Colors.white),),
//             elevation: 0.0,
//           iconTheme: IconThemeData(color: Colors.black),
//           backgroundColor: Pallete.PRIMARY,
//             centerTitle: true,
//       ),
// backgroundColor: Colors.white,
// body: Builder(builder: (BuildContext context){
//   return WebView(
//     // initialUrl: "https://flutter.dev",
//     initialUrl: "http://action.bankaceh.co.id/faq.html",
//     javascriptMode: JavascriptMode.unrestricted,
//     gestureNavigationEnabled: false,
//   onWebViewCreated: (WebViewController webViewController){
//     _controller.complete(webViewController);
//   },
//   );
// }),

//     );
//   }
// }

// class FAQ extends StatefulWidget {
//   static const routeName = '/faq';

//   final String title;
//   FAQ({Key key, this.title}) : super(key: key);
//   @override
//   State<StatefulWidget> createState(){
//     return _FAQState();
//   }
// }

// class _FAQState extends State<FAQ> {
//   final Completer<WebViewController> _controller = Completer<WebViewController>();
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(leading: IconButton(
//             icon: Icon(Icons.arrow_back_ios, color: Colors.white,),
//             onPressed: () {
//               Navigator.pop(context);
//             }),
//             title: Text("FAQ",style: TextStyle(color: Colors.white),),
//             elevation: 0.0,
//           iconTheme: IconThemeData(color: Colors.black),
//           backgroundColor: Pallete.PRIMARY,
//             centerTitle: true,
//       ),
// backgroundColor: Colors.white,
// body: Builder(builder: (BuildContext context){
//   return WebView(
//     // initialUrl: "https://flutter.dev",
//     initialUrl: "http://action.bankaceh.co.id/faq.html",
//     javascriptMode: JavascriptMode.unrestricted,
//     gestureNavigationEnabled: false,
//   onWebViewCreated: (WebViewController webViewController){
//     _controller.complete(webViewController);
//   },
//   );
// }),
//     );
//   }
// }
