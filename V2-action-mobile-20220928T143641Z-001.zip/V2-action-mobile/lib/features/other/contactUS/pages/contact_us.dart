import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class ContactUs extends StatefulWidget {
  static const routeName = '/contactUS';

  const ContactUs({Key? key}) : super(key: key);
  @override
  _ContactUsState createState() => _ContactUsState();
}

class _ContactUsState extends State<ContactUs> {
  @override
  void initState() {
    _getItem();
    super.initState();
  }

  void _launchCaller(String? number) async {
    var call = "tel:$number";
    if (await canLaunch(call)) {
      await launch(call);
    } else {
      throw ' Could not place call';
    }
  }

  void _laungEmail(String? emailID) async {
    var url = "mailto:$emailID?subject";
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw ' Could not send Email';
    }
  }

  void _launchMaps(String url) async {
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw ' Could not open maps';
    }
  }

  String? email = '';
  // ignore: prefer_typing_uninitialized_variables
  var dataNotel;
  // ignore: prefer_typing_uninitialized_variables
  var dataAlamat;
  String? alamatString = '';
  String? alamatValue = '';

  var alamat = '';
  String? notel = '';
  String? notel1 = '';

  _getItem() async {
    final resp = await API.postNoLoading(context, '/contactus', {});
    if (resp != null && resp['code'] == 0) {
      dataNotel = resp['dataNotel'];
      dataAlamat = resp['dataAlamat'];
      setState(() {
        notel = dataNotel['label'];
        notel1 = dataNotel['value'];
        alamatString = dataAlamat['label'];
        alamatValue = dataAlamat['value'];
        email = resp['email'];
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
            icon: const Icon(
              Icons.arrow_back_ios,
              color: Colors.white,
            ),
            onPressed: () {
              Navigator.pop(context);
            }),
        title: const Text(
          "Hubungi Kami",
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'Poppins',
          ),
        ),
        elevation: 0.0,
        iconTheme: const IconThemeData(color: Colors.black),
        backgroundColor: Pallete.primary,
        centerTitle: true,
      ),
      body: Container(
        padding: const EdgeInsets.all(16),
        child: Column(
          //crossAxisAlignment: CrossAxisAlignment.center,
          //mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(
              child: const Text(
                "Hubungi Kami",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Poppins',
                ),
              ),
              alignment: Alignment.center,
            ),
            Container(
              child: const Text(
                "PT. Bank Aceh Syariah",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Poppins',
                ),
              ),
              alignment: Alignment.center,
            ),
            const SizedBox(height: 16),
            OutlinedButton(
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: Pallete.primary),
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(8))),
              ),
              onPressed: () {
                _launchMaps(alamatValue!);
              },
              //splashColor: Pallete.primary,

              child: Container(
                height: 100,
                padding: const EdgeInsets.only(top: 8, bottom: 8),
                // width: 350,
                child: Row(
                  children: <Widget>[
                    Expanded(
                      flex: 3,
                      child: Image(
                          height: MediaQuery.of(context).size.height / 12,
                          image: const AssetImage('assets/images/maps.png')),
                    ),
                    const SizedBox(
                      width: 8,
                    ),
                    Container(
                      // height: 60,
                      color: Pallete.primary,
                      width: 1,
                    ),
                    const SizedBox(
                      width: 8,
                    ),
                    Expanded(
                      flex: 20,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          const Text(
                            "Kantor Pusat",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Poppins',
                            ),
                          ),
                          Text(
                            // 'Jl. Mr. Mohd. Hasan No.89, Batoh\nBanda Aceh 23245',
                            alamatString!,

                            style: const TextStyle(
                                fontFamily: 'Poppins', color: Colors.black),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
            const SizedBox(
              height: 16,
            ),
            OutlinedButton(
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: Pallete.primary),
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(8))),
              ),
              onPressed: () {
                _laungEmail(email);
              },
              //splashColor: Pallete.primary,

              child: Container(
                height: 100,
                padding: const EdgeInsets.only(top: 8, bottom: 8),
                // width: 350,
                child: Row(
                  children: <Widget>[
                    Expanded(
                      flex: 3,
                      child: Image(
                          height: MediaQuery.of(context).size.height / 12,
                          image: const AssetImage('assets/images/email.png')),
                    ),
                    const SizedBox(
                      width: 8,
                    ),
                    Container(
                      // height: 60,
                      color: Pallete.primary,
                      width: 1,
                    ),
                    const SizedBox(
                      width: 8,
                    ),
                    Expanded(
                      flex: 20,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          const Text(
                            "Email",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Poppins',
                            ),
                          ),
                          Text(
                            email!,
                            style: const TextStyle(
                              fontFamily: 'Poppins',
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
            const SizedBox(
              height: 16,
            ),
            OutlinedButton(
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: Pallete.primary),
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(8))),
              ),
              onPressed: () {
                _launchCaller(notel1);
              },
              //splashColor: Pallete.primary,

              child: Container(
                height: 100,
                padding: const EdgeInsets.only(top: 8, bottom: 8),
                width: 350,
                child: Row(
                  children: <Widget>[
                    Expanded(
                      flex: 3,
                      child: Image(
                          height: MediaQuery.of(context).size.height / 12,
                          image: const AssetImage('assets/images/call.png')),
                    ),
                    const SizedBox(
                      width: 8,
                    ),
                    Container(
                      // height: 60,
                      color: Pallete.primary,
                      width: 1,
                    ),
                    const SizedBox(
                      width: 8,
                    ),
                    Expanded(
                      flex: 20,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          const Text(
                            "Contact Center",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Poppins',
                            ),
                          ),
                          Text(
                            notel1!,
                            style: const TextStyle(
                              fontFamily: 'Poppins',
                            ),
                          ),
                          Text(
                            // "22966 (Hunting)",
                            notel!,
                            style: const TextStyle(
                              fontFamily: 'Poppins',
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
//   _getMap() async {
//   final resp await API.postNoLoading(context, '/contactus', {});
//  if (resp != null && resp['code'] == 0){
//    var notel = resp['notel'];
//  }
// }
}
