import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_mpin.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/crypto/ist_crypto.dart';
import 'package:bpd_aceh/features/other/rekeningku/pengaturanRekening/page/setting_rekening.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class RekeningKUMPIN extends StatelessWidget {
  static const routeName = '/rekeningKUMPIN';
  final int? index; //uji coba harusnya

  const RekeningKUMPIN({Key? key, this.index}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return ISTMPIN(
      onFinishedVal: (value) async {
        Map<String, Object> param = {};
        final String pinEnc = await ISTCrypto.encryptAES(value);
        param['mpin'] = pinEnc;

        final resp = await API.post(context, '/acct/addaccount/post', param);
        if (resp['code'] == 0) {
          Navigator.pop(context);
          Navigator.pop(context);
          Navigator.pop(context);
          Navigator.pushNamed(context, SettingRek.routeName);
        } else {
          const DialogBox().showImageDialog(
              message: resp['message'],
              isError: true,
              image: const Image(
                image: AssetImage('assets/images/icon-failed.png'),
              ),
              buttonCancel: 'OK',
              onOk: () {},
              context: context);
        }
      },
    );
  }
}
