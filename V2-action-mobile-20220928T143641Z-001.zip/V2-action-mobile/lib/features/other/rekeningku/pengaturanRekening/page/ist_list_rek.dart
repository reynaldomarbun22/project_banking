import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_mpin.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/crypto/ist_crypto.dart';
import 'package:bpd_aceh/features/other/rekeningku/pengaturanRekening/remove_mpin.dart';
import 'package:flutter/material.dart';

class ISTListRek extends StatelessWidget {
  const ISTListRek({
    Key? key,
    this.index,
    this.isPrimary,
    this.accountBalance,
    this.accountType,
    this.accountNumber,
    this.accountName,
    this.onChanged,
  }) : super(key: key);
  final bool? isPrimary;
  final String? accountBalance;
  final String? accountType;
  final String? accountNumber;
  final String? accountName;
  final int? index;
  final Function()? onChanged;

  @override
  Widget build(BuildContext context) {
    // ignore: unused_element
    _doRemove() {
      return ISTMPIN(onFinishedVal: (value) async {
        Map<String, Object?> param = {};
        final String pinEnc = await ISTCrypto.encryptAES(value);
        param['mpin'] = pinEnc;
        param['listaccountke'] = index;
        final resp = await API.post(context, '/acct/removeaccount/post', param);
        if (resp != null && resp['code'] == 0) {
          Navigator.pop(context);
        }
      });
    }

    _doSetDefaultRek() async {
      Map<String, Object?> param = {};
      param['listaccountke'] = index;
      final resp = await API.post(context, '/acct/setdefault/post', param);
      if (resp != null && resp['code'] == 0) {
        onChanged!();
      }
      Navigator.pop(context);
      // Navigator.popAndPushNamed(context, SettingRek.routeName);
    }

    return Container(
      color: isPrimary! ? Pallete.primary : Colors.white,
      padding: const EdgeInsets.only(top: 8, bottom: 8, left: 16, right: 16),
      child: InkWell(
        onTap: () {
          isPrimary!
              ? Container()
              : const DialogBox().showImageDialog(
                  // title: '',
                  message: "Apakah anda yakin akan mengganti rekening anda",
                  buttonOk: 'Setuju',
                  buttonCancel: "Batal",
                  isError: false,
                  image: const Image(
                    image: AssetImage('assets/images/icon-warning.png'),
                  ),
                  onOk: () {
                    _doSetDefaultRek();
                  },
                  context: context);
        },
        // onTap: (){ _doSetDefaultRek();},
        child: Column(
          children: <Widget>[
            Row(crossAxisAlignment: CrossAxisAlignment.center, children: <
                Widget>[
              Expanded(
                flex: 8,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      accountName!,
                      style: TextStyle(
                          color: !isPrimary! ? Pallete.primary : Colors.white,
                          fontWeight: FontWeight.bold),
                    ),
                    Text(accountType!,
                        style: TextStyle(
                            color:
                                !isPrimary! ? Pallete.primary : Colors.white)),
                    Text(accountNumber!,
                        style: TextStyle(
                            color:
                                !isPrimary! ? Pallete.primary : Colors.white)),
                    Text(accountBalance!,
                        style: TextStyle(
                            color:
                                !isPrimary! ? Pallete.primary : Colors.white)),
                  ],
                ),
              ),
              Expanded(
                flex: 3,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    !isPrimary!
                        ? IconButton(
                            icon: const Image(
                                color: Colors.red,
                                image: AssetImage(
                                    "assets/images/icon-delete.png")),
                            onPressed: () {
                              const DialogBox().showImageDialog(
                                  message:
                                      "Apakah Anda yakin akan menghapus Daftar Rekening",
                                  context: context,
                                  buttonCancel: "Tidak",
                                  buttonOk: "Hapus",
                                  image: Image.asset(
                                    'assets/images/icon-warning.png',
                                    scale: 3,
                                  ),
                                  isError: true,
                                  onOk: () async {
                                    // !isPrimary
                                    // ?
                                    var result = await Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                RemoveMPIN(
                                                  index: index,
                                                )));
                                    if (result == true) {
                                      Navigator.pop(context, true);
                                      onChanged!();
                                    }
                                    // : Navigator.pop(context);
                                    // Navigator.pop(context);
                                  });
                              // Navigator.pop(context);
                            })
                        : Container()
                    // ?
                  ],
                ),
              ),
            ]),
            // SizedBox(
            //   height: 8,
            // ),
            const Divider(
              color: Pallete.primary,
              height: 1,
            ),
          ],
        ),
      ),
    );
  }
}
