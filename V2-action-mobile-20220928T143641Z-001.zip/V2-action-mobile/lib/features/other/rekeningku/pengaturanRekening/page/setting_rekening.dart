import 'dart:ui';

import 'package:bpd_aceh/core/api/api.dart';

import 'package:bpd_aceh/features/other/rekeningku/pengaturanRekening/page/ist_list_rek.dart';
import 'package:bpd_aceh/features/other/rekeningku/pengaturanRekening/page/rekening_input.dart';
import 'package:flutter/material.dart';
import '../../../../../components/palete.dart';
import '../../../../../components/button.dart';

class SettingRek extends StatefulWidget {
  static const routeName = '/settingRek';
  final Function()? callback;

  const SettingRek({Key? key, this.callback}) : super(key: key);
  @override
  _SettingRekState createState() => _SettingRekState();
}

class _SettingRekState extends State<SettingRek> {
  // ignore: unused_element
  _showLoading(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return Stack(
          children: [
            Positioned.fill(
                child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                    child: Container(
                      color: Colors.white12,
                    ))),
            const Center(
                child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Pallete.primary),
            ))
          ],
        );
      },
    );
  }

  final Widget _appBarTitle = const Text(
    'Pengaturan Rekening',
    style: TextStyle(
      //fontWeight: FontWeight.bold,
      color: Colors.white,
      fontFamily: 'Poppins',

      // fontSize: FontSize.TITLE,
    ),
  );

  // var _accountBalance = "";
  // var _accountName = "";
  // var _accountNumber = "";
  // var _accountType = "";
  bool isChange = false;
  bool isLoading = false;

  List<ISTListRek> _listAccounts = [];
  _doInquiryListRek() async {
    // if (isLoading) await _showLoading(context);
    if (_listAccounts.isEmpty) {
      setState(() {
        isLoading = true;
      });
    } else {
      setState(() {
        isLoading = false;
      });
    }
    final resp = await API.postNoLoading(context, '/acct/listAccount', {});
    if (resp != null && resp['code'] == 0) {
      var listResp = resp['accountList'];
      List<dynamic> listRespDyn = (listResp);
      List<ISTListRek> listParam = [];
      for (var i = 0; i < listRespDyn.length; i++) {
        ISTListRek cardItem = ISTListRek(
          accountBalance: listRespDyn[i]['accountBalance'],
          accountName: listRespDyn[i]['accountOwnerName'],
          accountNumber: listRespDyn[i]['accountNo'],
          accountType: listRespDyn[i]['accountProductName'],
          isPrimary: listRespDyn[i]['accountDefault'],
          index: i,
          onChanged: () {
            isChange = true;
            _doInquiryListRek();
          },
          // oncha {

          //   Navigator.pop(context);
          //   // _doInquiryListRek();
          //   setState(() {
          //     _accountBalance = accountBalance;
          //     _accountType = accountType;
          //     _accountNumber = accountNumber;
          //     _accountName = accountName;

          //   }
          //   );

          //   if (widget.callback != null) widget.callback();
          // },
        );
        listParam.add(cardItem);
      }
      setState(() {
        _listAccounts = listParam;
        isLoading = false;
      });
    }
  }

  Future<bool> _willPopCallback() async {
    if (isChange) {
      Navigator.pop(context, true);
      return false;
    }
    return true; // return true if the route to be popped
  }

  // @override
  // void didChangeDependencies() {
  //   _doInquiryListRek();
  //   super.didChangeDependencies();
  // }

  @override
  void initState() {
    // _showLoading(context);
    _doInquiryListRek();
    super.initState();
    //  _doInquiryListAccountSingle();
    // _doInquiryListRek();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _willPopCallback,
      child: Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(
            backgroundColor: Pallete.primary,
            centerTitle: true,
            title: _appBarTitle,
            leading: IconButton(
                color: Colors.white,
                icon: const Icon(Icons.arrow_back_ios),
                onPressed: () {
                  Navigator.pop(context, isChange);
                }),
          ),
          body: SingleChildScrollView(
            child: Column(
              children: <Widget>[
                isLoading
                    ? Container(
                        padding: const EdgeInsets.only(top: 16),
                        child: CircularProgressIndicator(
                          backgroundColor: Colors.grey[350],
                          strokeWidth: 3,
                          valueColor:
                              const AlwaysStoppedAnimation<Color>(Pallete.primary),
                          // valueColor:
                          //     new AlwaysStoppedAnimation<Color>(Colors.red),
                          // //   child: Container(
                          // //   color: Colors.grey[300],
                          // //   height: 100,
                          // //   width: 100,
                          // // )
                        ),
                      )
                    : Column(children: _listAccounts),
                const SizedBox(
                  height: 16,
                ),
                Container(
                    padding: const EdgeInsets.all(16),
                    child: ISTOutlineButton(
                      onPressed: () {
                        Navigator.pushNamed(context, RekeningInput.routeName);
                      },
                      text: "Tambah Rekening",
                    )),
              ],
            ),
          )),
    );
  }

  // _showAccountDialog({BuildContext context, List<ISTListRek> list}) {
  //   return Container(
  //     child: Scaffold(
  //       body: SingleChildScrollView(
  //         child: Center(
  //           child: Column(
  //             crossAxisAlignment: CrossAxisAlignment.center,
  //             children: <Widget>[
  //               SizedBox(height: 8),
  //               Padding(
  //                 padding: const EdgeInsets.symmetric(horizontal: 8.0),
  //                 child: Column(children: list),
  //               ),
  //               SizedBox(height: 8),
  //             ],
  //           ),
  //         ),
  //       ),
  //     ),
  //   );
  // }

}
