import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_style.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/features/other/rekeningku/pengaturanRekening/page/rekeningku_mpin.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class RekeningInput extends StatefulWidget {
  static const routeName = '/RekeningInput';

  const RekeningInput({Key? key}) : super(key: key);
  @override
  _RekeningInputState createState() => _RekeningInputState();
}

class _RekeningInputState extends State<RekeningInput> {
  final _noRekcontroller = TextEditingController();

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  // ignore: unused_field
  final bool _autoValidate = false;
  bool isLoading = false;
  // ignore: unused_field
  bool _norekError = false;
  bool showPass = true;
  bool _success = true;

  _doValidate() {
    if (_noRekcontroller.text == '') {
      setState(() {
        _norekError = true;
      });
      _success = false;
    } else {
      _norekError = false;

      _success = true;
    }
    return _success;
  }

  _doInquiryRek() async {
    Map<String, Object> param = {};
    param['accountNumber'] = _noRekcontroller.text.replaceAll("-", "");
    final resp = await API.post(context, '/acct/addaccount/inq', param);
    // if (resp == null) return;
    if (resp != null && resp['code'] == 0) {
      // ignore: unused_local_variable
      List<dynamic>? listMap = resp['resi'];

      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => const RekeningKUMPIN(
                  // list: listParam,
                  )));
    } else {
      const DialogBox().showImageDialog(
          message: resp['message'],
          isError: true,
          image: const Image(
            image: AssetImage('assets/images/icon-failed.png'),
          ),
          buttonCancel: 'OK',
          onOk: () {},
          context: context);
    }
    // Navigator.pop(context);
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Pallete.primary,
        centerTitle: true,
        title: const Text(
          "Pengaturan Rekening",
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'Poppins',
          ),
        ),
        leading: IconButton(
            color: Colors.white,
            icon: const Icon(Icons.arrow_back_ios),
            onPressed: () {
              // Navigator.
              Navigator.pop(context);
            }),
      ),
      body: Column(
        children: <Widget>[
          Form(
              key: _formKey,
              // ignore: deprecated_member_use
              autovalidateMode: AutovalidateMode.always,
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    const SizedBox(
                      height: 8,
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: const Text('Masukkan nomor rekening'),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      alignment: Alignment.topLeft,
                      child: TextFormField(
                        keyboardType: TextInputType.number,
                        validator: (val) {
                          if (val!.isEmpty || val == '0') {
                            return "Mohon diisi";
                          } else {
                            return null;
                          }
                        },
                        inputFormatters: [
                          // ignore: deprecated_member_use
                          FilteringTextInputFormatter.digitsOnly,
                        ],
                        controller: _noRekcontroller,
                        maxLength: ISTConstants.acctToMaxLength,
                        decoration: const InputDecoration(
                          counterText: '',
                          // errorText: _keRekeningBasError ? "Mohon diisi" : null,
                          hintText: 'Masukkan no. rekening',
                          hintStyle: ISTStyle.hintStyle,
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 16,
                    ),
                    Container(
                        padding: const EdgeInsets.all(16),
                        child: ISTOutlineButton(
                          onPressed: () {
                            setState(() {});
                            if (!_doValidate()) return;
                            _doInquiryRek();
                          },
                          text: "Tambah Rekening",
                        )),
                  ])),
        ],
      ),
    );
  }
}
