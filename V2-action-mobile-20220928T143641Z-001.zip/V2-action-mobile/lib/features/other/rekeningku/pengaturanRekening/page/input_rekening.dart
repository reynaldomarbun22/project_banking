import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/features/other/rekeningku/pengaturanRekening/page/rekeningku_mpin.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../../../../components/ist_style.dart';
import '../../../../../components/palete.dart';
import '../../../../../components/button.dart';

class InputRek extends StatefulWidget {
  static const routeName = '/inputRek';

  const InputRek({Key? key}) : super(key: key);
  @override
  _InputRekState createState() => _InputRekState();
}

class _InputRekState extends State<InputRek> {
  final _noRekcontroller = TextEditingController();

  final Widget _appBarTitle = const Text(
    'Pengaturan Rekening',
    style: TextStyle(color: Colors.white),
  );

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  // ignore: unused_field
  final bool _autoValidate = false;
  // final _pinController = MaskedTextController(mask: ("000000"));
  // final _norekController = MaskedTextController(mask: ("0000 0000 0000 0000"));

  bool isLoading = false;
  // ignore: unused_field
  final bool _norekError = false;
  // ignore: unused_field
  final bool _pinError = false;
  bool showPass = true;

  // ignore: unused_field
  bool _rekError = false;
  bool _success = true;

  _doValidate() {
    if (_noRekcontroller.text == '') {
      setState(() {
        _rekError = true;
      });
      _success = false;
    } else {
      _rekError = false;

      _success = true;
    }
    return _success;
  }

  _doInquiryRek() async {
    Map<String, Object> param = {};
    param['accountNumber'] = _noRekcontroller.text.replaceAll("-", "");
    final resp = await API.post(context, '/acct/addaccount/inq', param);
    // if (resp == null) return;
    if (resp != null && resp['code'] == 0) {
      // List<ISTConfirmationItem> listParam = [];
      // ignore: unused_local_variable
      List<dynamic>? listMap = resp['resi'];

      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => const RekeningKUMPIN(
                  // list: listParam,
                  )));
    } else {
      const DialogBox().showImageDialog(
          message: resp['message'],
          isError: true,
          image: const Image(
            image: AssetImage('assets/images/icon-failed.png'),
          ),
          buttonCancel: 'OK',
          onOk: () {},
          context: context);
    }
  }

  @override
  void initState() {
    // _doInquiryRek();
    super.initState();
    // _doInquiryRek();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Pallete.primary,
          centerTitle: true,
          title: _appBarTitle,
          leading: IconButton(
              color: Colors.white,
              icon: const Icon(Icons.arrow_back_ios),
              onPressed: () {
                Navigator.pop(context);
              }),
        ),
        body: Column(children: <Widget>[
          Container(
            padding: const EdgeInsets.all(16),
            child: Expanded(
              child: Column(
                children: <Widget>[
                  Form(
                    key: _formKey,
                    // ignore: deprecated_member_use
                    autovalidateMode: AutovalidateMode.always,
                    child: SingleChildScrollView(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          const Text('Masukkan nomor rekening'),
                          Container(
                            alignment: Alignment.topLeft,
                            child: TextFormField(
                              keyboardType: TextInputType.number,
                              validator: (val) {
                                if (val!.isEmpty || val == '0') {
                                  return "Mohon diisi";
                                } else {
                                  return null;
                                }
                              },
                              inputFormatters: [
                                // ignore: deprecated_member_use
                                FilteringTextInputFormatter.digitsOnly,
                              ],
                              controller: _noRekcontroller,
                              maxLength: ISTConstants.acctToMaxLength,
                              decoration: const InputDecoration(
                                counterText: '',
                                hintText: 'Masukkan no. rekening',
                                hintStyle: ISTStyle.hintStyle,
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 16,
                          ),
                        ],
                      ),
                    ),
                  ),
                  ISTOutlineButton(
                    onPressed: () {
                  setState(() {});
                  if (!_doValidate()) return;
                  _doInquiryRek();
                    },
                    text: "Tambah Rekening",
                  ),
                ],
              ),
            ),
          ),
        ]));
  }
}
