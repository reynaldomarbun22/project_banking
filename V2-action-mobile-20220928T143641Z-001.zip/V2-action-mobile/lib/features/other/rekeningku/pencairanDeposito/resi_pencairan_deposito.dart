import 'package:bpd_aceh/components/ist_receipt_repo.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/utils/string_utils.dart';
import 'package:bpd_aceh/features/home/home_page.dart';
import 'package:bpd_aceh/features/other/rekeningku/pencairanDeposito/receipt_pencairan_deposito.dart';
import 'package:bpd_aceh/features/splash/splash.dart';
import 'package:flutter/material.dart';

class ReceiptPencairanDeposito extends StatefulWidget {
  static const routeName = '/transfer/receiptbas';
  final List<ISTReceiptItemPencairan> list;
  final List<ISTReceiptItemPencairan>? listSertif;
  final List<ISTReceiptItemInbox> lists;
  final String? amount;
  final ISTReceiptStatusPencairan? status;
  final String? noRef;
  final String? description;
  final String img;
  final String? title;
  final String? detail;
  final String? time;
  final String? date;
  final String? waktu;
  final String? srcAccount;
  final String? memo;
  final String? subtitle; //
  final String? titleresi;
  final String? nameBank;
  final String? additional;

  const ReceiptPencairanDeposito(
      {Key? key,
      this.subtitle,
      required this.lists,
      this.memo,
      this.srcAccount, //
      this.waktu,
      required this.list,
      required this.date,
      this.time,
      required this.detail,
      required this.amount,
      this.status,
      this.noRef,
      required this.img,
      this.title,
      this.titleresi,
      this.description,
      this.additional,
      this.listSertif,
      this.nameBank})
      : super(key: key);

  @override
  _ReceiptPencairanDepositoState createState() =>
      _ReceiptPencairanDepositoState();
}

class _ReceiptPencairanDepositoState extends State<ReceiptPencairanDeposito> {
  @override
  void initState() {
    // _saveInbox();
    super.initState();
  }

  // _saveInbox() async {
  //   InboxDBRepository repo = InboxDBRepository();
  //   await repo.open();
  //   InboxModel model = InboxModel();
  //   model.subtitle = widget.subtitle;
  //   model.listresi = jsonEncode(widget.lists);
  //   model.amount = widget.amount;
  //   model.time = widget.time;
  //   model.date = widget.date;
  //   model.detail = widget.detail;
  //   model.image = widget.img;
  //   model.status = widget.status.index.toString();
  //   model.titleresi = widget.titleresi;
  //   model.nameBank = widget.nameBank;

  //   // model.title = title;
  //   // model.srcAcc = srcAccount;
  //   model.noRef = widget.noRef;
  //   // model.memo =  memo;//
  //   await repo.insert(model);
  //   await repo.close();
  // }

  @override
  Widget build(BuildContext context) {
    _doFinish() {
      Navigator.pushNamedAndRemoveUntil(
          context, HomePage.routeName, ModalRoute.withName(Splash.routeName));
    }

    // ignore: unused_element
    _doAddFav() async {
      Map<String, Object> param = {};
      param['idresi'] = widget.noRef!;
      final resp = await API.post(context, '/favorite/add', param);
      if (resp != null && resp['code'] == 0) {
        showDialog(
          context: context,
          barrierDismissible: false,
          useRootNavigator: true,
          builder: (BuildContext context) {
            return AlertDialog(
              // contentPadding: EdgeInsets.all(8),
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(20.0)),
              ),
              content: SingleChildScrollView(
                child: Column(
                  children: <Widget>[
                    const Text(
                      'Berhasil',
                      style: TextStyle(color: Pallete.primary, fontSize: 20),
                    ),
                    const SizedBox(
                      height: 4,
                    ),
                    Image(
                      height: MediaQuery.of(context).size.width * 0.25,
                      image: const AssetImage('assets/images/icon-success.png'),
                    ),
                    const SizedBox(
                      height: 4,
                    ),
                    const Text('Favorit berhasil di tambahkan',
                        textAlign: TextAlign.center),
                    const SizedBox(
                      height: 8,
                    ),
                    Container(
                      alignment: Alignment.center,
                      child: OutlinedButton(
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(
                            color: Pallete.primary,
                          ),
                          primary: Pallete.primary,
                          shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.all(Radius.circular(18)),
                          ),
                        ),
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: Text(
                          "Ok",
                          style: Theme.of(context)
                              .textTheme
                              .bodyText1!
                              .copyWith(
                                  fontWeight: FontWeight.w600,
                                  color: Pallete.primary),
                        ),
                      ),
                    )
                  ],
                ),
              ),
              //actions: _checkbutton(context),
            );
          },
        );
      } else {
        showDialog(
          context: context,
          barrierDismissible: false,
          useRootNavigator: true,
          builder: (BuildContext context) {
            return AlertDialog(
              // contentPadding: EdgeInsets.all(8),
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(20.0)),
              ),
              content: SingleChildScrollView(
                child: Column(
                  children: <Widget>[
                    const Text(
                      'Peringatan',
                      style: TextStyle(
                        color: Colors.red,
                        fontSize: 20,
                      ),
                    ),
                    const SizedBox(
                      height: 4,
                    ),
                    Image(
                      height: MediaQuery.of(context).size.width * 0.25,
                      image: const AssetImage('assets/images/icon-warning.png'),
                    ),
                    const SizedBox(
                      height: 4,
                    ),
                    Text(resp['message'], textAlign: TextAlign.center),
                    const SizedBox(
                      height: 8,
                    ),
                    Container(
                      alignment: Alignment.center,
                      child: OutlinedButton(
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(
                            color: Colors.red,
                          ),
                          // splashColor: Colors.red,
                          shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.all(Radius.circular(18)),
                          ),
                        ),
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: Text(
                          "Batal",
                          style: Theme.of(context)
                              .textTheme
                              .bodyText1!
                              .copyWith(
                                  fontWeight: FontWeight.w600,
                                  color: Colors.red),
                        ),
                      ),
                    )
                  ],
                ),
              ),
              //actions: _checkbutton(context),
            );
          },
        );
      }

      // Navigator.pop(context);
    }

    return WillPopScope(
        onWillPop: () async => false,
        child: Scaffold(
            backgroundColor: Colors.white,
            body:

                // ISTReceiptDeposito(
                //     description: widget.description,
                //     resiItem: widget.listSertif,
                //     onTap: () {
                // Navigator.pop(context);
                //       _doAddFav();
                //
                //     },
                //     items: widget.list,
                //     onFinished: () {
                //       _doFinish();
                //     },
                //     type: "DEPOSITO",
                //     noref: 'ADVICE PENCAIRAN DEPOSITO',
                //     title: widget.titleresi,
                //     amount: widget.amount,
                //     detail: widget.time,
                //     // noRef: widget.noRef,
                //     date: widget.date,
                //     time: widget.detail,
                //     status: widget.status)
                ISTReceiptPencairan(
              items: widget.list,
              // onTap: () {
              //   _doAddFav();
              //   Navigator.pop(context);
              // },

              onFinished: () {
                _doFinish();
              },
              status: widget.status,
              type: "Pencairan",
              title: widget.titleresi,
              amount: widget.amount,
              time: widget.date,
              // noRef: widget.noRef,
              date: widget.date,
              footer1: widget.additional == null
                  ? Container()
                  : Text(
                      StringUtils.getValueAsString(widget.additional!),
                      style: const TextStyle(fontSize: 11),
                      textAlign: TextAlign.center,
                    ),
              // time: widget.detail,
            )));
  }
}
