import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_mpin.dart';
import 'package:bpd_aceh/components/ist_receipt_repo.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/crypto/ist_crypto.dart';
import 'package:bpd_aceh/features/other/rekeningku/pencairanDeposito/receipt_pencairan_deposito.dart';
import 'package:bpd_aceh/features/other/rekeningku/pencairanDeposito/resi_pencairan_deposito.dart';
import 'package:flutter/material.dart';

class MpinPencairanDeposito extends StatelessWidget {
  static const routeName = 'MPINPencairanDeposito';

  const MpinPencairanDeposito({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return ISTMPIN(
      onFinishedVal: (value) async {
        Map<String, Object> param = {};
        final String pinEnc = await ISTCrypto.encryptAES(value);
        param['mpin'] = pinEnc;

        final resp =
            await API.post(context, '/deposito/disbursement/post', param);
        if (resp['code'] != null && resp['code'] == 0) {
          List<ISTReceiptItemPencairan> listParam = [];
          List<ISTReceiptItemInbox> listParams = [];
          List<dynamic> listMap = resp['resi'];
          for (var item in listMap) {
            ISTReceiptItemPencairan itemParam =
                ISTReceiptItemPencairan(key: item['key'], value: item['value']);
            listParam.add(itemParam);
          }
          for (var item in listMap) {
            ISTReceiptItemInbox itemParams =
                ISTReceiptItemInbox(key: item['key'], value: item['value']);
            listParams.add(itemParams);
          }

          // ignore: unused_local_variable
          ISTReceiptStatusPencairan status = ISTReceiptStatusPencairan.suspect;

          if (resp['status'] != null && resp['status'] == 'success') {
            status = ISTReceiptStatusPencairan.success;
          }

          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => ReceiptPencairanDeposito(
                        // noRef: resp['idresi'],
                        date: resp['waktu'],
                        detail: resp['dstAccountOwnerName'],
                        nameBank: resp['destBankName'],
                        time: resp['dstAccountNo'],
                        img: "assets/images/icon-transfer-other-active.png",
                        // title: "Transfer Antar Bank Lain",
                        subtitle: "Transfer",
                        list: listParam,
                        lists: listParams,
                        additional: resp['additionalInfo'],
                        amount: resp['amountStr'],
                        // status: status,
                        titleresi: resp['title'],
                      )));
        } else if (resp['code'] != null && resp['code'] != 0) {
          if (resp['code'] == -1002) {
            //Salah MPIN
            const DialogBox().showImageDialog(
                message: resp['message'],
                isError: true,
                buttonCancel: 'OK',
                onCancel: () {
                  Navigator.pop(context);
                },
                onOk: () {},
                context: context);
          } else if (resp['code'] == -4901) {
            //Saldo Tidak Cukup
            const DialogBox().showImageDialog(
                message: resp['message'],
                isError: true,
                buttonCancel: 'OK',
                onCancel: () {
                  Navigator.pop(context);
                  Navigator.pop(context);
                  Navigator.pop(context);
                },
                onOk: () {},
                context: context);
          } else if (resp['code'] == -1108) {
            //MPIN Ke Blokir
            const DialogBox().showImageDialog(
                message: resp['message'],
                isError: true,
                buttonCancel: 'OK',
                onCancel: () {
                  Navigator.pop(context);
                  Navigator.pop(context);
                  Navigator.pop(context);
                },
                onOk: () {},
                context: context);
          } else {
            const DialogBox().showImageDialog(
                message: resp['message'],
                isError: true,
                buttonCancel: 'OK',
                onCancel: () {
                  Navigator.pop(context);
                },
                onOk: () {},
                context: context);
          }
        }
      },
    );
  }
}
