import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/features/other/rekeningku/pencairanDeposito/confirm_pencairan_deposito.dart';
import 'package:flutter/material.dart';

class ISTCardAccountDepositoItem extends StatelessWidget {
  const ISTCardAccountDepositoItem({
    Key? key,
    this.index,
    this.accountBalance,
    this.accountType,
    this.accountNumber,
    this.accountName,
    this.callback,
  }) : super(key: key);
  final String? accountBalance;
  final String? accountType;
  final String? accountNumber;
  final String? accountName;
  final int? index;

  final Function(String? accountBalance, String? accountType,
      String? accountNumber, String? accountName)? callback;

  @override
  Widget build(BuildContext context) {
    // ignore: unused_element
    _doSetDefaultRek() async {
      callback!(accountBalance, accountType, accountNumber,
          accountName);

      // Navigator.pushReplacement(
      //     context,
      //     new MaterialPageRoute(
      //         builder: (context) => new PembukaanTabungan(
      //               rekening: accountName,
      //             )));
      // Navigator.pop(context);
      // _doIn
    }

    _doInquiry() async {
      Map<String, Object?> param = {};
      param['accNo'] = accountNumber;
      final resp = await API.postNoLoading(
          context, '/deposito/disbursement/inquiry', param);
      if (resp['code'] == 0) {
        List<ISTConfirmationItem> listParam = [];
        List<dynamic> listMap = resp['resi'];
        for (var item in listMap) {
          ISTConfirmationItem itemParam =
              ISTConfirmationItem(key: item['key'], value: item['value']);
          listParam.add(itemParam);
        }
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => ConfirmPencairanDeposito(
                      list: listParam,
                    )));
      } else {
        const DialogBox().showImageDialog(
            message: resp['message'],
            isError: true,
            image: const Image(
              image: AssetImage('assets/images/icon-failed.png'),
            ),
            buttonCancel: 'OK',
            onOk: () {},
            context: context);
      }
    }

    return Card(
      color: Colors.white,
      child: InkWell(
        onTap: () {
          // _doSetDefaultRek();
          _doInquiry();
        },
        child: Container(
          padding: const EdgeInsets.all(8),
          child: Row(crossAxisAlignment: CrossAxisAlignment.center, children: <
              Widget>[
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: <Widget>[
                  Text(
                    accountBalance!,
                    style: const TextStyle(
                        color: Pallete.primary, fontWeight: FontWeight.bold),
                  ),
                  Text(accountType!, style: const TextStyle(color: Pallete.primary)),
                  Text(accountNumber!,
                      style: const TextStyle(color: Pallete.primary)),
                  Text(accountName!, style: const TextStyle(color: Pallete.primary)),
                ],
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
