import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/core/api/api.dart';

import 'package:flutter/material.dart';

class ListCabang extends StatefulWidget {
  static const routeName = '/ListCabang';

  const ListCabang({Key? key}) : super(key: key);
  @override
  _ListCabangState createState() => _ListCabangState();
}

class ListItem {
  // final String code;
  final String? name;
  final String? nameId;
  final int? index;

  ListItem({
    this.index,
    this.name,
    this.nameId,
  });
}

class _ListCabangState extends State<ListCabang> {
  List<ListItem> _listFiltered = [];
  List<ListItem> _listCabang = [];
  ListItem? code;

  @override
  void didChangeDependencies() {
    _doInquiryBank();
    super.didChangeDependencies();
  }

  @override
  void initState() {
    _doInquiryBank();
    super.initState();
  }

  // String getInitials(code) {
  //   print(code[0]);
  //   List<String> names = code.split(" ");

  //   String initials = "";
  //   int numWords = 2;

  //   if (numWords < names.length) {
  //     numWords = names.length;
  //   }
  //   initials = '${names[1][0]}';

  //   return initials;
  // }

  _doInquiryBank() async {
    // final _url = 'listBranch';
    const url = '/branch/list';
    var resp = await API.postNoLoading(context, url, {});
    // if (_listCabang.isNotEmpty) _listCabang.clear();
    if (resp['code'] == 0) {
      final List<dynamic> accountList = resp['listBranch'];
      List<ListItem> _listbuilds = [];
      // print(accountList[0]['productNameId']);
      for (var i = 0; i < accountList.length; i++) {
        // var initial = getInitials(accountList[i]['branchName']);
        _listbuilds.add(ListItem(
            // code: initial,
            index: i,
            name: accountList[i]['branchName'],
            nameId: accountList[i]['branchId']
            // link: null,
            // id: accountList[i]['id'].toString()
            ));
      }
      // for (var item in accountList) {
      //   var initial = getInitials(item['productNameid']);
      //   _listbuilds.add(ListItem(code: initial, name: item['productNameid']));
      // }

      print(_listbuilds);

      setState(() {
        _listCabang = _listbuilds;
        _listFiltered = _listCabang;
      });
    } else {
      const DialogBox().showErrorDialog(
        context: context,
        message: resp['message'],
      );
    }

    // catch (_) {}
  }

  // onTapped(ListItem item) {
  //   Navigator.pop(context, {"${item.code}-${item.name}"});
  // }
  onTapped(ListItem item) {
    Navigator.pop(context, {"${item.name}-${item.nameId}"});

    // Navigator.pushReplacement(
    //     context,
    //     new MaterialPageRoute(
    //         builder: (context) => new DeskripsiTab(
    //               name: item.name,
    //               // url: item.link,
    //               // id: item.id,
    //             )));
  }

  // List<BankItem> _listbuilds = [];
  // List<BankItem> _buildList = [];

  // get resp =>bank;

  // _doInquiryBank(){
  //   setState(() {
  //         _listbank = _listbuilds;
  //         _listFiltered = _listbank;
  //   });

  // }

  final TextEditingController _search = TextEditingController();
  String _searchText = "";
  Icon _searchIcon = const Icon(Icons.search);
  Widget _appBarTitle = const Text(
    'Pembukaan Tabungan',
    style: TextStyle(
      fontFamily: 'Poppins',
      color: Colors.white,

      // fontSize: FontSize.TITLE,
    ),
  );

  void _searchPressed() {
    setState(() {
      if (_searchIcon.icon == Icons.search) {
        _searchIcon = const Icon(
          Icons.close,
          color: Colors.white,
        );
        _appBarTitle = TextField(
          style: const TextStyle(color: Colors.white),
          autofocus: true,
          controller: _search,
          onChanged: (text) {
            setState(() {
              _searchText = text;
            });
          },
          decoration: const InputDecoration(
              // prefixIcon: Icon(Icons.search),
              hintText: 'Cari Nama Bank...',
              hintStyle: TextStyle(color: Colors.white)),
        );
      } else {
        _searchIcon = const Icon(Icons.search);
        _appBarTitle =
            const Text('Pilih Bank', style: TextStyle(color: Colors.white));
        _searchText = "";
        _search.clear();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          backgroundColor: Pallete.primary,
          leading: IconButton(
            icon: const Icon(
              Icons.arrow_back_ios,
              color: Colors.white,
            ),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          actions: <Widget>[
            IconButton(
              color: Colors.white,
              icon: _searchIcon,
              onPressed: _searchPressed,
            ),
          ],
          centerTitle: true,
          title: _appBarTitle),
      backgroundColor: Colors.white,
      body: Column(
        children: <Widget>[
          // SizedBox(
          //   height: 8,
          // ),
          Expanded(
            child: Container(child: _buildList()),
          ),
          // SizedBox(
          //   height: 8,
          // ),
        ],
      ),
    );
  }

  _buildList() {
    if (_searchText.isNotEmpty) {
      List<ListItem> tempList = List.empty();
      for (ListItem item in _listCabang) {
        if (item.name != null) {
          if (item.name!.toLowerCase().contains(_searchText.toLowerCase())) {
            tempList.add(item);
          }
        }
      }
      _listFiltered = tempList;
    } else {
      _listFiltered = _listCabang;
    }

    return ListView.separated(
        separatorBuilder: (BuildContext context, int index) => const Divider(),

        // separatorBuilder: (context, inx) {
        //   return Divider(
        //     endIndent: 2,
        //     color: Pallete.primary,
        //   );
        // },
        // padding: EdgeInsets.only(left: 16, right: 16),
        // ignore: unnecessary_null_comparison
        itemCount: _listCabang == null ? 0 : _listFiltered.length,
        shrinkWrap: true,
        itemBuilder: (context, index) {
          final item = _listFiltered[index];
          return Card(
            elevation: 0,
            child: InkWell(
              child: Container(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 8),
                child: Column(
                  children: <Widget>[
                    const SizedBox(
                      height: 4,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        Expanded(
                          // flex: 12,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Text(item.name!,
                                  style: const TextStyle(
                                      color: Pallete.primary,
                                      fontWeight: FontWeight.bold)),
                              // Text(item.name,
                              //     style: TextStyle(color: Pallete.THIRDY)),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 4,
                    )
                    // Divider(
                    //   color: Pallete.primary,
                    // ),
                  ],
                ),
              ),
              onTap: () => onTapped(item),
            ),
            // title: Text(item.name),
            // onTap: () => onTapped(item),
          );
        });
  }
}
