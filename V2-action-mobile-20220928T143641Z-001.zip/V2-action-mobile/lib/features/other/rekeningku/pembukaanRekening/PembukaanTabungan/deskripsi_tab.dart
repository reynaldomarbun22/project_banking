import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
// import 'package:bpd_aceh/features/inbox/inboxDB.dart';
import 'package:bpd_aceh/features/other/rekeningku/pembukaanRekening/PembukaanTabungan/pembukaan_tabungan.dart';
import 'package:flutter/material.dart';
import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';

class DeskripsiTab extends StatefulWidget {
  static const routeName = '/faq';
  final String? url;
  final String? name;
  final String? id;
  final int? index;

  const DeskripsiTab({Key? key, this.url, this.name, this.id, this.index})
      : super(key: key);

  @override
  _DeskripsiTabState createState() => _DeskripsiTabState();
}

// http://action.bankaceh.co.id/faq.html
// https://youtube.com/
class _DeskripsiTabState extends State<DeskripsiTab> {
  final flutterWebViewPlugin = FlutterWebviewPlugin();
  // final String url = "http://action.bankaceh.co.id/faq.html";
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.name!,
          style: const TextStyle(color: Colors.white),
        ),
        centerTitle: true,
        backgroundColor: Pallete.primary,
        leading: IconButton(
            icon: const Icon(
              Icons.arrow_back_ios,
              color: Colors.white,
            ),
            onPressed: () {
              Navigator.pop(context);
            }),
      ),
      body: Container(
        color: Colors.white,
        child: Column(
          children: [
            Expanded(
              child: Container(
                color: Colors.white,
                padding: const EdgeInsets.only(left: 8, right: 8, bottom: 8),
                child: WebviewScaffold(
                  url: widget.url!,
                  mediaPlaybackRequiresUserGesture: false,
                  withZoom: true,
                  withLocalStorage: true,
                  hidden: true,
                  withJavascript: true,
                  scrollBar: true,
                  clearCookies: true,
                  initialChild: Container(
                    color: Colors.white,
                    child: const Center(
                      child: Text('Waiting.....'),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              padding: const EdgeInsets.only(left: 16, right: 16),
              child: ISTOutlineButton(
                onPressed: () {
                  Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                          builder: (context) => PembukaanTabungan(
                                name: widget.name,
                                id: widget.id,
                                indexTab: widget.index,
                              )));
                },
                text: 'Lanjut',
              ),
            ),
            const SizedBox(
              height: 16,
            )
          ],
        ),
      ),
    );
  }
}
