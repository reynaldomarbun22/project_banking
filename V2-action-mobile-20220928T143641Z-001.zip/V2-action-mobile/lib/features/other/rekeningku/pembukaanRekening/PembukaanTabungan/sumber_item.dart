import 'package:flutter/material.dart';

class SumberItem {
  final String? sumber;
  final String? sumberKey;
  final int? sumberIndex;


  SumberItem(
      {Key? key,
      this.sumberKey,
     this.sumber,
     this.sumberIndex,
     });
}