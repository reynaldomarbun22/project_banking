import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_mpin.dart';
import 'package:bpd_aceh/components/ist_receipt_repo.dart';
import 'package:bpd_aceh/components/ist_receipt_tabungan.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/crypto/ist_crypto.dart';
import 'package:bpd_aceh/features/other/rekeningku/pembukaanRekening/PembukaanTabungan/receipt_pembukaan.dart';
import 'package:flutter/material.dart';

class MpinPembukaanRekening extends StatelessWidget {
  static const routeName = '/PembukaanTabungan/MpinPembukaanRekening';

  const MpinPembukaanRekening({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return ISTMPIN(
      onFinishedVal: (value) async {
        Map<String, Object> param = {};
        final String pinEnc = await ISTCrypto.encryptAES(value);
        param['mpin'] = pinEnc;

        final resp = await API.post(context, '/pembukaan-rek/request', param);
        if (resp['code'] != null && resp['code'] == 0) {
          List<ISTReceiptItemTabungan> listParam = [];
          List<ISTReceiptItemTabungan> listResi = [];
          List<ISTReceiptItemInbox> listParams = [];
          List<dynamic> listMap = resp['resi'];
          for (var item in listMap) {
            ISTReceiptItemTabungan itemParam =
                ISTReceiptItemTabungan(key: item['key'], value: item['value']);
            listParam.add(itemParam);
          }
          for (var item in listMap) {
            ISTReceiptItemInbox itemParams =
                ISTReceiptItemInbox(key: item['key'], value: item['value']);
            listParams.add(itemParams);
          }
          List<dynamic> listMapResi = resp['resiImageOA'];
          for (var items in listMapResi) {
            ISTReceiptItemTabungan itemResi = ISTReceiptItemTabungan(
                key: items['key'], value: items['value']);
            listResi.add(itemResi);
          }
          print(listMap);

          ISTReceiptStatusTabungan status = ISTReceiptStatusTabungan.suspect;

          if (resp['status'] != null && resp['status'] == 'success') {
            status = ISTReceiptStatusTabungan.success;
          }

          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => ReceiptPembukaanRekenig(
                        noRef: resp['idresi'],
                        date: resp['waktu'],
                        detail: resp['dstAccountOwnerName'],
                        nameBank: resp['destBankName'],
                        time: resp['dstAccountNo'],
                        img: "assets/images/icon-transfer-other-active.png",
                        // title: "Transfer Antar Bank Lain",
                        subtitle: "Transfer",
                        imgTab: resp['imageOA'],
                        addinfoImg: resp['additionalinfoImageOA'],
                        titleimg: resp['titelImageOA'],
                        listResi: listResi,
                        list: listParam,
                        lists: listParams,

                        amount: resp['amountStr'],
                        status: status,
                        titleresi: resp['destBankName'],
                      )));
        } else if (resp['code'] != null && resp['code'] != 0) {
          if (resp['code'] == -1002) {
            //Salah MPIN
            const DialogBox().showImageDialog(
                message: resp['message'],
                isError: true,
                buttonCancel: 'OK',
                onCancel: () {
                  Navigator.pop(context);
                },
                onOk: () {},
                context: context);
          } else if (resp['code'] == -4901) {
            //Saldo Tidak Cukup
            const DialogBox().showImageDialog(
                message: resp['message'],
                isError: true,
                buttonCancel: 'OK',
                onCancel: () {
                  Navigator.pop(context);
                  Navigator.pop(context);
                  Navigator.pop(context);
                },
                onOk: () {},
                context: context);
          } else if (resp['code'] == -1108) {
            //MPIN Ke Blokir
            const DialogBox().showImageDialog(
                message: resp['message'],
                isError: true,
                buttonCancel: 'OK',
                onCancel: () {
                  Navigator.pop(context);
                  Navigator.pop(context);
                  Navigator.pop(context);
                },
                onOk: () {},
                context: context);
          } else {
            const DialogBox().showImageDialog(
                message: resp['message'],
                isError: true,
                buttonCancel: 'OK',
                onCancel: () {
                  Navigator.pop(context);
                },
                onOk: () {},
                context: context);
          }
        }
      },
    );
  }
}
