
// class TujuanItem {
//   final String tujuan;
//   final String tujuanIndex;

//   TujuanItem(this.tujuan, this.tujuanIndex);

//   factory TujuanItem.fromJson(dynamic json) {
//     return TujuanItem(json['title'] as String, json['value'] as String);
//   }

//   @override
//   String toString() {
//     return '{ ${this.tujuan}, ${this.tujuanIndex} }';
//   }
// }
import 'package:flutter/material.dart';

class TujuanItem {
  final String? tujuan;
  final String? tujuanKey;
  final int? tujuanIndex;


  TujuanItem(
      {Key? key,
      this.tujuanKey,
     this.tujuan,
     this.tujuanIndex,
     });
}