import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/features/other/rekeningku/pembukaanRekening/PembukaanTabungan/pembukaan_tabungan.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:webview_flutter/webview_flutter.dart';

class SnKTabungan extends StatefulWidget {
  static const routeName = '/SnKTabungan';

  const SnKTabungan({Key? key}) : super(key: key);

  @override
  _SnKTabunganState createState() => _SnKTabunganState();
}

class _SnKTabunganState extends State<SnKTabungan> {
  bool switchControl = false;
  bool isLoading = false;
  final Set<Factory> gestureRecognizers = {
    Factory(() => EagerGestureRecognizer()),
  }.toSet();

  // ignore: unused_element
  _doSendBiometricsStatus(auth) async {
    final api = auth == true ? "/biometric/enable" : "/biometric/disable";
    final resp = await API.post(context, api, {});
    if (resp['code'] != null && resp['code'] == 0) {
      return true;
    } else if (resp['code'] != null && resp['code'] != 0) {
      const DialogBox().showImageDialog(
          message: resp['message'],
          isError: true,
          buttonCancel: 'OK',
          onOk: () {},
          context: context);

      return false;
    }
  }

  bool checklist = false;
  var textHolder = 'Tidak Aktif';

  void toggleChecklist(bool value) {
    setState(() {
      checklist = value;
    });
  }

  _getStatusBiometrics() async {
    final _bioStatus =
        await ISTConstants().getConstants(ISTConstants.biometricStatus);
    if (_bioStatus != null && _bioStatus == false) {
      setState(() {
        switchControl = false;
      });
    } else if (_bioStatus != null && _bioStatus == true) {
      setState(() {
        switchControl = true;
      });
    } else {
      setState(() {
        switchControl = false;
      });
    }
  }

  @override
  void initState() {
    _getStatusBiometrics();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    //bool _boolValue = false;
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Pallete.primary,
          title: const Text(
            "Pembukaan Tabungan",
            style: TextStyle(color: Colors.white),
          ),
          centerTitle: true,
          leading: IconButton(
              icon: const Icon(
                Icons.arrow_back_ios,
                color: Colors.white,
              ),
              onPressed: () {
                Navigator.pop(context);
              }),
        ),
        body: SafeArea(
            child: Column(children: <Widget>[
          Expanded(
            child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                child: Stack(
                  children: <Widget>[
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.7,
                      width: MediaQuery.of(context).size.width * 0.9,
                      child: WebView(
                        initialUrl:
                            'https://action.bankaceh.co.id/snk-deposito.html',
                        debuggingEnabled: true,
                        javascriptMode: JavascriptMode.unrestricted,
                        gestureRecognizers: gestureRecognizers
                            as Set<Factory<OneSequenceGestureRecognizer>>?,
                        onPageFinished: (finish) {
                          setState(() {
                            isLoading = false;
                          });
                        },
                      ),
                    ),
                    isLoading
                        ? const Center(
                            child: Text('Waiting...'),
                          )
                        : Stack(),
                    // SizedBox(
                    //   height: 16,
                    // ),
                  ],
                )),
          ),
          const SizedBox(
            height: 16,
          ),
          const Divider(
            height: 0,
            thickness: 1,
            color: Pallete.primary,
          ),
          Container(
            padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
            child: Row(
              mainAxisSize: MainAxisSize.max,
              children: <Widget>[
                Checkbox(
                    activeColor: Pallete.primary,
                    value: checklist,
                    onChanged: (value) {
                      setState(() {
                        checklist = !checklist;
                      });
                    }),
                Expanded(
                  child: GestureDetector(
                    onTap: () {
                      setState(() {
                        checklist = !checklist;
                      });
                    },
                    child: Container(
                      padding: const EdgeInsets.only(right: 16.0),
                      child: const Text(
                        "Saya telah membaca, memahami, dan menyetujui syarat dan ketentuan yang berlaku untuk pembukaan rekening tabungan.",
                        softWrap: true,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.only(left: 16, right: 16),
            child: ISTOutlineButton(
                text: 'Lanjut',
                onPressed: () async {
                  if (checklist) {
                    Navigator.pushReplacementNamed(
                        context, PembukaanTabungan.routeName);

                    // _checkBiometrics();
                    // return _showMyDialog(context);
                  }
                }),
          ),
          const SizedBox(height: 16)
        ])));
  }
}
      
      
//        SafeArea(
//         child: Column(
//           children: <Widget>[
//             Expanded(
//               child: SingleChildScrollView(
//                 child: Padding(
//                     padding: const EdgeInsets.symmetric(
//                         horizontal: 16, vertical: 16),
//                     child: Column(
//                       children: <Widget>[
//                         ParagraphWidget.lv1(
//                           judul: 'SYARAT DAN KETENTUAN PEMBUKAAN TABUNGAN',
//                           textList: [
//                             TextSpan(text: '\n'),
//                           ],
//                         ),
//                         ParagraphWidget.lv1(
//                           number: "1.",
//                           textList: [
//                             TextSpan(
//                                 text:
//                                     'Layanan Mobile Banking Bank Aceh hanya dapat digunakan untuk jenis-jenis transaksi yang telah ditentukan bank. Nasabah harus memenuhi persyaratan serta mematuhi limit atau batasan transaksi yang telah ditentukan oleh bank.'),
//                           ],
//                         ),
                       
//                         ParagraphWidget.lv1(
//                           number: "2.",
//                           textList: [
//                             TextSpan(
//                                 text:
//                                     'Nasabah dapat menggunakan Mobile Banking Bank Aceh untuk mendapatkan info rekening dan atau melakukan transaksi perbankan yang telah disediakan oleh bank.'),
//                           ],
//                         ),
//                         ParagraphWidget.lv1(
//                           number: "3.",
//                           textList: [
//                             TextSpan(
//                                 text:
//                                     'Jenis fasilitas layanan Mobile Banking Bank Aceh yang disediakan oleh bank terdiri dari transaksi non-finansial dan transaksi finansial, bank memiliki kewenangan untuk mengubah fasilitas ataupun kebijakan atas layanan Mobile Banking Bank Aceh setiap saat.'),
//                           ],
//                         ),
                       
//                         SizedBox(
//                           height: 16,
//                         ),
//                         Divider(
//                           height: 0,
//                           thickness: 1,
//                           color: Pallete.primary,
//                         ),
//                         Container(
//                           padding: EdgeInsets.symmetric(
//                               vertical: 16, horizontal: 16),
//                           child: Row(
//                             mainAxisSize: MainAxisSize.max,
//                             children: <Widget>[
//                               Checkbox(
//                                   activeColor: Pallete.primary,
//                                   value: checklist,
//                                   onChanged: (value) {
//                                     setState(() {
//                                       checklist = !checklist;
//                                     });
//                                   }),
//                               Expanded(
//                                 child: GestureDetector(
//                                   onTap: () {
//                                     setState(() {
//                                       checklist = !checklist;
//                                     });
//                                   },
//                                   child: Container(
//                                     padding: const EdgeInsets.only(right: 16.0),
//                                     child: Text(
//                                       "Saya telah membaca, memahami, dan menyetujui syarat dan ketentuan yang berlaku untuk pembukaan rekening tabungan.",
//                                       softWrap: true,
//                                     ),
//                                   ),
//                                 ),
//                               ),
//                             ],
//                           ),
//                         ),
//                         Container(
//                           // padding: EdgeInsets.only(left: 16, right: 16),
//                           child: ISTOutlineButton(
//                               text: 'Lanjut',
//                               onPressed: () async {
//                                 if (checklist) {
//                                   Navigator.pushReplacementNamed(
//                                       context, PembukaanTabungan.routeName);

//                                   // _checkBiometrics();
//                                   // return _showMyDialog(context);
//                                 }
//                               }),
//                         ),
//                         SizedBox(height: 16)
//                       ],
//                     )),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
