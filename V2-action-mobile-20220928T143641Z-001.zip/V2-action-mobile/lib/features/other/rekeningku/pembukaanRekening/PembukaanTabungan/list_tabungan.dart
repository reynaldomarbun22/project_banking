import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/features/other/rekeningku/pembukaanRekening/PembukaanTabungan/deskripsi_tab.dart';
import 'package:flutter/material.dart';

class ListTabungan extends StatefulWidget {
  static const routeName = '/ListTabungan';

  const ListTabungan({Key? key}) : super(key: key);
  @override
  _ListTabunganState createState() => _ListTabunganState();
}

class ListItem {
  final String? code;
  final String? name;
  final String? link;
  final String? id;
  final int? indexTab;
  ListItem({
    this.code,
    this.name,
    this.link,
    this.id,
    this.indexTab,
  });
}

class _ListTabunganState extends State<ListTabungan> {
  List<ListItem> _listFiltered = [];
  List<ListItem> _listTabungan = [];
  ListItem? code;

  @override
  void didChangeDependencies() {
    _doInquiryBank();
    super.didChangeDependencies();
  }

  @override
  void initState() {
    _doInquiryBank();
    super.initState();
  }

  String getInitials(code) {
    print(code[0]);
    List<String> names = code.split(" ");

    String initials = "";
    int numWords = 2;

    if (numWords < names.length) {
      numWords = names.length;
    }
    initials = names[1][0];

    return initials;
  }

  _doInquiryBank() async {
    const _url = '/jenistabungan/list';
    // final  String url='';
    var resp = await API.postNoLoading(context, _url, {});
    if (_listTabungan.isNotEmpty) _listTabungan.clear();
    if (resp['code'] == 0) {
      final List<dynamic> accountList = resp['listJenisTabungan'];
      List<ListItem> _listbuilds = [];
      // print(accountList[0]['productNameId']);
      for (var i = 0; i < accountList.length; i++) {
        var initial = getInitials(accountList[i]['productNameId']);

        _listbuilds.add(ListItem(
            code: initial,
            indexTab: i,
            name: accountList[i]['productNameId'],
            link: accountList[i]['url'],
            id: accountList[i]['id'].toString()));
      }
      // for (var item in accountList) {
      //   var initial = getInitials(item['productNameid']);
      //   _listbuilds.add(ListItem(code: initial, name: item['productNameid']));
      // }

      print(_listbuilds);

      setState(() {
        _listTabungan = _listbuilds;
        _listFiltered = _listTabungan;
      });
    } else {
      const DialogBox().showErrorDialog(
        context: context,
        message: resp['message'],
      );
    }

    // catch (_) {}
  }

  // onTapped(ListItem item) {
  //   Navigator.pop(context, {"${item.code}-${item.name}"});
  // }
  onTapped(ListItem item) {
    Navigator.pushReplacement(
        context,
        MaterialPageRoute(
            builder: (context) => DeskripsiTab(
                  name: item.name,
                  url: item.link,
                  id: item.id,
                  index: item.indexTab,
                )));
  }

  // List<BankItem> _listbuilds = [];
  // List<BankItem> _buildList = [];

  // get resp =>bank;

  // _doInquiryBank(){
  //   setState(() {
  //         _listbank = _listbuilds;
  //         _listFiltered = _listbank;
  //   });

  // }

  // ignore: unused_field
  final TextEditingController _search = TextEditingController();
  final String _searchText = "";
  // ignore: unused_field
  final Icon _searchIcon = const Icon(Icons.search);
  final Widget _appBarTitle = const Text(
    'Pembukaan Tabungan',
    style: TextStyle(
      fontFamily: 'Poppins',
      color: Colors.white,

      // fontSize: FontSize.TITLE,
    ),
  );

  // void _searchPressed() {
  //   setState(() {
  //     if (this._searchIcon.icon == Icons.search) {
  //       this._searchIcon = Icon(
  //         Icons.close,
  //         color: Colors.white,
  //       );
  //       this._appBarTitle = TextField(
  //         style: TextStyle(color: Colors.white),
  //         autofocus: true,
  //         controller: _search,
  //         onChanged: (text) {
  //           setState(() {
  //             this._searchText = text;
  //           });
  //         },
  //         decoration: InputDecoration(
  //             prefixIcon: Icon(Icons.search),
  //             hintText: 'Cari Nama Bank...',
  //             hintStyle: TextStyle(color: Colors.white)),
  //       );
  //     } else {
  //       this._searchIcon = Icon(Icons.search);
  //       this._appBarTitle =
  //           Text('Pilih Bank', style: TextStyle(color: Colors.white));
  //       this._searchText = "";
  //       _search.clear();
  //     }
  //   });
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          backgroundColor: Pallete.primary,
          leading: IconButton(
            icon: const Icon(
              Icons.arrow_back_ios,
              color: Colors.white,
            ),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          // actions: <Widget>[
          //   IconButton(
          //     color: Colors.white,
          //     icon: _searchIcon,
          //     onPressed: _searchPressed,
          //   ),
          // ],
          centerTitle: true,
          title: _appBarTitle),
      backgroundColor: Colors.white,
      body: Column(
        children: <Widget>[
          // SizedBox(
          //   height: 8,
          // ),
          Expanded(
            child: Container(child: _buildList()),
          ),
          // SizedBox(
          //   height: 8,
          // ),
        ],
      ),
    );
  }

  _buildList() {
    if (_searchText.isNotEmpty) {
      List<ListItem> tempList = List.empty();
      for (ListItem item in _listTabungan) {
        if (item.name != null) {
          if (item.name!.toLowerCase().contains(_searchText.toLowerCase())) {
            tempList.add(item);
          }
        }
      }
      _listFiltered = tempList;
    } else {
      _listFiltered = _listTabungan;
    }

    return ListView.separated(
        separatorBuilder: (BuildContext context, int index) => const Divider(),

        // separatorBuilder: (context, inx) {
        //   return Divider(
        //     endIndent: 2,
        //     color: Pallete.primary,
        //   );
        // },
        // padding: EdgeInsets.only(left: 16, right: 16),
        // ignore: unnecessary_null_comparison
        itemCount: _listTabungan == null ? 0 : _listFiltered.length,
        shrinkWrap: true,
        itemBuilder: (context, index) {
          final item = _listFiltered[index];
          return Card(
            elevation: 0,
            child: InkWell(
              child: Container(
                padding: const EdgeInsets.only(left: 4, right: 4),
                child: Column(
                  children: <Widget>[
                    const SizedBox(
                      height: 4,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        Expanded(
                          flex: 2,
                          child: CircleAvatar(
                            backgroundColor: Pallete.primary,
                            child: Text(
                              item.code!,
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                        const SizedBox(
                          width: 8,
                        ),
                        Expanded(
                          flex: 12,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Text(item.name!,
                                  style: const TextStyle(
                                      color: Pallete.primary,
                                      fontWeight: FontWeight.bold)),
                              Text(item.name!,
                                  style: const TextStyle(color: Pallete.thirdy)),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 4,
                    )
                    // Divider(
                    //   color: Pallete.primary,
                    // ),
                  ],
                ),
              ),
              onTap: () => onTapped(item),
            ),
            // title: Text(item.name),
            // onTap: () => onTapped(item),
          );
        });
  }
}
