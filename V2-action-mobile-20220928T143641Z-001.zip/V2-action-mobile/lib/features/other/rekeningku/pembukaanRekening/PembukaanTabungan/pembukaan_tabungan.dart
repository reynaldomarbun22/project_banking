
// ignore_for_file: unnecessary_string_escapes

import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_card_account_item.dart';
import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/ist_style.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/core/utils/string_utils.dart';
import 'package:bpd_aceh/features/other/rekeningku/pembukaanRekening/PembukaanTabungan/confirm_page.dart';
import 'package:bpd_aceh/features/other/rekeningku/pembukaanRekening/PembukaanTabungan/list_cabang.dart';
import 'package:bpd_aceh/features/other/rekeningku/pembukaanRekening/PembukaanTabungan/list_tabungan.dart';
import 'package:bpd_aceh/features/other/rekeningku/pembukaanRekening/PembukaanTabungan/sumber_item.dart';
import 'package:bpd_aceh/features/other/rekeningku/pembukaanRekening/PembukaanTabungan/tujuan_item.dart';
import 'package:bpd_aceh/features/other/rekeningku/pengaturanRekening/page/ist_list_rek.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
// import 'package:contact_picker/contact_picker.dart';

class PembukaanTabungan extends StatefulWidget {
  static const routeName = '/PembukaanTabungan';

  final String? nomorHp;
  final String? name;
  final String? rekening;
  final String? id;
  final String? value;
  final int? indexTab;
  final Function()? callback;

  const PembukaanTabungan({
    Key? key,
    this.nomorHp,
    this.value,
    this.callback,
    this.name,
    this.id,
    this.indexTab,
    this.rekening,
  }) : super(key: key);

  @override
  // ignore: no_logic_in_create_state
  _PembukaanTabunganState createState() => _PembukaanTabunganState(nomorHp);
}

class _PembukaanTabunganState extends State<PembukaanTabungan> {
  String? dropdownValue;
  final TextEditingController _numTopupController = TextEditingController();
  String nomorhp = "";
  String accountName = "";
  String? redaksiname = "";

  final String? nomorHp;
  final _nominalPembukaancontroller = ISTConstants().moneyMaskedController;
  final _jenisTabunganController = TextEditingController();
  // ignore: unused_field
  final _tujuanPembukaanController = TextEditingController();
  // ignore: unused_field
  final _jenisPenandaanController = TextEditingController();
  final _jenisCabangController = TextEditingController();
  final _jenisRekeningController = TextEditingController();
  // ignore: unused_field
  final _catatanTabungan = TextEditingController();
  final focusNode = FocusNode();

  _PembukaanTabunganState(this.nomorHp);

  @override
  void initState() {
    // if (nomorHp != null) {
    //   _numTopupController.text = nomorHp;
    //   fromContact = true;
    // }
    if (widget.name != null) {
      setState(() {
        _jenisTabunganController.text = widget.name!;
      });
    }
    super.initState();
    // SystemChannels.textInput.invokeMethod('TextInput.hide');
    _getTujuan();
    _getSumber();
    _getRedaksi();
  }

  // ignore: unused_field
  bool _numError = false;
  bool _dropError = false;
  bool _success = true;
  bool fromContact = false;

  _doValidate() {
    if (_numTopupController.text == '') {
      setState(() {
        _numError = true;
      });
      _success = false;
    }

    if (_selectedTujuan == null) {
      setState(() {
        _dropError = true;
      });
      _success = false;
    } else if (_selectedSumber == null) {
      setState(() {
        _dropError = true;
      });
      _success = false;
    } else {
      _numError = false;
      _dropError = false;
      _success = true;
    }
    return _success;
  }

  _doInquiry() async {
    setState(() {
      _doValidate();
    });

    Map<String, Object?> param = {};
    //param['denomIdx'] = double.parse(_selected.denomination).toInt();
    // param['denomIdx'] = _selected.denomIndex;
    // param['phoneNo'] = _numTopupController.text;

    // param['productAccountName'] = ;
    param['productAccountIdx'] = widget.indexTab;
    param['sourceAccount'] = _accountType;
    param['sourceAccountNumber'] = _accountNumber;
    param['branch'] = bankName;
    param['branchId'] = bank;
    param['depositAmount'] =
        int.parse(_nominalPembukaancontroller.text.replaceAll(",", ""));
    param['sourcesOfFund'] = _selectedSumber!.sumber;
    param['purposeOfOpeningTheAccount'] = _selectedTujuan!.tujuan;

    final resp =
        await API.postNoLoading(context, '/pembukaan-rek/inquiry', param);
    if (resp['code'] == 0) {
      List<ISTConfirmationItem> listParam = [];
      List<dynamic> listMap = resp['resi'];
      for (var item in listMap) {
        ISTConfirmationItem itemParam =
            ISTConfirmationItem(key: item['key'], value: item['value']);
        listParam.add(itemParam);
      }
      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => ConfirmPembukaanRekening(
                    list: listParam,
                  )));
    } else {
      const DialogBox().showImageDialog(
          message: resp['message'],
          isError: true,
          image: const Image(
            image: AssetImage('assets/images/icon-failed.png'),
          ),
          buttonCancel: 'OK',
          onOk: () {},
          context: context);
    }
  }

  List<TujuanItem> _list = [];
  TujuanItem? _selectedTujuan;

  _getTujuan() async {
    try {
      setState(() {
        _selectedTujuan = null;
      });
      if (_list.isNotEmpty) {
        Future.delayed(Duration.zero);
        _list.clear();
      }
      Map<String, Object> param = {};
      // param['listTujuanPembukanRekening'] = _tujuanPembukaanController.text;
      final resp =
          await API.postNoLoading(context, '/tujuan-pembukaan-rek/list', param);
      if (resp['code'] == 0) {
        // print(resp);
        // print(resp['listTujuanPembukanRekening']);
        // var listResp = json.decode(resp['listTujuanPembukanRekening']);
        // List<dynamic> listRespMini = (listResp);
        // List<TujuanItem> listTujuan =
        //     listResp.map((e) => TujuanItem.fromJson(e)).toList();

        // print(listTujuan);
        // // for (var j = 0; j < datas.length; j++) {
        // //   TujuanItem items = TujuanItem(
        // //       // tujuanIndex: item["value"],
        // //       // tujuan: resp[i].toString(),
        // //       tujuan: datas[j].toString());
        // //   listTujuan.add(items);
        // // }
        // // print(listTujuan);
        // setState(() {
        //   _list = listTujuan;
        // });
        var listResp = resp['listTujuanPembukanRekening'];
        List<dynamic> listRespMini = (listResp);
        List<TujuanItem> listTujuan = [];
        //for (var item in listRespMini) {
        for (var i = 0; i < listRespMini.length; i++) {
          TujuanItem items = TujuanItem(
            tujuanKey: listRespMini[i]['value'],
            tujuanIndex: i,
            tujuan: listRespMini[i]['title'],
          );

          listTujuan.add(items);
        }

        setState(() {
          _list = listTujuan;
        });
      }
    } catch (_) {}
  }

  List<SumberItem> _listSumber = [];
  SumberItem? _selectedSumber;

  _getSumber() async {
    try {
      setState(() {
        _selectedSumber = null;
      });
      if (_listSumber.isNotEmpty) {
        Future.delayed(Duration.zero);
        _listSumber.clear();
      }
      Map<String, Object> param = {};
      // param['listTujuanPembukanRekening'] = _tujuanPembukaanController.text;
      final resp = await API.postNoLoading(context, '/sumber-dana/list', param);
      if (resp['code'] == 0) {
        // print(resp);
        // print(resp['listTujuanPembukanRekening']);
        // var listResp = json.decode(resp['listTujuanPembukanRekening']);
        // List<dynamic> listRespMini = (listResp);
        // List<TujuanItem> listTujuan =
        //     listResp.map((e) => TujuanItem.fromJson(e)).toList();

        // print(listTujuan);
        // // for (var j = 0; j < datas.length; j++) {
        // //   TujuanItem items = TujuanItem(
        // //       // tujuanIndex: item["value"],
        // //       // tujuan: resp[i].toString(),
        // //       tujuan: datas[j].toString());
        // //   listTujuan.add(items);
        // // }
        // // print(listTujuan);
        // setState(() {
        //   _list = listTujuan;
        // });
        var listResp = resp['listPendanaan'];
        List<dynamic> listRespMini2 = (listResp);
        List<SumberItem> listSumber1 = [];
        //for (var item in listRespMini) {
        for (var i = 0; i < listRespMini2.length; i++) {
          SumberItem items = SumberItem(
            sumberKey: listRespMini2[i]['value'],
            sumberIndex: i,
            sumber: listRespMini2[i]['title'],
          );

          listSumber1.add(items);
        }

        setState(() {
          _listSumber = listSumber1;
        });
      }
    } catch (_) {}
  }

  // final ContactPicker _contactPicker = new ContactPicker();
  // Contact _contact;

  bool status = false;
  String? result;
  String bank = "";
  String bankName = "";

  // ignore: unused_field
  var _accountBalance = "";
  // ignore: unused_field
  var _accountName = "";
  var _accountNumber = "";
  var _accountType = "";

  _doGoToListTabungan() async {
    // ignore: unused_local_variable
    var result = await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (BuildContext context) => const ListTabungan(),
        ));
    // final res = result.toString().replaceAll("\{", "").replaceAll("\}", "");

    // if (widget.name != null)
    //   setState(() {
    //     _jenisTabunganController.text = widget.name;
    //   });
  }

  void showAccountTabungan({
    required BuildContext context,
    List<ISTCardAccountTabunganItem>? list,
    List<ISTListRek>? listRek,
  }) {
    showDialog(
        context: context,
        barrierDismissible: true,
        builder: (context) {
          return Center(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Colors.white,
              ),
              height: MediaQuery.of(context).size.height * 0.7,
              width: MediaQuery.of(context).size.width * 0.8,
              child: Scaffold(
                  body: Column(children: <Widget>[
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.7 - 52,
                  // child: SingleChildScrollView(
                  child: Center(
                    child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    // SizedBox(height: 8),

                    const Image(
                      image: AssetImage('assets/images/rek.png'),
                      // color: Pallete.primary,
                      width: 90,
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      "Daftar Rekening Tabungan Anda",
                      style: TextStyle(
                          color: Pallete.primary,
                          fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    // Text('Silakan pilih rekening',
                    //     style: TextStyle(color: Pallete.primary)),
                    // Text('untuk dijadikan rekening utama',
                    //     style: TextStyle(color: Pallete.primary)),
                    const SizedBox(height: 8),
//sadasdas
                    Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12.0,
                        ),
                        child: SizedBox(
                          height: MediaQuery.of(context).size.height * 0.7 -
                              187,
                          child: SingleChildScrollView(
                              child: Column(children: list!)),
                        )),
                    //asdasdas
                  ],
                    ),
                    // ),
                  ),
                ),
                const Spacer(),
                ISTFlatButton(
                  onPressed: () {
                Navigator.pop(context);
                  },
                  text: 'Tutup',
                  color: Pallete.primary,
                )
              ])),
            ),
          );
        });
  }

  _doInquiryListAccount() async {
    final resp = await API.post(context, '/acct/listAccount', {});
    if (resp != null && resp['code'] == 0) {
      var listResp = resp['accountList'];
      List<dynamic> listRespDyn = (listResp);
      List<ISTCardAccountTabunganItem> listParam = [];
      // ignore: unused_local_variable
      List<ISTListRek> listParamss = [];

      for (var i = 0; i < listRespDyn.length; i++) {
        ISTCardAccountTabunganItem cardItem = ISTCardAccountTabunganItem(
          accountBalance: listRespDyn[i]['accountBalance'], //
          accountName: listRespDyn[i]['accountOwnerName'],
          accountNumber: listRespDyn[i]['accountNo'], //
          accountType: listRespDyn[i]['accountProductName'], //
          isPrimary: listRespDyn[i]['accountDefault'],
          index: i,
          callback: (accountBalance, accountType, accountNumber, accountName) {
            // Navigator.push(context);
            // Navigator.pushReplacement(
            //     context,
            //     new MaterialPageRoute(
            //         builder: (context) => new PembukaanTabungan(
            //               name: accountName,
            //             )));
            setState(() {
              _jenisRekeningController.text =
                  accountName! + " - " + accountNumber!;
              _accountBalance = accountBalance!;
              _accountType = accountType!;
              _accountNumber = accountNumber;
              _accountName = accountName;
            });
            if (widget.callback != null) widget.callback!();
          },
        );

        listParam.add(cardItem);
      }
      showAccountTabungan(
        context: context,
        list: listParam,
      );
    }
  }

  _doGoToListCabang() async {
    var result = await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (BuildContext context) => const ListCabang(),
        ));
    final res = result.toString().replaceAll("\{", "").replaceAll("\}", "");
    if (res != "null") {
      setState(() {
        List<String> resList = res.split("-");

        bank = resList[0];
        bankName = resList[1];

        _jenisCabangController.text = bank + '-' + bankName;
      });
    }
  }

  _getRedaksi() async {
    final resp = await API.postNoLoading(context, '/redaksi/dao', {});
    if (resp['code'] == 0) {
      setState(() {
        redaksiname = resp['redaksi'];
      });
    }
  }
  // _doGoToListRekening() async {
  //   var result = await Navigator.push(
  //       context,
  //       MaterialPageRoute(
  //         builder: (BuildContext context) => new DaftarBL(),
  //       ));
  //   final res = result.toString().replaceAll("\{", "").replaceAll("\}", "");
  //   if (res != "null")
  //     setState(() {
  //       List<String> resList = res.split("");
  //       bank = resList[0];
  //       bankName = resList[1];
  //       _jenisRekeningController.text = res;
  //     });
  // }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        resizeToAvoidBottomInset: true,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          centerTitle: true,
          title: const Text("Pembukaan Tabungan",
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'Poppins',
              )),
          elevation: 0.0,
          backgroundColor: Pallete.primary,
        ),
        backgroundColor: Colors.white,
        body: SingleChildScrollView(
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  const SizedBox(height: 16),
                  Container(
                    alignment: Alignment.center,
                    padding: const EdgeInsets.only(left: 16, right: 16),
                    color: Colors.white,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        const Text(
                          "Jenis Tabungan",
                        ),
                        Container(
                          alignment: Alignment.topLeft,
                          child: TextFormField(
                            validator: (val) {
                              if (val!.isEmpty) {
                                return "Mohon diisi";
                              } else {
                                return null;
                              }
                            },
                            controller: _jenisTabunganController,
                            onTap: () {
                              _doGoToListTabungan();
                            },
                            readOnly: true,
                            showCursor: false,
                            decoration: const InputDecoration(
                              // errorText:
                              //     _kodeBankError ? "Mohon diisi" : null,
                              hintText: 'Pilih Jenis Tabungan',
                              hintStyle: ISTStyle.hintStyle,
                              suffixIcon: Icon(
                                Icons.keyboard_arrow_right,
                                size: 38,
                              ),
                            ),
                          ),
                        ),
                        _dropError
                            ? Container(
                                alignment: Alignment.centerLeft,
                                child: const Text(
                                  'Mohon pilih Jenis Tabungan',
                                  style: TextStyle(color: Colors.red),
                                ),
                              )
                            : const SizedBox.shrink(),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    alignment: Alignment.center,
                    padding: const EdgeInsets.only(left: 16, right: 16),
                    color: Colors.white,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        const Text(
                          "Pilih Rekening Sumber",
                        ),
                        Container(
                          alignment: Alignment.topLeft,
                          child: TextFormField(
                            validator: (val) {
                              if (val!.isEmpty) {
                                return "Mohon diisi";
                              } else {
                                return null;
                              }
                            },
                            controller: _jenisRekeningController,
                            onTap: () {
                              _doInquiryListAccount();
                            },
                            readOnly: true,
                            showCursor: false,
                            decoration: const InputDecoration(
                              suffixStyle: TextStyle(),
                              // errorText:
                              //     _kodeBankError ? "Mohon diisi" : null,
                              hintText: 'Pilih Rekening Sumber',
                              hintStyle: ISTStyle.hintStyle,
                              suffixIcon: Icon(
                                Icons.keyboard_arrow_right,
                                size: 38,
                              ),
                            ),
                          ),
                        ),
                        _dropError
                            ? Container(
                                alignment: Alignment.centerLeft,
                                child: const Text(
                                  'Mohon pilih Rekening Sumber',
                                  style: TextStyle(color: Colors.red),
                                ),
                              )
                            : const SizedBox.shrink(),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    alignment: Alignment.center,
                    padding: const EdgeInsets.only(left: 16, right: 16),
                    color: Colors.white,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        const Text(
                          "Kantor Pembukaan Rekening",
                        ),
                        Container(
                          alignment: Alignment.topLeft,
                          child: TextFormField(
                            validator: (val) {
                              if (val!.isEmpty) {
                                return "Mohon diisi";
                              } else {
                                return null;
                              }
                            },
                            enableInteractiveSelection: false,
                            controller: _jenisCabangController,
                            onTap: () {
                              _doGoToListCabang();
                            },
                            // onEditingComplete: ,
                            readOnly: true,
                            showCursor: false,
                            decoration: const InputDecoration(
                              // errorText:
                              //     _kodeBankError ? "Mohon diisi" : null,
                              hintText: 'Pilih Kantor Pembukaan Rekening',
                              hintStyle: ISTStyle.hintStyle,
                              suffixIcon: Icon(
                                Icons.keyboard_arrow_right,
                                size: 38,
                              ),
                            ),
                          ),
                        ),
                        _dropError
                            ? Container(
                                alignment: Alignment.centerLeft,
                                child: const Text(
                                  'Mohon pilih kantor pembukaan rekening',
                                  style: TextStyle(color: Colors.red),
                                ),
                              )
                            : const SizedBox.shrink(),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    alignment: Alignment.center,
                    padding: const EdgeInsets.only(left: 16, right: 16),
                    color: Colors.white,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        const Text(
                          "Setoran Awal",
                        ),
                        Container(
                          alignment: Alignment.topLeft,
                          child: TextFormField(
                            enableSuggestions: false,
                            enableInteractiveSelection: false,
                            autofocus: false,
                            expands: false,
                            validator: (val) {
                              if (val!.isEmpty || val == '0') {
                                return "Mohon diisi";
                              } else {
                                return null;
                              }
                            },
                            inputFormatters: [
                              // ignore: deprecated_member_use
                              FilteringTextInputFormatter.digitsOnly,
                            ],
                            // controller: _nominalPembukaancontroller,
                            maxLength: ISTConstants.nominalMaxLength,
                            onChanged: (value) {
                              // if (_nominalPembukaancontroller.text.trim().isEmpty) {
                              //   _nominalPembukaancontroller.text = '';
                              // }
                            },
                            keyboardType: TextInputType.number,
                            decoration: const InputDecoration(
                              counterText: '',
                              // errorText:_nominalBLError ? "Mohon diisi" : null,
                              prefixText: 'IDR ',
                              prefixStyle: TextStyle(),
                              hintText: 'Masukkan nominal',
                              hintStyle: ISTStyle.hintStyle,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.only(left: 16, right: 16),
                    alignment: Alignment.topLeft,
                    child: Text(StringUtils.getValueAsString(redaksiname!),
                        style: const TextStyle(
                            color: Colors.grey,
                            fontStyle: FontStyle.italic,
                            fontSize: 12)),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    alignment: Alignment.center,
                    padding: const EdgeInsets.only(left: 16, right: 16),
                    color: Colors.white,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        const Text(
                          "Sumber Dana",
                        ),
                        Container(
                          // padding: EdgeInsets.only(right: 8),
                          alignment: Alignment.topLeft,
                          child: DropdownButton<SumberItem>(
                            // autofocus: true,
                            // value: dropdownValue,
                            value: _listSumber.isEmpty
                                ? null
                                : _selectedSumber,
                            hint: const Text("Sumber Dana", style: ISTStyle.hintStyle),
                            isExpanded: true,
                            // iconSize: 38,
                            icon: const Icon(
                              Icons.keyboard_arrow_down,
                              size: 38,
                            ),
                            // iconSize: 30,
                            // style: TextStyle(color: Colors.black),
                            underline: Container(
                              height: 1,
                              color: Colors.grey,
                            ),
                            // onChanged: (TujuanItem newValue) {
                            //   setState(() {
                            //     _selected = newValue;
                            //   });
                            // },
                            onChanged: (SumberItem? valueSumber) {
                              setState(() {
                                _selectedSumber = valueSumber;
                              });
                            },
                            // items: <String>['sdasda', 'sadasda', 'asdasdasdas']
                            //     .map<DropdownMenuItem<String>>((value) {
                            //   return DropdownMenuItem<String>(
                            //     value: value,
                            //     child: Text(value),
                            //   );
                            // }).toList(),
                            items: _listSumber.map((SumberItem _listSumber) {
                              return DropdownMenuItem<SumberItem>(
                                value: _listSumber,
                                child: Row(
                                  children: <Widget>[
                                    Text(_listSumber.sumber!),
                                  ],
                                ),
                              );
                            }).toList(),
                            isDense: false,
                          ),
                        ),
                        _dropError
                            ? Container(
                                alignment: Alignment.centerLeft,
                                child: const Text(
                                  'Mohon pilih rekening sumber',
                                  style: TextStyle(color: Colors.red),
                                ),
                              )
                            : const SizedBox.shrink(),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    alignment: Alignment.center,
                    padding: const EdgeInsets.only(left: 16, right: 16),
                    color: Colors.white,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        const Text(
                          "Tujuan Penggunaan",
                        ),
                        Container(
                          // padding: EdgeInsets.only(right: 8),
                          alignment: Alignment.topLeft,
                          child: DropdownButton<TujuanItem>(
                            // value: dropdownValue,
                            value: _list.isEmpty
                                ? null
                                : _selectedTujuan,
                            hint: const Text("Pilih Tujuan Penggunaan",
                                style: ISTStyle.hintStyle),
                            isExpanded: true,
                            // iconSize: 38,
                            icon: const Icon(
                              Icons.keyboard_arrow_down,
                              size: 38,
                            ),
                            // iconSize: 30,
                            // style: TextStyle(color: Colors.black),
                            underline: Container(
                              height: 1,
                              color: Colors.grey,
                            ),
                            // onChanged: (TujuanItem newValue) {
                            //   setState(() {
                            //     _selected = newValue;
                            //   });
                            // },
                            onChanged: (TujuanItem? newValue) {
                              setState(() {
                                _selectedTujuan = newValue;
                              });
                            },
                            // items: <String>['sdasda', 'sadasda', 'asdasdasdas']
                            //     .map<DropdownMenuItem<String>>((value) {
                            //   return DropdownMenuItem<String>(
                            //     value: value,
                            //     child: Text(value),
                            //   );
                            // }).toList(),
                            items: _list.map((TujuanItem _list) {
                              return DropdownMenuItem<TujuanItem>(
                                value: _list,
                                child: Row(
                                  children: <Widget>[
                                    Text(_list.tujuan!),
                                  ],
                                ),
                              );
                            }).toList(),
                            isDense: false,
                          ),
                        ),
                        _dropError
                            ? Container(
                                alignment: Alignment.centerLeft,
                                child: const Text(
                                  'Mohon pilih tujuan penggunaan',
                                  style: TextStyle(color: Colors.red),
                                ),
                              )
                            : const SizedBox.shrink(),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  Padding(
                    padding: const EdgeInsets.only(left: 16, right: 16),
                    child: ISTOutlineButton(
                        onPressed: () {
                          // setState(() {});
                          // if (!_doValidate()) return;
                          _doInquiry();
                        },
                        text: "Lanjut"),
                  ),
                  const SizedBox(
                    height: 8,
                  )
                ])),
      ),
    );
  }
}

// class TujuanItem {
//   final String tujuan;
//   final String tujuanIndex;

//   TujuanItem(this.tujuan, this.tujuanIndex);

//   factory TujuanItem.fromJson(dynamic json) {
//     return TujuanItem(json['title'] as String, json['value'] as String);
//   }

//   @override
//   String toString() {
//     return '{ ${this.tujuan}, ${this.tujuanIndex} }';
//   }
// }
