import 'package:bpd_aceh/components/ist_menu_container.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/other/rekeningku/pembukaanRekening/PembukaanDeposito/snk_deposito.dart';
import 'package:bpd_aceh/features/other/rekeningku/pembukaanRekening/PembukaanTabungan/snk_pembukaan_tabungan.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:bpd_aceh/core/controller/controller_menu.dart';

class PembukaanRekeningPage extends StatefulWidget {
  static const routeName = '/pembukaanRekeningPage';

  const PembukaanRekeningPage({Key? key}) : super(key: key);
  @override
  _PembukaanRekeningPageState createState() => _PembukaanRekeningPageState();
}

class _PembukaanRekeningPageState extends State<PembukaanRekeningPage> {
  final controllerMenu = Get.put(MenuController());
  bool press = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text("Pembukaan Rekening",
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'Poppins',
            )),
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      backgroundColor: Colors.white,
      body: ListView(
        children: <Widget>[
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            child: Center(
              child: Text(
                "Buka Rekening",
                style: TextStyle(
                  fontFamily: 'Poppins',
                  color: Pallete.primary,
                  // color: Colors.white,
                  fontSize: Theme.of(context).textTheme.headline4!.fontSize,
                ),
              ),
            ),
          ),
          buildMenuPembukaanRekening(context),
        ],
      ),
    );
  }

  buildMenuPembukaanRekening(context) {
    return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8.0),
        child: Wrap(
          crossAxisAlignment: WrapCrossAlignment.start,
          children: <Widget>[
            Visibility(
              visible: controllerMenu.getVisibilityTabungan(),
              child: ISTMenuContainer.none(
                onTap: () {
                  Navigator.pushNamed(context, SnKTabungan.routeName);
                },
                image: Image.asset(
                  'assets/images/rek.png',
                  width: 50,
                ),
                // color: Colors.grey,
                text: 'Tabungan',
              ),
            ),
            Visibility(
              visible: controllerMenu.getVisibilityDeposito(),
              child: ISTMenuContainer.none(
                onTap: () {
                  Navigator.pushNamed(context, SnKDeposito.routeName);
                },
                image: Image.asset(
                  'assets/images/sito.png',
                  width: 50,
                ),
                // color: Colors.grey,
                text: 'Deposito',
              ),
            ),
          ],
        ));
  }
}
