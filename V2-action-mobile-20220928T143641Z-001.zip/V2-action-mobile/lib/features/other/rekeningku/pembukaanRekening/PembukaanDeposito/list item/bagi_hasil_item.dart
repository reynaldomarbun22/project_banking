import 'package:flutter/material.dart';

class BagiHasilItem {
  final String? bagihasil;
  final String? bagihasilKey;
  final int? bagihasilIndex;


  BagiHasilItem(
      {Key? key,
      this.bagihasil,
     this.bagihasilIndex,
     this.bagihasilKey
     });
}