import 'package:flutter/material.dart';

class TujuanDepositoItem {
  final String? tujuanDepo;
  final String? tujuanDepoKey;
  final int? tujuanDepoIndex;


  TujuanDepositoItem(
      {Key? key,
      this.tujuanDepo,
     this.tujuanDepoIndex,
     this.tujuanDepoKey
     });
}