import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_mpin.dart';
import 'package:bpd_aceh/components/ist_receipt_deposito.dart';
import 'package:bpd_aceh/components/ist_receipt_repo.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/crypto/ist_crypto.dart';
import 'package:bpd_aceh/features/other/rekeningku/pembukaanRekening/PembukaanDeposito/receipt_deposito.dart';
import 'package:flutter/material.dart';

class MpinDeposito extends StatelessWidget {
  static const routeName = '/PembukaanDeposito/MpinPembukaanDeposito';

  const MpinDeposito({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return ISTMPIN(
      onFinishedVal: (value) async {
        Map<String, Object> param = {};
        final String pinEnc = await ISTCrypto.encryptAES(value);
        param['mpin'] = pinEnc;

        final resp = await API.post(context, '/deposito/post', param);
        if (resp['code'] != null && resp['code'] == 0) {
          List<ISTReceiptItemDeposito> listParam = [];
          List<ISTReceiptItemInbox> listParams = [];
          List<dynamic> listMap = resp['resi'];
          for (var item in listMap) {
            ISTReceiptItemDeposito itemParam =
                ISTReceiptItemDeposito(key: item['key'], value: item['value']);
            listParam.add(itemParam);
          }
          for (var item in listMap) {
            ISTReceiptItemInbox itemParams =
                ISTReceiptItemInbox(key: item['key'], value: item['value']);
            listParams.add(itemParams);
          }
          print(listMap);
          List<ISTReceiptItemDeposito> listSertif = [];
          // Map listSertifikasi = resp['sertifikasi'];
          final Map test = resp['sertifikasi'];
          List<dynamic> resiSertif = test['resi'];
          for (var item in resiSertif) {
            ISTReceiptItemDeposito itemParam =
                ISTReceiptItemDeposito(key: item['key'], value: item['value']);
            listSertif.add(itemParam);
          }

          // ignore: unused_local_variable
          ISTReceiptStatusDeposito status = ISTReceiptStatusDeposito.suspect;

          if (resp['status'] != null && resp['status'] == 'success') {
            status = ISTReceiptStatusDeposito.success;
          }

          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => ReceiptPembukaanDeposito(
                        description: test['content'],
                        listSertif: listSertif,
                        // noRef: resp['idresi'],
                        noresi: test['bilyetNumber'],
                        title: test['titleSertifikasi'],
                        date: resp['waktu'],
                        detail: resp['dstAccountOwnerName'],
                        nameBank: resp['destBankName'],
                        time: resp['dstAccountNo'],
                        img: "assets/images/icon-transfer-other-active.png",
                        // title: "Transfer Antar Bank Lain",
                        subtitle: "Transfer",
                        list: listParam,
                        lists: listParams,
                        amount: resp['amountStr'],
                        memo: test['additionalInfo'],
                        // status: status,
                        titleresi: resp['title'],
                      )));
        } else if (resp['code'] != null && resp['code'] != 0) {
          if (resp['code'] == -1002) {
            //Salah MPIN
            const DialogBox().showImageDialog(
                message: resp['message'],
                isError: true,
                buttonCancel: 'OK',
                onCancel: () {
                  Navigator.pop(context);
                },
                onOk: () {},
                context: context);
          } else if (resp['code'] == -4901) {
            //Saldo Tidak Cukup
            const DialogBox().showImageDialog(
                message: resp['message'],
                isError: true,
                buttonCancel: 'OK',
                onCancel: () {
                  Navigator.pop(context);
                  Navigator.pop(context);
                  Navigator.pop(context);
                },
                onOk: () {},
                context: context);
          } else if (resp['code'] == -1108) {
            //MPIN Ke Blokir
            const DialogBox().showImageDialog(
                message: resp['message'],
                isError: true,
                buttonCancel: 'OK',
                onCancel: () {
                  Navigator.pop(context);
                  Navigator.pop(context);
                  Navigator.pop(context);
                },
                onOk: () {},
                context: context);
          } else {
            const DialogBox().showImageDialog(
                message: resp['message'],
                isError: true,
                buttonCancel: 'OK',
                onCancel: () {
                  Navigator.pop(context);
                },
                onOk: () {},
                context: context);
          }
        }
      },
    );
  }
}
