
import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_card_account_item.dart';
import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/ist_style.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/features/other/rekeningku/pembukaanRekening/PembukaanDeposito/confirm_deposito.dart';
import 'package:bpd_aceh/features/other/rekeningku/pembukaanRekening/PembukaanDeposito/list%20item/bagi_hasil_item.dart';
import 'package:bpd_aceh/features/other/rekeningku/pembukaanRekening/PembukaanDeposito/list%20item/jangka_waktu_item.dart';
import 'package:bpd_aceh/features/other/rekeningku/pembukaanRekening/PembukaanDeposito/list%20item/jenis_perpanjangan_item.dart';
import 'package:bpd_aceh/features/other/rekeningku/pembukaanRekening/PembukaanDeposito/list%20item/sumber_pendanaan_item.dart';
import 'package:bpd_aceh/features/other/rekeningku/pembukaanRekening/PembukaanDeposito/list%20item/tujuan_deposito_item.dart';
import 'package:bpd_aceh/features/other/rekeningku/pengaturanRekening/page/ist_list_rek.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
// import 'package:contact_picker/contact_picker.dart';

class PembukaanDeposito extends StatefulWidget {
  static const routeName = '/PembukaanDeposito';

  final String? nomorHp;
  final String? value;
  final Function()? callback;

  const PembukaanDeposito({
    Key? key,
    this.nomorHp,
    this.value,
    this.callback,
  }) : super(key: key);

  @override
  // ignore: no_logic_in_create_state
  _PembukaanDepositoState createState() => _PembukaanDepositoState(nomorHp);
}

class _PembukaanDepositoState extends State<PembukaanDeposito> {
  String? dropdownValue;
  final TextEditingController _numTopupController = TextEditingController();
  String nomorhp = "";
  final String? nomorHp;
  final _nominalPembukaancontroller = ISTConstants().moneyMaskedController;
  // ignore: unused_field
  final _jenisTabunganController = TextEditingController();
  final _sumberDanaController = TextEditingController();
  final _bagiHasilController = TextEditingController();

  _PembukaanDepositoState(this.nomorHp);

  @override
  void initState() {
    if (nomorHp != null) {
      _numTopupController.text = nomorHp!;
      fromContact = true;
    }
    super.initState();
    _getBagiHasil();
    _getJangkawaktu();
    _getJenisPerpanjangan();
    _getSumberPendanaan();
    _getTujuanDeposito();
  }

  // ignore: unused_field
  bool _numError = false;
  bool _dropError = false;
  bool _success = true;
  bool fromContact = false;

  _doValidate() {
    // if (_numTopupController.text == null || _numTopupController.text == '') {
    //   setState(() {
    //     _numError = true;
    //   });
    //   _success = false;
    // }

    if (_selectedJangkawaktu == null ||
        _selectedSumberPendanaan == null ||
        _selectedTujuanDeposito == null) {
      setState(() {
        _dropError = true;
      });
      _success = false;
    } else {
      _numError = false;
      _dropError = false;
      _success = true;
    }
    return _success;
  }

  _doInquiry() async {
    Map<String, Object?> param = {};
    param['amountDeposito'] =
        int.parse(_nominalPembukaancontroller.text.replaceAll(",", ""));
    param['dstAccName'] = _accountName;
    param['dstAccNo'] = _accountNumber;
    param['keyJangkaWaktu'] = _selectedJangkawaktu!.jangkawaktuKey;
    // param['titleJangka']
    param['srcAccName'] = _accountName;
    param['srcAccNo'] = _accountNumber;
    param['titleDestination'] = _selectedTujuanDeposito!.tujuanDepoKey;
    param['titleJangkaWaktu'] = _selectedJangkawaktu!.jangkawaktuTitle;
    param['titleSumber'] = _selectedSumberPendanaan!.sumberpendanaanKey;
    param['valueDestination'] = _selectedTujuanDeposito!.tujuanDepo;
    param['valueJangkaWaktu'] = _selectedJangkawaktu!.jangkawaktu;
    param['valueSumber'] = _selectedSumberPendanaan!.sumberpendanaan;
    final resp = await API.postNoLoading(context, '/deposito/inquiry', param);
    if (resp['code'] == 0) {
      List<ISTConfirmationItem> listParam = [];
      List<dynamic> listMap = resp['resi'];
      for (var item in listMap) {
        ISTConfirmationItem itemParam =
            ISTConfirmationItem(key: item['key'], value: item['value']);
        listParam.add(itemParam);
      }
      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => ConfirmPembukaanDeposito(
                    list: listParam,
                  )));
    } else {
      const DialogBox().showImageDialog(
          message: resp['message'],
          isError: true,
          image: const Image(
            image: AssetImage('assets/images/icon-failed.png'),
          ),
          buttonCancel: 'OK',
          onOk: () {},
          context: context);
    }
  }

  List<JangkaWaktuItem> _listJangkawaktu = [];
  JangkaWaktuItem? _selectedJangkawaktu;

  _getJangkawaktu() async {
    try {
      setState(() {
        _selectedJangkawaktu = null;
      });
      if (_listJangkawaktu.isNotEmpty) {
        Future.delayed(Duration.zero);
        _listJangkawaktu.clear();
      }
      Map<String, Object> param = {};
      // param['listTujuanPembukanRekening'] = _tujuanPembukaanController.text;
      final resp = await API.postNoLoading(
          context, '/deposito/jangka-waktu/list', param);
      if (resp['code'] == 0) {
        var listResp = resp['listJangkaWaktu'];
        List<dynamic> listRespMini1 = (listResp);
        List<JangkaWaktuItem> listJangkawaktu1 = [];
        //for (var item in listRespMini) {
        for (var i = 0; i < listRespMini1.length; i++) {
          JangkaWaktuItem items = JangkaWaktuItem(
            jangkawaktu: listRespMini1[i]['value'],
            jangkawaktuIndex: i,
            jangkawaktuTitle: listRespMini1[i]['title'],
            jangkawaktuKey: listRespMini1[i]['key'],
          );

          listJangkawaktu1.add(items);
        }

        setState(() {
          _listJangkawaktu = listJangkawaktu1;
        });
      }
    } catch (_) {}
  }

  List<BagiHasilItem> _listBagihasil = [];
  // ignore: unused_field
  BagiHasilItem? _selectedBagihasil;

  _getBagiHasil() async {
    try {
      setState(() {
        _selectedBagihasil = null;
      });
      if (_listBagihasil.isNotEmpty) {
        Future.delayed(Duration.zero);
        _listBagihasil.clear();
      }
      Map<String, Object> param = {};
      // param['listTujuanPembukanRekening'] = _tujuanPembukaanController.text;
      final resp = await API.postNoLoading(context, '/sumber-dana/list', param);
      if (resp['code'] == 0) {
        var listResp = resp['listPendanaan'];
        List<dynamic> listRespMini2 = (listResp);
        List<BagiHasilItem> listbagihasil = [];
        //for (var item in listRespMini) {
        for (var i = 0; i < listRespMini2.length; i++) {
          BagiHasilItem items = BagiHasilItem(
            bagihasil: listRespMini2[i]['value'],
            bagihasilIndex: i,
            bagihasilKey: listRespMini2[i]['title'],
          );

          listbagihasil.add(items);
        }

        setState(() {
          _listBagihasil = listbagihasil;
        });
      }
    } catch (_) {}
  }

  List<JenisPerpanjanganItem> _listJenisPerpanjangan = [];
  // ignore: unused_field
  JenisPerpanjanganItem? _selectedJenisPerpanjangan;

  _getJenisPerpanjangan() async {
    try {
      setState(() {
        _selectedJenisPerpanjangan = null;
      });
      if (_listJenisPerpanjangan.isNotEmpty) {
        Future.delayed(Duration.zero);
        _listJenisPerpanjangan.clear();
      }
      Map<String, Object> param = {};
      // param['listTujuanPembukanRekening'] = _tujuanPembukaanController.text;
      final resp = await API.postNoLoading(context, '/sumber-dana/list', param);
      if (resp['code'] == 0) {
        var listResp = resp['listPendanaan'];
        List<dynamic> listRespMini3 = (listResp);
        List<JenisPerpanjanganItem> listJenisPerpanjangan = [];
        //for (var item in listRespMini) {
        for (var i = 0; i < listRespMini3.length; i++) {
          JenisPerpanjanganItem items = JenisPerpanjanganItem(
            jenisperpanjangan: listRespMini3[i]['value'],
            jenisperpanjanganIndex: i,
            jenisperpanjangaKey: listRespMini3[i]['title'],
          );

          listJenisPerpanjangan.add(items);
        }

        setState(() {
          _listJenisPerpanjangan = listJenisPerpanjangan;
        });
      }
    } catch (_) {}
  }

  List<SumberPendanaanItem> _listSumberPendanaan = [];
  SumberPendanaanItem? _selectedSumberPendanaan;

  _getSumberPendanaan() async {
    try {
      setState(() {
        _selectedSumberPendanaan = null;
      });
      if (_listSumberPendanaan.isNotEmpty) {
        Future.delayed(Duration.zero);
        _listSumberPendanaan.clear();
      }
      Map<String, Object> param = {};
      // param['listTujuanPembukanRekening'] = _tujuanPembukaanController.text;
      final resp =
          await API.postNoLoading(context, '/deposito/sumber-dana/list', param);
      if (resp['code'] == 0) {
        var listResp = resp['listPendanaan'];
        List<dynamic> listRespMini5 = (listResp);
        List<SumberPendanaanItem> listSumberPendanaan = [];
        //for (var item in listRespMini) {
        for (var i = 0; i < listRespMini5.length; i++) {
          SumberPendanaanItem items = SumberPendanaanItem(
            sumberpendanaan: listRespMini5[i]['value'],
            sumberpendanaanIndex: i,
            sumberpendanaanKey: listRespMini5[i]['title'],
          );

          listSumberPendanaan.add(items);
        }

        setState(() {
          _listSumberPendanaan = listSumberPendanaan;
        });
      }
    } catch (_) {}
  }

  List<TujuanDepositoItem> _listTujuanDeposito = [];
  TujuanDepositoItem? _selectedTujuanDeposito;

  _getTujuanDeposito() async {
    try {
      setState(() {
        _selectedTujuanDeposito = null;
      });
      if (_listTujuanDeposito.isNotEmpty) {
        Future.delayed(Duration.zero);
        _listTujuanDeposito.clear();
      }
      Map<String, Object> param = {};
      // param['listTujuanPembukanRekening'] = _tujuanPembukaanController.text;
      final resp =
          await API.postNoLoading(context, '/deposito/tujuan/list', param);
      if (resp['code'] == 0) {
        var listResp = resp['listTujuan'];
        List<dynamic> listRespMini4 = (listResp);
        List<TujuanDepositoItem> listTujuanDeposito = [];
        //for (var item in listRespMini) {
        for (var i = 0; i < listRespMini4.length; i++) {
          TujuanDepositoItem items = TujuanDepositoItem(
            tujuanDepo: listRespMini4[i]['value'],
            tujuanDepoIndex: i,
            tujuanDepoKey: listRespMini4[i]['title'],
          );

          listTujuanDeposito.add(items);
        }

        setState(() {
          _listTujuanDeposito = listTujuanDeposito;
        });
      }
    } catch (_) {}
  }

  bool status = false;
  String? result;
  String bank = "";
  String bankName = "";
  // ignore: unused_field
  var _accountBalance = "";
  var _accountName = "";
  var _accountNumber = "";
  // ignore: unused_field
  var _accountType = "";

  void showAccountTabungan({
    required BuildContext context,
    List<ISTCardAccountTabunganItem>? list,
    List<ISTListRek>? listRek,
  }) {
    showDialog(
        context: context,
        barrierDismissible: true,
        builder: (context) {
          return Center(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Colors.white,
              ),
              height: MediaQuery.of(context).size.height * 0.7,
              width: MediaQuery.of(context).size.width * 0.8,
              child: Scaffold(
                  body: Column(children: <Widget>[
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.7 - 52,
                  // child: SingleChildScrollView(
                  child: Center(
                    child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    const SizedBox(height: 8),
                    const Image(
                      image: AssetImage(
                          'assets/images/icon-pencairan-deposito.png'),
                      // color: Pallete.primary,
                      width: 90,
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      "Daftar Rekening Tabungan Anda",
                      style: TextStyle(
                          color: Pallete.primary,
                          fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    // Text('Silakan pilih rekening',
                    //     style: TextStyle(color: Pallete.primary)),
                    // Text('untuk dijadikan rekening utama',
                    //     style: TextStyle(color: Pallete.primary)),
                    const SizedBox(height: 8),
//sadasdas
                    Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12.0,
                        ),
                        child: SizedBox(
                          height: MediaQuery.of(context).size.height * 0.7 -
                              187,
                          child: SingleChildScrollView(
                              child: Column(children: list!)),
                        )),
                    //asdasdas
                  ],
                    ),
                    // ),
                  ),
                ),
                const Spacer(),
                const SizedBox(
                  height: 8,
                ),
                ISTFlatButton(
                  onPressed: () {
                Navigator.pop(context);
                  },
                  text: 'Tutup',
                  color: Pallete.primary,
                )
              ])),
            ),
          );
        });
  }

  _doInquiryListAccount() async {
    final resp = await API.post(context, '/acct/listAccount', {});
    if (resp != null && resp['code'] == 0) {
      var listResp = resp['accountList'];
      List<dynamic> listRespDyn = (listResp);
      List<ISTCardAccountTabunganItem> listParam = [];
      // ignore: unused_local_variable
      List<ISTListRek> listParamss = [];

      for (var i = 0; i < listRespDyn.length; i++) {
        ISTCardAccountTabunganItem cardItem = ISTCardAccountTabunganItem(
          accountBalance: listRespDyn[i]['accountBalance'], //
          accountName: listRespDyn[i]['accountOwnerName'],
          accountNumber: listRespDyn[i]['accountNo'], //
          accountType: listRespDyn[i]['accountProductName'], //
          isPrimary: listRespDyn[i]['accountDefault'],
          index: i,
          callback: (accountBalance, accountType, accountNumber, accountName) {
            setState(() {
              _sumberDanaController.text =
                  accountName! + " - " + accountNumber!;
              _accountBalance = accountBalance!;
              _accountType = accountType!;
              _accountNumber = accountNumber;
              _accountName = accountName;
              _bagiHasilController.text = accountName + " - " + accountNumber;
            });
            if (widget.callback != null) widget.callback!();
          },
        );

        listParam.add(cardItem);
      }
      showAccountTabungan(
        context: context,
        list: listParam,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title:
            const Text("Pembukaan Deposito", style: TextStyle(color: Colors.white)),
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
          child: Column(crossAxisAlignment: CrossAxisAlignment.center, children: <
              Widget>[
            const SizedBox(
              height: 16,
            ),
            Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.only(left: 16, right: 16),
              color: Colors.white,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const Text(
                    "Rekening Sumber Dana",
                  ),
                  Container(
                    alignment: Alignment.topLeft,
                    child: TextFormField(
                      validator: (val) {
                        if (val!.isEmpty) {
                          return "Mohon pilih rekening sumber dana";
                        } else {
                          return null;
                        }
                      },
                      controller: _sumberDanaController,
                      onTap: () {
                        _doInquiryListAccount();
                      },
                      readOnly: true,
                      showCursor: false,
                      decoration: const InputDecoration(
                        suffixStyle: TextStyle(),
                        hintText: 'Pilih Rekening Sumber Dana',
                        hintStyle: ISTStyle.hintStyle,
                        suffixIcon: Icon(
                          Icons.keyboard_arrow_down,
                          size: 38,
                        ),
                      ),
                    ),
                  ),
                  _dropError
                      ? Container(
                          alignment: Alignment.centerLeft,
                          child: const Text(
                            'Mohon pilih Rekening Sumber',
                            style: TextStyle(color: Colors.red),
                          ),
                        )
                      : const SizedBox.shrink(),
                ],
              ),
            ),
            const SizedBox(height: 8),
            Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.only(left: 16, right: 16),
              color: Colors.white,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const Text(
                    "Jangka Waktu",
                  ),
                  Container(
                    // padding: EdgeInsets.only(right: 8),
                    alignment: Alignment.topLeft,
                    child: DropdownButton<JangkaWaktuItem>(
                      // value: dropdownValue,
                      value: _listJangkawaktu.isEmpty
                          ? null
                          : _selectedJangkawaktu,
                      hint: const Text("Pilih jangka waktu deposito",
                          style: ISTStyle.hintStyle),
                      isExpanded: true,
                      // iconSize: 38,
                      icon: const Icon(
                        Icons.keyboard_arrow_down,
                        size: 38,
                      ),
                      // iconSize: 30,
                      // style: TextStyle(color: Colors.black),
                      underline: Container(
                        height: 1,
                        color: Colors.grey,
                      ),
                      // onChanged: (TujuanItem newValue) {
                      //   setState(() {
                      //     _selected = newValue;
                      //   });
                      // },
                      onChanged: (JangkaWaktuItem? valJangkawaktu) {
                        setState(() {
                          _selectedJangkawaktu = valJangkawaktu;
                        });
                      },
                      // items: <String>['sdasda', 'sadasda', 'asdasdasdas']
                      //     .map<DropdownMenuItem<String>>((value) {
                      //   return DropdownMenuItem<String>(
                      //     value: value,
                      //     child: Text(value),
                      //   );
                      // }).toList(),
                      items: _listJangkawaktu
                          .map((JangkaWaktuItem _listJangkawaktu) {
                        return DropdownMenuItem<JangkaWaktuItem>(
                          value: _listJangkawaktu,
                          child: Row(
                            children: <Widget>[
                              Text(_listJangkawaktu.jangkawaktuTitle!),
                            ],
                          ),
                        );
                      }).toList(),
                      isDense: false,
                    ),
                  ),
                  _dropError
                      ? Container(
                          alignment: Alignment.centerLeft,
                          child: const Text(
                            'Mohon pilih jangka waktu deposito',
                            style: TextStyle(color: Colors.red),
                          ),
                        )
                      : const SizedBox.shrink(),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.only(left: 16, right: 8),
              alignment: Alignment.topLeft,
              child: InkWell(
                child: const Text(
                  'Nisbah bagi hasil',
                  style: TextStyle(
                      fontStyle: FontStyle.italic,
                      fontSize: 10,
                      color: Colors.blue),
                ),
                onTap: () {},
              ),
            ),
            const SizedBox(height: 8),
            Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.only(left: 16, right: 16),
              color: Colors.white,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const Text(
                    "Nominal",
                  ),
                  Container(
                    alignment: Alignment.topLeft,
                    child: TextFormField(
                      validator: (val) {
                        if (val!.isEmpty || val == '0') {
                          return "Mohon diisi";
                        } else {
                          return null;
                        }
                      },
                      inputFormatters: [
                        // ignore: deprecated_member_use
                        FilteringTextInputFormatter.digitsOnly,
                      ],
                      controller: _nominalPembukaancontroller,
                      maxLength: ISTConstants.nominalMaxLength,
                      onChanged: (value) {
                        if (_nominalPembukaancontroller.text.trim().isEmpty) {
                          _nominalPembukaancontroller.text = '';
                        }
                      },
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        counterText: '',
                        prefixText: 'IDR ',
                        prefixStyle: TextStyle(),
                        hintText: 'Masukkan nominal',
                        hintStyle: ISTStyle.hintStyle,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.only(left: 16, right: 16),
              color: Colors.white,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const Text(
                    "Pembayaran Bagi Hasil",
                  ),
                  Container(
                    alignment: Alignment.topLeft,
                    child: TextFormField(
                      autofocus: false,
                      enabled: false,
                      validator: (val) {
                        if (val!.isEmpty || val == '0') {
                          return "Mohon diisi";
                        } else {
                          return null;
                        }
                      },
                      inputFormatters: [
                        // ignore: deprecated_member_use
                        FilteringTextInputFormatter.digitsOnly,
                      ],
                      controller: _bagiHasilController,
                      maxLength: ISTConstants.nominalMaxLength,
                      onChanged: (value) {
                        if (_bagiHasilController.text.trim().isEmpty) {
                          _bagiHasilController.text = '';
                        }
                      },
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        counterText: '',
                        prefixStyle: TextStyle(),
                        hintText: 'Pilih pencairan',
                        hintStyle: ISTStyle.hintStyle,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.only(left: 16, right: 16),
              color: Colors.white,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const Text(
                    "Sumber Dana",
                  ),
                  Container(
                    alignment: Alignment.topLeft,
                    child: DropdownButton<SumberPendanaanItem>(
                      value: _listSumberPendanaan.isEmpty
                          ? null
                          : _selectedSumberPendanaan,
                      hint: const Text("Pilih Sumber Dana", style: ISTStyle.hintStyle),
                      isExpanded: true,
                      // iconSize: 38,
                      icon: const Icon(
                        Icons.keyboard_arrow_down,
                        size: 38,
                      ),
                      underline: Container(
                        height: 1,
                        color: Colors.grey,
                      ),
                      onChanged: (SumberPendanaanItem? valueSumber) {
                        setState(() {
                          _selectedSumberPendanaan = valueSumber;
                        });
                      },
                      items: _listSumberPendanaan
                          .map((SumberPendanaanItem _listSumberPendanaan) {
                        return DropdownMenuItem<SumberPendanaanItem>(
                          value: _listSumberPendanaan,
                          child: Row(
                            children: <Widget>[
                              Text(_listSumberPendanaan.sumberpendanaanKey!),
                            ],
                          ),
                        );
                      }).toList(),
                      isDense: false,
                    ),
                  ),
                  _dropError
                      ? Container(
                          alignment: Alignment.centerLeft,
                          child: const Text(
                            'Mohon pilih sumber dana',
                            style: TextStyle(color: Colors.red),
                          ),
                        )
                      : const SizedBox.shrink(),
                ],
              ),
            ),
            const SizedBox(height: 8),
            Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.only(left: 16, right: 16),
              color: Colors.white,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const Text(
                    "Tujuan Deposito",
                  ),
                  Container(
                    // padding: EdgeInsets.only(right: 8),
                    alignment: Alignment.topLeft,
                    child: DropdownButton<TujuanDepositoItem>(
                      // value: dropdownValue,
                      value: _listTujuanDeposito.isEmpty
                          ? null
                          : _selectedTujuanDeposito,
                      hint: const Text("Pilih tujuan deposito",
                          style: ISTStyle.hintStyle),
                      isExpanded: true,
                      icon: const Icon(
                        Icons.keyboard_arrow_down,
                        size: 38,
                      ),
                      underline: Container(
                        height: 1,
                        color: Colors.grey,
                      ),

                      onChanged: (TujuanDepositoItem? valueSumber) {
                        setState(() {
                          _selectedTujuanDeposito = valueSumber;
                        });
                      },

                      items: _listTujuanDeposito
                          .map((TujuanDepositoItem _listTujuanDeposito) {
                        return DropdownMenuItem<TujuanDepositoItem>(
                          value: _listTujuanDeposito,
                          child: Row(
                            children: <Widget>[
                              Text(_listTujuanDeposito.tujuanDepoKey!),
                            ],
                          ),
                        );
                      }).toList(),
                      isDense: false,
                    ),
                  ),
                  _dropError
                      ? Container(
                          alignment: Alignment.centerLeft,
                          child: const Text(
                            'Mohon pilih tujuan deposito',
                            style: TextStyle(color: Colors.red),
                          ),
                        )
                      : const SizedBox.shrink(),
                ],
              ),
            ),
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.only(left: 16, right: 16),
              child: ISTOutlineButton(
                  onPressed: () {
                    setState(() {});
                    if (!_doValidate()) return;
                    _doInquiry();
                  },
                  text: "Lanjut"),
            ),
            const SizedBox(
              height: 16,
            )
          ])),
    );
  }
}
