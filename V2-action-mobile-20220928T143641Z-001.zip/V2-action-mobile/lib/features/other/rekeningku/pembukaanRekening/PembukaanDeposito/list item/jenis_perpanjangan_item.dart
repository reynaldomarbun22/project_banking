import 'package:flutter/material.dart';

class JenisPerpanjanganItem {
  final String? jenisperpanjangan;
  final String? jenisperpanjangaKey;
  final int? jenisperpanjanganIndex;


  JenisPerpanjanganItem(
      {Key? key,
      this.jenisperpanjangaKey,
     this.jenisperpanjangan,
     this.jenisperpanjanganIndex
     });
}