import 'package:flutter/material.dart';

class JangkaWaktuItem {
  final String? jangkawaktu;
  final String? jangkawaktuKey;
  final String? jangkawaktuTitle;
  final int? jangkawaktuIndex;

  JangkaWaktuItem(
      {Key? key,
      this.jangkawaktu,
      this.jangkawaktuTitle,
      this.jangkawaktuIndex,
      this.jangkawaktuKey});
}
