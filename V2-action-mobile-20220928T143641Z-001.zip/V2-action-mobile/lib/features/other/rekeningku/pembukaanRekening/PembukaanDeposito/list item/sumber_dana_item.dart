import 'package:flutter/material.dart';

class SumberDanaItem {
  final String? sumberdana;
  final String? sumberdanaKey;
  final int? sumberdanaIndex;


  SumberDanaItem(
      {Key? key,
      this.sumberdana,
     this.sumberdanaIndex,
     this.sumberdanaKey,
     });
}