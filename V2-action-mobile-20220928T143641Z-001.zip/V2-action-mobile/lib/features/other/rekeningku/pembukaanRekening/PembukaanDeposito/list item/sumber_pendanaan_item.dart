import 'package:flutter/material.dart';

class SumberPendanaanItem {
  final String? sumberpendanaan;
  final String? sumberpendanaanKey;
  final int? sumberpendanaanIndex;

  SumberPendanaanItem(
      {Key? key,
      this.sumberpendanaan,
     this.sumberpendanaanIndex,
     this.sumberpendanaanKey
     });
}