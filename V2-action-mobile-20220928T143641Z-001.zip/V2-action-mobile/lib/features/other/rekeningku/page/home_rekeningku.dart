import 'package:bpd_aceh/components/ist_card_account.dart';
import 'package:bpd_aceh/components/ist_card_account_dest.dart';
import 'package:bpd_aceh/components/ist_menu_container.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/features/other/rekeningku/pengaturanRekening/page/ist_list_rek.dart';
import 'package:bpd_aceh/features/other/rekeningku/pengaturanRekening/page/setting_rekening.dart';
import 'package:bpd_aceh/features/other/rekeningku/widgets/deposito_item.dart';
import 'package:bpd_aceh/features/statements/statements.dart';
import 'package:flutter/material.dart';
import '../../../../components/palete.dart';
import 'package:get/get.dart';
import 'package:bpd_aceh/core/controller/controller_menu.dart';

class HomeRekeningKU extends StatefulWidget {
  static const routeName = '/homeRekeningKU';

  final Function()? callback;
  const HomeRekeningKU({
    Key? key,
    this.callback,
  }) : super(key: key);
  @override
  _HomeRekeningKUState createState() => _HomeRekeningKUState();
}

class _HomeRekeningKUState extends State<HomeRekeningKU> {
  final controllerMenu = Get.put(MenuController());
  String? accNo;

  void showAccountTabungan2({
    required BuildContext context,
    List<ISTCardAccountDestItem>? list,
    List<ISTListRek>? listRek,
  }) {
    showDialog(
        context: context,
        barrierDismissible: true,
        builder: (context) {
          return Center(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Colors.white,
              ),
              height: MediaQuery.of(context).size.height * 0.7,
              width: MediaQuery.of(context).size.width * 0.8,
              child: Scaffold(
                  body: Column(children: <Widget>[
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.7 - 52,
                  // child: SingleChildScrollView(
                  child: Center(
                    child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    const SizedBox(height: 16),
                    const Image(
                      image: AssetImage('assets/images/rek.png'),
                      // color: Pallete.primary,
                      width: 70,
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      "Daftar Rekening Tabungan Anda",
                      style: TextStyle(
                          color: Pallete.primary,
                          fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    // Text('Silakan pilih rekening',
                    //     style: TextStyle(color: Pallete.primary)),
                    // Text('untuk dijadikan rekening utama',
                    //     style: TextStyle(color: Pallete.primary)),
                    const SizedBox(height: 8),
//sadasdas
                    Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12.0,
                        ),
                        child: SizedBox(
                          height: MediaQuery.of(context).size.height * 0.7 -
                              187,
                          child: SingleChildScrollView(
                              child: Column(children: list!)),
                        )),
                    //asdasdas
                  ],
                    ),
                    // ),
                  ),
                ),
                const Spacer(),
                const SizedBox(
                  height: 8,
                ),
                ISTFlatButton(
                  onPressed: () {
                Navigator.pop(context);
                  },
                  text: 'Tutup',
                  color: Pallete.primary,
                )
              ])),
            ),
          );
        });
  }

  // ignore: unused_element
  _doInquiryListAccount2() async {
    final resp = await API.post(context, '/penutupan-rek/list-close', {});
    if (resp != null && resp['code'] == 0) {
      var listResp = resp['accountList'];
      List<dynamic> listRespDyn = (listResp);
      List<ISTCardAccountDestItem> listParam2 = [];
      // ignore: unused_local_variable
      List<ISTListRek> listParamss = [];

      for (var i = 0; i < listRespDyn.length; i++) {
        ISTCardAccountDestItem cardItem = ISTCardAccountDestItem(
          accountBalance: listRespDyn[i]['accountBalance'], //
          accountName: listRespDyn[i]['accountOwnerName'],
          accountNumber: listRespDyn[i]['accountNo'], //
          accountType: listRespDyn[i]['accountProductName'], //
          isPrimary: listRespDyn[i]['accountDefault'],
          index: i,
          callback: (accountBalance, accountType, accountNumber, accountName) {
            // Navigator.push(context);
            // Navigator.pushReplacement(
            //     context,
            //     new MaterialPageRoute(
            //         builder: (context) => new PembukaanTabungan(
            //               name: accountName,
            //             )));
            setState(() {
              accNo = accountNumber;
            });
            if (widget.callback != null) widget.callback!();
          },
        );

        listParam2.add(cardItem);
      }
      showAccountTabungan2(
        context: context,
        list: listParam2,
      );
    }
  }

  void showAccountTabungan({
    required BuildContext context,
    List<ISTCardAccountDepositoItem>? list,
    List<ISTListRek>? listRek,
  }) {
    showDialog(
        context: context,
        barrierDismissible: true,
        builder: (context) {
          return Center(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Colors.white,
              ),
              height: MediaQuery.of(context).size.height * 0.7,
              width: MediaQuery.of(context).size.width * 0.8,
              child: Scaffold(
                  body: Column(children: <Widget>[
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.7 - 52,
                  // child: SingleChildScrollView(
                  child: Center(
                    child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    const SizedBox(height: 16),
                    const Image(
                      image: AssetImage(
                          'assets/images/icon-pencairan-deposito.png'),
                      // color: Pallete.primary,
                      width: 70,
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      "Daftar Rekening Deposito Anda",
                      style: TextStyle(
                          color: Pallete.primary,
                          fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    // Text('Silakan pilih rekening',
                    //     style: TextStyle(color: Pallete.primary)),
                    // Text('untuk dijadikan rekening utama',
                    //     style: TextStyle(color: Pallete.primary)),
                    const SizedBox(height: 8),
//sadasdas
                    Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12.0,
                        ),
                        child: SizedBox(
                          height: MediaQuery.of(context).size.height * 0.7 -
                              187,
                          // ignore: unnecessary_null_comparison
                          child: list!.length == null
                              ? const Text(
                                'sadasdasd',
                                style:
                                    TextStyle(color: Pallete.primary),
                              )
                              : SingleChildScrollView(
                                  child: Column(children: list)),
                        )),
                    //asdasdas
                  ],
                    ),
                    // ),
                  ),
                ),
                const Spacer(),
                const SizedBox(
                  height: 8,
                ),
                ISTFlatButton(
                  onPressed: () {
                Navigator.pop(context);
                  },
                  text: 'Tutup',
                  color: Pallete.primary,
                )
              ])),
            ),
          );
        });
  }

  // ignore: unused_element
  _doInquiryListAccount() async {
    final resp = await API.post(context, '/deposito/list', {});
    if (resp != null && resp['code'] == 0) {
      var listResp = resp['deposito'];
      List<dynamic>? listRespDyn = (listResp);
      List<ISTCardAccountDepositoItem> listParam = [];
      // ignore: unused_local_variable
      List<ISTListRek> listParamss = [];

      if (listRespDyn != null) {
        for (var i = 0; i < listRespDyn.length; i++) {
          ISTCardAccountDepositoItem cardItem = ISTCardAccountDepositoItem(
            accountBalance: listRespDyn[i]['amount'], //
            accountName: listRespDyn[i]['accName'],
            accountNumber: listRespDyn[i]['accNo'], //
            accountType: listRespDyn[i]['depositoType'], //
            // isPrimary: listRespDyn[i]['accountDefault'],
            index: i,
            callback:
                (accountBalance, accountType, accountNumber, accountName) {
              setState(() {
                accNo = accountBalance;
              });
              if (widget.callback != null) widget.callback!();
            },
          );

          listParam.add(cardItem);
        }
      } else {}
      showAccountTabungan(
        context: context,
        list: listParam,
      );
    }
  }

  bool press = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text("Rekeningku",
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'Poppins',
            )),
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const ISTCardAccount(context: null, menu: ISTMenu.rekeningKu),
            const SizedBox(height: 16),
            // buildMenuPembelian(context),
            Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0),
                child: Wrap(
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: <Widget>[
                    // Visibility(
                    //   visible: controllerMenu.getVisibilityBukaRekening(),
                    //   child: ISTMenuContainer.none(
                    //     onTap: () {
                    //       Navigator.pushNamed(
                    //           context, PembukaanRekeningPage.routeName);
                    //     },
                    //     image: Image.asset(
                    //       'assets/images/burek.png',
                    //       width: 50,
                    //     ),
                    //     // color: Colors.grey,
                    //     text: 'Buka Rekening\nbaru',
                    //   ),
                    // ),
                    Visibility(
                      visible:
                          controllerMenu.getVisibilityPengaturanRekening(),
                      child: ISTMenuContainer.none(
                        onTap: () async {
                          var result = await Navigator.pushNamed(
                              context, SettingRek.routeName);
                          if (result == true) {
                            Navigator.popAndPushNamed(
                                context, HomeRekeningKU.routeName);
                          }
                        },
                        image: Image.asset(
                          'assets/images/NewPengaturanRek.png',
                          width: 50,
                        ),
                        //color: Colors.grey,
                        text: 'Pengaturan\nRekening',
                      ),
                    ),
                    // Visibility(
                    //   visible:
                    //       controllerMenu.getVisibilityPencairanDeposito(),
                    //   child: ISTMenuContainer.none(
                    //     onTap: () async {
                    //       _doInquiryListAccount();
                    //     },
                    //     image: Image.asset(
                    //       'assets/images/pencairan-deposito.png',
                    //       width: 50,
                    //     ),
                    //     //color: Colors.grey,
                    //     text: 'Pencairan\nDeposito',
                    //   ),
                    // ),
                    // Visibility(
                    //   visible:
                    //       controllerMenu.getVisibilityPenutupanTabungan(),
                    //   child: ISTMenuContainer.none(
                    //     onTap: () async {
                    //       _doInquiryListAccount2();
                    //     },
                    //     image: Image.asset(
                    //       'assets/images/icon-tutup-tabungan.png',
                    //       width: 50,
                    //     ),
                    //     //color: Colors.grey,
                    //     text: 'Penutupan\nTabungan',
                    //   ),
                    // ),
                    Visibility(
                      visible: controllerMenu.getVisibilityMutasiRekening(),
                      child: ISTMenuContainer.none(
                        onTap: () {
                          Navigator.pushNamed(context, Statements.routeName);
                        },
                        image: Image.asset(
                          'assets/images/NewIconMutasi.png',
                          width: 50,
                        ),
                        // color: Colors.grey,
                        text: 'Mutasi\nRekening',
                      ),
                    ),
                  ],
                ))
          ],
        ),
      ),
    );
  }
}
