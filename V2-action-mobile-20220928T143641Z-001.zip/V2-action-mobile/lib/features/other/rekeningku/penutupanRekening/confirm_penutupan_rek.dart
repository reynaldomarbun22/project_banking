import 'package:bpd_aceh/components/ist_confirmation.dart';
// import 'package:bpd_aceh/components/ISTReceipt.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/other/rekeningku/penutupanRekening/mpin_penutupan_rek.dart';
// import 'package:bpd_aceh/features/transfer/mpin/transfer_mpin.dart';
import 'package:flutter/material.dart';

class ConfirmationPenutupanRek extends StatefulWidget {
  static const routeName = '/PenutupanRekening/Confirmpenutupanrek';
  final List<ISTConfirmationItem>? list;

  const ConfirmationPenutupanRek({Key? key, this.list}) : super(key: key);
  // final String srcAcct;
  // final String destAcct;
  // final String nominal;
  // final String note;

  // const TransferConfirmPageBL(
  //     {Key key, this.srcAcct, this.destAcct, this.nominal, this.note, List<ISTConfirmationItem> list})
  //     : super(key: key);

  @override
  State<ConfirmationPenutupanRek> createState() => _ConfirmationPenutupanRek();
}

class _ConfirmationPenutupanRek extends State<ConfirmationPenutupanRek> {
  // bool showPass = true;
  // bool isLoading = false;

  @override
  Widget build(BuildContext context) {
    // final loginText = Text(
    //   'Transfer',
    //   style: TextStyle(
    //       fontWeight: FontWeight.w100, color: Colors.white, fontSize: 20),
    // );

    _doTransfer() {
      Navigator.pushNamed(context, MPINPenutupanRekening.routeName);
    }

    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Pallete.primary,
          leading: IconButton(
              icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
              onPressed: () {
                Navigator.pop(context);
              }),
          title: const Text(
            'Penutupan Rekening Tabungan',
            style: TextStyle(color: Colors.white),
          ),
          centerTitle: true,
          elevation: 0.0,
        ),
        body: ISTConfirmation(
            items: widget.list,
            title: 'Konfirmasi Penutupan Rekening Tabungan',
            onFinished: () {
              _doTransfer();
            }));
  }
}
