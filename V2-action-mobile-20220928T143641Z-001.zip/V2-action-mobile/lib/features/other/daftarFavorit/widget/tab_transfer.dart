import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/core/api/api.dart';
// import 'package:bpd_aceh/features/other/daftarFavorit/pages/daftarFavorit.dart';
import 'package:bpd_aceh/features/transfer/transferAntarBAS/inquiryBAS/transferinq_bas.dart';
import 'package:bpd_aceh/features/transfer/transferBankLain/inquiryBL/transfer_bank_lain.dart';
import 'package:bpd_aceh/features/transfer/transferRTGS/inquiryRTGS/transfer_rtgs.dart';
import 'package:bpd_aceh/features/transfer/transferSKN/inquirySKN/transfer_skn.dart';
import 'package:flutter/material.dart';

class TabTransferFavoriteItem extends StatelessWidget {
  const TabTransferFavoriteItem(
      {Key? key,
      this.ownerName,
      this.nameBank,
      this.noRek,
      this.id,
      this.initial,
      this.callback,
      this.destno,
      this.destcode})
      : super(key: key);
  final String? ownerName;
  final String? nameBank;
  final String? noRek;
  final String? destno;
  final String? destcode;

  final int? id;
  final String? initial;

  final Function(String? ownerName, String? nameBank, String? noRek,
      String? destcode, int? id)? callback;

  @override
  Widget build(BuildContext context) {
    _doremoveT() async {
      Map<String, Object?> param = {};
      param['newid'] = id;
      final resp = await API.post(context, '/favorite/delete', param);
      Navigator.pop(context);
      if (resp != null && resp['code'] == 0) {
        callback!(nameBank, noRek, ownerName, destcode,
            id); // buat rfresh screen sesudah didelete

      }
    }

    return Card(
      elevation: 0,
      child: InkWell(
        onTap: () {
          // print(initial);
          if (initial == 'OWN') {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => TransferBas(
                          bnfAcctNo: noRek,
                          bnfAcctName: ownerName,
                        )));
          } else if (initial == "OTHER_ONLINE") {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => TransferBankLain(
                          bnf_acct_no: noRek,
                          bnf_acct_name: ownerName,
                          namebank: nameBank,
                          kodebank: destcode,
                        )));
          } else if (initial == "5501") {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => TransferSKN(
                          bnf_acct_no: noRek,
                          bnf_acct_name: ownerName,
                          namebank: nameBank,
                          kodebank: destcode,
                        )));
          } else if (initial == "5502") {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => TransferRTGS(
                          bnf_acct_no: noRek,
                          bnf_acct_name: ownerName,
                          namebank: nameBank,
                          kodebank: destcode,
                        )));
          }
        },
        child: Container(
          padding: const EdgeInsets.only(left: 4, right: 4),
          child: Column(
            children: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                      flex: 2,
                      child: Image.asset(
                          'assets/images/icon-tranfer-active.png')
                      //  CircleAvatar(
                      //   backgroundColor: Pallete.PRIMARY,
                      //   child: Text(
                      //     ownerName.substring(0, 1),
                      //     style: TextStyle(
                      //         color: Colors.white, fontWeight: FontWeight.bold),
                      //   ),
                      // )
                      ),
                  const SizedBox(
                    width: 8,
                  ),
                  initial == '5502'
                      ? Expanded(
                          flex: 12,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Text(ownerName!,
                                  style: const TextStyle(
                                      color: Pallete.primary,
                                      fontWeight: FontWeight.bold)),
                              const Text('RTGS',
                                  style: TextStyle(color: Pallete.thirdy)),
                              Text(nameBank!,
                                  style: const TextStyle(color: Pallete.thirdy)),
                              Text(noRek!,
                                  style: const TextStyle(color: Pallete.thirdy)),
                            ],
                          ))
                      : initial == '5501'
                          ? Expanded(
                              flex: 12,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Text(ownerName!,
                                      style: const TextStyle(
                                          color: Pallete.primary,
                                          fontWeight: FontWeight.bold)),
                                  const Text('SKN',
                                      style: TextStyle(color: Pallete.thirdy)),
                                  Text(nameBank!,
                                      style: const TextStyle(color: Pallete.thirdy)),
                                  Text(noRek!,
                                      style: const TextStyle(color: Pallete.thirdy)),
                                ],
                              ))
                          : Expanded(
                              flex: 12,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Text(ownerName!,
                                      style: const TextStyle(
                                          color: Pallete.primary,
                                          fontWeight: FontWeight.bold)),
                                  Text(nameBank!,
                                      style: const TextStyle(color: Pallete.thirdy)),
                                  Text(noRek!,
                                      style: const TextStyle(color: Pallete.thirdy)),
                                ],
                              )),
                  Expanded(
                      flex: 3,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          IconButton(
                              icon: const Image(
                                  image: AssetImage(
                                      "assets/images/icon-delete.png")),
                              onPressed: () {
                                const DialogBox().showImageDialog(
                                    message:
                                        "Apakah Anda yakin akan menghapus Daftar Favorit",
                                    context: context,
                                    buttonCancel: "Tidak",
                                    buttonOk: "Hapus",
                                    image: Image.asset(
                                      'assets/images/icon-warning.png',
                                    ),
                                    isError: true,
                                    onOk: () {
                                      _doremoveT();
                                      //  Navigator.pop(context, 'anjing!');
                                    });
                              })
                        ],
                      )),
                ],
              ),
              const Divider(
                color: Pallete.primary,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
