import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/Paket_Data/inq_paketdata/inquiripaket.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PLN/prabayarPLN.dart/plninqury.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/Pulsa/TSEL/pembelian_pulsa_fix.dart';
// import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/Pulsa/pulsa.dart';
import 'package:flutter/material.dart';

class TabPurchaseFavoriteItem extends StatelessWidget {
  const TabPurchaseFavoriteItem(
      {Key? key,
      this.typeProvider,
      this.textProvider,
      this.numberCard,
      this.id,
      this.callback})
      : super(key: key);
  final String? typeProvider;
  final String? textProvider;
  final String? numberCard;
  final int? id;
  final Function(String? typeProvider, String? textProvider, String? numberCard,
      int? id)? callback;

  @override
  Widget build(BuildContext context) {
    _doremoveT() async {
      Map<String, Object?> param = {};
      param['newid'] = id;
      final resp = await API.post(context, '/favorite/delete', param);
      Navigator.pop(context);
      if (resp != null && resp['code'] == 0) {
        callback!(typeProvider, textProvider, numberCard,
            id); // buat rfresh screen sesudah didelete
      }
    }

    return Card(
      elevation: 0,
      child: InkWell(
        onTap: () {
          if (typeProvider == "Pembelian Pulsa") {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => PembelianPulsa(
                          nomorHp: numberCard,
                        )));
          } else if (textProvider == "Listrik Prepaid") {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => ListrikPrabayarPage(
                          noInvoice: numberCard,
                        )));
          } else if (typeProvider == "Pembelian Paket Data") {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => InquiryPaketData(
                          nomorHp: numberCard,
                        )));
          }
        },
        child: Container(
          padding: const EdgeInsets.only(left: 4, right: 4),
          child: Column(
            children: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                      flex: 2,
                      child: CircleAvatar(
                        backgroundColor: Pallete.primary,
                        child: Text(
                          textProvider!.substring(6, 7),
                          style: const TextStyle(
                              color: Colors.white, fontWeight: FontWeight.bold),
                        ),
                      )),
                  const SizedBox(
                    width: 8,
                  ),
                  Expanded(
                      flex: 12,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text(typeProvider!,
                              style: const TextStyle(
                                  color: Pallete.primary,
                                  fontWeight: FontWeight.bold)),
                          Text(textProvider!,
                              style: const TextStyle(color: Pallete.thirdy)),
                          Text(numberCard!,
                              style: const TextStyle(color: Pallete.thirdy)),
                        ],
                      )),
                  Expanded(
                      flex: 3,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          IconButton(
                              icon: const Image(
                                  image: AssetImage(
                                      "assets/images/icon-delete.png")),
                              onPressed: () {
                                const DialogBox().showImageDialog(
                                    message:
                                        "Apakah Anda yakin akan menghapus Daftar Favorite",
                                    context: context,
                                    buttonCancel: "Tidak",
                                    buttonOk: "Hapus",
                                    image: Image.asset(
                                      'assets/images/icon-warning.png',
                                      scale: 3,
                                    ),
                                    isError: true,
                                    onOk: () {
                                      _doremoveT();
                                    });
                              })
                        ],
                      )),
                ],
              ),
              const Divider(
                color: Pallete.thirdy,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
