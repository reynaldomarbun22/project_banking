import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PBB/confirm_item_pbb.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PBB/page_tahun.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PDAM/tirtadaroy/pdam_confirmation.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PDAM/tirtadaroy/confirm_new_tirtadaroy.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PDAM/tirtadaroy/widgets/list_detail.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PLN/pascabayarPLN/plninqury.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PLN/prabayarPLN.dart/plninqury.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/Telkom/IndiHome/indihome_page.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/Telkom/Telepon_Rumah/telepon_rumah_page.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/Universitas/ArRaniry/ar_raniry_page.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/Universitas/TeukurUmar/teuku_umar_page.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/asuransi/bpjs/inq_bpjs.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/infaq/Infaq_BaitulMalAceh/infaq_baitul_mal_aceh.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/pemda/e_setor.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/pulsa_pascabayar/pascabayar_page.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/samsat/samsat.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/keretaapi/kai/inq_kai.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/pesawat/citilink/inq_citilink.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/pesawat/garuda/inq_garuda.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/tvberlangganan/mnc%20vision/inquiry_mnc.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/tvberlangganan/transvision/transvision.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/zakat/Baitul/zakat_baitul_mall_aceh.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/Paket_Data/inq_paketdata/inquiripaket.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/Pulsa/TSEL/pembelian_pulsa_fix.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/topup/gopay/inqury_gopay.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/topup/linkAja/inqury_link_aja.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/topup/ovo/inqury_ovo.dart';
import 'package:flutter/material.dart';

class TabPaymentFavoriteItem extends StatelessWidget {
  const TabPaymentFavoriteItem(
      {Key? key,
      this.listPBB,
      this.kota,
      this.code,
      this.desc,
      this.typePayment,
      this.textType,
      this.id,
      this.noRek,
      this.callback})
      : super(key: key);
  final String? typePayment;
  final String? textType;
  final String? desc;
  final String? noRek;
  final int? id;
  final String? code;
  final String? kota;
  final String? listPBB;

  final Function(
      String? typePayment,
      String? noRek,
      String? textType,
      String? desc,
      int? id,
      String? code,
      String? kota,
      String? listPBB)? callback;

  @override
  Widget build(BuildContext context) {
    _doTransfer() async {
      if (listPBB != null) {
        Map<String, Object?> param = {};

        param['nop'] = noRek;
        param['tranAdditionalData2'] = listPBB;

        final resp = await API.post(context, '/pbb/tahun/Inquiry', param);
        if (resp != null && resp['code'] == 0) {
          List<ConfirmationItemPBB> listParam = [];
          List<dynamic> listMap = resp['resi'];
          for (var item in listMap) {
            ConfirmationItemPBB itemParam =
                ConfirmationItemPBB(key: item['key'], value: item['value']);
            listParam.add(itemParam);
          }
          var listResp = resp['listTahun'];
          List<dynamic> listRespMini = (listResp);
          List<DropdownItemPBB> listKewarganegaraan = [];
          //for (var item in listRespMini) {
          for (var i = 0; i < listRespMini.length; i++) {
            DropdownItemPBB items = DropdownItemPBB(
              tahunindex: i,
              tahun: listRespMini[i]['stringTahun'],
              // tahunkey: listRespMini[i]['key'],
            );

            listKewarganegaraan.add(items);
            print(listKewarganegaraan);
          }

          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => PageTahun(
                        listdrop: listKewarganegaraan,
                        list: listParam,
                      )));
        } else {
          const DialogBox().showImageDialog(
              message: resp['message'],
              isError: true,
              image: const Image(
                image: AssetImage('assets/images/icon-failed.png'),
              ),
              buttonCancel: 'OK',
              onOk: () {},
              context: context);
        }
      }
    }

    _doTransferPDAM() async {
      Map<String, Object?> param = {};
      param['tranAdditionalData2'] = listPBB;
      param['idPelanggan'] = noRek;

      final resp = await API.post(context, '/pdam/tirtadaroy/Inquiry', param);
      if (resp != null && resp['code'] == 0) {
        List<ListConfirmationPDAM> listParam1 = [];
        List<dynamic> listMap = resp['resi'];
        for (var item in listMap) {
          ListConfirmationPDAM itemParam =
              ListConfirmationPDAM(key: item['key'], value: item['value']);
          listParam1.add(itemParam);
        }
        // var listResp = resp['resiDetail'];
        // List<dynamic> listRespDyn = (listResp);

        List<DetailItem> _listitems = [];
        // ignore: unused_local_variable
        List<DetailItem> _listitem = [];
        // //   List<dynamic> listResidetail = resp['resiDetail'];

        //   for (var item in listResidetail) {
        //     ListConfirmationPDAM itemParam =
        //         ListConfirmationPDAM(key: item['key'], value: item['value']);
        //     listParams.add(itemParam);
        //   }
        for (var item in resp['resiDetail']) {
          // print(item['respCode']);

          _listitems.add(DetailItem(
              periode: item['periode'],
              pemakaian: item['pemakaian'],
              denda: item['denda'],
              biaya: item['biaya'],
              tagihan: item['tagihan']));
        }

        List<ListConfirmationPDAM> listParam3 = [];
        List<dynamic> listMap3 = resp['resiTotalBayar'];
        for (var item in listMap3) {
          ListConfirmationPDAM itemParam3 =
              ListConfirmationPDAM(key: item['key'], value: item['value']);
          listParam3.add(itemParam3);
        }
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => PageConfirmPDAM(
                      // itemList: _itemList1,

                      items1: listParam1,
                      items2: _listitems,
                      items3: listParam3,
                    )));
      } else {
        const DialogBox().showImageDialog(
            message: resp['message'],
            isError: true,
            image: const Image(
              image: AssetImage('assets/images/icon-failed.png'),
            ),
            buttonCancel: 'OK',
            onOk: () {},
            context: context);
      }
    }

    _doremoveT() async {
      Map<String, Object?> param = {};
      param['newid'] = id;
      final resp = await API.post(context, '/favorite/delete', param);
      print(resp);
      Navigator.pop(context);
      if (resp != null && resp['code'] == 0) {
        callback!(
            typePayment,
            noRek,
            textType,
            desc,
            id,
            code,
            kota,
            listPBB); // buat rfresh screen sesudah didelete
      }
    }

    return Card(
      elevation: 0,
      child: InkWell(
        onTap: () {
          if (code == "4501") {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => const ZakatMalBaitulAceh()));
          } else if (code == "4701") {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => const InfaqMalBaitulAceh()));
          } else if (code == "4902") {
            Navigator.push(context,
                MaterialPageRoute(builder: (context) => const TeukurUmar()));
          } else if (code == "4901") {
            Navigator.push(context,
                MaterialPageRoute(builder: (context) => const ArRaniry()));
          } else if (code == "4008") {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => PascaBayarPage(
                          noInvoice: noRek,
                        )));
          } else if (code == "4014") {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => PascaBayarPage(
                          noInvoice: noRek,
                        )));
          } else if (code == "4012") {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => PascaBayarPage(
                          noInvoice: noRek,
                        )));
          } else if (code == "4013") {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => PascaBayarPage(
                          noInvoice: noRek,
                        )));
          } else if (code == "5102") {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => ListrikPascaBayarPage(
                          noInvoice: noRek,
                        )));
          } else if (code == "4511") {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => TeleponRumah(
                          noInvoice: noRek,
                        )));
          } else if (code == "4512") {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => IndiHome(
                          noInvoice: noRek,
                        )));
          } else if (code == "4904") {
            Navigator.push(context,
                MaterialPageRoute(builder: (context) => const Samsat()));
          } else if (code == "4801") {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => Transvision(
                          noJastel: noRek,
                        )));
          } else if (code == "5211") {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => InquiryMNCVision(
                          noJastel: noRek,
                        )));
          } else if (code == "4903") {
            Navigator.push(context,
                MaterialPageRoute(builder: (context) => const EsetorPemda()));
          } else if (code == "5201") {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => const InquiryGaruda()));
          } else if (code == "5202") {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => const InquiryCitilink()));
          } else if (code == "4009") {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => InquiryPaketData(
                          nomorHp: noRek,
                        )));
          } else if (code == "4014") {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => InquiryPaketData(
                          nomorHp: noRek,
                        )));
          } else if (code == "4007") {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => PembelianPulsa(
                          nomorHp: noRek,
                        )));
          } else if (code == "4010") {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => PembelianPulsa(
                          nomorHp: noRek,
                        )));
          } else if (code == "4011") {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => PembelianPulsa(
                          nomorHp: noRek,
                        )));
          } else if (code == "5121") {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => KeretaKAI(
                          kodeBayar: noRek,
                        )));
          } else if (code == "5101") {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => ListrikPrabayarPage(
                          noInvoice: noRek,
                        )));
          } else if (code == "5301") {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => GopayPage(
                          noInvoice: noRek,
                        )));
          } else if (code == "5302") {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => OvoPage(
                          noInvoice: noRek,
                        )));
            // Navigator.push(context, new MaterialPageRoute(builder: (context) =>new InfaqMalBaitulAceh()));
          } else if (code == "5303") {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => LinkAjaPage(
                          noInvoice: noRek,
                        )));
            // Navigator.push(context, new MaterialPageRoute(builder: (context) =>new InfaqMalBaitulAceh()));
          } else if (code == "5401") {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => InquiryBPJS(
                          kodeBayar: noRek,
                        )));
          } else if (code == "5421") {
            _doTransfer();
          } else if (code == "5411") {
            _doTransferPDAM();
            // Navigator.push(
            //     context,
            //     new MaterialPageRoute(
            //         builder: (context) => new InquiryTirtaDaroy(
            //               kodeBayar: noRek,
            //               // kota: listPBB
            //             )));
          }
          // else if (textType == "Lion") {
          //   Navigator.push(
          //       context,
          //       new MaterialPageRoute(
          //           builder: (context) => new ListrikPrabayarPage(
          //                 noInvoice: noRek,
          //               )));
          //   // Navigator.push(context, new MaterialPageRoute(builder: (context) =>new InfaqMalBaitulAceh()));
          // }
        },
        child: Container(
          padding: const EdgeInsets.only(left: 4, right: 4),
          child: Column(
            children: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    flex: 2,
                    child: Image.asset(
                        'assets/images/icon-payments-active.png'),
                    //  CircleAvatar(
                    //   backgroundColor: Pallete.primary,
                    //   child: Text(
                    //     desc.substring(0, 1),
                    //     style: TextStyle(
                    //         color: Colors.white, fontWeight: FontWeight.bold),
                    //   ),
                    // ),
                  ),
                  const SizedBox(
                    width: 8,
                  ),
                  code == '5411'
                      ? Expanded(
                          flex: 12,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              // Text(typePayment,
                              //     style: TextStyle(
                              //         color: Pallete.primary,
                              //         fontWeight: FontWeight.bold)),
                              Text(textType!,
                                  style: const TextStyle(
                                      color: Pallete.thirdy,
                                      fontWeight: FontWeight.bold)),
                              Text(kota!,
                                  style: const TextStyle(
                                    color: Pallete.thirdy,
                                  )),
                              noRek == ""
                                  ? Container()
                                  : Text(noRek!,
                                      style: const TextStyle(color: Pallete.thirdy)),
                            ],
                          ),
                        )
                      : code == '5421'
                          ? Expanded(
                              flex: 12,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  // Text(typePayment,
                                  //     style: TextStyle(
                                  //         color: Pallete.primary,
                                  //         fontWeight: FontWeight.bold)),
                                  Text(textType!,
                                      style: const TextStyle(
                                          color: Pallete.thirdy,
                                          fontWeight: FontWeight.bold)),
                                  Text(kota!,
                                      style: const TextStyle(
                                        color: Pallete.thirdy,
                                      )),
                                  noRek == ""
                                      ? Container()
                                      : Text(noRek!,
                                          style:
                                              const TextStyle(color: Pallete.thirdy)),
                                ],
                              ),
                            )
                          : Expanded(
                              flex: 12,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  // Text(typePayment,
                                  //     style: TextStyle(
                                  //         color: Pallete.primary,
                                  //         fontWeight: FontWeight.bold)),
                                  Text(textType!,
                                      style: const TextStyle(
                                          color: Pallete.thirdy,
                                          fontWeight: FontWeight.bold)),
                                  noRek == ""
                                      ? Container()
                                      : Text(noRek!,
                                          style:
                                              const TextStyle(color: Pallete.thirdy)),
                                ],
                              ),
                            ),
                  Expanded(
                      flex: 3,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          IconButton(
                              icon: const Image(
                                  image: AssetImage(
                                      "assets/images/icon-delete.png")),
                              onPressed: () {
                                const DialogBox().showImageDialog(
                                    message:
                                        "Apakah Anda yakin akan menghapus Daftar Favorit",
                                    context: context,
                                    buttonCancel: "Tidak",
                                    buttonOk: "Hapus",
                                    image: Image.asset(
                                      'assets/images/icon-warning.png',
                                    ),
                                    isError: true,
                                    onOk: () {
                                      _doremoveT();
                                    });
                              })
                        ],
                      )),
                ],
              ),
              const Divider(
                color: Pallete.primary,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

//
//ini dijadiin componen(istAvatarList)
