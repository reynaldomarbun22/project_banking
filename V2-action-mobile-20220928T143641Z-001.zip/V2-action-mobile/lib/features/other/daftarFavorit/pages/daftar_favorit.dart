import 'package:bpd_aceh/components/ist_list_fav.dart';
import 'package:flutter/material.dart';

class DaftarFavoriteFull extends StatelessWidget {
  static const routeName = '/DaftarF';

  const DaftarFavoriteFull({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ISTListFav(
      context: context,
      // ignore: prefer_const_literals_to_create_immutables
      menu: [
        ISTFavoritEnum.transfer,
        // ISTFavoritEnum.pembelian,
        ISTFavoritEnum.pembayaran,
      ],
      // menu: ISTFavoritEnum.transfer,
    );
  }
}
