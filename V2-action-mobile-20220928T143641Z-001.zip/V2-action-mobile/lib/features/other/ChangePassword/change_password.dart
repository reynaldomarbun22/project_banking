import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_style.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/core/crypto/ist_crypto.dart';
import 'package:bpd_aceh/core/utils/string_utils.dart';
import 'package:bpd_aceh/features/landing/landing.dart';
import 'package:bpd_aceh/features/login/login.dart';
import 'package:bpd_aceh/features/splash/splash.dart';
import 'package:flutter/material.dart';
import 'package:wc_form_validators/wc_form_validators.dart';

class ChangePass extends StatefulWidget {
  static const routeName = '/ChangeMPIN';

  const ChangePass({Key? key}) : super(key: key);
  @override
  _ChangePassState createState() => _ChangePassState();
}

class _ChangePassState extends State<ChangePass> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  // ignore: unused_field
  bool _autoValidate = false;

  final _oldPasswordController = TextEditingController();
  final _passwordController = TextEditingController();
  final _passwordConfirmController = TextEditingController();

  bool showOldPass = true;
  bool showPass = true;
  bool showPassConfirm = true;
  bool isLoading = false;
  bool _oldPassError = false;
  bool _passError = false;
  bool _passConfError = false;

  _showOldPassword() {
    setState(() {
      showOldPass = !showOldPass;
    });
  }

  _showPassword() {
    setState(() {
      showPass = !showPass;
    });
  }

  _showPasswordConfirm() {
    setState(() {
      showPassConfirm = !showPassConfirm;
    });
  }

  bool _validateInputs() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      return true;
    } else {
      setState(() {
        _autoValidate = true;
      });
      return false;
    }
  }

  bool _doValidate() {
    if (_validateInputs() != true) return false;
    bool _success = true;
    if (_oldPasswordController.text.isEmpty) {
      setState(() {
        _oldPassError = true;
      });
      _success = false;
    } else {
      setState(() {
        _oldPassError = false;
      });
    }

    if (_passwordController.text.isEmpty) {
      setState(() {
        _passError = true;
      });
      _success = false;
    } else {
      setState(() {
        _passError = false;
      });
    }
    if (_passwordConfirmController.text.isEmpty) {
      setState(() {
        _passConfError = true;
      });
      _success = false;
    } else {
      setState(() {
        _passConfError = false;
      });
    }
    return _success;
  }

  _doChangePassword() async {
    if (_doValidate()) {
      Map<String, Object> param = {};
      final oldPassword =
          await ISTCrypto.encryptAES(_oldPasswordController.text);
      final newPassword = await ISTCrypto.encryptAES(_passwordController.text);
      param['oldPassword'] = oldPassword;
      param['newPassword'] = newPassword;

      final resp = await API.post(context, '/change/password', param);
      if (resp['code'] == 0) {
        const DialogBox().showImageDialog(
            title: 'Anda berhasil mengganti Password Anda',
            message: resp['message'],
            buttonOk: 'Selesai',
            isError: false,
            image: const Image(
              image: AssetImage('assets/images/icon-success.png'),
            ),
            onOk: () async {
              await ISTConstants().setString(ISTConstants.authCookie, '');
              await ISTConstants().setString(ISTConstants.loggedInKey, '');
              Navigator.pushNamedAndRemoveUntil(
                  context,
                  LandingPageScreen.routeName,
                  ModalRoute.withName(Splash.routeName));
              Navigator.pushNamed(context, LoginPage.routeName);
            },
            context: context);
      } else if (resp['code'] != null && resp['code'] != 0) {
        if (resp['code'] == -1007) {
          const DialogBox().showImageDialog(
              message: resp['message'],
              isError: true,
              image: const Image(
                image: AssetImage('assets/images/icon-failed.png'),
              ),
              buttonCancel: 'OK',
              onOk: () {},
              onCancel: () {
                Navigator.pushNamedAndRemoveUntil(
                    context,
                    LandingPageScreen.routeName,
                    ModalRoute.withName(Splash.routeName));
                Navigator.pushNamed(context, LoginPage.routeName);
              },
              context: context);
        } else {
          const DialogBox().showImageDialog(
              message: resp['message'],
              isError: true,
              image: const Image(
                image: AssetImage('assets/images/icon-failed.png'),
              ),
              buttonCancel: 'OK',
              onOk: () {},
              context: context);
        }
      }
    }
  }
  //-1007

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          leading: IconButton(
              icon: const Icon(
                Icons.arrow_back_ios,
                color: Colors.white,
              ),
              onPressed: () {
                Navigator.pop(context);
              }),
          title: const Text(
            'Ganti Password',
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'Poppins',
            ),
          ),
          centerTitle: true,
          elevation: 0.0,
          iconTheme: const IconThemeData(color: Colors.black),
          backgroundColor: Pallete.primary,
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            child: Container(
              padding: const EdgeInsets.all(16),
              child: Form(
                key: _formKey,
                // ignore: deprecated_member_use
                autovalidateMode: AutovalidateMode.always,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    const SizedBox(height: 16),
                    Container(
                        alignment: Alignment.topLeft,
                        child: const Text('PASSWORD LAMA')),
                    TextFormField(
                      inputFormatters: [
                        // StringUtils.alphaNumeric(),
                        StringUtils.noSpace()
                      ],
                      onChanged: (val) {
                        setState(() {
                          if (val.isEmpty) {
                            _oldPassError = true;
                          } else {
                            _oldPassError = false;
                          }
                        });
                      },
                      maxLength: ISTConstants.passwordMaxLength,

                      // maxLength: 30,
                      expands: false,
                      obscureText: showOldPass,
                      keyboardType: TextInputType.text,
                      onSaved: (String? val) {
                        _oldPasswordController.text = val!;
                      },
                      decoration: InputDecoration(
                        hintText: 'Masukkan Password Lama Anda',
                        errorText: _oldPassError ? "Mohon diisi" : null,
                        hintStyle: ISTStyle.hintStyle,
                        suffixIcon: IconButton(
                          icon: Icon(showOldPass
                              ? Icons.visibility
                              : Icons.visibility_off),
                          onPressed: () {
                            _showOldPassword();
                          },
                        ),
                      ),
                      controller: _oldPasswordController,
                      validator: (val) {
                        if (val!.length < 8) {
                          return "*minimal 8 karakter";
                        } else {
                          return null;
                        }
                      },
                    ),
                    const SizedBox(height: 8),
                    Container(
                        alignment: Alignment.topLeft,
                        child: const Text('PASSWORD BARU')),
                    TextFormField(
                      maxLength: ISTConstants.passwordMaxLength,
                      inputFormatters: [
                        // StringUtils.alphaNumeric(),
                        StringUtils.noSpace()
                      ],
                      onChanged: (val) {
                        setState(() {
                          if (val.isEmpty) {
                            _passError = true;
                          } else {
                            _passError = false;
                          }
                        });
                      },
                      // maxLength: 25,
                      expands: false,
                      obscureText: showPass,
                      keyboardType: TextInputType.text,
                      validator: Validators.compose([
                        Validators.required('Mohon diisi'),
                        Validators.patternString(
                            r'^(?=.*?[a-z])(?=.*?[0-9]).{8,32}$',
                            'Minimal 8 karakter kombinasi huruf dan angka'),
                        Validators.minLength(
                            8, 'Minimal 8 karakter kombinasi huruf dan angka')
                      ]),
                      // validator: (val) {
                      //   if (val.length < 8) {
                      //     return "*minimal 8 karakter kombinasi huruf dan angka";
                      //   } else {
                      //     return null;
                      //   }
                      // },
                      onSaved: (String? val) {
                        _passwordController.text = val!;
                      },
                      decoration: InputDecoration(
                        hintText: 'Masukkan Password Baru Anda',
                        errorText: _passError ? "Mohon diisi" : null,
                        hintStyle: ISTStyle.hintStyle,
                        suffixIcon: IconButton(
                          icon: Icon(showPass
                              ? Icons.visibility
                              : Icons.visibility_off),
                          onPressed: () {
                            _showPassword();
                          },
                        ),
                      ),
                      controller: _passwordController,
                    ),
                    const SizedBox(height: 8),
                    Container(
                        alignment: Alignment.topLeft,
                        child: const Text('KONFIRMASI PASSWORD BARU')),
                    TextFormField(
                      maxLength: ISTConstants.passwordMaxLength,
                      inputFormatters: [
                        // StringUtils.alphaNumeric(),
                        StringUtils.noSpace()
                      ],
                      onChanged: (val) {
                        setState(() {
                          if (val.isEmpty) {
                            _passConfError = true;
                          } else {
                            _passConfError = false;
                          }
                        });
                      },
                      // maxLength: 25,
                      expands: false,
                      validator: (val) {
                        if (val != _passwordController.text) {
                          return "*konfirmasi password tidak sama";
                        } else {
                          return null;
                        }
                      },
                      onSaved: (String? val) {
                        _passwordConfirmController.text = val!;
                      },
                      obscureText: showPassConfirm,
                      keyboardType: TextInputType.text,
                      decoration: InputDecoration(
                        hintText: 'Konfirmasi Password Baru Anda',
                        errorText: _passConfError ? "Mohon diisi" : null,
                        hintStyle: ISTStyle.hintStyle,
                        suffixIcon: IconButton(
                          icon: Icon(showPassConfirm
                              ? Icons.visibility
                              : Icons.visibility_off),
                          onPressed: () {
                            _showPasswordConfirm();
                          },
                        ),
                      ),
                      controller: _passwordConfirmController,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 16),
                      child: ISTOutlineButton(
                          onPressed: () {
                            _doChangePassword();
                          },
                          text: 'Lanjut'),
                    )
                  ],
                ),
              ),
            ),
          ),
        ));
  }
}
