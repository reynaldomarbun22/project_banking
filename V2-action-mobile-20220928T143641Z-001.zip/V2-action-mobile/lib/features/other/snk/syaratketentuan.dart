import 'dart:io';

import 'package:bpd_aceh/components/palete.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class TermsAndConditionOthers extends StatefulWidget {
  static const routeName = '/snk';

  const TermsAndConditionOthers({Key? key}) : super(key: key);

  @override
  _TermsAndConditionOthersState createState() =>
      _TermsAndConditionOthersState();
}

class _TermsAndConditionOthersState extends State<TermsAndConditionOthers> {
  final bool _boolValue = false;
  bool isLoading = true;

  final Set<Factory> gestureRecognizers = {
    Factory(() => EagerGestureRecognizer()),
  }.toSet();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          title: const Text(
            "Syarat dan Ketentuan",
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'Poppins',
            ),
          ),
          centerTitle: true,
          backgroundColor: Pallete.primary,
        ),
        backgroundColor: Colors.white,
        body: foreground());
  }

  // ignore: unused_element
  _onPressed() async {
    if (_boolValue) {
      Navigator.pop(context);
    }
  }

  Widget foreground() {
    return SafeArea(
      child: Column(
        children: <Widget>[
          Expanded(
            // child: SingleChildScrollView(
            child: Padding(
                padding: const EdgeInsets.symmetric(),
                child: Stack(
                  children: <Widget>[
                    isLoading
                        ? const Center(
                            child: Text('Waiting...'),
                          )
                        : Stack(),
                    // Container(
                    //   height: MediaQuery.of(context).size.height * 11,
                    //   width: MediaQuery.of(context).size.width * 11,
                    //   child:
                    WebView(
                      initialUrl: (Platform.isAndroid)
                          ? 'https://action.bankaceh.co.id/faq.html'
                          // ? "http://action.bankaceh.co.id/faq.html"
                          : 'https://action.bankaceh.co.id/snk-ios.html',
                      debuggingEnabled: true,
                      javascriptMode: JavascriptMode.unrestricted,
                      gestureRecognizers: gestureRecognizers
                          as Set<Factory<OneSequenceGestureRecognizer>>?,
                      onPageFinished: (finish) {
                        setState(() {
                          isLoading = false;
                        });
                      },
                    ),

                    // Padding(
                    //   padding: const EdgeInsets.symmetric(horizontal: 16),
                    //   child: Divider(
                    //     height: 0,
                    //     thickness: 1,
                    //     color: Pallete.PRIMARY,
                    //   ),
                    // ),
                    // SizedBox(
                    //   height: 16,
                    // ),
                    // Container(
                    //   padding: const EdgeInsets.symmetric(
                    //       horizontal: 16.0, vertical: 12),
                    //   child: ISTOutlineButton(
                    //       text: 'OK',
                    //       onPressed: () {
                    //         Navigator.pop(context);
                    //       }),
                    // ),
                    // SizedBox(height: 16)
                  ],
                )),
          ),
          // ),
        ],
      ),
    );
  }
}
