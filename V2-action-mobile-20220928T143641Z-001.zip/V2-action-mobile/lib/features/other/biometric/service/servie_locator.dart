// import 'package:bpd_aceh/features/other/biometric/service/local_authethication_service.dart';
// import 'package:get_it/get_it.dart';

// GetIt locator = GetIt();

// void setupLocator() {
//   locator.registerLazySingleton(() => LocalAuthenticationService());
// }