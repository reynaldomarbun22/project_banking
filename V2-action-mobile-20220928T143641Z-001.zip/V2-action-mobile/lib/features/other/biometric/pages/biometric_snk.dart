import 'dart:io';
import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';

import 'package:bpd_aceh/features/termcondition/paragraph_widget.dart';
import 'package:flutter/material.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';

import 'package:local_auth/local_auth.dart';
import 'package:flutter/services.dart';
import 'package:local_auth/error_codes.dart' as auth_error;

class SnKBiometric extends StatefulWidget {
  static const routeName = '/SnKbiometric';

  const SnKBiometric({Key? key}) : super(key: key);

  @override
  _SnKBiometricState createState() => _SnKBiometricState();
}

class _SnKBiometricState extends State<SnKBiometric> {
  bool switchControl = false;

  _checkBiometrics() async {
    var localAuth = LocalAuthentication();
    bool canCheckBiometrics = await localAuth.canCheckBiometrics;
    if (!canCheckBiometrics) return BiometricType;

    final _bioStatus =
        await ISTConstants().getConstants(ISTConstants.biometricStatus);
    if (_bioStatus != null && _bioStatus == false) {
      setState(() {
        switchControl = false;
      });
    } else if (_bioStatus != null && _bioStatus == true) {
      setState(() {
        switchControl = true;
      });
    } else {
      setState(() {
        switchControl = false;
      });
    }
    List<BiometricType> availableBiometrics =
        await localAuth.getAvailableBiometrics();
    if (availableBiometrics.isEmpty) {
      const DialogBox().showImageDialog(
          message:
              'Biometrik tidak ditemukan, silahkan cek pengaturan biometrik di device anda',
          isError: true,
          image: const Image(
            image: AssetImage('assets/images/icon-failed.png'),
          ),
          buttonCancel: 'OK',
          onOk: () {},
          context: context);
    }
    bool auth = false;
    if (Platform.isIOS) {
      if (availableBiometrics.contains(BiometricType.face)) {
        try {
          bool didAuthenticate = await localAuth.authenticate(
              biometricOnly: true,
              useErrorDialogs: false,
              localizedReason: 'Please authenticate to show account balance');
          if (didAuthenticate) {
            auth = true;
            var biometricResult = await _doSendBiometricsStatus(auth);
            if (biometricResult) {
              await ISTConstants()
                  .setConstants(ISTConstants.biometricsTermsAndCondition, true);

              await ISTConstants()
                  .setConstants(ISTConstants.biometricStatus, true);
              Navigator.pop(context, true);
              //berhasil :D
            }
            return;
          } else {
            return;
          }
        } on PlatformException catch (e) {
          if (e.code == auth_error.notEnrolled) {
            // Handle this exception here.
            const DialogBox().showImageDialog(
                message: 'Silahkan atur Face di perangkat anda',
                isError: true,
                buttonCancel: 'OK',
                onOk: () {
                  Navigator.pop(context);
                },
                context: context);
          }
        }

        // Face ID.
        // const iosStrings = const IOSAuthMessages(
        //     cancelButton: 'cancel',
        //     goToSettingsButton: 'settings',
        //     goToSettingsDescription: 'Please set up your Touch ID.',
        //     lockOut: 'Please reenable your Touch ID');
        // auth = await localAuth.authenticateWithBiometrics(
        //     localizedReason: 'Please authenticate',
        //     useErrorDialogs: false,
        //     iOSAuthStrings: iosStrings);
      } else if (availableBiometrics.contains(BiometricType.fingerprint)) {
        try {
          bool didAuthenticate = await localAuth.authenticate(
              biometricOnly: true,
              useErrorDialogs: false,
              localizedReason: 'Please authenticate to show account balance');
          if (didAuthenticate) {
            auth = true;
            var biometricResult = await _doSendBiometricsStatus(auth);
            if (biometricResult) {
              await ISTConstants()
                  .setConstants(ISTConstants.biometricsTermsAndCondition, true);

              await ISTConstants()
                  .setConstants(ISTConstants.biometricStatus, true);
              Navigator.pop(context, true);
              //berhasil :D
            }
            return;
          } else {
            return;
          }
        } on PlatformException catch (e) {
          if (e.code == auth_error.notEnrolled) {
            // Handle this exception here.
            const DialogBox().showImageDialog(
                message: 'Silahkan atur Fingerprint di perangkat anda',
                isError: true,
                buttonCancel: 'OK',
                onOk: () {
                  Navigator.pop(context);
                },
                context: context);
          }
        }
        // Touch ID.
        // auth = await localAuth.authenticateWithBiometrics(
        //   useErrorDialogs: false,
        //   localizedReason: 'Please authenticate',
        // );
        // if (!auth) {
        //   DialogBox().showImageDialog(
        //       message: 'Silahkan cek Fingerprint/Face ID di perangkat anda',
        //       isError: true,
        //       buttonCancel: 'OK',
        //       onOk: () {
        //         Navigator.pop(context);
        //       },
        //       context: context);
        // }
      }
    } else if (Platform.isAndroid) {
      if (availableBiometrics.contains(BiometricType.face)) {
        try {
          bool didAuthenticate = await localAuth.authenticate(
              biometricOnly: true,
              useErrorDialogs: false,
              localizedReason: 'Please authenticate to show account balance');
          if (didAuthenticate) {
            auth = true;
            var biometricResult = await _doSendBiometricsStatus(auth);
            if (biometricResult) {
              await ISTConstants()
                  .setConstants(ISTConstants.biometricsTermsAndCondition, true);

              await ISTConstants()
                  .setConstants(ISTConstants.biometricStatus, true);
              Navigator.pop(context, true);
              //berhasil :D
            }
            return;
          } else {
            return;
          }
        } on PlatformException catch (e) {
          if (e.code == auth_error.notEnrolled) {
            // Handle this exception here.
            const DialogBox().showImageDialog(
                message: 'Silahkan atur Face di perangkat anda',
                isError: true,
                buttonCancel: 'OK',
                onOk: () {
                  Navigator.pop(context);
                },
                context: context);
          }
        }
      } else if (availableBiometrics.contains(BiometricType.fingerprint)) {
        try {
          bool didAuthenticate = await localAuth.authenticate(
              biometricOnly: true,
              useErrorDialogs: false,
              localizedReason: 'Please authenticate to show account balance');
          if (didAuthenticate) {
            auth = true;
            var biometricResult = await _doSendBiometricsStatus(auth);
            if (biometricResult) {
              await ISTConstants()
                  .setConstants(ISTConstants.biometricsTermsAndCondition, true);

              await ISTConstants()
                  .setConstants(ISTConstants.biometricStatus, true);
              Navigator.pop(context, true);
              //berhasil :D
            }
            return;
          } else {
            return;
          }
        } on PlatformException catch (e) {
          if (e.code == auth_error.notEnrolled) {
            // Handle this exception here.
            const DialogBox().showImageDialog(
                message: 'Silahkan atur Fingerprint di perangkat anda',
                isError: true,
                buttonCancel: 'OK',
                onOk: () {
                  Navigator.pop(context);
                },
                context: context);
          }
        }
      }
    } else {
      const DialogBox().showImageDialog(
          message: 'Perangkat tidak dikenal',
          isError: true,
          buttonCancel: 'OK',
          onOk: () {
            Navigator.pop(context);
          },
          context: context);
    }

    if (auth == true) {
      var biometricResult = await _doSendBiometricsStatus(auth);
      if (biometricResult) {
        await ISTConstants()
            .setConstants(ISTConstants.biometricsTermsAndCondition, true);

        await ISTConstants().setConstants(ISTConstants.biometricStatus, true);
        Navigator.pop(context, true);
        Navigator.pop(context, true);

        // Navigator.pushNamed(context, OtherWidget.routeName,true);
        // DialogBox().showImageDialog(
        //     message: 'Berhasil',
        //     title: 'Pengaturan Fingerprint',
        //     context: context,
        //     isError: false,
        //     buttonOk: 'Selesai',
        //     onOk: () {
        //       Navigator.pushNamed(context, HomePage.routeName);
        //     });
      }
      return;
    } else {
      // return;
      // var biometricResult = await _doSendBiometricsStatus(auth);
      // if (biometricResult) {
      //   await ISTConstants()
      //       .setConstants(ISTConstants.BIOMETRICS_STATUS, false);
      //   Navigator.pop(context, false);
      // }
      return _doSendBiometricsStatus(auth);
    }
  }

  _doSendBiometricsStatus(auth) async {
    final api = auth == true ? "/biometric/enable" : "/biometric/disable";
    final resp = await API.post(context, api, {});
    if (resp['code'] != null && resp['code'] == 0) {
      return true;
    } else if (resp['code'] != null && resp['code'] != 0) {
      const DialogBox().showImageDialog(
          message: resp['message'],
          isError: true,
          buttonCancel: 'OK',
          onOk: () {},
          context: context);

      return false;
    }
  }

  // ignore: unused_element
  _showMyDialog(BuildContext context) async {
    await showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          content: const Text(
            'Atur Biometric',
          ),
          actions: <Widget>[
            Switch(
              onChanged: (bool bool) {
                // ignore: void_checks
                return _checkBiometrics();
              },
              value: switchControl,
              activeColor: Pallete.primary,
            ),
          ],
        );
      },
    );
  }

  bool checklist = false;
  var textHolder = 'Tidak Aktif';

  void toggleChecklist(bool value) {
    setState(() {
      checklist = value;
    });
  }

  _getStatusBiometrics() async {
    final _bioStatus =
        await ISTConstants().getConstants(ISTConstants.biometricStatus);
    if (_bioStatus != null && _bioStatus == false) {
      setState(() {
        switchControl = false;
      });
    } else if (_bioStatus != null && _bioStatus == true) {
      setState(() {
        switchControl = true;
      });
    } else {
      setState(() {
        switchControl = false;
      });
    }
  }

  @override
  void initState() {
    _getStatusBiometrics();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    //bool _boolValue = false;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Pallete.primary,
        title: const Text(
          "Biometric",
          style: TextStyle(color: Colors.white, fontFamily: 'Poppins'),
        ),
        centerTitle: true,
        leading: IconButton(
            icon: const Icon(
              Icons.arrow_back_ios,
              color: Colors.white,
            ),
            onPressed: () {
              Navigator.pop(context);
            }),
      ),
      body: SafeArea(
        child: Column(
          children: <Widget>[
            Expanded(
              child: SingleChildScrollView(
                child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 16),
                    child: Column(
                      children: const <Widget>[
                        ParagraphWidget.lv1(
                          judul: 'Syarat dan Ketentuan Biometric',
                          textList: [
                            TextSpan(text: '\n'),
                          ],
                        ),
                        ParagraphWidget.lv1(
                          number: "1.",
                          textList: [
                            TextSpan(
                                text:
                                    'Nasabah wajib mengamankan penggunaan fitur biometric login dalam aplikasi Mobile Banking Bank Aceh jika menggunakan sidik jari (fingerprint) atau identifikasi wajah (face ID) atau retina mata (iris) dengan cara sebagai berikut : '),
                            TextSpan(text: '\n'),
                            TextSpan(
                              text:
                                  'Kecuali dinyatakan lain secara tegas dalam Syarat dan Ketentuan ini, istilah-istilah berikut ini mempunyai arti sebagai berikut:',
                            ),
                          ],
                        ),
                        ParagraphWidget.lv2(
                          number: "a.",
                          textList: [
                            TextSpan(
                              text:
                                  'Membatasi penambahan jumlah sidik jari atau identifikasi wajah atau retina mata (iris) yang terlalu banyak atau yang tidak diperlukan pada perangkat handphone;',
                            ),
                          ],
                        ),
                        ParagraphWidget.lv2(
                          number: "b.",
                          textList: [
                            TextSpan(
                              text:
                                  'Tidak mendaftarkan sidik jari (fingerprint) atau identifikasi wajah (face ID) atau retina mata (iris) selain dari nasabah pemilik rekening (yang melakukan akses ke aplikasi Mobile Banking Bank Aceh);',
                            ),
                          ],
                        ),
                        ParagraphWidget.lv2(
                          number: "c.",
                          textList: [
                            TextSpan(
                              text:
                                  'Tidak memberikan perangkat handphone maupun akses scan sidik jari (fingerprint) atau identifikasi wajah (face ID) atau retina mata (iris) kepada orang lain termasuk petugas bank atau anggota keluarga atau orang terdekat.',
                            ),
                          ],
                        ),
                        ParagraphWidget.lv1(
                          number: "2.",
                          textList: [
                            TextSpan(
                                text:
                                    'Aplikasi Mobile Banking Bank Aceh tidak menyimpan data (fingerprint) atau identifikasi wajah (face ID) atau retina mata (iris) nasabah. Melainkan hanya menggunakan (fingerprint) atau identifikasi wajah (face ID) atau retina mata (iris) yang telah diverifikasi serta disimpan oleh pemilik handphone selaku pemilik rekening yang akan melakukan akses pada aplikasi Mobile Banking Bank Aceh.'),
                          ],
                        ),
                        ParagraphWidget.lv1(
                          number: "3.",
                          textList: [
                            TextSpan(
                                text:
                                    'Aplikasi Mobile Banking Bank Aceh tidak menyimpan data (fingerprint) atau identifikasi wajah (face ID) atau retina mata (iris) nasabah. Melainkan hanya menggunakan (fingerprint) atau identifikasi wajah (face ID) atau retina mata (iris) yang telah diverifikasi serta disimpan oleh pemilik handphone selaku pemilik rekening yang akan melakukan akses pada aplikasi Mobile Banking Bank Aceh.'),
                          ],
                        ),
                        ParagraphWidget.lv1(
                          number: "4.",
                          textList: [
                            TextSpan(
                                text:
                                    'Untuk biometric login menggunakan sidik jari (fingerprint), dapat digunakan pada semua jenis perangkat handphone yang memiliki fitur scan dan penyimpanan sidik jari (fingerprint).'),
                          ],
                        ),
                        ParagraphWidget.lv1(
                          number: "5.",
                          textList: [
                            TextSpan(
                                text:
                                    'Untuk biometric login menggunakan identifikasi wajah (face ID), dapat digunakan hanya pada jenis perangkat handphone tertentu yang telah memiliki fitur scan dan penyimpanan identifikasi wajah ( face ID).'),
                          ],
                        ),
                        ParagraphWidget.lv1(
                          number: "6.",
                          textList: [
                            TextSpan(
                                text:
                                    'Untuk biometric login menggunakan retina mata (iris) , dapat digunakan hanya pada jenis perangkat handphone tertentu yang telah memiliki fitur scan dan penyimpanan retina mata (iris).'),
                          ],
                        ),
                        SizedBox(
                          height: 16,
                        ),
                        Divider(
                          height: 0,
                          thickness: 1,
                          color: Pallete.primary,
                        ),
                        // SizedBox(height: 16)
                      ],
                    )),
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
              child: Row(
                mainAxisSize: MainAxisSize.max,
                children: <Widget>[
                  Checkbox(
                      activeColor: Pallete.primary,
                      value: checklist,
                      onChanged: (value) {
                        setState(() {
                          checklist = !checklist;
                        });
                      }),
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        setState(() {
                          checklist = !checklist;
                        });
                      },
                      child: Container(
                        padding: const EdgeInsets.only(right: 16.0),
                        child: const Text(
                          "Saya menyetujui seluruh syarat dan ketentuan yang diberlakukan oleh setiap pihak terkait.",
                          softWrap: true,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.only(left: 16, right: 16),
              child: ISTOutlineButton(
                  text: 'Lanjut',
                  onPressed: () async {
                    if (checklist) {
                      _checkBiometrics();
                      // return _showMyDialog(context);
                    }
                  }),
            ),
            const SizedBox(height: 16)
          ],
        ),
      ),
    );
  }
}
