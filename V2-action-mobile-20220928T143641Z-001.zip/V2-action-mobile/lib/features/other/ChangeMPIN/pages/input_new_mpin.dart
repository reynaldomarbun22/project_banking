import 'package:bpd_aceh/components/ist_mpin.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/features/other/ChangeMPIN/pages/confirm_change_mpin.dart';
import 'package:flutter/material.dart';

class NewMPIN extends StatefulWidget {
  static const routeName = '/newMPIN';

  const NewMPIN({Key? key}) : super(key: key);
  @override
  _NewMPINState createState() => _NewMPINState();
}

class _NewMPINState extends State<NewMPIN> {
  _doStoreNewMPIN(value) async {
    ISTConstants().setString(ISTConstants.mpinChange, value);
    Navigator.pushNamed(context, ConfirmChangeMPIN.routeName);
  }

  @override
  Widget build(BuildContext context) {
    return ISTMPIN(
      appBarTitle: "Ganti MPIN",
      title: "Masukkan 6 digit MPIN baru anda",
      onFinishedVal: (val) {
        _doStoreNewMPIN(val);
      },
    );
  }
}
