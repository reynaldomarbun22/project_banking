import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_mpin.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/core/crypto/ist_crypto.dart';
import 'package:bpd_aceh/features/home/home_page.dart';
import 'package:bpd_aceh/features/splash/splash.dart';
import 'package:flutter/material.dart';

class ConfirmChangeMPIN extends StatefulWidget {
  static const routeName = '/confirmChangeMPIN';
  const ConfirmChangeMPIN({
    Key? key,
    required this.context,
  }) : super(key: key);
  final BuildContext? context;
  @override
  _ConfirmChangeMPINState createState() => _ConfirmChangeMPINState();
}

class _ConfirmChangeMPINState extends State<ConfirmChangeMPIN> {
  bool isError = false;

  _doChangeMPIN(value) async {
    final mpinCreate = await ISTConstants().getString(ISTConstants.mpinChange);
    if (value != mpinCreate) {
      setState(() {
        isError = true;
      });
      return;
    }
    Map<String, Object> param = {};
    final String pinEnc = await ISTCrypto.encryptAES(value);
    param['mpin'] = pinEnc;
    final resp = await API.post(context, '/change/mpin/create', param);
    if (resp['code'] == 0) {
      const DialogBox().showImageDialog(
          title: 'Anda berhasil mengganti MPIN Anda',
          message: resp['message'],
          buttonOk: 'Selesai',
          isError: false,
          image: const Image(
            image: AssetImage('assets/images/icon-success.png'),
          ),
          onOk: () {
            Navigator.pushNamedAndRemoveUntil(context, HomePage.routeName,
                ModalRoute.withName(Splash.routeName));
          },
          context: context);
    } else if (resp['code'] != 0) {
      if (resp['code'] == -2019) {
        const DialogBox().showImageDialog(
            message: resp['message'],
            isError: true,
            buttonCancel: 'OK',
            onCancel: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            onOk: () {},
            context: context);
      } else {
        const DialogBox().showImageDialog(
            message: resp['message'],
            isError: true,
            image: const Image(
              image: AssetImage('assets/images/icon-failed.png'),
            ),
            buttonCancel: 'OK',
            onOk: () {},
            context: context);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return ISTMPIN(
      appBarTitle: "Ganti MPIN",
      title: "Konfirmasi MPIN baru anda",
      onFinishedVal: (val) {
        _doChangeMPIN(val);
      },
      errorText: 'MPIN Tidak sesuai dengan MPIN sebelumnya',
      isError: isError,
    );
  }
}
