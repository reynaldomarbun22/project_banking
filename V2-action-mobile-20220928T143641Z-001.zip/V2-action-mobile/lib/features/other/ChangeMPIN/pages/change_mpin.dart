import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/crypto/ist_crypto.dart';
import 'package:bpd_aceh/features/other/ChangeMPIN/pages/input_new_mpin.dart';
import 'package:flutter/material.dart';
import 'package:bpd_aceh/components/ist_mpin.dart';

class OLDMPIN extends StatefulWidget {
  static const routeName = '/oldMPIN';

  const OLDMPIN({Key? key}) : super(key: key);
  @override
  _OLDMPINState createState() => _OLDMPINState();
}

class _OLDMPINState extends State<OLDMPIN> {
  _doValidateMPIN(value) async {
    Map<String, Object> param = {};
    final String pinEnc = await ISTCrypto.encryptAES(value);
    param['mpin'] = pinEnc;
    final resp = await API.post(context, '/change/mpin/validation', param);
    if (resp['code'] == 0) {
      Navigator.pushNamed(context, NewMPIN.routeName);
    } else {
      const DialogBox().showImageDialog(
          message: resp['message'],
          isError: true,
          image: const Image(
            image: AssetImage('assets/images/icon-failed.png'),
          ),
          buttonCancel: 'OK',
          onOk: () {},
          context: context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ISTMPIN(
      appBarTitle: "Ganti MPIN",
      title: "Masukkan 6 digit MPIN lama anda",
      onFinishedVal: (val) {
        _doValidateMPIN(val);
      },
    );
  }
}
