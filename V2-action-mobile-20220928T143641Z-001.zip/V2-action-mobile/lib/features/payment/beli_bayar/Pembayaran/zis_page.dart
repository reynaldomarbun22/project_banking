import 'package:bpd_aceh/components/ist_menu_container.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/infaq/Infaq_BaitulMalAceh/infaq_baitul_mal_aceh.dart';

import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/infaq/infaq_screen.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/zakat/zakat_screen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:bpd_aceh/core/controller/controller_menu.dart';

class ZisScreen extends StatefulWidget {
  static const routeName = '/ZisScreen';

  const ZisScreen({Key? key}) : super(key: key);
  @override
  _ZisScreenState createState() => _ZisScreenState();
}

class _ZisScreenState extends State<ZisScreen> {
  final controllerMenu = Get.put(MenuController());
  bool press = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text(
          "ZIS",
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'Poppins',
          ),
        ),
//        actions: <Widget>[
//          IconButton(
//            icon: Icon(
//              Icons.notifications,
//              color: Colors.white,
//            ),
//            onPressed: () {
//              // _doLogout();
//            },
//          )
//        ],
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      backgroundColor: Colors.white,
      body: ListView(
        children: <Widget>[
          Visibility(
            visible: controllerMenu.getVisibilityZakat(),
            child: ListTile(
              title: const Text('Zakat'),
              trailing: const Icon(Icons.arrow_forward_ios),
              onTap: () {
                Navigator.pushNamed(context, ZakatScreen.routeName);
              },
            ),
          ),
          Visibility(
            visible: controllerMenu.getVisibilityZakat(),
            child: const Divider(
              thickness: 1,
              color: Colors.grey,
            ),
          ),
          Visibility(
            visible: controllerMenu.getVisibilityInfak(),
            child: ListTile(
                title: const Text('Infak'),
                trailing: const Icon(Icons.arrow_forward_ios),
                onTap: () {
                  Navigator.pushNamed(context, InfaqScreen.routeName);
                }),
          ),
          Visibility(
            visible: controllerMenu.getVisibilityInfak(),
            child: const Divider(
              thickness: 1,
              color: Colors.grey,
            ),
          ),

          // Column(
          //   crossAxisAlignment: CrossAxisAlignment.start,
          //   children: <Widget>[
          //     ISTCardAccount(
          //       context: context,
          //       menu: ISTMenu.billpay,
          //     ),
          //     SizedBox(height: 8),
          //     SingleChildScrollView(
          //       child: buildMenuZakat(context),
          //     )
          //   ],
          // ),
        ],
      ),
      // Column(
      //   crossAxisAlignment: CrossAxisAlignment.start,
      //   children: <Widget>[
      //     ISTCardAccount(context: context, menu: ISTMenu.billpay),
      //     SizedBox(height: 8),
      //     SingleChildScrollView(
      //       child: buildMenuInfaq(context),
      //     )
      //   ],
      // ),
    );
  }
}

buildMenuInfaq(context) {
  return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      child: ISTMenuContainer(
        onTap: () {
          Navigator.pushNamed(context, InfaqMalBaitulAceh.routeName);
        },
        image: Image.asset(
          'assets/images/icon-baitulMal.png',
          width: 50,
        ),
        text: 'Baitul Mal Aceh',
      ));
}
