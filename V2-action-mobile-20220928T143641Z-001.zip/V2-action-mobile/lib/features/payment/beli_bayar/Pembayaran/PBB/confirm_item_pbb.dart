import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/ist_style.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PBB/confirm_pbb.dart';
import 'package:flutter/material.dart';

class ConfirmationItemPBB {
  final String? key;
  final String? value;
  ConfirmationItemPBB({this.key, this.value});
}

class ConfirmationPBB extends StatefulWidget {
  static const routeName = '/Confirmpbb';
  final List<ConfirmationItemPBB>? list;
  final List<ConfirmationItemPBB>? listPBB;

  const ConfirmationPBB({
    Key? key,
    this.list,
    this.listPBB,
    this.items,
    this.title,
    this.onFinished,
    this.dropitem,

    // this.items1,
  }) : super(key: key);

  final String? title;
  final List<ConfirmationItemPBB>? items;
  final List<DropdownItemPBB>? dropitem;
  final Function? onFinished;

  @override
  _ConfirmationPBBState createState() => _ConfirmationPBBState();
}

class _ConfirmationPBBState extends State<ConfirmationPBB> {
  List<DropdownItemPBB>? _listtahun = [];

  DropdownItemPBB? _selectedtahun;
  bool _dropError = false;
  bool _success = false;
  @override
  void initState() {
    _getselectedtahun();

    //  print(widget.dropitem);
    super.initState();
  }

  _doValidate() {
    if (_selectedtahun == null) {
      setState(() {
        _dropError = true;
      });
      _success = false;
    } else {
      _dropError = false;

      _success = true;
    }
    return _success;
  }

  _doTransfer() async {
    if (_dropError == false) {
      Map<String, Object?> param = {};

      // int.parse(_eSetorController.text.replaceAll(",", ""));
      param['tahunIdx'] = _selectedtahun!.tahunindex;
      final resp = await API.post(context, '/pbb/Inquiry', param);
      if (resp != null && resp['code'] == 0) {
        List<ISTConfirmationItem> listParam = [];
        List<dynamic> listMap = resp['resi'];
        for (var item in listMap) {
          ISTConfirmationItem itemParam =
              ISTConfirmationItem(key: item['key'], value: item['value']);
          listParam.add(itemParam);
        }

        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => PBBConfirmation(
                      list: listParam,
                    )));
      } else {
        const DialogBox().showImageDialog(
            message: resp['message'],
            isError: true,
            image: const Image(
              image: AssetImage('assets/images/icon-failed.png'),
            ),
            buttonCancel: 'OK',
            onOk: () {},
            context: context);
      }
    }
  }

  _getselectedtahun() async {
    try {
      setState(() {
        _selectedtahun = null;
      });
      if (_listtahun!.isNotEmpty) {
        Future.delayed(Duration.zero);
        _listtahun!.clear();
      }
      //  var listResp = widget.dropitem;
      //   List<dynamic> listRespMini = (listResp);
      //   List<DropdownItemPBB> listtahun = [];
      //   //for (var item in listRespMini) {
      //   for (var i = 0; i < listRespMini.length; i++) {
      //     DropdownItemPBB items = DropdownItemPBB(
      //       tahunindex: i,
      //       tahun:  listRespMini[i]['tahun'],
      //       // tahunkey : listRespMini[i]['title'],
      //     );

      //     listtahun.add(items);
      //   }

      setState(() {
        _listtahun = widget.dropitem;
      });
    } catch (_) {}
  }

  List<Widget> _buildItems() {
    List<Widget> ret = [];
    if (widget.items == null || widget.items!.isEmpty) {
      return [];
    }
    for (ConfirmationItemPBB item in widget.items!) {
      ret.add(Column(children: <Widget>[
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Expanded(flex: 1, child: Text(item.key!)),
            Expanded(
              flex: 1,
              child: Text(
                item.value!,
                textAlign: TextAlign.right,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Poppins',
                ),
              ),
            )
          ],
        ),
      ]));
      ret.add(const Divider(
        thickness: 1,
      ));
    }
    return ret;
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: <Widget>[
        const SizedBox(height: 16),
        // Center(child: Text('titel')),
        const SizedBox(height: 16),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
                border: Border.all(
                  color:
                      _buildItems().isNotEmpty ? Pallete.primary : Colors.white,
                  width: 0.5,
                ),
                borderRadius: BorderRadius.circular(10)),
            child: Column(children: <Widget>[
              Column(
                children: _buildItems(),
              ),
              Container(
                alignment: Alignment.center,
                // padding: EdgeInsets.only(left: 16, right: 16),
                color: Colors.white,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    const Text(
                      "Tahun",
                    ),
                    Container(
                      // padding: EdgeInsets.only(right: 8),
                      alignment: Alignment.topLeft,
                      child: DropdownButton<DropdownItemPBB>(
                        // iconEnabledColor: Pallete.primary,
                        // value: dropdownValue,
                        value: _listtahun == null || _listtahun!.isEmpty
                            ? null
                            : _selectedtahun,
                        hint: const Text("Pilih tahun", style: ISTStyle.hintStyle),
                        isExpanded: true,
                        // iconSize: 38,
                        icon: const Icon(
                          Icons.keyboard_arrow_down,
                          size: 38,
                        ),
                        // iconSize: 30,
                        // style: TextStyle(color: Colors.black),
                        underline: Container(
                          height: 1,
                          color: Colors.grey,
                        ),

                        onChanged: (DropdownItemPBB? valuePen) {
                          setState(() {
                            _selectedtahun = valuePen;
                          });
                        },

                        items: _listtahun!.map((DropdownItemPBB _listtahun) {
                          return DropdownMenuItem<DropdownItemPBB>(
                            value: _listtahun,
                            child: Row(
                              children: <Widget>[
                                Expanded(
                                  child: Text(
                                    _listtahun.tahun!,
                                    style: const TextStyle(fontSize: 12),
                                  ),
                                ),
                              ],
                            ),
                          );
                        }).toList(),
                        isDense: false,
                      ),
                    ),
                    _dropError
                        ? Container(
                            alignment: Alignment.centerLeft,
                            child: const Text(
                              'Mohon pilih tahun',
                              style: TextStyle(color: Colors.red),
                            ),
                          )
                        : const SizedBox.shrink(),
                  ],
                ),
              ),
            ]),
          ),
        ),
        const SizedBox(height: 16),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: ISTOutlineButton(
            onPressed: () {
              if (!_doValidate()) return;
              _doTransfer();
            },
            text: 'Lanjut',
          ),
        )
      ],
    );
  }
}

class DropdownItemPBB {
  final String? tahun;
  final String? tahunkey;
  final int? tahunindex;

  DropdownItemPBB({
    Key? key,
    this.tahun,
    this.tahunkey,
    this.tahunindex,
  });
}
