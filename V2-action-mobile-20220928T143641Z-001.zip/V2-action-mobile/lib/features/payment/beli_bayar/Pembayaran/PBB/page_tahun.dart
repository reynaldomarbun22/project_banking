import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PBB/confirm_item_pbb.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PBB/mpin_pbb.dart';

import 'package:flutter/material.dart';

class PageTahun extends StatefulWidget {
  static const routeName = '/PageTahun';

  final List<ConfirmationItemPBB>? list;
  final List<DropdownItemPBB>? listdrop;

  const PageTahun({Key? key, this.list, this.listdrop}) : super(key: key);

  @override
  _PageTahunState createState() => _PageTahunState();
}

class _PageTahunState extends State<PageTahun> {
  @override
  Widget build(BuildContext context) {
    _doTransfer() {
      Navigator.pushNamed(context, PBBMPIN.routeName);
    }

    return Scaffold(
        resizeToAvoidBottomInset: true,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          centerTitle: true,
          title: const Text("PBB",
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'Poppins',
              )),
          actions: const <Widget>[],
          elevation: 0.0,
          backgroundColor: Pallete.primary,
        ),
        backgroundColor: Colors.white,
        body: ConfirmationPBB(
            items: widget.list,
            dropitem: widget.listdrop,
            // title: 'Konfirmasi Layanan',
            onFinished: () {
              _doTransfer();
            }));
  }
}
