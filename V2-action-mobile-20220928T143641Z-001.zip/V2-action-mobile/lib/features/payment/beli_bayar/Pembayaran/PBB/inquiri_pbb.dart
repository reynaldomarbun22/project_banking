import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_card_account.dart';
import 'package:bpd_aceh/components/ist_style.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PBB/confirm_item_pbb.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PBB/page_tahun.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class InquiryPBB extends StatefulWidget {
  static const routeName = '/InquiryPBB';

  const InquiryPBB({Key? key}) : super(key: key);

  @override
  _InquiryPBBState createState() => _InquiryPBBState();
}

class _InquiryPBBState extends State<InquiryPBB> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final _eSetorController = TextEditingController();

  bool _dropError = false;
  // ignore: unused_field
  bool _autoValidate = false;

  @override
  void initState() {
    super.initState();
    _getStatusPenduduk();
  }

  bool _validateInputs() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      return true;
    } else {
      setState(() {
        _autoValidate = true;
      });
      return false;
    }
  }

  bool _doValidate() {
    if (_validateInputs() != true) return false;
    bool _success = true;
    if (_eSetorController.text.isEmpty) {
      setState(() {
        _dropError = true;
      });
      _success = false;
    } else {
      setState(() {
        _dropError = false;
      });
    }
    return _success;
  }

  _doTransfer() async {
    if (_doValidate()) {
      Map<String, Object?> param = {};

      param['nop'] = _eSetorController.text;
      param['kotaIdx'] = _selectedKota?.statusIndex ?? '';

      final resp = await API.post(context, '/pbb/tahun/Inquiry', param);
      if (resp != null && resp['code'] == 0) {
        List<ConfirmationItemPBB> listParam = [];
        List<dynamic> listMap = resp['resi'];
        for (var item in listMap) {
          ConfirmationItemPBB itemParam =
              ConfirmationItemPBB(key: item['key'], value: item['value']);
          listParam.add(itemParam);
        }
        var listResp = resp['listTahun'];
        List<dynamic> listRespMini = (listResp);
        List<DropdownItemPBB> listKewarganegaraan = [];
        //for (var item in listRespMini) {
        for (var i = 0; i < listRespMini.length; i++) {
          DropdownItemPBB items = DropdownItemPBB(
            tahunindex: i,
            tahun: listRespMini[i]['stringTahun'],
            // tahunkey: listRespMini[i]['key'],
          );

          listKewarganegaraan.add(items);
          print(listKewarganegaraan);
        }

        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => PageTahun(
                      listdrop: listKewarganegaraan,
                      list: listParam,
                    )));
      } else {
        const DialogBox().showImageDialog(
            message: resp['message'],
            isError: true,
            image: const Image(
              image: AssetImage('assets/images/icon-failed.png'),
            ),
            buttonCancel: 'OK',
            onOk: () {},
            context: context);
      }
    }
  }

  List<WilayahKota> _listKota = [];
  WilayahKota? _selectedKota;
  _getStatusPenduduk() async {
    try {
      setState(() {
        _selectedKota = null;
      });
      if (_listKota.isNotEmpty) {
        Future.delayed(Duration.zero);
        _listKota.clear();
      }
      Map<String, Object> param = {};

      final resp = await API.postNoLoading(context, '/pbb/list', param);
      if (resp['code'] == 0) {
        var listResp = resp['listKota'];
        List<dynamic> listRespMini = (listResp);
        List<WilayahKota> listkota = [];
        for (var i = 0; i < listRespMini.length; i++) {
          WilayahKota items = WilayahKota(
            statusIndex: i,
            status: listRespMini[i]['kota'].toString(),
            statusTitle: listRespMini[i]['path'],
          );

          listkota.add(items);
        }

        setState(() {
          _listKota = listkota;
        });
      }
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text("PBB",
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'Poppins',
            )),
        actions: const <Widget>[],
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      backgroundColor: Colors.white,
      body: Container(
        // padding: EdgeInsets.only(bottom: 20),
        color: Colors.white,
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              ISTCardAccount(
                context: context,
                menu: ISTMenu.billpay,
              ),
              Container(
                padding: const EdgeInsets.only(left: 16, right: 16),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      const SizedBox(
                        height: 16,
                      ),
                      Form(
                        // ignore: deprecated_member_use
                        autovalidateMode: AutovalidateMode.always,
                        key: _formKey,
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: <Widget>[
                              Container(
                                alignment: Alignment.center,
                                // padding: EdgeInsets.only(left: 16, right: 16),
                                color: Colors.white,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    const Text(
                                      "Kota / Kabupaten",
                                    ),
                                    Container(
                                      // padding: EdgeInsets.only(right: 8),
                                      alignment: Alignment.topLeft,
                                      child: DropdownButton<WilayahKota>(
                                        // iconEnabledColor: Pallete.primary,
                                        // value: dropdownValue,
                                        value: _listKota.isEmpty
                                            ? null
                                            : _selectedKota,
                                        hint: const Text(
                                            "Pilih kota / kabupaten",
                                            style: ISTStyle.hintStyle),
                                        isExpanded: true,
                                        // iconSize: 38,
                                        icon: const Icon(
                                          Icons.keyboard_arrow_down,
                                          size: 38,
                                        ),
                                        // iconSize: 30,
                                        // style: TextStyle(color: Colors.black),
                                        underline: Container(
                                          height: 1,
                                          color: Colors.grey,
                                        ),

                                        onChanged: (WilayahKota? valuePen) {
                                          setState(() {
                                            _selectedKota = valuePen;
                                          });
                                        },

                                        items: _listKota
                                            .map((WilayahKota _listKota) {
                                          return DropdownMenuItem<WilayahKota>(
                                            value: _listKota,
                                            child: Row(
                                              children: <Widget>[
                                                Text(_listKota.status!),
                                              ],
                                            ),
                                          );
                                        }).toList(),
                                        isDense: false,
                                      ),
                                    ),
                                    _dropError
                                        ? Container(
                                            alignment: Alignment.centerLeft,
                                            child: const Text(
                                              'Mohon pilih Kota / Kabupaten',
                                              style:
                                                  TextStyle(color: Colors.red),
                                            ),
                                          )
                                        : const SizedBox.shrink(),
                                  ],
                                ),
                              ),
                              const SizedBox(
                                height: 8,
                              ),
                              Container(
                                alignment: Alignment.topLeft,
                                child: const Text(
                                  'Nomor Objek Pajak (NOP)',
                                  style: TextStyle(color: Colors.black87),
                                ),
                              ),
                              Container(
                                alignment: Alignment.topLeft,
                                child: TextFormField(
                                  validator: (val) {
                                    if (val!.isEmpty || val == '0') {
                                      _dropError = true;
                                    } else {
                                      _dropError = false;
                                    }
                                  },
                                  inputFormatters: [
                                    // ignore: deprecated_member_use
                                    FilteringTextInputFormatter.digitsOnly,
                                  ],
                                  controller: _eSetorController,
                                  maxLength: 20,
                                  keyboardType: TextInputType.number,
                                  decoration: const InputDecoration(
                                    counterText: '',
                                    hintText: 'Masukkan Kode Pembayaran',
                                    hintStyle: ISTStyle.hintStyle,
                                  ),
                                ),
                              ),
                            ]),
                      ),
                      const SizedBox(
                        height: 32,
                      ),
                      ISTOutlineButton(
                        onPressed: () {
                          _doTransfer();
                        },
                        text: 'Lanjut',
                      ),
                      const SizedBox(
                        height: 16,
                      )
                    ]),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class WilayahKota {
  final String? status;
  final String? statusTitle;
  final int? statusIndex;

  WilayahKota({
    Key? key,
    this.status,
    this.statusTitle,
    this.statusIndex,
  });
}
