import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/tvberlangganan/transvision/transvisionmpin.dart';
import 'package:flutter/material.dart';

class TransvisionConfirmation extends StatefulWidget {
  static const routeName = '/TransvisionConfirmation';

  final List<ISTConfirmationItem>? list;

  const TransvisionConfirmation({Key? key, this.list}) : super(key: key);

  @override
  _TransvisionConfirmationState createState() =>
      _TransvisionConfirmationState();
}

class _TransvisionConfirmationState extends State<TransvisionConfirmation> {
  @override
  Widget build(BuildContext context) {
    _doTransfer() {
      Navigator.pushNamed(context, TransvisionMPIN.routeName);
    }

    return Scaffold(
        resizeToAvoidBottomInset: true,
        appBar: AppBar(
          leading: IconButton(
            // icon: Icon(Icons.chevron_left, color: Colors.white),
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white),

            onPressed: () {
              Navigator.pop(context);
            },
          ),
          centerTitle: true,
          title: const Text("Transvision",
              style: TextStyle(color: Colors.white, fontFamily: 'Poppins')),
          actions: const <Widget>[],
          elevation: 0.0,
          backgroundColor: Pallete.primary,
        ),
        backgroundColor: Colors.white,
        body: ISTConfirmation(
            items: widget.list,
            title: 'Konfirmasi Layanan',
            onFinished: () {
              _doTransfer();
            }));
  }
}
