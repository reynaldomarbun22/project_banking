import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_card_account.dart';
import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/ist_style.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/utils/string_utils.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/tvberlangganan/transvision/confirmationtransvision.dart';

import 'package:flutter/material.dart';

class Transvision extends StatefulWidget {
  static const routeName = '/Transvision';
  final String? noJastel;

  const Transvision({Key? key, this.noJastel}) : super(key: key);
  @override
  // ignore: no_logic_in_create_state
  _TransvisionState createState() => _TransvisionState(noJastel);
}

class _TransvisionState extends State<Transvision> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final TextEditingController _transController = TextEditingController();
  final String? noJastel;
  _TransvisionState(this.noJastel);
  // ignore: unused_field
  final bool _transError = false;
  bool favoritTransvision = false;
  // ignore: unused_field
  bool _autoValidate = false;
  @override
  void initState() {
    if (noJastel != null) {
      _transController.text = noJastel!;
      favoritTransvision = true;
    }
    super.initState();
  }

  bool _doValidate() {
    if (_formKey.currentState!.validate()) {
      return true;
    } else {
      setState(() {
        _autoValidate = true;
      });
      return false;
    }
  }

  _doTransfer() async {
    if (_doValidate()) {
      Map<String, Object> param = {};

      param['noJastel'] = _transController.text;
      // int.parse(_transController.text.replaceAll(",", ""));

      final resp =
          await API.post(context, '/payment/tv/transvision/inquiry', param);
      if (resp != null && resp['code'] == 0) {
        List<ISTConfirmationItem> listParam = [];
        List<dynamic> listMap = resp['resi'];
        for (var item in listMap) {
          ISTConfirmationItem itemParam =
              ISTConfirmationItem(key: item['key'], value: item['value']);
          listParam.add(itemParam);
        }
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => TransvisionConfirmation(
                      list: listParam,
                    )));
      } else {
        const DialogBox().showImageDialog(
            message: resp['message'],
            isError: true,
            image: const Image(
              image: AssetImage('assets/images/icon-failed.png'),
            ),
            buttonCancel: 'OK',
            onOk: () {},
            context: context);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text("Transvision",
            style: TextStyle(color: Colors.white, fontFamily: 'Poppins')),
        actions: const <Widget>[],
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      backgroundColor: Colors.white,
      body: Container(
        color: Colors.white,
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              ISTCardAccount(
                context: context,
                menu: ISTMenu.billpay,
              ),
              const SizedBox(
                height: 16,
              ),
              Container(
                padding: const EdgeInsets.only(left: 16, right: 16),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Form(
                        // ignore: deprecated_member_use
                        autovalidateMode: AutovalidateMode.always,
                        key: _formKey,
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: <Widget>[
                              Container(
                                // padding: EdgeInsets.only(left: 8, right: 8),
                                alignment: Alignment.topLeft,
                                child: const Text(
                                  'ID Pelanggan :',
                                  style: TextStyle(color: Colors.black87),
                                ),
                              ),
                              favoritTransvision
                                  ? Column(
                                      children: [
                                        Container(
                                          alignment: Alignment.topLeft,
                                          child: Text('$noJastel'),
                                        ),
                                        const Divider(
                                          thickness: 1.5,
                                        )
                                      ],
                                    )
                                  : Container(
                                      // padding: EdgeInsets.only(left: 8, right: 8),
                                      alignment: Alignment.topLeft,
                                      child: TextFormField(
                                        keyboardType: TextInputType.number,
                                        validator: (val) {
                                          if (val!.isEmpty || val == '0') {
                                            return "Mohon diisi";
                                          } else {
                                            return null;
                                          }
                                        },
                                        inputFormatters: [
                                          StringUtils.alphaNumeric(),
                                          StringUtils.noSpace()
                                        ],
                                        controller: _transController,
                                        maxLength: 15,
                                        decoration: const InputDecoration(
                                          counterText: '',
                                          hintText: 'Masukkan ID Pelanggan',
                                          hintStyle: ISTStyle.hintStyle,
                                        ),
                                      ),
                                    ),
                            ]),
                      ),
                    ]),
              ),
              const SizedBox(
                height: 50,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: ISTOutlineButton(
                  onPressed: () {
                    _doTransfer();
                  },
                  text: 'Lanjut',
                ),
              ),
              const SizedBox(
                height: 16,
              )
            ],
          ),
        ),
      ),
    );
  }
}
