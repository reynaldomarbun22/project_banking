import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/Telkom/IndiHome/indihome_page.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/tvberlangganan/mnc%20vision/inquiry_mnc.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/tvberlangganan/transvision/transvision.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:bpd_aceh/core/controller/controller_menu.dart';

class TVBerlanggananPage extends StatefulWidget {
  static const routeName = '/TVBerlanggananPage';

  const TVBerlanggananPage({Key? key}) : super(key: key);
  @override
  _TVBerlanggananPageState createState() => _TVBerlanggananPageState();
}

class _TVBerlanggananPageState extends State<TVBerlanggananPage> {
  final controllerMenu = Get.put(MenuController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: true,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          centerTitle: true,
          title: const Text("TV Berlangganan",
              style: TextStyle(color: Colors.white, fontFamily: 'Poppins')),
          elevation: 0.0,
          backgroundColor: Pallete.primary,
        ),
        backgroundColor: Colors.white,
        body: Container(
          padding: const EdgeInsets.only(left: 8, right: 8),
          child: ListView(
            children: <Widget>[
              Visibility(
                visible: controllerMenu.getVisibilityMnc(),
                child: ListTile(
                  title: const Text('MNC Vision'),
                  trailing: const Icon(Icons.arrow_forward_ios),
                  onTap: () {
                    Navigator.pushNamed(context, InquiryMNCVision.routeName);
                  },
                ),
              ),
              Visibility(
                visible: controllerMenu.getVisibilityMnc(),
                child: const Divider(
                  thickness: 1,
                  color: Colors.grey,
                ),
              ),
              Visibility(
                visible: controllerMenu.getVisibilityTransvision(),
                child: ListTile(
                    title: const Text('Transvision'),
                    trailing: const Icon(Icons.arrow_forward_ios),
                    onTap: () {
                      Navigator.pushNamed(context, Transvision.routeName);
                    }),
              ),
              Visibility(
                visible: controllerMenu.getVisibilityTransvision(),
                child: const Divider(
                  thickness: 1,
                  color: Colors.grey,
                ),
              ),
              Visibility(
                visible: controllerMenu.getVisibilityIndihome(),
                child: ListTile(
                  title: const Text('IndiHome'),
                  trailing: const Icon(Icons.arrow_forward_ios),
                  onTap: () {
                    Navigator.pushNamed(context, IndiHome.routeName);
                  },
                ),
              ),
              Visibility(
                visible: controllerMenu.getVisibilityIndihome(),
                child: const Divider(
                  thickness: 1,
                  color: Colors.grey,
                ),
              ),
            ],
          ),
        ));
  }
}

// import 'package:bpd_aceh/components/ISTCardAccount.dart';

// import 'package:bpd_aceh/components/ISTMenuContainer.dart';

// import 'package:bpd_aceh/components/Pallete.dart';
// import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/tvberlangganan/transvision/transvision.dart';

// import 'package:flutter/material.dart';

// class TvBerlangganan extends StatefulWidget {
//   static const routeName = '/TvBerlangganan';

//   @override
//   _TvBerlanggananState createState() => _TvBerlanggananState();
// }

// class _TvBerlanggananState extends State<TvBerlangganan> {
//   final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       resizeToAvoidBottomInset: true,
//       appBar: AppBar(
//         leading: IconButton(
//           icon: Icon(Icons.arrow_back_ios, color: Colors.white),
//           onPressed: () {
//             Navigator.pop(context);
//           },
//         ),
//         centerTitle: true,
//         title: Text("Pemda / Pemkot", style: TextStyle(color: Colors.white)),
//         actions: <Widget>[
//           IconButton(
//             icon: Icon(
//               Icons.notifications,
//               color: Colors.white,
//             ),
//             onPressed: () {},
//           )
//         ],
//         elevation: 0.0,
//         backgroundColor: Pallete.primary,
//       ),
//       backgroundColor: Colors.white,
//       body: Container(
//         color: Colors.white,
//         child: SingleChildScrollView(
//           child: Column(
//             children: <Widget>[
//               ISTCardAccount(
//                 context: context,
//                 menu: ISTMenu.transfer,
//               ),
//               SizedBox(
//                 height: 16,
//               ),
//               ISTMenuContainer(
//                   onTap: () {
//                     Navigator.pushNamed(context, Transvision.routeName);
//                   },
//                   image: Image.asset(
//                     'assets/images/icon-transvision.png',
//                     width: 50,
//                   ),
//                   text: 'Transvision'),
//               ISTMenuContainer(
//                   onTap: () {},
//                   image: Image.asset(
//                     'assets/images/icon-favorite.png',
//                     width: 50,
//                   ),
//                   text: 'favorite'),
//               SizedBox(
//                 height: 16,
//               )
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
