import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_card_account.dart';
import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/ist_style.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/Telkom/Telepon_Rumah/confirmation_page_telepon_rumah.dart';

import 'package:flutter/material.dart';

class TeleponRumah extends StatefulWidget {
  static const routeName = '/teleponRumah';
  final String? noInvoice;

  const TeleponRumah({
    Key? key,
    this.noInvoice,
  }) : super(key: key);

  @override
  _TeleponRumahState createState() => _TeleponRumahState();
}

class _TeleponRumahState extends State<TeleponRumah> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final _kodeArea = TextEditingController();
  final _nomortelepon = TextEditingController();

  // final String noInvoice;

  // _TeleponRumahState(this.noInvoice);

  @override
  void initState() {
    if (widget.noInvoice != null) {
      var invoice = widget.noInvoice!.split(' ');
      print(invoice);
      _kodeArea.text = invoice[0];
      _nomortelepon.text = invoice[1];

      favoritTeleponRumah = true;
    }
    super.initState();
  }

  // ignore: unused_field
  bool _autoValidate = false;
  bool favoritTeleponRumah = false;

  bool _doValidate() {
    if (_formKey.currentState!.validate()) {
      return true;
    } else {
      setState(() {
        _autoValidate = true;
      });
      return false;
    }
  }

  _doInquiry() async {
    if (_doValidate()) {
      Map<String, Object> param = {};

      param['noJastel'] = _nomortelepon.text;
      param['kdArea'] = _kodeArea.text;

      final resp =
          await API.post(context, '/payment/telkom/pstn/inquiry', param);
      if (resp['code'] != null && resp['code'] == 0) {
        List<ISTConfirmationItem> listParam = [];
        List<dynamic> listMap = resp['resi'];
        for (var item in listMap) {
          ISTConfirmationItem itemParam =
              ISTConfirmationItem(key: item['key'], value: item['value']);
          listParam.add(itemParam);
        }
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => ConfirmationPageTeleponRumah(
                      list: listParam,
                    )));
      } else {
        const DialogBox().showImageDialog(
            message: resp['message'],
            isError: true,
            image: const Image(
              image: AssetImage('assets/images/icon-failed.png'),
            ),
            buttonCancel: 'OK',
            onOk: () {},
            context: context);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    // ignore: unused_local_variable
    final halfMediaWidth = MediaQuery.of(context).size.width / 3;
    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text("Telepon Rumah (PSTN)",
            style: TextStyle(color: Colors.white, fontFamily: 'Poppins')),
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      backgroundColor: Colors.white,
      body: Container(
        // padding: EdgeInsets.only(bottom: 20),
        color: Colors.white,
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              ISTCardAccount(context: context, menu: ISTMenu.billpay),
              const SizedBox(
                height: 16,
              ),
              Container(
                padding: const EdgeInsets.only(left: 16, right: 16),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Form(
                        // ignore: deprecated_member_use
                        autovalidateMode: AutovalidateMode.always,
                        key: _formKey,
                        child: Column(
                            // mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: <Widget>[
                              Container(
                                padding: const EdgeInsets.only(top: 8),
                                alignment: Alignment.topLeft,
                                child: const Text(
                                  'Kode Area & No. Telepon :',
                                  style: TextStyle(color: Colors.black87),
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.only(top: 8),
                                alignment: Alignment.topCenter,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: <Widget>[
                                    Container(
                                      alignment: Alignment.topCenter,
                                      width:
                                          (((MediaQuery.of(context).size.width /
                                                      28) -
                                                  5) *
                                              8),
                                      child: TextFormField(
                                        maxLength: 4,
                                        decoration: const InputDecoration(
                                          counterText: '',
                                          // errorText:_noRekBLError ? "Mohon diisi" : null,
                                          hintText: 'Kode Area',
                                          hintStyle: ISTStyle.hintStyle,
                                        ),
                                        // hintText: 'First Name',
                                        validator: (val) {
                                          if (val!.isEmpty || val == '0') {
                                            return "Mohon diisi";
                                          } else {
                                            return null;
                                          }
                                        },
                                        controller: _kodeArea,
                                        keyboardType: TextInputType.number,
                                      ),
                                    ),
                                    Container(
                                      alignment: Alignment.center,
                                      // color: Colors.yellow,
                                      width:
                                          (((MediaQuery.of(context).size.width /
                                                      45) -
                                                  5) *
                                              8),
                                      // width: halfMediaWidth,
                                      // color: Colors.blue,
                                      child: const Text(''),
                                    ),
                                    Container(
                                      // color: Colors.red,
                                      // padding:
                                      //     EdgeInsets.only(left: 8, right: 120),
                                      alignment: Alignment.center,
                                      // width: halfMediaWidth,
                                      width:
                                          (((MediaQuery.of(context).size.width /
                                                      11) -
                                                  5) *
                                              8),
                                      child: TextFormField(
                                        controller: _nomortelepon,
                                        keyboardType: TextInputType.number,
                                        maxLength: 9,
                                        decoration: const InputDecoration(
                                          counterText: '',
                                          hintText: 'No. Telepon',
                                          hintStyle: ISTStyle.hintStyle,
                                        ),
                                        // hintText: 'Last Name',
                                        validator: (val) {
                                          if (val!.isEmpty || val == '0') {
                                            return "Mohon diisi";
                                          } else {
                                            return null;
                                          }
                                        },
                                      ),
                                    )
                                  ],
                                ),
                              ),

                              // Container(
                              //   // padding: EdgeInsets.only(left: 8, right: 8),
                              //   alignment: Alignment.topLeft,
                              //   child: Text(
                              //     'ID Pelanggan :',
                              //     style: TextStyle(color: Colors.black87),
                              //   ),
                              // ),
                              // favoritTeleponRumah
                              //     ? Column(children: [
                              //         Container(
                              //             alignment: Alignment.topLeft,
                              //             child: Text('$noInvoice')),
                              //         Divider(
                              //           thickness: 1.5,
                              //         )
                              //       ])
                              //     : Container(
                              //         alignment: Alignment.topLeft,
                              //         child: TextFormField(
                              //           validator: (val) {
                              //             if (val.isEmpty || val == '0') {
                              //               return "Mohon diisi";
                              //             } else {
                              //               return null;
                              //             }
                              //           },
                              //           inputFormatters: [
                              //             // ignore: deprecated_member_use
                              //             WhitelistingTextInputFormatter
                              //                 // ignore: deprecated_member_use
                              //                 .digitsOnly
                              //           ],
                              //           controller: _idpelanggan,
                              //           keyboardType: TextInputType.number,
                              //           decoration: InputDecoration(
                              //             hintText: 'Masukkan ID Pelanggan',
                              //             hintStyle: ISTStyle.HINT_STYLE,
                              //           ),
                              //         ),
                              //       ),
                              const SizedBox(
                                height: 8,
                              ),
                            ]),
                      ),
                    ]),
              ),
              const SizedBox(
                height: 50,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: ISTOutlineButton(
                  onPressed: () {
                    _doInquiry();
                  },
                  text: 'Lanjut',
                ),
              ),
              const SizedBox(
                height: 16,
              )
            ],
          ),
        ),
      ),
    );
  }
}
