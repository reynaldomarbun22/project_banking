import 'package:bpd_aceh/components/ist_receipt.dart';
import 'package:bpd_aceh/components/ist_receipt_repo.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/features/home/home_page.dart';
import 'package:bpd_aceh/features/splash/splash.dart';
import 'package:flutter/material.dart';

class TeleponRumahReceiptPage extends StatelessWidget {
  static const routeName = '/teleponRumahReceiptPage';
  final List<ISTReceiptItem>? list;
  final List<ISTReceiptItemInbox>? lists;
  final String? amount;
  final ISTReceiptStatus? status;
  final String? noRef;
  final String? img;
  final String? title;
  final String? detail;
  final String? time;
  final String? date;
  final String? waktu;
  final String? subtitle;
  final String? destAcc;

  const TeleponRumahReceiptPage({
    Key? key,
    this.destAcc,
    this.subtitle,
    this.lists,
    this.waktu,
    this.list,
    this.date,
    this.time,
    this.detail,
    this.amount,
    this.status,
    this.noRef,
    this.img,
    this.title,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    _doFinish() {
      Navigator.pushNamedAndRemoveUntil(
          context, HomePage.routeName, ModalRoute.withName(Splash.routeName));
    }

    _doAddFav() async {
      Map<String, Object?> param = {};
      param['idresi'] = noRef;
      final resp = await API.post(context, '/favorite/add', param);
      if (resp != null && resp['code'] == 0) {
        showDialog(
          context: context,
          barrierDismissible: false,
          useRootNavigator: true,
          builder: (BuildContext context) {
            return AlertDialog(
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(20.0)),
              ),
              content: SingleChildScrollView(
                child: Column(
                  children: <Widget>[
                    const Text(
                      'Berhasil',
                      style: TextStyle(color: Pallete.primary, fontSize: 20),
                    ),
                    const SizedBox(
                      height: 4,
                    ),
                    Image(
                      height: MediaQuery.of(context).size.width * 0.25,
                      image: const AssetImage('assets/images/icon-success.png'),
                    ),
                    const SizedBox(
                      height: 4,
                    ),
                    const Text('Favorit berhasil di tambahkan',
                        textAlign: TextAlign.center),
                    const SizedBox(
                      height: 8,
                    ),
                    Container(
                      alignment: Alignment.center,
                      child: OutlinedButton(
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(
                            color: Pallete.primary,
                          ),
                          primary: Pallete.primary,
                          shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.all(Radius.circular(18)),
                          ),
                        ),
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: Text(
                          "Ok",
                          style: Theme.of(context)
                              .textTheme
                              .bodyText1!
                              .copyWith(
                                  fontWeight: FontWeight.w600,
                                  color: Pallete.primary),
                        ),
                      ),
                    )
                  ],
                ),
              ),
              //actions: _checkbutton(context),
            );
          },
        );
      } else {
        showDialog(
          context: context,
          barrierDismissible: false,
          useRootNavigator: true,
          builder: (BuildContext context) {
            return AlertDialog(
              // contentPadding: EdgeInsets.all(8),
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(20.0)),
              ),
              content: SingleChildScrollView(
                child: Column(
                  children: <Widget>[
                    const Text(
                      'Peringatan',
                      style: TextStyle(
                        color: Colors.red,
                        fontSize: 20,
                      ),
                    ),
                    const SizedBox(
                      height: 4,
                    ),
                    Image(
                      height: MediaQuery.of(context).size.width * 0.25,
                      image: const AssetImage('assets/images/icon-warning.png'),
                    ),
                    const SizedBox(
                      height: 4,
                    ),
                    Text(resp['message'], textAlign: TextAlign.center),
                    const SizedBox(
                      height: 8,
                    ),
                    Container(
                      alignment: Alignment.center,
                      child: OutlinedButton(
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(
                            color: Colors.red,
                          ),
                          // splashColor: Colors.red,
                          shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.all(Radius.circular(18)),
                          ),
                        ),
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: Text(
                          "Batal",
                          style: Theme.of(context)
                              .textTheme
                              .bodyText1!
                              .copyWith(
                                  fontWeight: FontWeight.w600,
                                  color: Colors.red),
                        ),
                      ),
                    )
                  ],
                ),
              ),
              //actions: _checkbutton(context),
            );
          },
        );
      }
    }

    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
          backgroundColor: Colors.white,
          body: ISTReceipt(
              onTap: () {
                Navigator.pop(context);
                _doAddFav();
              },
              items: list,
              onFinished: () {
                _doFinish();
              },
              noRef: noRef,
              title: title,
              amount: amount,
              status: status)),
    );
  }
}
