import 'package:bpd_aceh/components/ist_card_account.dart';
import 'package:bpd_aceh/components/ist_menu_container.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/Universitas/universitas_screen.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/favorite/favoritepayment.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/infaq/infaq_screen.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/pemda/e_setor.dart';

import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/samsat/samsat.dart';

import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/zakat/zakat_screen.dart';

import 'package:flutter/material.dart';

class PembayaranPage extends StatefulWidget {
  static const routeName = '/pembayaranScreen';

  const PembayaranPage({Key? key}) : super(key: key);
  @override
  _PembayaranPageState createState() => _PembayaranPageState();
}

class _PembayaranPageState extends State<PembayaranPage> {
  bool press = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text("Pembayaran", style: TextStyle(color: Colors.white)),
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      backgroundColor: Colors.white,
      body: Column(
        children: <Widget>[
          const ISTCardAccount(context: null, menu: ISTMenu.billpay),
          const SizedBox(height: 8),
          buildMenuPembayaran(context)
        ],
      ),
    );
  }
}

buildMenuPembayaran(context) {
  return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      child: Wrap(
        crossAxisAlignment: WrapCrossAlignment.center,
        children: <Widget>[
          ISTMenuContainer(
            onTap: () {
              Navigator.pushNamed(context, FavoritePaymentPage.routeName);
            },
            image: Image.asset(
              'assets/images/icon-favorite.png',
              width: 50,
            ),
            // color: Colors.grey,
            text: 'Favorit',
          ),

          ISTMenuContainer(
            onTap: () {
              Navigator.pushNamed(context, ZakatScreen.routeName);
            },
            image: Image.asset(
              'assets/images/icon-zakat.png',
              width: 50,
            ),
            text: 'Zakat',
          ),
          ISTMenuContainer(
            onTap: () {
              Navigator.pushNamed(context, InfaqScreen.routeName);
            },
            image: Image.asset(
              'assets/images/icon-infak.png',
              width: 50,
            ),
            text: 'Infak',
          ),
          ISTMenuContainer.none(
            onTap: () {
              Navigator.pushNamed(context, EsetorPemda.routeName);
            },
            image: Image.asset(
              'assets/images/Icon-pemkot.png',
              width: 50,
            ),
            // color: Colors.grey,
            text: 'Pemkot \nBanda Aceh',
          ),

          ISTMenuContainer(
            onTap: () {
              Navigator.pushNamed(context, UniversitasScreen.routeName);
            },
            image: Image.asset(
              'assets/images/icon-universitas.png',
              width: 50,
            ),
            // color: Colors.grey,
            text: 'Universitas\n',
          ),
          // ISTMenuContainer(
          //   onTap: () {
          //     Navigator.pushNamed(context, TelkomScreen.routeName);
          //   },
          //   image: Image.asset(
          //     'assets/images/icon-telkom.png',
          //     width: 50,
          //   ),
          //   // color: Colors.grey,
          //   text: 'Telkom',
          // ),
          ISTMenuContainer.none(
            onTap: () {
              Navigator.pushNamed(context, Samsat.routeName);
            },
            image: Image.asset(
              'assets/images/samsat.png',
              width: 50,
            ),
            // color: Colors.grey,
            text: 'Samsat Aceh\n',
          ),

          // ISTMenuContainer(
          //   onTap: () {
          //     // Navigator.pushNamed(context, Transvision.routeName);
          //   },
          //   image: Image.asset(
          //     'assets/images/Mpn-icon.png',
          //     width: 50,
          //   ),
          //   // color: Colors.grey,
          //   text: 'MPN G2',
          // ),
          // ISTMenuContainer(
          //   onTap: () {
          //     Navigator.pushNamed(context, Transvision.routeName);
          //   },
          //   image: Image.asset(
          //     'assets/images/icon-tv.png',
          //     width: 50,
          //   ),
          //   // color: Colors.grey,
          //   text: 'TV Berlangganan',
          // ),
          // ISTMenuContainer(
          //   onTap: () {
          //     Navigator.pushNamed(context, PascaBayarPage.routeName);
          //   },
          //   image: Image.asset(
          //     'assets/images/icon-pascabayar.png',
          //     width: 50,
          //   ),
          //   // color: Colors.grey,
          //   text: 'Pascabayar',
          // ),
          // ISTMenuContainer(
          //   onTap: () {
          //     // Navigator.pushNamed(context, Transvision.routeName);
          //   },
          //   image: Image.asset(
          //     'assets/images/ListrikPln-icon.png',
          //     width: 50,
          //   ),
          //   // color: Colors.grey,
          //   text: 'Listrik',
          // ),
          // ISTMenuContainer.none(
          //   onTap: () {
          //     // Navigator.pushNamed(context, Transvision.routeName);
          //   },
          //   image: Image.asset(
          //     'assets/images/Bpjs-icon.png',
          //     width: 50,
          //   ),
          //   // color: Colors.grey,
          //   text: 'BPJS Kesehatan',
          // ),
          // ISTMenuContainer(
          //   onTap: () {
          //     Navigator.pushNamed(context, InquiryPaketData.routeName);
          //   },
          //   image: Image.asset(
          //     'assets/images/transportasi.png',
          //     width: 50,
          //   ),
          //   // color: Colors.grey,
          //   text: 'Transportasi',
          // ),
        ],
      ));
}
