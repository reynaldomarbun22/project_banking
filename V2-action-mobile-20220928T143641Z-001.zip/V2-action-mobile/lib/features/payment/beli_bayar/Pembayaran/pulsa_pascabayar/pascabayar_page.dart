// ignore_for_file: unnecessary_new

import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_card_account.dart';
import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/ist_style.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/pulsa_pascabayar/pascabayar_confirm.dart';
// import 'package:contact_picker/contact_picker.dart';
import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
import 'package:fluttercontactpicker/fluttercontactpicker.dart';
// import 'package:permission_handler/permission_handler.dart';

class PascaBayarPage extends StatefulWidget {
  static const routeName = '/pascabayarpage';
  final String? noInvoice;

  const PascaBayarPage({Key? key, this.noInvoice}) : super(key: key);

  @override
  // ignore: no_logic_in_create_state
  _PascaBayarPageState createState() => _PascaBayarPageState(noInvoice);
}

class _PascaBayarPageState extends State<PascaBayarPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final String? noInvoice;
  String? redaksiname = "";
   bool _numError = false;

  _PascaBayarPageState(this.noInvoice);
  @override
  void initState() {
    if (noInvoice != null) {
      _hpController.text = noInvoice!;
      favoritPascabayar = true;
    }
    super.initState();
    _getRedaksi();
  }

  // final bool _autoValidate = false;
  bool _success = true;
  bool favoritPascabayar = false;
   final TextEditingController _hpController = TextEditingController();
  // final _hpController = new TextEditingController();
   

  // bool _doValidate() {
  //   if (_formKey.currentState!.validate()) {
  //     return true;
  //   } else {
  //     setState(() {
  //       _autoValidate = true;
  //     });
  //     return false;
  //   }
  // }
  _doValidate() {
    // ignore: unnecessary_null_comparison
    if (_hpController.text == null ||
        _hpController.text == '' ||
        _hpController.text.isEmpty) {
      setState(() {
        _numError = true;
      });
      _success = false;
    }

    else {
      _numError = false;
     
      _success = true;
    }
    return _success;
  }

  // final ContactPicker _contactPicker = new ContactPicker();

  String? result;

  

  

  _doTransfer() async {

      Map<String, Object> param = {};
      // param['idPel'] = int.parse(_hpController.text.replaceAll(",", ""));
      param['idPel'] = _hpController.text
        .replaceAll("^62", "0")
          .replaceAll("^0+", "0")
          .replaceAll("^62", "0");

      final resp = await API.post(context, '/payment/telco/inquiry', param);
      if (resp['code'] == 0 && resp['code'] != null) {
        List<ISTConfirmationItem> listParam = [];
        List<dynamic> listMap = resp['resi'];
        for (var item in listMap) {
          ISTConfirmationItem itemParam =
              ISTConfirmationItem(key: item['key'], value: item['value']);
          listParam.add(itemParam);
        }
        Navigator.push(
            context,
            new MaterialPageRoute(
                builder: (context) => new PascaBayarConfirmation(
                      list: listParam,
                    )));
      } else {
        const DialogBox().showImageDialog(
            message: resp['message'],
            isError: true,
            image: const Image(
              image: AssetImage('assets/images/icon-failed.png'),
            ),
            buttonCancel: 'OK',
            onOk: () {},
            context: context);
      }
    
  }

  _getRedaksi() async {
    final resp =
        await API.postNoLoading(context, '/redaksi/pulsa-pascabayar', {});
    if (resp['code'] == 0) {
      setState(() {
        redaksiname = resp['redaksi'];
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text("Pascabayar",
            style: TextStyle(color: Colors.white, fontFamily: 'Poppins')),
        actions: const <Widget>[],
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      backgroundColor: Colors.white,
      body: Container(
        color: Colors.white,
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              ISTCardAccount(
                context: context,
                menu: ISTMenu.billpay,
              ),
              const SizedBox(
                height: 16,
              ),
              Container(
                padding: const EdgeInsets.only(left: 16, right: 16),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Form(
                        // ignore: deprecated_member_use
                        autovalidateMode: AutovalidateMode.always,
                        key: _formKey,
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: <Widget>[
                              Container(
                                alignment: Alignment.topLeft,
                                child: const Text(
                                  'No. Handphone :',
                                  style: TextStyle(color: Colors.black87),
                                ),
                              ),
                              favoritPascabayar
                                  ? Column(children: [
                                      Container(
                                          alignment: Alignment.topLeft,
                                          child: Text('$noInvoice')),
                                      const Divider(
                                        thickness: 1.5,
                                      )
                                    ])
                                  : TextFormField(
                                   
                                    maxLength: ISTConstants.handphoneMaxLength,
                                    controller: _hpController,
                                    decoration: InputDecoration(
                                        errorText: _numError ? "Mohon diisi" : null,
                                        hintText: "Masukan Nomor Handphone",
                                        hintStyle: ISTStyle.hintStyle,
                                        suffixIcon: Container(
                                          width: 75,
                                          alignment: Alignment.bottomRight,
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.end,
                                            children: [
                                              IconButton(
                                                  icon: Image.asset(
                                                    'assets/images/icon-phonebook.png',
                                                    width: 30,
                                                  ),
                                                  onPressed: () async {
                                                    final PhoneContact contact =
                                                        await FlutterContactPicker
                                                            .pickPhoneContact();
                                                    print(contact);
                                                    RegExp regExp = RegExp(
                                                      r'{',
                                                      caseSensitive: false,
                                                      multiLine: false,
                                                    );
                                                    RegExp regExp2 = RegExp(
                                                      r'}',
                                                      caseSensitive: false,
                                                      multiLine: false,
                                                    );
                                                    RegExp regExp3 = RegExp(
                                                      r'-',
                                                      caseSensitive: false,
                                                      multiLine: false,
                                                    );
                                                    RegExp regExp4 = RegExp(
                                                      r'(\+62)',
                                                      caseSensitive: false,
                                                      multiLine: false,
                                                    );
                                                    RegExp regExp5 = RegExp(
                                                      r'(\+)',
                                                      caseSensitive: false,
                                                      multiLine: false,
                                                    );
                                                    RegExp regExp6 = RegExp(
                                                      ' ',
                                                      caseSensitive: false,
                                                      multiLine: false,
                                                    );
                                                    var noHP = contact.phoneNumber!.number!
                                                        .replaceAll(regExp, "")
                                                        .replaceAll(regExp2, "")
                                                        .replaceAll(regExp3, "")
                                                        .replaceAll(regExp4, "0")
                                                        .replaceAll(regExp5, "")
                                                        .replaceAll(regExp6, "");
                                                    noHP = noHP;
                                                    // .replaceAll("^0+", "0")
                                                    // .replaceAll("^+62", "0");
                                                    if (contact.phoneNumber!.number == '0' ||
                                                        contact.phoneNumber!.number == '08') {
                                                      // image = 0;
                                                    } else if (noHP.substring(0, 4) == "0811" ||
                                                        noHP.substring(0, 4) == "0821" ||
                                                        noHP.substring(0, 4) == "0851" ||
                                                        noHP.substring(0, 4) == "0812" ||
                                                        noHP.substring(0, 4) == "0822" ||
                                                        noHP.substring(0, 4) == "0852" ||
                                                        noHP.substring(0, 4) == "0813" ||
                                                        noHP.substring(0, 4) == "0823" ||
                                                        noHP.substring(0, 4) == "0853") {
                                                      // image = 1;
                                                    } else if (noHP.substring(0, 4) == "0859" ||
                                                        noHP.substring(0, 4) == "0817" ||
                                                        noHP.substring(0, 4) == "0877" ||
                                                        noHP.substring(0, 4) == "0818" ||
                                                        noHP.substring(0, 4) == "0878" ||
                                                        noHP.substring(0, 4) == "0819") {
                                                      // image = 2;
                                                    } else if (noHP.substring(0, 4) == "0814" ||
                                                        noHP.substring(0, 4) == "0855" ||
                                                        noHP.substring(0, 4) == "0815" ||
                                                        noHP.substring(0, 4) == "0856" ||
                                                        noHP.substring(0, 4) == "0858" ||
                                                        noHP.substring(0, 4) == "0816" ||
                                                        noHP.substring(0, 4) == "0857") {
                                                      // image = 3;
                                                    } else if (noHP.substring(0, 4) == "0881" ||
                                                        noHP.substring(0, 4) == "0882" ||
                                                        noHP.substring(0, 4) == "0883" ||
                                                        noHP.substring(0, 4) == "0884" ||
                                                        noHP.substring(0, 4) == "0885" ||
                                                        noHP.substring(0, 4) == "0886" ||
                                                        noHP.substring(0, 4) == "0887" ||
                                                        noHP.substring(0, 4) == "0888" ||
                                                        noHP.substring(0, 4) == "0889") {
                                                      // image = 4;
                                                    }

                                                    setState(() {
                                                      RegExp regExp = RegExp(
                                                        r'{',
                                                        caseSensitive: false,
                                                        multiLine: false,
                                                      );
                                                      RegExp regExp2 = RegExp(
                                                        r'}',
                                                        caseSensitive: false,
                                                        multiLine: false,
                                                      );
                                                      RegExp regExp3 = RegExp(
                                                        r'-',
                                                        caseSensitive: false,
                                                        multiLine: false,
                                                      );
                                                      RegExp regExp4 = RegExp(
                                                        r'(\+62)',
                                                        caseSensitive: false,
                                                        multiLine: false,
                                                      );
                                                      RegExp regExp5 = RegExp(
                                                        r'(\+)',
                                                        caseSensitive: false,
                                                        multiLine: false,
                                                      );
                                                      RegExp regExp6 = RegExp(
                                                        ' ',
                                                        caseSensitive: false,
                                                        multiLine: false,
                                                      );
                                                      var _phoneContact = contact
                                                          .phoneNumber!.number!
                                                          .replaceAll(regExp, "")
                                                          .replaceAll(regExp2, "")
                                                          .replaceAll(regExp3, "")
                                                          .replaceAll(regExp4, "0")
                                                          .replaceAll(regExp5, "")
                                                          .replaceAll(regExp6, "");
                                                      _hpController.text = _phoneContact;
                                                      // .replaceAll("^0+", "0")
                                                      // .replaceAll("^+62", "0");
                                                    });
                                                
                                                   
                                                  })
                                            ],
                                          ),
                                        )),
                                  ),
                              Container(
                                alignment: Alignment.topLeft,
                                child: Text('$redaksiname',
                                    // '*Operator yang tersedia adalah Telkomsel, dan XL',
                                    style: const TextStyle(
                                        color: Colors.grey,
                                        fontStyle: FontStyle.italic,
                                        fontSize: 12)),
                              ),
                            ]),
                      ),
                    ]),
              ),
              const SizedBox(
                height: 50,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: ISTOutlineButton(
                  onPressed: () {
                   setState(() {});
                  if (!_doValidate()) return;
                  _doTransfer();
                  },
                  text: 'Lanjut',
                ),
              ),
              const SizedBox(
                height: 16,
              )
            ],
          ),
        ),
      ),
    );
  }
}
