import 'package:bpd_aceh/components/ist_confirmation_citilink.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/pesawat/citilink/mpin_citilink.dart';
import 'package:flutter/material.dart';

class CitilinkConfirmation extends StatefulWidget {
  static const routeName = '/CitilinkConfirmation';

  final List<ISTConfirmationItem1>? list;
  final List<ISTConfirmationItem1>? list1;

  const CitilinkConfirmation({Key? key, this.list, this.list1})
      : super(key: key);

  @override
  _CitilinkConfirmationState createState() => _CitilinkConfirmationState();
}

class _CitilinkConfirmationState extends State<CitilinkConfirmation> {
  @override
  Widget build(BuildContext context) {
    _doTransfer() {
      Navigator.pushNamed(context, CitilinkMPIN.routeName);
    }

    return Scaffold(
        resizeToAvoidBottomInset: true,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          centerTitle: true,
          title: const Text("Citilink",
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'Poppins',
              )),
          elevation: 0.0,
          backgroundColor: Pallete.primary,
        ),
        backgroundColor: Colors.white,
        body: ISTConfirmationCitilink(
            items: widget.list,
            items1: widget.list1,
            title: 'Konfirmasi Layanan',
            onFinished: () {
              _doTransfer();
            }));
  }
}
