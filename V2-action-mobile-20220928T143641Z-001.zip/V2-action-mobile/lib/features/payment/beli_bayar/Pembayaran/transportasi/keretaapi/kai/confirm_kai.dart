import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/keretaapi/kai/mpin_kai.dart';
import 'package:flutter/material.dart';

class KeretaKAIConfirmation extends StatefulWidget {
  static const routeName = '/KeretaKAIConfirmation';

  final List<ISTConfirmationItem>? list;

  const KeretaKAIConfirmation({Key? key, this.list}) : super(key: key);

  @override
  _KeretaKAIConfirmationState createState() => _KeretaKAIConfirmationState();
}

class _KeretaKAIConfirmationState extends State<KeretaKAIConfirmation> {
  @override
  Widget build(BuildContext context) {
    _doTransfer() {
      Navigator.pushNamed(context, KeretaKAIMPIN.routeName);
    }

    return Scaffold(
        resizeToAvoidBottomInset: true,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          centerTitle: true,
          title: const Text("KAI",
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'Poppins',
              )),
          elevation: 0.0,
          backgroundColor: Pallete.primary,
        ),
        backgroundColor: Colors.white,
        body: ISTConfirmation(
            items: widget.list,
            title: 'Konfirmasi Layanan',
            onFinished: () {
              _doTransfer();
            }));
  }
}
