import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/pesawat/garuda/mpin_garuda.dart';
import 'package:flutter/material.dart';

class GarudaConfirmation extends StatefulWidget {
  static const routeName = '/GarudaConfirmation';

  final List<ISTConfirmationItem>? list;

  const GarudaConfirmation({Key? key, this.list}) : super(key: key);

  @override
  _GarudaConfirmationState createState() => _GarudaConfirmationState();
}

class _GarudaConfirmationState extends State<GarudaConfirmation> {
  @override
  Widget build(BuildContext context) {
    _doTransfer() {
      Navigator.pushNamed(context, GarudaMPIN.routeName);
    }

    return Scaffold(
        resizeToAvoidBottomInset: true,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          centerTitle: true,
          title: const Text("Garuda Indonesia",
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'Poppins',
              )),
          elevation: 0.0,
          backgroundColor: Pallete.primary,
        ),
        backgroundColor: Colors.white,
        body: ISTConfirmation(
            items: widget.list,
            title: 'Konfirmasi Layanan',
            onFinished: () {
              _doTransfer();
            }));
  }
}
