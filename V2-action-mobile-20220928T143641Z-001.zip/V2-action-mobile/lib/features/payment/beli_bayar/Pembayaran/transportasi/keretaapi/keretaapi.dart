import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/keretaapi/kai/inq_kai.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:bpd_aceh/core/controller/controller_menu.dart';

class KeretaPage extends StatefulWidget {
  static const routeName = '/KeretaPage';

  const KeretaPage({Key? key}) : super(key: key);
  @override
  _KeretaPageState createState() => _KeretaPageState();
}

class _KeretaPageState extends State<KeretaPage> {
  final controllerMenu = Get.put(MenuController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: true,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          centerTitle: true,
          title: const Text("Kereta",
              style: TextStyle(color: Colors.white, fontFamily: 'Poppins')),
          elevation: 0.0,
          backgroundColor: Pallete.primary,
        ),
        backgroundColor: Colors.white,
        body: Container(
          padding: const EdgeInsets.only(left: 8, right: 8),
          child: ListView(
            children: <Widget>[
              Visibility(
                visible: controllerMenu.getVisibilityKAI(),
                child: ListTile(
                  //  selectedTileColor: Pallete.primary,
                  title: const Text('KAI'),
                  trailing: const Icon(Icons.arrow_forward_ios),
                  onTap: () {
                    Navigator.pushNamed(context, KeretaKAI.routeName);
                  },
                ),
              ),
              Visibility(
                visible: controllerMenu.getVisibilityKAI(),
                child: const Divider(
                  thickness: 1,
                  color: Colors.grey,
                ),
              ),
              // Visibility(
              //   visible: controllerMenu.getVisibilityRailink(),
              //   child: ListTile(
              //       title: Text('RAILINK'),
              //       trailing: Icon(Icons.arrow_forward_ios),
              //       onTap: () {
              //         Navigator.pushNamed(context, KeretaRailink.routeName);
              //       }),
              // ),
              // Visibility(
              //   visible: controllerMenu.getVisibilityRailink(),
              //   child: Divider(
              //     thickness: 1,
              //     color: Colors.grey,
              //   ),
              // ),
            ],
          ),
        ));
  }
}
