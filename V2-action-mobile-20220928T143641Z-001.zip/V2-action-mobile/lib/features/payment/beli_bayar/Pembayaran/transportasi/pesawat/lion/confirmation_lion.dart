import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/palete.dart';

import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/pesawat/lion/mpin_lion.dart';
import 'package:flutter/material.dart';

class LionConfirmation extends StatefulWidget {
  static const routeName = '/LionConfirmation';

  final List<ISTConfirmationItem>? list;

  const LionConfirmation({Key? key, this.list}) : super(key: key);

  @override
  _LionConfirmationState createState() => _LionConfirmationState();
}

class _LionConfirmationState extends State<LionConfirmation> {
  @override
  Widget build(BuildContext context) {
    _doTransfer() {
      Navigator.pushNamed(context, LionMpin.routeName);
    }

    return Scaffold(
        resizeToAvoidBottomInset: true,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          centerTitle: true,
          title: const Text("Lion Air",
              style: TextStyle(color: Colors.white, fontFamily: 'Poppins')),
          elevation: 0.0,
          backgroundColor: Pallete.primary,
        ),
        backgroundColor: Colors.white,
        body: ISTConfirmation(
            items: widget.list,
            title: 'Konfirmasi Layanan',
            onFinished: () {
              _doTransfer();
            }));
  }
}
