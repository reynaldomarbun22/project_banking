import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/pesawat/garuda/inq_garuda.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/transportasi/pesawat/lion/inqury_lion.dart';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:bpd_aceh/core/controller/controller_menu.dart';

class PesawatPage extends StatefulWidget {
  static const routeName = '/PesawatPage';

  const PesawatPage({Key? key}) : super(key: key);
  @override
  _PesawatPageState createState() => _PesawatPageState();
}

class _PesawatPageState extends State<PesawatPage> {
  final controllerMenu = Get.put(MenuController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: true,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          centerTitle: true,
          title: const Text("Pesawat",
              style: TextStyle(color: Colors.white, fontFamily: 'Poppins')),
          elevation: 0.0,
          backgroundColor: Pallete.primary,
        ),
        backgroundColor: Colors.white,
        body: Container(
          padding: const EdgeInsets.only(left: 8, right: 8),
          child: ListView(
            children: <Widget>[
              Visibility(
                visible: controllerMenu.getVisibilityGaruda(),
                child: ListTile(
                  title: const Text('Garuda Indonesia'),
                  trailing: const Icon(Icons.arrow_forward_ios),
                  onTap: () {
                    Navigator.pushNamed(context, InquiryGaruda.routeName);
                  },
                ),
              ),
              Visibility(
                visible: controllerMenu.getVisibilityGaruda(),
                child: const Divider(
                  thickness: 1,
                  color: Colors.grey,
                ),
              ),
              // Visibility(
              //   visible: controllerMenu.getVisibilityCitiLink(),
              //   child: ListTile(
              //       title: Text('Citilink'),
              //       trailing: Icon(Icons.arrow_forward_ios),
              //       onTap: () {
              //         Navigator.pushNamed(context, InquiryCitilink.routeName);
              //       }),
              // ),
              // Visibility(
              //   visible: controllerMenu.getVisibilityCitiLink(),
              //   child: Divider(
              //     thickness: 1,
              //     color: Colors.grey,
              //   ),
              // ),
              Visibility(
                visible: controllerMenu.getVisibilityLion(),
                child: ListTile(
                    title: const Text('Lion Air'),
                    trailing: const Icon(Icons.arrow_forward_ios),
                    onTap: () {
                      Navigator.pushNamed(context, LionPage.routeName);
                    }),
              ),
              Visibility(
                visible: controllerMenu.getVisibilityLion(),
                child: const Divider(
                  thickness: 1,
                  color: Colors.grey,
                ),
              ),
            ],
          ),
        ));
  }
}
