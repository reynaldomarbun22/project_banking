import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_card_account.dart';
import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/ist_style.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/utils/string_utils.dart';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class KeretaRailink extends StatefulWidget {
  static const routeName = '/KeretaRailink';
  final String? kodeBayar;

  const KeretaRailink({Key? key, this.kodeBayar}) : super(key: key);

  @override
  // ignore: no_logic_in_create_state
  _KeretaKAIState createState() => _KeretaKAIState(kodeBayar);
}

class _KeretaKAIState extends State<KeretaRailink> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final _keretaController = TextEditingController();

  final String? kodeBayar;

  _KeretaKAIState(this.kodeBayar);

  // ignore: unused_field
  final bool _eSetorError = false;
  // ignore: unused_field
  bool _autoValidate = false;
  bool favoritKeretaKAI = false;

  // @override
  // void initState() {
  //   if (kodeBayar != null) {
  //     _keretaController.text = kodeBayar;
  //     favoritKeretaKAI = true;
  //   }
  //   super.initState();
  // }

  bool _doValidate() {
    if (_formKey.currentState!.validate()) {
      return true;
    } else {
      setState(() {
        _autoValidate = true;
      });
      return false;
    }
  }

  // ignore: unused_element
  _doTransfer() async {
    if (_doValidate()) {
      Map<String, Object> param = {};
      // param['kodeBayar'] = int.parse(_keretaController.text.replaceAll(",", ""));
      param['kodeBayar'] = _keretaController.text;

      final resp =
          await API.post(context, '/payment/KeretaRailink/inquiry', param);
      if (resp != null && resp['code'] == 0) {
        List<ISTConfirmationItem> listParam = [];
        List<dynamic> listMap = resp['resi'];
        for (var item in listMap) {
          ISTConfirmationItem itemParam =
              ISTConfirmationItem(key: item['key'], value: item['value']);
          listParam.add(itemParam);
        }
        // Navigator.push(
        //     context,
        //     new MaterialPageRoute(
        //         builder: (context) => new KeretaKAIConfirmation(
        //               list: listParam,
        //             )));
      } else {
        const DialogBox().showImageDialog(
            message: resp['message'],
            isError: true,
            image: const Image(
              image: AssetImage('assets/images/icon-failed.png'),
            ),
            buttonCancel: 'OK',
            onOk: () {},
            context: context);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text("Railink",
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'Poppins',
            )),
        actions: const <Widget>[],
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      backgroundColor: Colors.white,
      body: Container(
        // padding: EdgeInsets.only(bottom: 20),
        color: Colors.white,
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              ISTCardAccount(
                context: context,
                menu: ISTMenu.billpay,
              ),
              const SizedBox(
                height: 16,
              ),
              Container(
                padding: const EdgeInsets.only(left: 16, right: 16),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Form(
                        // ignore: deprecated_member_use
                        autovalidateMode: AutovalidateMode.always,
                        key: _formKey,
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: <Widget>[
                              Container(
                                alignment: Alignment.topLeft,
                                child: const Text(
                                  'Kode Pembayaran :',
                                  style: TextStyle(color: Colors.black87),
                                ),
                              ),
                              Container(
                                alignment: Alignment.topLeft,
                                child: TextFormField(
                                  validator: (val) {
                                    if (val!.isEmpty) {
                                      return "Mohon diisi";
                                    } else {
                                      return null;
                                    }
                                  },
                                  keyboardType: TextInputType.number,
                                  inputFormatters: [
                                    // ignore: deprecated_member_use
                                    FilteringTextInputFormatter.digitsOnly,
                                    StringUtils.noSpace()
                                  ],
                                  controller: _keretaController,
                                  onChanged: (value) {
                                    if (_keretaController.text.trim().isEmpty) {
                                      _keretaController.text = '';
                                    }
                                  },
                                  maxLength: 100,
                                  decoration: const InputDecoration(
                                    counterText: '',
                                    hintText: 'Masukkan kode pembayaran',
                                    hintStyle: ISTStyle.hintStyle,
                                    // prefixText: 'BL-',
                                    prefixStyle: TextStyle(
                                      color: Colors.black,
                                      fontSize: 16,
                                    ),
                                  ),
                                ),
                              ),
                            ]),
                      ),
                    ]),
              ),
              const SizedBox(
                height: 32,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: ISTOutlineButton(
                  onPressed: () {
                    // _doTransfer();
                  },
                  text: 'Lanjut',
                ),
              ),
              const SizedBox(
                height: 16,
              )
            ],
          ),
        ),
      ),
    );
  }
}
