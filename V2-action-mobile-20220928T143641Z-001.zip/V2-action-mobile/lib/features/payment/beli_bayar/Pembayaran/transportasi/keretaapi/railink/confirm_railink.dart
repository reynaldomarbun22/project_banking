import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:flutter/material.dart';

class KeretaRailinkConfirmation extends StatefulWidget {
  static const routeName = '/KeretaRailinkConfirmation';

  final List<ISTConfirmationItem>? list;

  const KeretaRailinkConfirmation({Key? key, this.list}) : super(key: key);

  @override
  _KeretaRailinkConfirmationState createState() =>
      _KeretaRailinkConfirmationState();
}

class _KeretaRailinkConfirmationState extends State<KeretaRailinkConfirmation> {
  @override
  Widget build(BuildContext context) {
    _doTransfer() {
      // Navigator.pushNamed(context, KeretaRailinkMPIN.routeName);
    }

    return Scaffold(
        resizeToAvoidBottomInset: true,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          centerTitle: true,
          title: const Text("Railink",
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'Poppins',
              )),
          elevation: 0.0,
          backgroundColor: Pallete.primary,
        ),
        backgroundColor: Colors.white,
        body: ISTConfirmation(
            items: widget.list,
            title: 'Konfirmasi Layanan',
            onFinished: () {
              _doTransfer();
            }));
  }
}
