import 'dart:io';
import 'dart:typed_data';

import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PDAM/tirtadaroy/widgets/list_detail.dart';
import 'package:flutter/services.dart';
import 'package:image_save/image_save.dart';
import 'package:share/share.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:screenshot/screenshot.dart';

enum ReceiptStatusPDAM { success, failed, suspect }

class ReceiptItemPDAM {
  final String? key;
  final String? value;

  ReceiptItemPDAM({this.key, this.value});
}

class ReceiptWidgetPDAM extends StatefulWidget {
  const ReceiptWidgetPDAM({
    Key? key,
    this.items,
    this.onFinished,
    this.onCheck,
    this.onTap,
    this.id,
    this.title,
    this.type,
    this.idresi,
    this.date,
    this.detailResi,
    this.detail,
    this.time,
    this.amount,
    this.status,
    this.footer1,
    this.footer2,
    this.footer3,
    this.footer4,
    this.noRef,
    this.noId,
    this.desc,
    this.desc1,
    this.resiTotal,
    this.fromKAi,
    this.fromPemkot,
    this.fromSamsat,
    this.fromArRaniry,
    this.fromArTeukuUmar,
    this.fromCitilink,
    this.fromGaruda,
    this.fromLion,
    this.fromBpjs,
  }) : super(key: key);
  final String? noRef;
  final String? noId;
  final String? title;
  final String? desc;
  final String? desc1;
  final String? fromKAi;
  final String? fromPemkot;
  final String? fromSamsat;
  final String? fromArRaniry;
  final String? fromArTeukuUmar;
  final String? fromCitilink;
  final String? fromGaruda;
  final String? fromLion;
  final String? fromBpjs;
  final int? id;
  final String? idresi;
  final String? amount;
  final List<ReceiptItemPDAM>? items;
  final List<DetailItem>? detailResi;
  final List<ReceiptItemPDAM>? resiTotal;

  final Function? onFinished;
  final Function? onCheck;
  final Function? onTap;

  final ReceiptStatusPDAM? status;
  final String? type;
  final String? detail;
  final String? time;
  final String? date;

  final Widget? footer1;
  final Widget? footer2;
  final Widget? footer3;
  final Widget? footer4;

  // final ISTReceipt data;
  // const ISTReceipt({Key key, @required this.data}) : super(key: key);

  @override
  _ReceiptWidgetPDAMState createState() => _ReceiptWidgetPDAMState();
}

class _ReceiptWidgetPDAMState extends State<ReceiptWidgetPDAM> {
  String statusStr = "";
  String imageStatus = "";
  bool isLoading = false;
  bool isOffline = false;

  bool isSuccess = false;
  bool _firstPress = true;

  // _saveinbox() async {
  //   Inbox(itemss: widget.items);
  //   InboxDBRepository repo = InboxDBRepository();
  //   await repo.open();
  //   InboxModel model = InboxModel();
  //   model.amount = widget.amount;
  //   model.status = widget.status.index.toString();
  //   model.title = widget.title;
  //   model.date =widget.date;
  //   var img = widget.type;
  //   var imgasset = "";
  //   if (img == 'PAYMENT_ZAKAT') {
  //     imgasset = 'assets/images/icon-wallet.png';
  //   } else if (img == 'TFBAS') {
  //     imgasset = 'assets/images/icon-wallet.png';
  //   }
  //   model.image = imgasset;
  //   await repo.insert(model);
  //   await repo.close();
  // }

  @override
  void initState() {
    switch (widget.status) {
      case ReceiptStatusPDAM.success:
        setState(() {
          statusStr = "Berhasil";
          imageStatus = "assets/images/icon-success.png";
        });
        break;
      case ReceiptStatusPDAM.failed:
        setState(() {
          statusStr = "Gagal";
          imageStatus = "assets/images/icon-failed.png";
        });
        break;
      case ReceiptStatusPDAM.suspect:
        setState(() {
          statusStr = "Sedang diproses";
          imageStatus = "assets/images/icon-warning.png";
        });
        break;

      default:
        setState(() {
          statusStr = "Berhasil";
          imageStatus = "assets/images/icon-success.png";
        });
    }

    // _saveinbox();
    super.initState();

    print(widget.status);
  }

  _changeStatus() {
    switch (widget.status) {
      case ReceiptStatusPDAM.success:
        setState(() {
          isSuccess = true;
          statusStr = "Berhasil";
          imageStatus = "assets/images/icon-success.png";
        });
        break;
      case ReceiptStatusPDAM.failed:
        setState(() {
          statusStr = "Gagal";
          imageStatus = "assets/images/icon-failed.png";
        });
        break;
      case ReceiptStatusPDAM.suspect:
        setState(() {
          statusStr = "Sedang diproses";
          imageStatus = "assets/images/icon-warning.png";
        });
        break;

      default:
    }
    return Container();
  }

  List<Widget> _buildItems() {
    List<Widget> ret = [];
    if (widget.items == null || widget.items!.isEmpty) {
      return [];
    }
    for (ReceiptItemPDAM item in widget.items!) {
      ret.add(Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Expanded(
              flex: 1,
              child: item.key == null ? const Text("") : Text(item.key!)),
          Expanded(
            flex: 1,
            child: Text(
              item.value == null ? "" : item.value!,
              textAlign: TextAlign.right,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          )
        ],
      ));
      ret.add(const Divider(
        thickness: 1,
      ));
    }
    return ret;
  }

  List<Widget> _buildResitotal() {
    List<Widget> ret = [];
    if (widget.items == null || widget.resiTotal!.isEmpty) {
      return [];
    }
    for (ReceiptItemPDAM item in widget.resiTotal!) {
      ret.add(Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Expanded(
              flex: 1,
              child: item.key == null ? const Text("") : Text(item.key!)),
          Expanded(
            flex: 1,
            child: Text(
              item.value == null ? "" : item.value!,
              textAlign: TextAlign.right,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          )
        ],
      ));
      ret.add(const Divider(
        thickness: 1,
      ));
    }
    return ret;
  }

  Widget buildItemtest() {
    return ListView.separated(
        separatorBuilder: (ctx, index) {
          return const Divider(
            height: 0,
          );
        },
        // physics: const NeverScrollableScrollPhysics(),
        itemCount: widget.detailResi!.length,
        itemBuilder: (context, index) {
          final item = widget.detailResi![index];
          return Container(
              padding: const EdgeInsets.only(bottom: 10),
              child: Column(
                children: [
                  Container(
                    color: Colors.grey[200],
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text("Periode"),
                            Text(item.periode!),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text("Pemakaian"),
                            Text(item.pemakaian!),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text("Denda"),
                            Text(item.denda!),
                          ],
                        ),
                        // Row(
                        //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        //   children: [
                        //     Text("Biaya"),
                        //     Text(item.biaya),
                        //   ],
                        // ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text("Tagihan"),
                            Text(item.tagihan!),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(item.noReffStr!),
                            Text(item.noReff!),
                          ],
                        ),
                        // Row(
                        //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        //   children: [
                        //     Text("noReffStr"),
                        //     Text(item.noReffStr),
                        //   ],
                        // ),
                      ],
                    ),
                  ),
                ],
              ));
        });
  }

  //yoseph
  // _scrshot() async {
  //   precacheImage(
  //       AssetImage(
  //         imageStatus,
  //       ),
  //       context);
  //   precacheImage(
  //       const AssetImage('assets/images/bank-logo-green.png'), context);
  //   precacheImage(
  //       const AssetImage('assets/images/logo-app-green.png'), context);
  //   precacheImage(const AssetImage('assets/images/icon-success.png'), context);
  //   Map<Permission, PermissionStatus> statuses = await [
  //     Permission.photos,
  //     Permission.storage,
  //     Permission.camera
  //   ].request();
  //   print(statuses);
  //   if (await Permission.storage.request().isGranted &&
  //       await Permission.photos.request().isGranted &&
  //       await Permission.camera.request().isGranted) {
  //     screenshotController
  //         .capture(pixelRatio: 3, delay: const Duration(milliseconds: 10))
  //         .then((image) async {
  //       var save =
  //           await ImageGallerySaver.saveImage(image!, name: "${widget.noRef}");
  //       if (save != null && save.toString().isNotEmpty) {
  //         const DialogBox().showImageDialog(
  //           isError: false,
  //           onOk: () {
  //             Navigator.pop(context);
  //           },
  //           // image: Icon(
  //           //   Icons.camera_alt,
  //           //   color: Pallete.PRIMARY,
  //           // ),
  //           title: "Perhatian",
  //           buttonOk: "OK",
  //           context: context,
  //           message: "Berhasil unduh resi",
  //         );
  //       }
  //     }).catchError((onError) {
  //       print(onError);
  //     });
  //   } else {
  //     const DialogBox().showImageDialog(
  //       isError: true,
  //       onOk: () {
  //         Navigator.pop(context);
  //       },
  //       // image: Icon(
  //       //   Icons.camera_alt,
  //       //   color: Pallete.PRIMARY,
  //       // ),
  //       title: "Perhatian",
  //       buttonOk: "OK",
  //       context: context,
  //       message: "Gagal unduh resi",
  //     );
  //   }
  // }

  // _scrshot() async {
  //   Map<Permission, PermissionStatus> statuses = await [
  //     Permission.photos,
  //     Permission.storage,
  //   ].request();

  //   screenshotController
  //       .capture(
  //     pixelRatio: 3,
  //   )
  //       .then((File image) async {
  //     final result = await ImageGallerySaver.saveImage(image.readAsBytesSync());
  //     print(result);
  //     DialogBox().showImageDialog(
  //       isError: false,
  //       onOk: () {
  //         Navigator.pop(context);
  //       },
  //       // image: Icon(
  //       //   Icons.camera_alt,
  //       //   color: Pallete.PRIMARY,
  //       // ),
  //       title: "Perhatian",
  //       buttonOk: "OK",
  //       context: context,
  //       message: "Berhasil unduh resi",
  //     );
  //   }).catchError((onError) {
  //     print(onError

// );
  //   });
  // }

  // _share() async {
  //   await [
  //     Permission.photos,
  //     Permission.storage,
  //   ].request();
  //   screenshotController
  //       .capture(
  //     pixelRatio: 3,
  //   )
  //       .then((File image) async {
  //     await Share.file(
  //         '${widget.date}${widget.title}',
  //         '${widget.date}${widget.title}.jpg',
  //         image.readAsBytesSync(),
  //         'image/jpg');
  //   });
  // }

  // _share() async {
  //   precacheImage(
  //       AssetImage(
  //         imageStatus,
  //       ),
  //       context);
  //   precacheImage(const AssetImage('assets/images/bank-logo-green.png'), context);
  //   precacheImage(const AssetImage('assets/images/logo-app-green.png'), context);
  //   precacheImage(const AssetImage('assets/images/icon-success.png'), context);
  //   await [
  //     Permission.photos,
  //     Permission.storage,
  //   ].request();
  //   screenshotController
  //       .capture(pixelRatio: 3, delay: const Duration(milliseconds: 10))
  //       .then((image) async {
  //     await Share.file('${widget.noRef}', '${widget.noRef}.jpg',
  //         image!, 'image/jpg');
  //   });
  // }

  late String noref;
  String _result = "";
  Future<void> _saveImage() async {
    setState(() {
      noref = widget.noRef!;
    });
    bool success = false;
    screenshotController
        .capture(pixelRatio: 3, delay: const Duration(milliseconds: 10))
        .then((image) async {
      print(image);
      print("ini datsssssSSSSSSSSS");
      try {
        success = (await ImageSave.saveImage(
          image,
          "$noref.jpg",
          albumName: "Action Mobile",
        ))!;
      } on PlatformException catch (e, s) {
        print(e);
        print(s);
      }
      setState(() {
        _result = success ? "Save to album success" : "Save to album failed";
        print(_result);
        const DialogBox().showImageDialog(
          isError: false,
          onOk: () {
            Navigator.pop(context);
          },
          // image: Icon(
          //   Icons.camera_alt,
          //   color: Pallete.primary,
          // ),
          title: "Perhatian",
          buttonOk: "OK",
          context: context,
          message: "Resi berhasil di unduh",
        );
        // showDialog(
        //   context: context,
        //   barrierDismissible: false,
        //   useRootNavigator: true,
        //   builder: (BuildContext context) {
        //     return AlertDialog(
        //       // contentPadding: EdgeInsets.all(8),
        //       shape: const RoundedRectangleBorder(
        //         borderRadius: BorderRadius.all(Radius.circular(20.0)),
        //       ),
        //       content: SizedBox(
        //         height: 230,
        //         child: Column(
        //           children: <Widget>[
        //             // SizedBox(
        //             //   height: 2,
        //             // ),

        //             const Text(
        //               'Resi berhasil di unduh',
        //               textAlign: TextAlign.center,
        //               style: TextStyle(
        //                 color: Pallete.primary,
        //               ),
        //             ),
        //             const SizedBox(
        //               height: 16,
        //             ),
        //             Container(
        //               alignment: Alignment.center,
        //               child: Row(
        //                 mainAxisAlignment: MainAxisAlignment.center,
        //                 children: [
        //                   SizedBox(
        //                     width: 120,
        //                     child: OutlineButton(
        //                       onPressed: () {
        //                         Navigator.pop(context);
        //                         setState(() {
        //                           // ss = false;
        //                         });
        //                       },
        //                       borderSide: const BorderSide(
        //                         color: Pallete.primary,
        //                       ),
        //                       splashColor: Pallete.primary,
        //                       shape: const RoundedRectangleBorder(
        //                         borderRadius:
        //                             BorderRadius.all(Radius.circular(18)),
        //                       ),
        //                       child: Text(
        //                         "Selesai",
        //                         style: Theme.of(context)
        //                             .textTheme
        //                             .bodyText1
        //                             ?.copyWith(
        //                                 fontWeight: FontWeight.w600,
        //                                 color: Pallete.primary),
        //                       ),
        //                     ),
        //                   ),
        //                 ],
        //               ),
        //             )
        //           ],
        //         ),
        //       ),
        //       //actions: _checkbutton(context),
        //     );
        //   },
        // );
      });
    });
  }

  Future<String> saveAndShare(Uint8List bytes) async {
    final directory = await getApplicationDocumentsDirectory();
    final image = File('${directory.path}/flutter.png');
    image.writeAsBytesSync(bytes);
    const text = 'Shared From Action Mobile';
    await Share.shareFiles([image.path], text: text);
    return directory.path;
  }

  ScreenshotController screenshotController = ScreenshotController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            const SizedBox(height: 8),
            Screenshot(
              controller: screenshotController,
              child: Container(
                color: Colors.white,
                // height: MediaQuery.of(context).size.height * 0.1,
                child: Padding(
                  padding: const EdgeInsets.only(top: 8, bottom: 8),
                  child: Column(
                    children: <Widget>[
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: const <Widget>[
                          Expanded(
                            flex: 1,
                            child: Center(
                              child: Image(
                                image: AssetImage(
                                    'assets/images/bank-logo-green.png'),
                                height: 40,
                              ),
                            ),
                          ),
                          Expanded(
                            flex: 1,
                            child: Center(
                              child: Image(
                                image: AssetImage(
                                    'assets/images/logo-app-green.png'),
                                // color: Pallete.PRIMARY,
                                height: 25,
                              ),
                            ),
                          )
                        ],
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'Status Transaksi',
                        style: TextStyle(color: Pallete.primary),
                      ),
                      Center(
                        child: Image(
                          image: AssetImage(
                              widget.status == ReceiptStatusPDAM.suspect
                                  ? "assets/images/icon-warning.png"
                                  : widget.status == ReceiptStatusPDAM.failed
                                      ? "assets/images/icon-failed.png"
                                      : 'assets/images/icon-success.png'),
                          // ||
                          //         widget.status == ReceiptStatusPDAM.failed
                          //     ? imageStatus
                          //     : 'assets/images/icon-success.png'),
                          height: 100,
                        ),
                      ),
                      Container(
                          child: widget.status == ReceiptStatusPDAM.suspect
                              ? const Text('Sedang diproses',
                                  style: TextStyle(color: Colors.orange))
                              : widget.status == ReceiptStatusPDAM.failed
                                  ? const Text('Gagal',
                                      style: TextStyle(color: Colors.red))
                                  : const Text('Berhasil',
                                      style:
                                          TextStyle(color: Pallete.primary))),
                      // Text(
                      //   widget.status == ReceiptStatusPDAM.suspect
                      //       ? "Sedang diproses"
                      //       : widget.status == ReceiptStatusPDAM.failed
                      //           ? "Gagal"
                      //           : 'Berhasil',
                      //   style: TextStyle(color: Pallete.PRIMARY),
                      // ),
                      const SizedBox(height: 8),
                      widget.status == ReceiptStatusPDAM.suspect &&
                              widget.type == 'QRPAYMENT'
                          ? Padding(
                              padding: EdgeInsets.symmetric(
                                  horizontal:
                                      MediaQuery.of(context).size.width * 0.35),
                              child: ISTOutlineButton(
                                color: Pallete.warning,
                                text: 'Cek Status',
                                onPressed:
                                    // _cekStatusQR();
                                    // ignore: unnecessary_statements
                                    widget.onCheck as void Function()?,
                              ),
                            )
                          : _changeStatus(),
                      // FlatButton(
                      //     onPressed: null,
                      //     child: Text(
                      //       "Cek Status",
                      //       style: TextStyle(color: Pallete.WARNING),
                      //     )),
                      const SizedBox(height: 8),
                      Container(
                        alignment: Alignment.center,
                        child: Text(
                          widget.title!,
                          textAlign: TextAlign.center,
                        ),
                      ),
                      Text(
                        widget.amount!,
                        style: TextStyle(
                            fontSize:
                                Theme.of(context).textTheme.headline4!.fontSize,
                            fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(height: 8),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: Column(children: [
                          Column(
                            children: _buildItems(),
                          ),
                          Container(
                              alignment: Alignment.topLeft,
                              child: const Text('Rincian Tagihan')),
                          const SizedBox(height: 8),

                          // Container(
                          //   height: 300,
                          //   child: buildItemtest(),
                          // ),
                          widget.detailResi!.length == 1
                              ? SizedBox(
                                  height: 110,
                                  child: buildItemtest(),
                                )
                              : Container(),
                          widget.detailResi!.length == 2
                              ? SizedBox(
                                  height: 224,
                                  child: buildItemtest(),
                                )
                              : Container(),
                          widget.detailResi!.length == 3
                              ? SizedBox(
                                  height: 340,
                                  child: buildItemtest(),
                                )
                              : Container(),
                          const SizedBox(
                            height: 8,
                          ),
                          Column(
                            children: _buildResitotal(),
                          ),
                        ]),
                      ),
                      const SizedBox(height: 8),

                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: widget.footer1,
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: widget.footer2,
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: widget.footer3,
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: widget.footer4,
                      )
                    ],
                  ),
                ),
              ),
            ),
            widget.fromKAi == "fromKAI"
                ? Container()
                : widget.fromCitilink == "fromCitilink" ||
                        widget.status == ReceiptStatusPDAM.suspect
                    ? Container()
                    : widget.fromGaruda == "fromGaruda"
                        ? Container()
                        : widget.fromLion == "fromLion"
                            ? Container()
                            : widget.fromBpjs == "fromBpjs"
                                ? Container()
                                : widget.fromPemkot == "fromPemkot"
                                    ? Container()
                                    : widget.fromSamsat == "fromSamsat"
                                        ? Container()
                                        : widget.fromArRaniry == "fromArRaniry"
                                            ? Container()
                                            : widget.fromArTeukuUmar ==
                                                    "fromArTeukuUmar"
                                                ? Container()
                                                : widget.type == 'QRPAYMENT'
                                                    ? Container()
                                                    : ISTFlatButton(
                                                        onPressed: () {
                                                          const DialogBox()
                                                              .showImageDialog(
                                                                  message:
                                                                      "Apakah anda yakin akan di simpan ke favorit",
                                                                  buttonOk:
                                                                      'Setuju',
                                                                  buttonCancel:
                                                                      "Batal",
                                                                  isError:
                                                                      false,
                                                                  image:
                                                                      const Image(
                                                                    image: AssetImage(
                                                                        'assets/images/icon-warning.png'),
                                                                  ),
                                                                  onOk: widget
                                                                          .onTap
                                                                      as void
                                                                          Function()?,
                                                                  context:
                                                                      context);
                                                        },
                                                        text:
                                                            'Simpan ke favorit',
                                                        color: Pallete.primary,
                                                      ),
            const SizedBox(height: 4),
            // widget.status == ReceiptStatusPDAM.suspect &&
            //         widget.type == 'QRPAYMENT'
            //     ? Container()
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: ISTOutlineButton(
                text: 'Selesai',
                onPressed: widget.onFinished as void Function()?,
              ),
            ),
            const SizedBox(height: 16),
            // widget.status == ReceiptStatusPDAM.suspect &&
            //         widget.type == 'QRPAYMENT'
            //     ? Container()
            Container(
              padding: const EdgeInsets.all(0),
              width: double.maxFinite,
              height: 50,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: TextButton(
                      onPressed: () {
                        if (_firstPress == true) {
                          _saveImage();
                        }
                        setState(() {
                          _firstPress = false;
                        });
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const <Widget>[
                          Icon(Icons.file_download, color: Pallete.primary),
                          SizedBox(width: 4),
                          Text(
                            "Unduh",
                            style: TextStyle(color: Pallete.primary),
                          )
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                    child: TextButton(
                      onPressed: () async {
                        final image = await screenshotController.capture();
                        if (image == null) return;
                        await saveAndShare(image);
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const <Widget>[
                          Icon(Icons.share, color: Pallete.primary),
                          SizedBox(width: 4),
                          Text(
                            "Bagikan",
                            style: TextStyle(color: Pallete.primary),
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
