import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PDAM/tirtadaroy/mpin_tirtadaroy.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PDAM/tirtadaroy/widgets/list_detail.dart';
import 'package:flutter/material.dart';

class ListConfirmationPDAM {
  final String? key;
  final String? value;
  // ignore: prefer_typing_uninitialized_variables
  final detail;
  ListConfirmationPDAM({this.key, this.value, this.detail});
}

class ListConfirmPDAM extends StatefulWidget {
  static const routeName = '/Confirmpdam';
  final List<ListConfirmationPDAM>? list;
  final List<ListConfirmationPDAM>? listPBB;

  const ListConfirmPDAM({
    Key? key,
    this.list,
    this.listPBB,
    this.items1,
    this.items2,
    this.items3,
    this.title,
    this.itemList,
    this.onFinished,
    this.dropitem,

    // this.items1,
  }) : super(key: key);

  final String? title;
  final List<ListConfirmationPDAM>? itemList;

  final List<ListConfirmationPDAM>? items1;
  final List<DetailItem>? items2;
  final List<ListConfirmationPDAM>? items3;
  final List<ListDropPDAM>? dropitem;
  final Function? onFinished;

  @override
  _ListConfirmPDAMState createState() => _ListConfirmPDAMState();
}

class _ListConfirmPDAMState extends State<ListConfirmPDAM> {
  // List<ListDropPDAM> _listtahun = [];

  // ignore: unused_field
  ListDropPDAM? _selectedtahun;
  // ignore: unused_field
  final bool _dropError = false;
  // ignore: unused_field
  final ScrollController _controllerOne = ScrollController();

  // ignore: unused_field
  final bool _success = false;
  // ignore: unused_field
  final List<DetailItem> _listitem = [];
  // ignore: unused_field
  ScrollController? _scrollController;

  @override
  void initState() {
    super.initState();
    _scrollController = ScrollController();
  }

// _doValidate() {
//     if (_selectedtahun == null ) {
//       setState(() {
//         _dropError = true;
//       });
//       _success = false;
//     } else {
//       _dropError = false;

//       _success = true;
//     }
//     return _success;

  // }
  _doTransfer() async {
    Navigator.push(context,
        MaterialPageRoute(builder: (context) => const TirtaDaroyMPIN()));
  }

  // _getselectedtahun() async {
  //   try {
  //     setState(() {
  //       _selectedtahun = null;
  //     });
  //     if (_listtahun.isNotEmpty) {
  //       Future.delayed(Duration.zero);
  //       _listtahun.clear();
  //     }
  //     //  var listResp = widget.dropitem;
  //     //   List<dynamic> listRespMini = (listResp);
  //     //   List<ListDropPDAM> listtahun = [];
  //     //   //for (var item in listRespMini) {
  //     //   for (var i = 0; i < listRespMini.length; i++) {
  //     //     ListDropPDAM items = ListDropPDAM(
  //     //       tahunindex: i,
  //     //       tahun:  listRespMini[i]['tahun'],
  //     //       // tahunkey : listRespMini[i]['title'],
  //     //     );

  //     //     listtahun.add(items);
  //     //   }

  //       setState(() {
  //         _listtahun = widget.dropitem;
  //       });

  //   } catch (_) {}
  // }

  List<Widget> _buildItems1() {
    List<Widget> ret = [];
    if (widget.items1!.isEmpty) {
      return [];
    }
    for (ListConfirmationPDAM item in widget.items1!) {
      ret.add(Column(children: <Widget>[
        item.key != 'Rincian Tagihan'
            ? Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Expanded(flex: 1, child: Text(item.key!)),
                  Expanded(
                    flex: 1,
                    child: Text(
                      item.value!,
                      textAlign: TextAlign.right,
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Poppins',
                      ),
                    ),
                  )
                ],
              )
            : Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Expanded(flex: 1, child: Text(item.key!)),
                  Expanded(
                    flex: 1,
                    child: Text(
                      item.value!,
                      textAlign: TextAlign.right,
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Poppins',
                      ),
                    ),
                  )
                ],
              ),
              Column(
                children: _buildColoumn(item.detail),
              )
            ],
              )
      ]));
      ret.add(const Divider(
        thickness: 1,
      ));
    }
    return ret;
  }

  _buildRow(resp) {
    try {
      var item = resp['item'];
      // ignore: unused_local_variable
      List<Widget> list = [];
      if (item != null || resp != item) {
        final col1 = item[0];
        final col2 = item[1];
        final col3 = item[2];
        final col4 = item[3];
        final col5 = item[4];

        return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                      Text(col1.key,
                          style: const TextStyle(
                              fontSize: 13,
                              color: Color.fromARGB(180, 5, 5, 5))),
                      Text(col1.value,
                          style: const TextStyle(
                            fontSize: 13,
                          ))
                    ]),
                    Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                      Text(col2.key,
                          style: const TextStyle(
                              fontSize: 13,
                              color: Color.fromARGB(180, 5, 5, 5))),
                      Text(col2.value,
                          style: const TextStyle(
                            fontSize: 13,
                          ))
                    ]),
                    Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                      Text(col3.key,
                          style: const TextStyle(
                              fontSize: 13,
                              color: Color.fromARGB(180, 5, 5, 5))),
                      Text(col3.value,
                          style: const TextStyle(
                            fontSize: 13,
                          ))
                    ]),
                    Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                      Text(col4.key,
                          style: const TextStyle(
                              fontSize: 13,
                              color: Color.fromARGB(180, 5, 5, 5))),
                      Text(col4.value,
                          style: const TextStyle(
                            fontSize: 13,
                          ))
                    ]),
                    Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                      Text(col5.key,
                          style: const TextStyle(
                              fontSize: 13,
                              color: Color.fromARGB(180, 5, 5, 5))),
                      Text(col5.value,
                          style: const TextStyle(
                            fontSize: 13,
                          ))
                    ])
                  ]),

              // SizedBox(height: 13),
              // ],
              // )
            ]);
      } else {
        return Container();
      }
    } catch (e) {
      print('error _buildDetail : $e');
    }
  }

  bool loading = true;

  _buildColoumn(param) {
    try {
      List<Widget> widgetlist = [];
      if (param != null || param != {}) {
        var data = param['item'];
        for (var item in data) {
          widgetlist.add(Container(
              width: 400,
              decoration: BoxDecoration(
                color: Colors.grey[200],
              ),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    _buildRow(item),
                  ])));
          // widgetlist.add(Container(
          //     height: 5,
          //     decoration: BoxDecoration(
          //       color: Pallete.PRIMARY,
          //     )));
        }
        return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: widgetlist);
      } else {
        return Container();
      }
    } catch (e) {
      print('error _buildDetail : $e');
    }
  }

  Widget buildItemtest() {
    return ListView.separated(
        separatorBuilder: (ctx, index) {
          return const Divider(
            height: 0,
          );
        },
        // physics: const NeverScrollableScrollPhysics(),
        itemCount: widget.items2!.length,
        itemBuilder: (context, index) {
          final item = widget.items2![index];
          return Container(
              padding: const EdgeInsets.only(bottom: 10),
              child: Column(
                children: [
                  Container(
                    color: Colors.grey[200],
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text("Periode"),
                            Text(item.periode!),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text("Pemakaian"),
                            Text(item.pemakaian!),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text("Denda"),
                            Text(item.denda!),
                          ],
                        ),
                        // Row(
                        //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        //   children: [
                        //     Text("Biaya"),
                        //     Text(item.biaya),
                        //   ],
                        // ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text("Tagihan"),
                            Text(item.tagihan!),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ));
        });
  }

  // List<Widget> _buildItems2() {
  //   List<Widget> ret = [];
  //   var pairs = partition(widget.items2, 4);

  //   if (widget.items2 == null || widget.items2.isEmpty) {
  //     return [];
  //   }
  //   for (ListConfirmationPDAM item in widget.items2) {
  //     ret.add(Column(children: <Widget>[
  //       Row(
  //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //         children: <Widget>[
  //           Expanded(flex: 1, child: Text(item.key)),
  //           Expanded(
  //             flex: 1,
  //             child: Text(
  //               item.value,
  //               textAlign: TextAlign.right,
  //               style: TextStyle(
  //                 fontWeight: FontWeight.bold,
  //                 fontFamily: 'Poppins',
  //               ),
  //             ),
  //           )
  //         ],
  //       ),

  //     ]));
  //     ret.add(Divider(
  //       thickness: 1,
  //     ));
  //   }
  //   return ret;
  // }

  List<Widget> _buildItems3() {
    List<Widget> ret = [];
    if (widget.items3 == null || widget.items3!.isEmpty) {
      return [];
    }
    for (ListConfirmationPDAM item in widget.items3!) {
      ret.add(Column(children: <Widget>[
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Expanded(flex: 1, child: Text(item.key!)),
            Expanded(
              flex: 1,
              child: Text(
                item.value!,
                textAlign: TextAlign.right,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Poppins',
                ),
              ),
            )
          ],
        ),
      ]));
      ret.add(const Divider(
        thickness: 1,
      ));
    }
    return ret;
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: <Widget>[
        // SizedBox(height: 16),
        // Center(child: Text('titel')),
        const SizedBox(height: 32),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
                border: Border.all(
                  color: _buildItems1().isNotEmpty
                      ? Pallete.primary
                      : Colors.white,
                  width: 0.5,
                ),
                borderRadius: BorderRadius.circular(10)),
            child: Column(children: <Widget>[
              Column(
                children: _buildItems1(),
              ),
              Container(
                  alignment: Alignment.topLeft, child: const Text('Rincian Tagihan')),
              const SizedBox(
                height: 8,
              ),
              widget.items2!.length == 1
                  ? SizedBox(
                      height: 100,
                      child: buildItemtest(),
                    )
                  : Container(),
              widget.items2!.length == 2
                  ? SizedBox(
                      height: 180,
                      child: buildItemtest(),
                    )
                  : Container(),
              widget.items2!.length == 3
                  ? SizedBox(
                      height: 280,
                      child: buildItemtest(),
                    )
                  : Container(),
              const SizedBox(
                height: 8,
              ),
              Column(
                children: _buildItems3(),
              ),
            ]),
          ),
        ),
        const SizedBox(height: 16),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: ISTOutlineButton(
            onPressed: () {
              // if (!_doValidate()) return;
              _doTransfer();
            },
            text: 'Lanjut',
          ),
        )
      ],
    );
  }
}

class ListDropPDAM {
  final String? tahun;
  final String? tahunkey;
  final int? tahunindex;

  ListDropPDAM({
    Key? key,
    this.tahun,
    this.tahunkey,
    this.tahunindex,
  });
}

// Container(
//   height: 300,
//   color: Colors.blue,
//   child: Expanded
//   (child:
//   Container(child:

//    ListView.separated(
//         separatorBuilder: (ctx, index) {
//           return Divider(
//          height: 0,
//           );
//         },
//         itemCount: widget.items2.length,
//         itemBuilder: (context, index) {
//           final item = widget.items2[index];
//           return
//             Container(

//               color: Colors.grey[200],
//               child: Column(
//                                             children:[ Container(
//                   child: Row(
//                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                    children: [
//                    Text(item.key),
//                    Text(item.value),
//                    ],
//                   ),
//                 ),

//                                             ]
//               )

//             );

//         }),

//   )
//   )
//   ,
// ),
