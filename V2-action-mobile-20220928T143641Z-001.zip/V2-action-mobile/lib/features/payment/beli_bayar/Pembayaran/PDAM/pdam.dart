import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PDAM/tirtadaroy/inq_tirtadaroy.dart';
import 'package:flutter/material.dart';

class PDAMPage extends StatefulWidget {
  static const routeName = '/PDAMPage';

  const PDAMPage({Key? key}) : super(key: key);
  @override
  _PDAMPageState createState() => _PDAMPageState();
}

class _PDAMPageState extends State<PDAMPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: true,
        //
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          centerTitle: true,
          title: const Text("PDAM", style: TextStyle(color: Colors.white)),
          elevation: 0.0,
          backgroundColor: Pallete.primary,
        ),
        backgroundColor: Colors.white,
        body: Container(
          padding: const EdgeInsets.only(left: 8, right: 8),
          child: ListView(
            children: <Widget>[
              ListTile(
                title: const Text('Tirta Daroy   (Banda Aceh)'),
                trailing: const Icon(Icons.arrow_forward_ios),
                onTap: () {
                  Navigator.pushNamed(context, InquiryTirtaDaroy.routeName);
                },
              ),
              const Divider(
                thickness: 1,
                color: Colors.grey,
              ),
              // ListTile(
              //   title: Text('Citilink'),
              //   trailing: Icon(Icons.arrow_forward_ios),
              //   onTap: (){Navigator.pushNamed(context, InquiryCitilink.routeName);}
              // ),
              // Divider(
              //   thickness: 1,

              //   color: Colors.grey,
              // ),
              // ListTile(
              //   title: Text('Lion'),
              //   trailing: Icon(Icons.arrow_forward_ios),
              //   onTap: (){Navigator.pushNamed(context, InquiryLion.routeName);}
              // )
            ],
          ),
        ));
  }
}
