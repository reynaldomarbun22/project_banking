import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_mpin.dart';
import 'package:bpd_aceh/components/ist_receipt_repo.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/crypto/ist_crypto.dart';
import 'package:bpd_aceh/features/home/home_page.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PDAM/tirtadaroy/receipt_tirtadaroy.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PDAM/tirtadaroy/widgets/list_detail.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PDAM/tirtadaroy/widgets/resi_widget.dart';
import 'package:bpd_aceh/features/splash/splash.dart';
import 'package:flutter/material.dart';

class TirtaDaroyMPIN extends StatelessWidget {
  static const routeName = '/TirtaDaroyMPIN';

  const TirtaDaroyMPIN({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    // _cekStatus() {}
    return ISTMPIN(
      onFinishedVal: (value) async {
        Map<String, Object> param = {};
        final String pinEnc = await ISTCrypto.encryptAES(value);
        param['mpin'] = pinEnc;
        final resp = await API.post(context, '/pdam/tirtadaroy/request', param);
        if (resp['code'] != null && resp['code'] == 0) {
          List<DetailItem> _listitems = [];

          for (var item in resp['resiDetail']) {
            // print(item['respCode']);

            _listitems.add(DetailItem(
                periode: item['periode'],
                pemakaian: item['pemakaian'],
                denda: item['denda'],
                biaya: item['biaya'],
                tagihan: item['tagihan'],
                noReff: item['noReff'],
                noReffStr: item['noReffStr']));
          }
          List<ReceiptItemPDAM> listParam = [];
          List<ISTReceiptItemInbox> listParams = [];
          List<ReceiptItemPDAM> listTotalbayar = [];
          List<dynamic> listMap = resp['resi'];
          List<dynamic> listresitotal = resp['resiTotalBayar'];
          for (var item in listresitotal) {
            ReceiptItemPDAM itemTotalBayar =
                ReceiptItemPDAM(key: item['key'], value: item['value']);
            listTotalbayar.add(itemTotalBayar);
          }
          for (var item in listMap) {
            ReceiptItemPDAM itemParam =
                ReceiptItemPDAM(key: item['key'], value: item['value']);
            listParam.add(itemParam);
          }
          for (var item in listMap) {
            ISTReceiptItemInbox itemParams =
                ISTReceiptItemInbox(key: item['key'], value: item['value']);
            listParams.add(itemParams);
          }
          ReceiptStatusPDAM? status;

          if (resp['status'] != null && resp['status'] == 'success') {
            status = ReceiptStatusPDAM.success;
          }
          if (resp['status'] != null && resp['status'] == 'suspect') {
            status = ReceiptStatusPDAM.suspect;
          }
          if (resp['status'] != null && resp['status'] == 'failed') {
            status = ReceiptStatusPDAM.failed;
          }

          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => TirtaDaroyReceipt(
                        img: "assets/images/icon-payments-active.png",
                        title: resp['titel'],
                        date: resp['waktu'],
                        list: listParam,
                        lists: listParams,
                        amount: resp['amountStr'],
                        noRef: resp['idresi'],
                        status: status,
                        listtotal: listTotalbayar,
                        detailresi: _listitems,
                        subtitle: "Layanan",
                        detail: resp['dstAccountNo'],
                        keterangan1: resp['additionalinfo'],
                        // keterangan2: resp['additionalinfo1'],
                      )));
        } else if (resp['code'] != null && resp['code'] != 0) {
          if (resp['code'] == -1002) {
            //Salah MPIN
            const DialogBox().showImageDialog(
                message: resp['message'],
                isError: true,
                buttonCancel: 'OK',
                onCancel: () {
                  Navigator.pop(context);
                },
                onOk: () {},
                context: context);
          } else if (resp['code'] == -4901) {
            //Saldo Tidak Cukup
            const DialogBox().showImageDialog(
                message: resp['message'],
                isError: true,
                buttonCancel: 'OK',
                onCancel: () {
                  Navigator.pushNamedAndRemoveUntil(context, HomePage.routeName,
                      ModalRoute.withName(Splash.routeName));
                },
                onOk: () {},
                context: context);
          } else if (resp['code'] == -1108) {
            //MPIN Ke Blokir
            const DialogBox().showImageDialog(
                message: resp['message'],
                isError: true,
                buttonCancel: 'OK',
                onCancel: () {
                  Navigator.pushNamedAndRemoveUntil(context, HomePage.routeName,
                      ModalRoute.withName(Splash.routeName));
                },
                onOk: () {},
                context: context);
          } else if (resp['code'] == -9999) {
            //MPIN Ke Blokir
            const DialogBox().showImageDialog(
                message: resp['message'],
                isError: true,
                buttonCancel: 'OK',
                onCancel: () {
                  Navigator.pushNamedAndRemoveUntil(context, HomePage.routeName,
                      ModalRoute.withName(Splash.routeName));
                },
                onOk: () {},
                context: context);
          } else {
            const DialogBox().showImageDialog(
                message: resp['message'],
                isError: true,
                buttonCancel: 'OK',
                onCancel: () {
                  Navigator.pop(context);
                },
                onOk: () {},
                context: context);
          }
        }
      },
    );
  }
}
