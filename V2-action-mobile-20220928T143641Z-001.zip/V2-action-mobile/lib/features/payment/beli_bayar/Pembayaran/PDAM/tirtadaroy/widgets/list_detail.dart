class DetailItem {
  final String? periode;
  final String? pemakaian;
  final String? denda;
  final String? tagihan;
  final String? biaya;
  final String? noReff;
  final String? noReffStr;

  DetailItem(
      {this.periode,
      this.pemakaian,
      this.denda,
      this.tagihan,
      this.biaya,
      this.noReff,
      this.noReffStr
      });
}

class Notice {
  final String? text;

  Notice({this.text});
}