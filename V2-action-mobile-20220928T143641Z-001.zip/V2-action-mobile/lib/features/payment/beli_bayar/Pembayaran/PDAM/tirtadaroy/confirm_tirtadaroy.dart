import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PDAM/tirtadaroy/mpin_tirtadaroy.dart';
import 'package:flutter/material.dart';

class TirtaDaroyConfirm extends StatefulWidget {
  static const routeName = '/TirtaDaroyConfirm';

  final List<ISTConfirmationItem>? list;

  const TirtaDaroyConfirm({Key? key, this.list}) : super(key: key);

  @override
  _TirtaDaroyConfirmState createState() => _TirtaDaroyConfirmState();
}

class _TirtaDaroyConfirmState extends State<TirtaDaroyConfirm> {
  @override
  Widget build(BuildContext context) {
    _doTransfer() {
      Navigator.pushNamed(context, TirtaDaroyMPIN.routeName);
    }

    return Scaffold(
        resizeToAvoidBottomInset: true,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          centerTitle: true,
          title: const Text("PDAM",
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'Poppins',
              )),
          elevation: 0.0,
          backgroundColor: Pallete.primary,
        ),
        backgroundColor: Colors.white,
        body: ISTConfirmation(
            items: widget.list,
            title: 'Konfimasi Layanan',
            onFinished: () {
              _doTransfer();
            }));
  }
}
