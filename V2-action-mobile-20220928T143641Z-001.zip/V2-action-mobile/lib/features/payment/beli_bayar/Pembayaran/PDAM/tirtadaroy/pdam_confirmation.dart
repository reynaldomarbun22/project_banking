import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PBB/mpin_pbb.dart';
// import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PDAM/pdam.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PDAM/tirtadaroy/confirm_new_tirtadaroy.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PDAM/tirtadaroy/widgets/list_detail.dart';

import 'package:flutter/material.dart';

class PageConfirmPDAM extends StatefulWidget {
  static const routeName = '/PageConfirmPDAM';

  final List<ListConfirmationPDAM>? items1;
  final List<DetailItem>? items2;
  final List<ListConfirmationPDAM>? items3;
  // final List<ListConfirmationPDAM> itemList;

  const PageConfirmPDAM({Key? key, this.items2, this.items1, this.items3})
      : super(key: key);

  @override
  _PageConfirmPDAMState createState() => _PageConfirmPDAMState();
}

class _PageConfirmPDAMState extends State<PageConfirmPDAM> {
  @override
  Widget build(BuildContext context) {
    _doTransfer() {
      Navigator.pushNamed(context, PBBMPIN.routeName);
    }

    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text("PDAM",
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'Poppins',
            )),
        actions: const <Widget>[],
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      backgroundColor: Colors.white,
      body: ListConfirmPDAM(
          title: 'Konfirmasi Layanan',
          // itemList: widget.itemList,
          items1: widget.items1,
          items2: widget.items2,
          items3: widget.items3,
          onFinished: () {
            _doTransfer();
          }),
    );
  }
}
