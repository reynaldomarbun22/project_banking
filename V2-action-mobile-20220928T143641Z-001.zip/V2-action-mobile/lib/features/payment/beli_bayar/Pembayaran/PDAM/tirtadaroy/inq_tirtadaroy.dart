import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_card_account.dart';
import 'package:bpd_aceh/components/ist_style.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/core/utils/string_utils.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PBB/inquiri_pbb.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PDAM/tirtadaroy/pdam_confirmation.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PDAM/tirtadaroy/confirm_new_tirtadaroy.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PDAM/tirtadaroy/widgets/list_detail.dart';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class InquiryTirtaDaroy extends StatefulWidget {
  static const routeName = '/InquiryTirtaDaroy';
  final String? kodeBayar;

  const InquiryTirtaDaroy({Key? key, this.kodeBayar}) : super(key: key);

  @override
  // ignore: no_logic_in_create_state
  _InquiryBPJSState createState() => _InquiryBPJSState(kodeBayar);
}

class _InquiryBPJSState extends State<InquiryTirtaDaroy> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final _keretaController = TextEditingController();

  final String? kodeBayar;

  _InquiryBPJSState(this.kodeBayar);

  // ignore: unused_field
  final bool _eSetorError = false;
  // ignore: unused_field
  bool _autoValidate = false;
  bool favoritPDAM = false;
  final bool _dropError = false;
  // ignore: unused_field
  List<ListConfirmationPDAM>? _itemList1;
  @override
  void initState() {
    if (kodeBayar != null) {
      _keretaController.text = kodeBayar!;
      favoritPDAM = true;
    }
    super.initState();
    _getKota();
  }

  bool _doValidate() {
    if (_formKey.currentState!.validate()) {
      return true;
    } else {
      setState(() {
        _autoValidate = true;
      });
      return false;
    }
  }

  _doTransfer() async {
    if (_doValidate()) {
      Map<String, Object?> param = {};
      param['kotaIdx'] = _selectedKota!.statusIndex;
      // param['kodeBayar'] = int.parse(_keretaController.text.replaceAll(",", ""));
      param['idPelanggan'] = _keretaController.text;

      final resp = await API.post(context, '/pdam/tirtadaroy/Inquiry', param);
      if (resp != null && resp['code'] == 0) {
        List<ListConfirmationPDAM> listParam1 = [];
        List<dynamic> listMap = resp['resi'];
        for (var item in listMap) {
          ListConfirmationPDAM itemParam =
              ListConfirmationPDAM(key: item['key'], value: item['value']);
          listParam1.add(itemParam);
        }
        // var listResp = resp['resiDetail'];
        // List<dynamic> listRespDyn = (listResp);

        List<DetailItem> _listitems = [];
        // ignore: unused_local_variable
        List<DetailItem> _listitem = [];
        // //   List<dynamic> listResidetail = resp['resiDetail'];

        //   for (var item in listResidetail) {
        //     ListConfirmationPDAM itemParam =
        //         ListConfirmationPDAM(key: item['key'], value: item['value']);
        //     listParams.add(itemParam);
        //   }
        for (var item in resp['resiDetail']) {
          // print(item['respCode']);

          _listitems.add(DetailItem(
              periode: item['periode'],
              pemakaian: item['pemakaian'],
              denda: item['denda'],
              biaya: item['biaya'],
              tagihan: item['tagihan']));
        }

        List<ListConfirmationPDAM> listParam3 = [];
        List<dynamic> listMap3 = resp['resiTotalBayar'];
        for (var item in listMap3) {
          ListConfirmationPDAM itemParam3 =
              ListConfirmationPDAM(key: item['key'], value: item['value']);
          listParam3.add(itemParam3);
        }
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => PageConfirmPDAM(
                      // itemList: _itemList1,

                      items1: listParam1,
                      items2: _listitems,
                      items3: listParam3,
                    )));
      } else {
        const DialogBox().showImageDialog(
            message: resp['message'],
            isError: true,
            image: const Image(
              image: AssetImage('assets/images/icon-failed.png'),
            ),
            buttonCancel: 'OK',
            onOk: () {},
            context: context);
      }
    }
  }

  List<WilayahKota> _listKota = [];
  WilayahKota? _selectedKota;
  _getKota() async {
    try {
      setState(() {
        _selectedKota = null;
      });
      if (_listKota.isNotEmpty) {
        Future.delayed(Duration.zero);
        _listKota.clear();
      }
      Map<String, Object> param = {};

      final resp = await API.postNoLoading(context, '/pdam/list', param);
      if (resp['code'] == 0) {
        var listResp = resp['listKota'];
        List<dynamic> listRespMini = (listResp);
        List<WilayahKota> listkota = [];
        for (var i = 0; i < listRespMini.length; i++) {
          WilayahKota items = WilayahKota(
            statusIndex: i,
            status: listRespMini[i]['kota'].toString(),
            statusTitle: listRespMini[i]['path'],
          );

          listkota.add(items);
        }

        setState(() {
          _listKota = listkota;
        });
      }
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text("PDAM",
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'Poppins',
            )),
        actions: const <Widget>[],
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      backgroundColor: Colors.white,
      body: Container(
        // padding: EdgeInsets.only(bottom: 20),
        color: Colors.white,
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              ISTCardAccount(
                context: context,
                menu: ISTMenu.billpay,
              ),
              const SizedBox(
                height: 16,
              ),
              Container(
                padding: const EdgeInsets.only(left: 16, right: 16),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Form(
                        // ignore: deprecated_member_use
                        autovalidateMode: AutovalidateMode.always,
                        key: _formKey,
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: <Widget>[
                              Container(
                                alignment: Alignment.center,
                                // padding: EdgeInsets.only(left: 16, right: 16),
                                color: Colors.white,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    const Text(
                                      "Kota / Kabupaten",
                                    ),
                                    Container(
                                      // padding: EdgeInsets.only(right: 8),
                                      alignment: Alignment.topLeft,
                                      child: DropdownButton<WilayahKota>(
                                        // iconEnabledColor: Pallete.PRIMARY,
                                        // value: dropdownValue,
                                        value: _listKota.isEmpty
                                            ? null
                                            : _selectedKota,
                                        hint: const Text("Pilih kota / kabupaten",
                                            style: ISTStyle.hintStyle),
                                        isExpanded: true,
                                        // iconSize: 38,
                                        icon: const Icon(
                                          Icons.keyboard_arrow_down,
                                          size: 38,
                                        ),
                                        // iconSize: 30,
                                        // style: TextStyle(color: Colors.black),
                                        underline: Container(
                                          height: 1,
                                          color: Colors.grey,
                                        ),

                                        onChanged: (WilayahKota? valuePen) {
                                          setState(() {
                                            _selectedKota = valuePen;
                                          });
                                        },

                                        items: _listKota
                                            .map((WilayahKota _listKota) {
                                          return DropdownMenuItem<WilayahKota>(
                                            value: _listKota,
                                            child: Row(
                                              children: <Widget>[
                                                Text(_listKota.status!),
                                              ],
                                            ),
                                          );
                                        }).toList(),
                                        isDense: false,
                                      ),
                                    ),
                                    _dropError
                                        ? Container(
                                            alignment: Alignment.centerLeft,
                                            child: const Text(
                                              'Mohon pilih Kota / Kabupaten',
                                              style:
                                                  TextStyle(color: Colors.red),
                                            ),
                                          )
                                        : const SizedBox.shrink(),
                                  ],
                                ),
                              ),
                              const SizedBox(
                                height: 8,
                              ),
                              Container(
                                alignment: Alignment.topLeft,
                                child: const Text(
                                  'ID Pelanggan',
                                  style: TextStyle(color: Colors.black87),
                                ),
                              ),
                              favoritPDAM
                                  ? Column(children: [
                                      Container(
                                          alignment: Alignment.topLeft,
                                          child: Text('$kodeBayar')),
                                      const Divider(
                                        thickness: 1.5,
                                      )
                                    ])
                                  : Container(
                                      alignment: Alignment.topLeft,
                                      child: TextFormField(
                                        validator: (val) {
                                          if (val!.isEmpty) {
                                            return "Mohon diisi";
                                          } else {
                                            return null;
                                          }
                                        },
                                        keyboardType: TextInputType.number,
                                        inputFormatters: [
                                          // ignore: deprecated_member_use
                                          FilteringTextInputFormatter
                                              .digitsOnly,
                                          StringUtils.noSpace()
                                        ],
                                        controller: _keretaController,
                                        onChanged: (value) {
                                          if (_keretaController.text
                                              .trim()
                                              .isEmpty) {
                                            _keretaController.text = '';
                                          }
                                        },
                                        maxLength:
                                            ISTConstants.handphoneMaxLength,
                                        decoration: const InputDecoration(
                                          counterText: '',
                                          hintText: 'Masukkan ID Pelanggan',
                                          hintStyle: ISTStyle.hintStyle,
                                          // prefixText: 'BL-',
                                          prefixStyle: TextStyle(
                                            color: Colors.black,
                                            fontSize: 16,
                                          ),
                                        ),
                                      ),
                                    ),
                            ]),
                      ),
                    ]),
              ),
              const SizedBox(
                height: 32,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: ISTOutlineButton(
                  onPressed: () {
                    _doTransfer();
                  },
                  text: 'Lanjut',
                ),
              ),
              const SizedBox(
                height: 16,
              )
            ],
          ),
        ),
      ),
    );
  }
}
