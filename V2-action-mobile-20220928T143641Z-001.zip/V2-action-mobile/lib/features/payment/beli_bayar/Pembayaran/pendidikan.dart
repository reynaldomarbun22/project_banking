import 'package:bpd_aceh/components/ist_menu_container.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/Universitas/universitas_screen.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/infaq/Infaq_BaitulMalAceh/infaq_baitul_mal_aceh.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:bpd_aceh/core/controller/controller_menu.dart';

class PendidikaScreen extends StatefulWidget {
  static const routeName = '/PendidikaScreen';

  const PendidikaScreen({Key? key}) : super(key: key);
  @override
  _PendidikaScreenState createState() => _PendidikaScreenState();
}

class _PendidikaScreenState extends State<PendidikaScreen> {
  final controllerMenu = Get.put(MenuController());
  bool press = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text(
          "Pendidikan",
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'Poppins',
          ),
        ),
//        actions: <Widget>[
//          IconButton(
//            icon: Icon(
//              Icons.notifications,
//              color: Colors.white,
//            ),
//            onPressed: () {
//              // _doLogout();
//            },
//          )
//        ],
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      backgroundColor: Colors.white,
      body: ListView(
        children: <Widget>[
          // ListTile(
          //   title: Text('Kursus'),
          //   trailing: Icon(Icons.arrow_forward_ios),
          //   onTap: () {
          //     // Navigator.pushNamed(context, InquiryTirtaDaroy.routeName);
          //   },
          // ),
          // Divider(
          //   thickness: 1,
          //   color: Colors.grey,
          // ),
          // ListTile(
          //   title: Text('Sekolah'),
          //   trailing: Icon(Icons.arrow_forward_ios),
          //   onTap: () {
          //     // Navigator.pushNamed(context, InquiryTirtaDaroy.routeName);
          //   },
          // ),
          // Divider(
          //   thickness: 1,
          //   color: Colors.grey,
          // ),
          Visibility(
            visible: controllerMenu.getVisibilityPerguruanTinggi(),
            child: ListTile(
              title: const Text('Perguruan Tinggi'),
              trailing: const Icon(Icons.arrow_forward_ios),
              onTap: () {
                Navigator.pushNamed(context, UniversitasScreen.routeName);
              },
            ),
          ),
          Visibility(
            visible: controllerMenu.getVisibilityPerguruanTinggi(),
            child: const Divider(
              thickness: 1,
              color: Colors.grey,
            ),
          ),
        ],
      ),
      // Column(
      //   crossAxisAlignment: CrossAxisAlignment.start,
      //   children: <Widget>[
      //     ISTCardAccount(context: context, menu: ISTMenu.billpay),
      //     SizedBox(height: 8),
      //     SingleChildScrollView(
      //       child: buildMenuInfaq(context),
      //     )
      //   ],
      // ),
    );
  }
}

buildMenuInfaq(context) {
  return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      child: ISTMenuContainer(
        onTap: () {
          Navigator.pushNamed(context, InfaqMalBaitulAceh.routeName);
        },
        image: Image.asset(
          'assets/images/icon-baitulMal.png',
          width: 50,
        ),
        text: 'Baitul Mal Aceh',
      ));
}
