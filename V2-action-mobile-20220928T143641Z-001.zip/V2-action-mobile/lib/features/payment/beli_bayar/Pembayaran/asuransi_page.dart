import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/asuransi/bpjs/inq_bpjs.dart';
import 'package:flutter/material.dart';
import 'package:bpd_aceh/core/controller/controller_menu.dart';
import 'package:get/get.dart';

class AsuransiScreen extends StatefulWidget {
  static const routeName = '/AsuransiScreen';

  const AsuransiScreen({Key? key}) : super(key: key);
  @override
  _AsuransiScreenState createState() => _AsuransiScreenState();
}

class _AsuransiScreenState extends State<AsuransiScreen> {
  final controllerMenu = Get.put(MenuController());
  bool press = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text(
          "Asuransi",
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'Poppins',
          ),
        ),
//        actions: <Widget>[
//          IconButton(
//            icon: Icon(
//              Icons.notifications,
//              color: Colors.white,
//            ),
//            onPressed: () {
//              // _doLogout();
//            },
//          )
//        ],
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      backgroundColor: Colors.white,
      body: ListView(
        children: <Widget>[
          Visibility(
            visible: controllerMenu.getVisibilityBPJS(),
            child: ListTile(
              title: const Text('BPJS Kesehatan'),
              trailing: const Icon(Icons.arrow_forward_ios),
              onTap: () {
                Navigator.pushNamed(context, InquiryBPJS.routeName);
              },
            ),
          ),
          Visibility(
            visible: controllerMenu.getVisibilityBPJS(),
            child: const Divider(
              thickness: 1,
              color: Colors.grey,
            ),
          ),
        ],
      ),
    );
  }
}
