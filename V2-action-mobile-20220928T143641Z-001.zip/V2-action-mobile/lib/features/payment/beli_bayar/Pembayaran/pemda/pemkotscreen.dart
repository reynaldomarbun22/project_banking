import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/pemda/e_setor.dart';
import 'package:flutter/material.dart';
import 'package:bpd_aceh/core/controller/controller_menu.dart';
import 'package:get/get.dart';

class PemkotPage extends StatefulWidget {
  static const routeName = '/PemkotPage';

  const PemkotPage({Key? key}) : super(key: key);
  @override
  _PemkotPageState createState() => _PemkotPageState();
}

class _PemkotPageState extends State<PemkotPage> {
  final controllerMenu = Get.put(MenuController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: true,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          centerTitle: true,
          title: const Text("Retribusi",
              style: TextStyle(color: Colors.white, fontFamily: 'Poppins')),
          elevation: 0.0,
          backgroundColor: Pallete.primary,
        ),
        backgroundColor: Colors.white,
        body: Container(
          padding: const EdgeInsets.only(left: 8, right: 8),
          child: ListView(
            children: <Widget>[
              Visibility(
                visible: controllerMenu.getVisibilityRetribusiPemkot(),
                child: ListTile(
                  title: const Text('Pemkot Banda Aceh'),
                  trailing: const Icon(Icons.arrow_forward_ios),
                  onTap: () {
                    Navigator.pushNamed(context, EsetorPemda.routeName);
                  },
                ),
              ),
              Visibility(
                visible: controllerMenu.getVisibilityRetribusiPemkot(),
                child: const Divider(
                  thickness: 1,
                  color: Colors.grey,
                ),
              ),
            ],
          ),
        ));
  }
}
