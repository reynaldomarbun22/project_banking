import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/pemda/e_setor_mpin.dart';
import 'package:flutter/material.dart';

class ESetorConfirmation extends StatefulWidget {
  static const routeName = '/eSetorConfirmation';

  final List<ISTConfirmationItem>? list;

  const ESetorConfirmation({Key? key, this.list}) : super(key: key);

  @override
  _ESetorConfirmationState createState() => _ESetorConfirmationState();
}

class _ESetorConfirmationState extends State<ESetorConfirmation> {
  @override
  Widget build(BuildContext context) {
    _doTransfer() {
      Navigator.pushNamed(context, ESetorMPIN.routeName);
    }

    return Scaffold(
        resizeToAvoidBottomInset: true,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          centerTitle: true,
          title: const Text("Pemkot Banda Aceh",
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'Poppins',
              )),
          actions: const <Widget>[],
          elevation: 0.0,
          backgroundColor: Pallete.primary,
        ),
        backgroundColor: Colors.white,
        body: ISTConfirmation(
            items: widget.list,
            title: 'Konfirmasi Layanan',
            onFinished: () {
              _doTransfer();
            }));
  }
}
