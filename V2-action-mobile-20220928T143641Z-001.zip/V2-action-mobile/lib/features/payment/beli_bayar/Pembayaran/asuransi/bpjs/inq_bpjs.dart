import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_card_account.dart';
import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/ist_style.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/utils/string_utils.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/asuransi/bpjs/confirmation_bpjs.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class InquiryBPJS extends StatefulWidget {
  static const routeName = '/InquiryBPJS';
  final String? kodeBayar;

  const InquiryBPJS({Key? key, this.kodeBayar}) : super(key: key);

  @override
  // ignore: no_logic_in_create_state
  _InquiryBPJSState createState() => _InquiryBPJSState(kodeBayar);
}

class _InquiryBPJSState extends State<InquiryBPJS> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _kodebayarController = TextEditingController();

  final String? kodeBayar;

  _InquiryBPJSState(this.kodeBayar);

  final bool _dropError = false;
  // ignore: unused_field
  bool _autoValidate = false;
  bool favoritInquiryBPJS = false;

  @override
  void initState() {
    if (kodeBayar != null) {
      _kodebayarController.text = kodeBayar!;
      favoritInquiryBPJS = true;
      _getDenom();
    }
    super.initState();
    // _getDenom();
  }

  bool _doValidate() {
    if (_formKey.currentState!.validate()) {
      return true;
    } else {
      setState(() {
        _autoValidate = true;
      });
      return false;
    }
  }

  _doTransfer() async {
    if (_doValidate()) {
      Map<String, Object> param = {};
      // param['kodeBayar'] = int.parse(_keretaController.text.replaceAll(",", ""));
      param['nomorVA'] = _kodebayarController.text;
      param['periodeDate'] = _selected!.denominationDesc.toString();

      final resp = await API.post(context, '/bpjs/Inquiry', param);
      if (resp != null && resp['code'] == 0) {
        List<ISTConfirmationItem> listParam = [];
        List<dynamic> listMap = resp['resi'];
        for (var item in listMap) {
          ISTConfirmationItem itemParam =
              ISTConfirmationItem(key: item['key'], value: item['value']);
          listParam.add(itemParam);
        }
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => BPJSConfirmation(
                      list: listParam,
                    )));
      } else {
        const DialogBox().showImageDialog(
            message: resp['message'],
            isError: true,
            image: const Image(
              image: AssetImage('assets/images/icon-failed.png'),
            ),
            buttonCancel: 'OK',
            onOk: () {},
            context: context);
      }
    }
  }

  List<DenomItem> _list = [];
  DenomItem? _selected;

  _getDenom() async {
    try {
      setState(() {
        _selected = null;
      });
      if (_list.isNotEmpty) {
        Future.delayed(Duration.zero);
        _list.clear();
      }
      // Map<String, Object> param = new Map();
      // param['phoneNo'] = '08123123131';
      final resp = await API.postNoLoading(context, '/bpjs/list', {});

      // final resp =
      //     await API.postNoLoading(context, '/purchase/pulsa/denom', param);
      if (resp['code'] == 0) {
        var listResp = resp['listDateBPJS'];
        List<dynamic> listRespMini = (listResp);
        List<DenomItem> listDenom = [];
        //for (var item in listRespMini) {
        for (var i = 0; i < listRespMini.length; i++) {
          DenomItem items = DenomItem(
            denomIndex: i,
            denomination: listRespMini[i]['title'].toString(),
            denominationDesc: listRespMini[i]['value'].toString(),
          );

          listDenom.add(items);
        }

        setState(() {
          _list = listDenom;
        });
      }
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text("BPJS Kesehatan",
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'Poppins',
            )),
        actions: const <Widget>[],
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      backgroundColor: Colors.white,
      body: Container(
        // padding: EdgeInsets.only(bottom: 20),
        color: Colors.white,
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              ISTCardAccount(
                context: context,
                menu: ISTMenu.billpay,
              ),
              const SizedBox(
                height: 16,
              ),
              Container(
                padding: const EdgeInsets.only(left: 16, right: 16),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Form(
                        // ignore: deprecated_member_use
                        autovalidateMode: AutovalidateMode.always,
                        key: _formKey,
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: <Widget>[
                              Container(
                                alignment: Alignment.topLeft,
                                child: const Text(
                                  'Nomor VA Peserta :',
                                  style: TextStyle(color: Colors.black87),
                                ),
                              ),
                              favoritInquiryBPJS
                                  ? Column(children: [
                                      Container(
                                          alignment: Alignment.topLeft,
                                          child: Text('$kodeBayar')),
                                      const Divider(
                                        thickness: 1.5,
                                      )
                                    ])
                                  : Container(
                                      alignment: Alignment.topLeft,
                                      child: TextFormField(
                                        validator: (val) {
                                          if (val!.isEmpty || val == '0') {
                                            return "Mohon diisi";
                                          } else {
                                            return null;
                                          }
                                        },
                                        keyboardType: TextInputType.number,
                                        inputFormatters: [
                                          // ignore: deprecated_member_use
                                          FilteringTextInputFormatter
                                              .digitsOnly,
                                          StringUtils.noSpace()
                                        ],
                                        controller: _kodebayarController,
                                        // onChanged: (value) {
                                        //   if (_keretaController.text.trim().isEmpty) {
                                        //     _keretaController.text = '';
                                        //   }
                                        // },
                                        onChanged: (val) {
                                          if (_kodebayarController
                                              .text.isNotEmpty) {
                                            _getDenom();
                                          } else {
                                            setState(() {
                                              _list.clear();
                                            });
                                          }
                                        },
                                        maxLength: 20,
                                        decoration: const InputDecoration(
                                          counterText: '',
                                          hintText: 'Masukkan Nomor VA Peserta',
                                          hintStyle: ISTStyle.hintStyle,
                                          prefixStyle: TextStyle(
                                            color: Colors.black,
                                            fontSize: 16,
                                          ),
                                        ),
                                      ),
                                    ),
                              const SizedBox(
                                height: 8,
                              ),
                              Container(
                                alignment: Alignment.topLeft,
                                child: const Text(
                                  "Periode Bayar :",
                                  style: TextStyle(color: Colors.black87),
                                ),
                              ),
                              DropdownButton<DenomItem>(
                                value: _list.isEmpty
                                    ? null
                                    : _selected,
                                hint: const Text("Pilih Periode Bayar",
                                    style: ISTStyle.hintStyle),
                                isExpanded: true,
                                icon: const Icon(Icons.arrow_drop_down),
                                iconSize: 30,

                                // focusColor: Pallete.primary,
                                iconEnabledColor: Pallete.primary,
                                // elevation: 16,
                                style: const TextStyle(color: Colors.black),
                                underline: Container(
                                  height: 1,
                                  color: Colors.grey,
                                ),
                                isDense: false,
                                onChanged: (DenomItem? newValue) {
                                  setState(() {
                                    _selected = newValue;
                                  });
                                },
                                items: _list.map((DenomItem _list) {
                                  return DropdownMenuItem<DenomItem>(
                                    value: _list,
                                    child: Row(
                                      children: <Widget>[
                                        Text(_list.denomination!),
                                      ],
                                    ),
                                  );
                                }).toList(),
                              ),
                              // Container(
                              //   // padding: EdgeInsets.only(left: 16, right: 16),
                              //   child: DropdownButton<BpjsItem>(
                              //     value: _list == null || _list.isEmpty
                              //         ? null
                              //         : _selected,
                              //     hint: Text("Pilih Bulan",
                              //         style: ISTStyle.HINT_STYLE),
                              //     isExpanded: true,
                              //     icon: Icon(Icons.arrow_drop_down),
                              //     iconSize: 30,
                              //     // elevation: 16,
                              //     style: TextStyle(color: Colors.black),
                              //     underline: Container(
                              //       height: 1,
                              //       color: Colors.grey,
                              //     ),
                              //     isDense: false,
                              //     onChanged: (BpjsItem newValue) {
                              //       setState(() {
                              //         _selected = newValue;
                              //       });
                              //     },
                              //     items: _list.map((BpjsItem _list) {
                              //       return DropdownMenuItem<BpjsItem>(
                              //         value: _list,
                              //         child: Row(
                              //           children: <Widget>[
                              //             Text(_list.value + _list.title),
                              //           ],
                              //         ),
                              //       );
                              //     }).toList(),
                              //   ),
                              // ),
                              _dropError
                                  ? Container(
                                      alignment: Alignment.centerLeft,
                                      child: const Text(
                                        'Mohon pilih periode bulan',
                                        style: TextStyle(color: Colors.red),
                                      ),
                                    )
                                  : const SizedBox.shrink(),
                              const SizedBox(
                                height: 8,
                              ),
                            ]),
                      ),
                    ]),
              ),
              const SizedBox(
                height: 32,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: ISTOutlineButton(
                  onPressed: () {
                    _doTransfer();
                  },
                  text: 'Lanjut',
                ),
              ),
              const SizedBox(
                height: 16,
              )
            ],
          ),
        ),
      ),
    );
  }
}

class DenomItem {
  final String? denomination;
  final String? denominationDesc;
  final int? denomIndex;

  DenomItem(
      {Key? key, this.denomination, this.denominationDesc, this.denomIndex});
}
