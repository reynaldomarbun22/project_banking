import 'package:flutter/material.dart';

class BpjsItem {
  final String? title;
  final String? value;
  final int? bpjsIndex;

  BpjsItem({Key? key, this.title, this.value, this.bpjsIndex});
}
