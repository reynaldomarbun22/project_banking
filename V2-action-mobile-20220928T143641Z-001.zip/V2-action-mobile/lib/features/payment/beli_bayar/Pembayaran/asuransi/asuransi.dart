import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/asuransi/bpjs/inq_bpjs.dart';
import 'package:flutter/material.dart';

class AsuransiPage extends StatefulWidget {
  static const routeName = '/AsuransiPage';

  const AsuransiPage({Key? key}) : super(key: key);
  @override
  _AsuransiPageState createState() => _AsuransiPageState();
}

class _AsuransiPageState extends State<AsuransiPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: true,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          centerTitle: true,
          title: const Text("Asuransi", style: TextStyle(color: Colors.white)),
          elevation: 0.0,
          backgroundColor: Pallete.primary,
        ),
        backgroundColor: Colors.white,
        body: Container(
          padding: const EdgeInsets.only(left: 8, right: 8),
          child: ListView(
            children: <Widget>[
              ListTile(
                title: const Text('BPJS Kesehatan'),
                trailing: const Icon(Icons.arrow_forward_ios),
                onTap: () {
                  Navigator.pushNamed(context, InquiryBPJS.routeName);
                },
              ),
              const Divider(
                thickness: 1,
                color: Colors.grey,
              ),
              // ListTile(
              //   title: Text('Citilink'),
              //   trailing: Icon(Icons.arrow_forward_ios),
              //   onTap: (){Navigator.pushNamed(context, InquiryCitilink.routeName);}
              // ),
              // Divider(
              //   thickness: 1,

              //   color: Colors.grey,
              // ),
              // ListTile(
              //   title: Text('Lion'),
              //   trailing: Icon(Icons.arrow_forward_ios),
              //   onTap: (){Navigator.pushNamed(context, InquiryLion.routeName);}
              // )
            ],
          ),
        ));
  }
}
