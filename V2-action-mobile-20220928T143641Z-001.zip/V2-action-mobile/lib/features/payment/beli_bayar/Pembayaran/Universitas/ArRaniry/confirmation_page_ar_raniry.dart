import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/Universitas/ArRaniry/ar_raniry_mpin.dart';
import 'package:flutter/material.dart';

class ConfirmationPageArRaniry extends StatefulWidget {
  static const routeName = '/ConfirmationPageArRaniry';

  final List<ISTConfirmationItem>? list;

  const ConfirmationPageArRaniry({Key? key, this.list}) : super(key: key);

  @override
  _ConfirmationPageArRaniryState createState() =>
      _ConfirmationPageArRaniryState();
}

class _ConfirmationPageArRaniryState extends State<ConfirmationPageArRaniry> {
  @override
  Widget build(BuildContext context) {
    _doTransfer() {
      Navigator.pushNamed(context, ArRaniryMpinPage.routeName);
    }

    return Scaffold(
        resizeToAvoidBottomInset: true,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          centerTitle: true,
          title: const Text("UIN Ar Raniry", style: TextStyle(color: Colors.white)),
          elevation: 0.0,
          backgroundColor: Pallete.primary,
        ),
        backgroundColor: Colors.white,
        body: ISTConfirmation(
            items: widget.list,
            title: 'Konfirmasi Layanan',
            onFinished: () {
              _doTransfer();
            }));
  }
}
