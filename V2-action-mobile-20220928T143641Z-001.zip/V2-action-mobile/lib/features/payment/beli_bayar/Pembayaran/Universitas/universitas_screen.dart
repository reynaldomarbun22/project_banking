import 'package:bpd_aceh/components/ist_menu_container.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/Universitas/ArRaniry/ar_raniry_page.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/Universitas/TeukurUmar/teuku_umar_page.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:bpd_aceh/core/controller/controller_menu.dart';

class UniversitasScreen extends StatefulWidget {
  static const routeName = '/universitasscreen';

  const UniversitasScreen({Key? key}) : super(key: key);
  @override
  _UniversitasScreenState createState() => _UniversitasScreenState();
}

class _UniversitasScreenState extends State<UniversitasScreen> {
  final controllerMenu = Get.put(MenuController());
  bool press = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text("Perguruan Tinggi",
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'Poppins',
            )),
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      backgroundColor: Colors.white,
      body: ListView(
        children: <Widget>[
          Visibility(
            visible: controllerMenu.getVisibilityUinRaniry(),
            child: ListTile(
              title: const Text('UIN Ar Raniry'),
              trailing: const Icon(Icons.arrow_forward_ios),
              onTap: () {
                Navigator.pushNamed(context, ArRaniry.routeName);
              },
            ),
          ),
          Visibility(
            visible: controllerMenu.getVisibilityUinRaniry(),
            child: const Divider(
              thickness: 1,
              color: Colors.grey,
            ),
          ),
          Visibility(
            visible: controllerMenu.getVisibilityTeukuUmar(),
            child: ListTile(
                title: const Text('Universitas Teuku Umar'),
                trailing: const Icon(Icons.arrow_forward_ios),
                onTap: () {
                  Navigator.pushNamed(context, TeukurUmar.routeName);
                }),
          ),
          Visibility(
            visible: controllerMenu.getVisibilityTeukuUmar(),
            child: const Divider(
              thickness: 1,
              color: Colors.grey,
            ),
          ),

          // Column(
          //   crossAxisAlignment: CrossAxisAlignment.start,
          //   children: <Widget>[
          //     ISTCardAccount(
          //       context: context,
          //       menu: ISTMenu.billpay,
          //     ),
          //     SizedBox(height: 8),
          //     SingleChildScrollView(
          //       child: buildMenuZakat(context),
          //     )
          //   ],
          // ),
        ],
      ),
      // Column(
      //   crossAxisAlignment: CrossAxisAlignment.start,
      //   children: <Widget>[
      //     ISTCardAccount(context: context, menu: ISTMenu.billpay),
      //     SizedBox(height: 8),
      //     SingleChildScrollView(
      //       child: buildMenuUniversitas(context),
      //     )
      //   ],
      // ),
    );
  }
}

buildMenuUniversitas(context) {
  return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      child: Wrap(
        children: <Widget>[
          ISTMenuContainer(
            onTap: () {
              Navigator.pushNamed(context, ArRaniry.routeName);
            },
            image: Image.asset(
              'assets/images/uin@2x.png',
              width: 50,
            ),
            // color: Colors.grey,
            text: 'UIN Ar Raniry',
          ),
          ISTMenuContainer.none(
            onTap: () {
              Navigator.pushNamed(context, TeukurUmar.routeName);
            },
            image: Image.asset(
              'assets/images/utu@2x.png',
              width: 50,
            ),
            // color: Colors.grey,
            text: 'Teuku Umar',
          ),
        ],
      ));
}
