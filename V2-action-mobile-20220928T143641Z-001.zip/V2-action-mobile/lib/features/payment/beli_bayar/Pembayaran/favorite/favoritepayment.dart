import 'package:bpd_aceh/components/ist_list_fav.dart';
import 'package:flutter/material.dart';

class FavoritePaymentPage extends StatefulWidget {
  static const routeName = '/favoritePayment';

  const FavoritePaymentPage({Key? key}) : super(key: key);

  @override
  _FavoritePaymentPageState createState() => _FavoritePaymentPageState();
}

class _FavoritePaymentPageState extends State<FavoritePaymentPage> {
  @override
  Widget build(BuildContext context) {
    return ISTListFav(menu: const [ISTFavoritEnum.pembayaran], context: context);
  }
}
