import 'package:bpd_aceh/components/ist_menu_container.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/infaq/Infaq_BaitulMalAceh/infaq_baitul_mal_aceh.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/topup/gopay/inqury_gopay.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/topup/linkAja/inqury_link_aja.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/topup/ovo/inqury_ovo.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:bpd_aceh/core/controller/controller_menu.dart';

class EmoneyScreen extends StatefulWidget {
  static const routeName = '/EmoneyScreen';

  const EmoneyScreen({Key? key}) : super(key: key);
  @override
  _EmoneyScreenState createState() => _EmoneyScreenState();
}

class _EmoneyScreenState extends State<EmoneyScreen> {
  final controllerMenu = Get.put(MenuController());
  bool press = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text(
          "E-Money",
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'Poppins',
          ),
        ),
//        actions: <Widget>[
//          IconButton(
//            icon: Icon(
//              Icons.notifications,
//              color: Colors.white,
//            ),
//            onPressed: () {
//              // _doLogout();
//            },
//          )
//        ],
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      backgroundColor: Colors.white,
      body: ListView(
        children: <Widget>[
          Visibility(
            visible: controllerMenu.getVisibilityLinkAja(),
            child: ListTile(
              title: const Text('LinkAja'),
              trailing: const Icon(Icons.arrow_forward_ios),
              onTap: () {
                Navigator.pushNamed(context, LinkAjaPage.routeName);
              },
            ),
          ),
          Visibility(
            visible: controllerMenu.getVisibilityLinkAja(),
            child: const Divider(
              thickness: 1,
              color: Colors.grey,
            ),
          ),
          Visibility(
            visible: controllerMenu.getVisibilityGopay(),
            child: ListTile(
                title: const Text('Gopay'),
                trailing: const Icon(Icons.arrow_forward_ios),
                onTap: () {
                  Navigator.pushNamed(context, GopayPage.routeName);
                }),
          ),
          Visibility(
            visible: controllerMenu.getVisibilityGopay(),
            child: const Divider(
              thickness: 1,
              color: Colors.grey,
            ),
          ),
          Visibility(
            visible: controllerMenu.getVisibilityOvo(),
            child: ListTile(
                title: const Text('OVO'),
                trailing: const Icon(Icons.arrow_forward_ios),
                onTap: () {
                  Navigator.pushNamed(context, OvoPage.routeName);
                }),
          ),
          Visibility(
            visible: controllerMenu.getVisibilityOvo(),
            child: const Divider(
              thickness: 1,
              color: Colors.grey,
            ),
          ),

          // Column(
          //   crossAxisAlignment: CrossAxisAlignment.start,
          //   children: <Widget>[
          //     ISTCardAccount(
          //       context: context,
          //       menu: ISTMenu.billpay,
          //     ),
          //     SizedBox(height: 8),
          //     SingleChildScrollView(
          //       child: buildMenuZakat(context),
          //     )
          //   ],
          // ),
        ],
      ),
      // Column(
      //   crossAxisAlignment: CrossAxisAlignment.start,
      //   children: <Widget>[
      //     ISTCardAccount(context: context, menu: ISTMenu.billpay),
      //     SizedBox(height: 8),
      //     SingleChildScrollView(
      //       child: buildMenuInfaq(context),
      //     )
      //   ],
      // ),
    );
  }
}

buildMenuInfaq(context) {
  return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      child: ISTMenuContainer(
        onTap: () {
          Navigator.pushNamed(context, InfaqMalBaitulAceh.routeName);
        },
        image: Image.asset(
          'assets/images/icon-baitulMal.png',
          width: 50,
        ),
        text: 'Baitul Mal Aceh',
      ));
}
