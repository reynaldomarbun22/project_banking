import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_card_account.dart';
import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/ist_style.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/samsat/confirmsamsat.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class Samsat extends StatefulWidget {
  static const routeName = '/Samsat';
  final String? kodeBayar;

  const Samsat({Key? key, this.kodeBayar}) : super(key: key);

  @override
  // ignore: no_logic_in_create_state
  _SamsatState createState() => _SamsatState(kodeBayar);
}

class _SamsatState extends State<Samsat> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final _eSamsatController = TextEditingController();

  final String? kodeBayar;
  String? redaksiname = "";

  _SamsatState(this.kodeBayar);

  // ignore: unused_field
  bool _eSetorError = false;
  // ignore: unused_field
  bool _autoValidate = false;
  bool favoritSamsat = false;

  @override
  void initState() {
    // if (kodeBayar != null) {
    //   _eSamsatController.text = kodeBayar;
    //   favoritSamsat = true;
    // }
    super.initState();
    _getRedaksi();
  }

  bool _validateInputs() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      return true;
    } else {
      setState(() {
        _autoValidate = true;
      });
      return false;
    }
  }

  bool _doValidate() {
    if (_validateInputs() != true) return false;
    bool _success = true;
    if (_eSamsatController.text.isEmpty) {
      setState(() {
        _eSetorError = true;
      });
      _success = false;
    } else {
      setState(() {
        _eSetorError = false;
      });
    }
    return _success;
  }

  _doTransfer() async {
    if (_doValidate()) {
      Map<String, Object> param = {};
      // param['kodeBayar'] = int.parse(_eSamsatController.text.replaceAll(",", ""));
      param['kodeBayar'] = _eSamsatController.text;

      final resp = await API.post(context, '/payment/esamsat/inquiry', param);
      if (resp != null && resp['code'] == 0) {
        List<ISTConfirmationItem> listParam = [];
        List<dynamic> listMap = resp['resi'];
        for (var item in listMap) {
          ISTConfirmationItem itemParam =
              ISTConfirmationItem(key: item['key'], value: item['value']);
          listParam.add(itemParam);
        }
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => SamsatConfirmation(
                      list: listParam,
                    )));
      } else {
        const DialogBox().showImageDialog(
            message: resp['message'],
            isError: true,
            image: const Image(
              image: AssetImage('assets/images/icon-failed.png'),
            ),
            buttonCancel: 'OK',
            onOk: () {},
            context: context);
      }
    }
  }

  _getRedaksi() async {
    final resp = await API.postNoLoading(context, '/redaksi/samsat', {});
    if (resp['code'] == 0) {
      setState(() {
        redaksiname = resp['redaksi'];
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text("Samsat Aceh",
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'Poppins',
            )),
        actions: const <Widget>[],
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      backgroundColor: Colors.white,
      body: Container(
        // padding: EdgeInsets.only(bottom: 20),
        color: Colors.white,
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              ISTCardAccount(
                context: context,
                menu: ISTMenu.billpay,
              ),
              const SizedBox(
                height: 16,
              ),
              Container(
                padding: const EdgeInsets.only(left: 16, right: 16),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Form(
                        // ignore: deprecated_member_use
                        autovalidateMode: AutovalidateMode.always,
                        key: _formKey,
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: <Widget>[
                              Container(
                                alignment: Alignment.topLeft,
                                child: const Text(
                                  'Kode Bayar :',
                                  style: TextStyle(color: Colors.black87),
                                ),
                              ),
                              Container(
                                alignment: Alignment.topLeft,
                                child: TextFormField(
                                  onChanged: (val) {
                                    setState(() {
                                      if (val.isEmpty) {
                                        _eSetorError = true;
                                      } else {
                                        _eSetorError = false;
                                      }
                                    });
                                  },
                                  inputFormatters: [
                                    FilteringTextInputFormatter.digitsOnly,
                                  ],
                                  controller: _eSamsatController,
                                  maxLength: 100,
                                  keyboardType: TextInputType.number,
                                  decoration: InputDecoration(
                                    errorText:
                                        _eSetorError ? "Mohon diisi" : null,
                                    counterText: '',
                                    hintText: 'Masukkan kode bayar e-samsat',
                                    hintStyle: ISTStyle.hintStyle,
                                    // prefixText: 'BL-',
                                    prefixStyle: const TextStyle(
                                      color: Colors.black,
                                      fontSize: 16,
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(
                                height: 8,
                              ),
                              Text('$redaksiname',
                                  textAlign: TextAlign.left,
                                  // '*Operator yang tersedia adalah Telkomsel, dan XL',
                                  style: const TextStyle(
                                      // wordSpacing: 34,
                                      color: Colors.grey,
                                      fontStyle: FontStyle.italic,
                                      fontSize: 12)),
                            ]),
                      ),
                    ]),
              ),
              const SizedBox(
                height: 32,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: ISTOutlineButton(
                  onPressed: () {
                    _doTransfer();
                  },
                  text: 'Lanjut',
                ),
              ),
              const SizedBox(
                height: 16,
              )
            ],
          ),
        ),
      ),
    );
  }
}
