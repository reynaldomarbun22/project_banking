import 'package:bpd_aceh/components/ist_receipt.dart';
import 'package:bpd_aceh/features/home/home_page.dart';
import 'package:bpd_aceh/features/splash/splash.dart';
import 'package:flutter/material.dart';

class InfaqBaznasReceiptPage extends StatefulWidget {
  static const routeName = '/infaq/baznasReceipt';
  final List<ISTReceiptItem>? list;
  final String? amount;
  final ISTReceiptStatus? status;
  final String? subtitle;

  const InfaqBaznasReceiptPage(
      {Key? key, this.list, this.amount, this.status, this.subtitle})
      : super(key: key);

  @override
  State<InfaqBaznasReceiptPage> createState() => _ResiFormState();
}

class _ResiFormState extends State<InfaqBaznasReceiptPage> {
  String dropdownValue = "0812345678";

  bool showPass = true;
  bool isLoading = false;

  @override
  Widget build(BuildContext context) {
    // ignore: unused_local_variable
    const buttonText = Text(
      'Selesai',
      style: TextStyle(
          fontWeight: FontWeight.w100, color: Colors.white, fontSize: 20),
    );

    _doFinish() {
      Navigator.pushNamedAndRemoveUntil(
          context, HomePage.routeName, ModalRoute.withName(Splash.routeName));
    }

    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
          backgroundColor: Colors.white,
          body: ISTReceipt(
              items: widget.list,
              onFinished: () {
                _doFinish();
              },
              title: 'Infaq Baznas',
              amount: widget.amount,
              status: ISTReceiptStatus.success)),
    );
  }
}
