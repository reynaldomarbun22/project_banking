import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/infaq/Infaq_RumahZakat/infaq_rumah_zakat_mpin.dart';
import 'package:flutter/material.dart';

class ConfirmationPageInfaqRumahZakat extends StatefulWidget {
  static const routeName = '/confirmationPageInfaqRumahZakat';

  final List<ISTConfirmationItem>? list;

  const ConfirmationPageInfaqRumahZakat({Key? key, this.list})
      : super(key: key);

  @override
  _ConfirmationPageInfaqRumahZakatState createState() =>
      _ConfirmationPageInfaqRumahZakatState();
}

class _ConfirmationPageInfaqRumahZakatState
    extends State<ConfirmationPageInfaqRumahZakat> {
  @override
  Widget build(BuildContext context) {
    _doTransfer() {
      Navigator.pushNamed(context, InfaqRumahZakatMpinPage.routeName);
    }

    return Scaffold(
        resizeToAvoidBottomInset: true,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          centerTitle: true,
          title: const Text("Rumah Zakat",
              style: TextStyle(color: Colors.white, fontFamily: 'Poppins')),
          // actions: <Widget>[
          //   IconButton(
          //     icon: Icon(
          //       Icons.notifications,
          //       color: Colors.white,
          //     ),
          //     onPressed: () {
          //       // _doLogout();
          //     },
          //   )
          // ],
          elevation: 0.0,
          backgroundColor: Pallete.primary,
        ),
        backgroundColor: Colors.white,
        body: ISTConfirmation(
            items: widget.list,
            title: 'Konfirmasi Layanan',
            onFinished: () {
              _doTransfer();
            }));
  }
}
