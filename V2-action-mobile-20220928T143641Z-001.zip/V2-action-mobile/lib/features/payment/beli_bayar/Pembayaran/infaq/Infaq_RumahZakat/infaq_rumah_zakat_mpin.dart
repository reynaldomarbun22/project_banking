import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_mpin.dart';
import 'package:bpd_aceh/components/ist_receipt.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/crypto/ist_crypto.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/infaq/Infaq_RumahZakat/infaq_rumah_zakat_receipt.dart';
import 'package:flutter/material.dart';

class InfaqRumahZakatMpinPage extends StatelessWidget {
  static const routeName = '/infaq/RumahZakatMPIN';

  const InfaqRumahZakatMpinPage({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    // ignore: unused_element
    _cekStatus() {}
    return ISTMPIN(
      onFinishedVal: (value) async {
        Map<String, Object> param = {};
        final String pinEnc = await ISTCrypto.encryptAES(value);
        param['mpin'] = pinEnc;
        final resp =
            await API.post(context, '/payment/infaq/4703/request', param);
        if (resp['code'] != null && resp['code'] == 0) {
          List<ISTReceiptItem> listParam = [];
          List<dynamic> listMap = resp['resi'];
          for (var item in listMap) {
            ISTReceiptItem itemParam =
                ISTReceiptItem(key: item['key'], value: item['value']);
            listParam.add(itemParam);
          }

          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => InfaqRumahZakatReceiptPage(
                        list: listParam,
                        amount: resp['amountStr'],
                        subtitle: "Layanan",
                        status: ISTReceiptStatus.success,
                      )));
        } else if (resp['code'] != null && resp['code'] != 0) {
          if (resp['code'] != -1002) {
            const DialogBox().showImageDialog(
                message: resp['message'],
                isError: true,
                buttonCancel: 'OK',
                onCancel: () {
                  Navigator.pop(context);
                  Navigator.pop(context);
                  Navigator.pop(context);
                },
                onOk: () {
                },
                context: context);
          } else {
            const DialogBox().showImageDialog(
                message: resp['message'],
                isError: true,
                buttonCancel: 'OK',
                onCancel: () {
                  Navigator.pop(context);
                  // Navigator.pop(context);
                  // Navigator.pop(context);
                },
                onOk: () {
                },
                context: context);
          }
        }
      },
    );
  }
}
