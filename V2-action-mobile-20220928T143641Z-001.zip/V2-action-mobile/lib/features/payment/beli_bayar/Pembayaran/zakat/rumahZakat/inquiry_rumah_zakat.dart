import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_card_account.dart';
import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/ist_style.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/core/utils/string_utils.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/zakat/rumahZakat/confirmation_rumah_zakat.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class RumahZakat extends StatefulWidget {
  static const routeName = '/rumahZakat';

  const RumahZakat({Key? key}) : super(key: key);

  @override
  _RumahZakatState createState() => _RumahZakatState();
}

class _RumahZakatState extends State<RumahZakat> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  // final _nominalRumahZakat = ISTConstants().moneyMaskedController;
  final _catatanlRumahZakat = TextEditingController();

  // ignore: unused_field
  bool _autoValidate = false;

  bool _doValidate() {
    if (_formKey.currentState!.validate()) {
      return true;
    } else {
      setState(() {
        _autoValidate = true;
      });
      return false;
    }
  }

  _doTransfer() async {
    if (_doValidate()) {
      Map<String, Object> param = {};

      // param['destAcctNo'] = _noRekBAScontroller.text.replaceAll("-", "");
      // param['amount'] = int.parse(_nominalRumahZakat.text.replaceAll(",", ""));
      param['memo'] = _catatanlRumahZakat.text;

      final resp =
          await API.post(context, '/payment/zakat/4503/inquiry', param);
      if (resp['code'] == 0) {
        List<ISTConfirmationItem> listParam = [];
        List<dynamic> listMap = resp['resi'];
        for (var item in listMap) {
          ISTConfirmationItem itemParam =
              ISTConfirmationItem(key: item['key'], value: item['value']);
          listParam.add(itemParam);
        }
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => ConfirmationRumahZakat(
                      list: listParam,
                    )));
      } else {
        const DialogBox().showImageDialog(
            message: resp['message'],
            isError: true,
            image: const Image(
              image: AssetImage('assets/images/icon-failed.png'),
            ),
            buttonCancel: 'OK',
            onOk: () {},
            context: context);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text(
          'Rumah Zakat',
          style: TextStyle(color: Colors.white, fontFamily: 'Poppins'),
        ),
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      body: Container(
        color: Colors.white,
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              ISTCardAccount(
                context: context,
                menu: ISTMenu.billpay,
              ),
              const SizedBox(
                height: 16,
              ),
              Container(
                padding: const EdgeInsets.only(left: 16, right: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Form(
                        // ignore: deprecated_member_use
                        autovalidateMode: AutovalidateMode.always,
                        key: _formKey,
                        child: Column(
                          children: <Widget>[
                            Container(
                              // padding: EdgeInsets.only(left: 8, right: 8),
                              alignment: Alignment.topLeft,
                              child: const Text(
                                'Nominal :',
                                style: TextStyle(color: Colors.black87),
                              ),
                            ),
                            Container(
                              // padding: EdgeInsets.only(left: 8, right: 8),
                              alignment: Alignment.topLeft,
                              child: TextFormField(
                                validator: (val) {
                                  if (val!.isEmpty || val == '0') {
                                    return "Mohon diisi";
                                  } else {
                                    return null;
                                  }
                                },
                                inputFormatters: [
                                  // ignore: deprecated_member_use
                                  FilteringTextInputFormatter.digitsOnly,
                                ],
                                // controller: _nominalRumahZakat,
                                maxLength: ISTConstants.nominalMaxLength,
                                onChanged: (value) {
                                  // if (_nominalRumahZakat.text.trim().isEmpty) {
                                  //   _nominalRumahZakat.text = '';
                                  // }
                                },
                                keyboardType: TextInputType.number,
                                decoration: const InputDecoration(
                                  counterText: '',
                                  // errorText: _nominalBasError ? "Mohon diisi" : null,
                                  prefixText: 'IDR ',
                                  prefixStyle: TextStyle(
                                    color: Colors.black,
                                  ),
                                  hintText: 'Masukkan nominal',
                                  hintStyle: ISTStyle.hintStyle,
                                ),
                              ),
                            ),
                            const SizedBox(
                              height: 16,
                            ),
                            Container(
                              // padding: EdgeInsets.only(left: 8, right: 8),
                              alignment: Alignment.topLeft,
                              child: const Text(
                                'Catatan :',
                                style: TextStyle(color: Colors.black87),
                              ),
                            ),
                            Container(
                              // padding: EdgeInsets.only(left: 8, right: 8),
                              alignment: Alignment.topLeft,
                              child: TextField(
                                inputFormatters: [
                                  StringUtils.alphaNumeric(),
                                ],
                                controller: _catatanlRumahZakat,
                                maxLength: ISTConstants.catatanTrfMaxLength,
                                decoration: const InputDecoration(
                                  hintText: 'Masukkan catatan',
                                  hintStyle: ISTStyle.hintStyle,
                                ),
                              ),
                            ),
                          ],
                        ))
                  ],
                ),
              ),
              const SizedBox(
                height: 50,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: ISTOutlineButton(
                  onPressed: () {
                    _doTransfer();
                  },
                  text: 'Lanjut',
                ),
              ),
              const SizedBox(
                height: 16,
              )
            ],
          ),
        ),
      ),
    );
  }
}
