import 'package:bpd_aceh/components/ist_receipt.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/features/home/home_page.dart';
import 'package:bpd_aceh/features/splash/splash.dart';
import 'package:flutter/material.dart';

class BaznasReceiptPageBas extends StatelessWidget {
  static const routeName = '/zakatBaznas/receiptbaznas';
  final List<ISTReceiptItem>? list;
  final String? amount;
  final ISTReceiptStatus? status;
  final String? noRef;
  final String? subtitle;
  const BaznasReceiptPageBas(
      {Key? key,
      this.list,
      this.noRef,
      this.amount,
      this.status,
      this.subtitle})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    // ignore: unused_local_variable
    const buttonText = Text(
      'Selesai',
      style: TextStyle(
          fontWeight: FontWeight.w100, color: Colors.white, fontSize: 20),
    );

    _doFinish() {
      Navigator.pushNamedAndRemoveUntil(
          context, HomePage.routeName, ModalRoute.withName(Splash.routeName));
    }

    _doAddFav() async {
      Map<String, Object?> param = {};
      param['idresi'] = noRef;
      final resp = await API.post(context, '/favorite/add', param);
      if (resp != null && resp['code'] == 0) {}
      Navigator.pop(context);
    }

    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
          backgroundColor: Colors.white,
          // appBar: AppBar(
          //   leading: Text(""),
          //   title: Text(
          //     'Resi',
          //     style: TextStyle(color: Colors.black),
          //   ),
          //   centerTitle: true,
          //   elevation: 0.0,
          //   iconTheme: IconThemeData(color: Colors.black),
          //   backgroundColor: Colors.transparent,
          // ),
          body: ISTReceipt(
              items: list,
              onTap: () {
                Navigator.pop(context);
                _doAddFav();
              },
              onFinished: () {
                _doFinish();
              },
              title: 'Zakat Baznas',
              amount: amount,
              status: ISTReceiptStatus.success)),
    );
  }
}
