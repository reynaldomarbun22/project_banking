import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/zakat/Baznaz/mpin_zakat_baznas.dart';
import 'package:flutter/material.dart';

class ConfirmationPageZakatBaznas extends StatefulWidget {
  static const routeName = '/confirmzakatBaznas/confirmZakatbaznas';

  final List<ISTConfirmationItem>? list;

  const ConfirmationPageZakatBaznas({Key? key, this.list}) : super(key: key);

  @override
  _ConfirmationPageZakatBaznasState createState() =>
      _ConfirmationPageZakatBaznasState();
}

class _ConfirmationPageZakatBaznasState
    extends State<ConfirmationPageZakatBaznas> {
  //  _doTransfer() {

  //     Navigator.pushNamed(context, ZakatBaznasMpinPage.routeName);
  //   }
  @override
  Widget build(BuildContext context) {
    _doTransfer() {
      Navigator.pushNamed(context, ZakatBaznasMpinPage.routeName);
    }

    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.chevron_left, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text("Badan Amil Zakat Nasional",
            style: TextStyle(color: Colors.white, fontFamily: 'Poppins')),
        // actions: <Widget>[
        //   IconButton(
        //     icon: Icon(
        //       Icons.notifications,
        //       color: Colors.white,
        //     ),
        //     onPressed: () {
        //       // _doLogout();
        //     },
        //   )
        // ],
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      backgroundColor: Colors.white,
      body: ISTConfirmation(
          items: widget.list,
          title: 'Konfirmasi Layanan',
          onFinished: () {
            _doTransfer();
          }),
    );
  }
}
