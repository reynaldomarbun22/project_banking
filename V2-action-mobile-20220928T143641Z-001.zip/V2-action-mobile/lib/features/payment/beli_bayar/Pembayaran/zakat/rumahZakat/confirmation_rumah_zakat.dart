import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/zakat/rumahZakat/mpin_rumah_zakat.dart';
import 'package:flutter/material.dart';

class ConfirmationRumahZakat extends StatefulWidget {
  static const routeName = '/confirmRumahZakat';
  final List<ISTConfirmationItem>? list;

  const ConfirmationRumahZakat({Key? key, this.list}) : super(key: key);

  @override
  _ConfirmationRumahZakatState createState() => _ConfirmationRumahZakatState();
}

class _ConfirmationRumahZakatState extends State<ConfirmationRumahZakat> {
  @override
  Widget build(BuildContext context) {
    _doTransfer() {
      Navigator.pushNamed(context, MpinRumahZakat.routeName);
    }

    return Scaffold(
      backgroundColor: Colors.white,
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text("Rumah Zakat",
            style: TextStyle(color: Colors.white, fontFamily: 'Poppins')),
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      body: ISTConfirmation(
          items: widget.list,
          title: 'Konfirmasi Layanan',
          onFinished: () {
            _doTransfer();
          }),
    );
  }
}
