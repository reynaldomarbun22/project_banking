import 'package:bpd_aceh/components/ist_menu_container.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/zakat/Baitul/zakat_baitul_mall_aceh.dart';
// import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/zakat/Baznaz/zakat_baznas.dart';
// import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/zakat/rumahZakat/inquiry_RumahZakat.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:bpd_aceh/core/controller/controller_menu.dart';

class ZakatScreen extends StatefulWidget {
  static const routeName = '/zakatScreen';

  const ZakatScreen({Key? key}) : super(key: key);

  @override
  _ZakatScreenState createState() => _ZakatScreenState();
}

class _ZakatScreenState extends State<ZakatScreen> {
  final controllerMenu = Get.put(MenuController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text(
          'Zakat',
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'Poppins',
          ),
        ),
        // actions: <Widget>[
        //   IconButton(
        //     icon: Icon(
        //       Icons.notifications,
        //       color: Colors.white,
        //     ),
        //     onPressed: () {
        //       // _doLogout();
        //     },
        //   )
        // ],
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      body: Container(
        padding: const EdgeInsets.only(bottom: 16),
        color: Colors.white,
        child: ListView(
          children: <Widget>[
            // Visibility(
            // visible: controllerMenu.getVisibilityZakatBMA(),
            // child:
            ListTile(
              title: const Text('Baitul Mal Aceh'),
              trailing: const Icon(Icons.arrow_forward_ios),
              onTap: () {
                Navigator.pushNamed(context, ZakatMalBaitulAceh.routeName);
              },
            ),
            // ),
            // Visibility(
            // visible: controllerMenu.getVisibilityZakatBMA(),
            // child:
            const Divider(
              thickness: 1,
              color: Colors.grey,
            ),
            // ),
            // ListTile(
            //     title: Text('Baznas(ACT/Rumah Yatim)'),
            //     trailing: Icon(Icons.arrow_forward_ios),
            //     onTap: () {
            //       Navigator.pushNamed(context, ZakatBaznas.routeName);
            //     }),
            // Divider(
            //   thickness: 1,
            //   color: Colors.grey,
            // ),
            // ListTile(
            //     title: Text('Rumah Zakat'),
            //     trailing: Icon(Icons.arrow_forward_ios),
            //     onTap: () {
            //       Navigator.pushNamed(context, RumahZakat.routeName);
            //     }),

            // Column(
            //   crossAxisAlignment: CrossAxisAlignment.start,
            //   children: <Widget>[
            //     ISTCardAccount(
            //       context: context,
            //       menu: ISTMenu.billpay,
            //     ),
            //     SizedBox(height: 8),
            //     SingleChildScrollView(
            //       child: buildMenuZakat(context),
            //     )
            //   ],
            // ),
          ],
        ),
        // Column(
        //   crossAxisAlignment: CrossAxisAlignment.start,
        //   children: <Widget>[
        //     ISTCardAccount(
        //       context: context,
        //       menu: ISTMenu.billpay,
        //     ),
        //     SizedBox(height: 8),
        //     SingleChildScrollView(
        //       child: buildMenuZakat(context),
        //     )
        //   ],
        // ),
      ),
    );
  }
}

buildMenuZakat(context) {
  return Padding(
    padding: const EdgeInsets.symmetric(horizontal: 8.0),
    child: ISTMenuContainer(
      onTap: () {
        Navigator.pushNamed(context, ZakatMalBaitulAceh.routeName);
      },
      image: Image.asset(
        'assets/images/icon-baitulMal.png',
        width: 50,
      ),
      text: 'Baitul Mal Aceh',
    ),
  );
}
