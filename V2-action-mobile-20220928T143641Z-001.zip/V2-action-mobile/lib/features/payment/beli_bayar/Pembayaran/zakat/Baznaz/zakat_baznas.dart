import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_card_account.dart';
import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/ist_style.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/core/utils/string_utils.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/zakat/Baznaz/confirmation_page_zakat_baznas.dart';
// import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/zakat/confirmation_page_zakat_baznas.dart';
// import 'package:bpd_aceh/features/payment/beli_bayar/infaq/confirmation_page_infaq_baznas.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class ZakatBaznas extends StatefulWidget {
  static const routeName = '/zakatBaznas';

  const ZakatBaznas({Key? key}) : super(key: key);

  @override
  _ZakatBaznasState createState() => _ZakatBaznasState();
}

class _ZakatBaznasState extends State<ZakatBaznas> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  // TextEditingController _nominalZakatBaznas =
  //     ISTConstants().moneyMaskedController;
  final TextEditingController _catatanZakatBaznas = TextEditingController();
  // ignore: unused_field
  bool _autoValidate = false;

  bool _doValidate() {
    if (_formKey.currentState!.validate()) {
      return true;
    } else {
      setState(() {
        _autoValidate = true;
      });
      return false;
    }
  }

  // bool _nominalZakatBaznasNumberError = false;
  // bool _catatanZakatBaznasError = false;

  _doTransfer() async {
    if (_doValidate()) {
      Map<String, Object> param = {};

      // param['destAcctNo'] = _noRekBAScontroller.text.replaceAll("-", "");
      // param['amount'] = int.parse(_nominalZakatBaznas.text.replaceAll(",", ""));
      param['memo'] = _catatanZakatBaznas.text;

      final resp =
          await API.post(context, '/payment/zakat/4502/inquiry', param);
      if (resp['code'] == 0) {
        List<ISTConfirmationItem> listParam = [];
        List<dynamic> listMap = resp['resi'];
        for (var item in listMap) {
          ISTConfirmationItem itemParam =
              ISTConfirmationItem(key: item['key'], value: item['value']);
          listParam.add(itemParam);
        }
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => ConfirmationPageZakatBaznas(
                      list: listParam,
                    )));
      } else {
        const DialogBox().showImageDialog(
            message: resp['message'],
            isError: true,
            image: const Image(
              image: AssetImage('assets/images/icon-failed.png'),
            ),
            buttonCancel: 'OK',
            onOk: () {},
            context: context);
      }
    }
  }

  // bool _doValidate() {
  //   bool _success = true;
  //   if (_nominalZakatBaznas.text.trim().isEmpty ||
  //       _nominalZakatBaznas.text.trim() == '0') {
  //     setState(() {
  //       _nominalZakatBaznasNumberError = true;
  //     });
  //     _success = false;
  //   } else {
  //     setState(() {
  //       _catatanZakatBaznasError = false;
  //     });
  //   }

  // if (_nominalInfaqBaznas.text.trim().isEmpty ||
  //     _nominalInfaqBaznas.text.trim() == '0') {
  //   setState(() {
  //     _catatanInfaqBaznasError = true;
  //   });
  //   _success = false;
  // } else {
  //   setState(() {
  //     _catatanInfaqBaznasError = false;
  //   });
  // }
  // return _success;
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        // resizeToAvoidBottomInset: true,
        appBar: AppBar(
          leading: IconButton(
            // icon: Icon(Icons.chevron_left, color: Colors.white),
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white),

            onPressed: () {
              Navigator.pop(context);
            },
          ),
          centerTitle: true,
          title: const Text("Badan Amil Zakat Nasional",
              style: TextStyle(color: Colors.white, fontFamily: 'Poppins')),
          elevation: 0.0,
          backgroundColor: Pallete.primary,
        ),
        body: Container(
          color: Colors.white,
          child: SingleChildScrollView(
            child: Column(children: <Widget>[
              const ISTCardAccount(context: null, menu: ISTMenu.billpay),
              const SizedBox(height: 16),
              Container(
                // alignment: Alignment.center,
                padding: const EdgeInsets.only(left: 16, right: 16),
                color: Colors.white,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Form(
                        // ignore: deprecated_member_use
                        autovalidateMode: AutovalidateMode.always,
                        key: _formKey,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: <Widget>[
                            Container(
                              alignment: Alignment.topLeft,
                              child: const Text(
                                "NOMINAL",
                              ),
                            ),
                            Container(
                              alignment: Alignment.topLeft,
                              child: TextFormField(
                                // controller: _nominalZakatBaznas,
                                keyboardType: TextInputType.number,
                                maxLength: ISTConstants.nominalMaxLength,
                                inputFormatters: <TextInputFormatter>[
                                  // ignore: deprecated_member_use
                                  FilteringTextInputFormatter.digitsOnly,
                                ],
                                validator: (val) {
                                  if (val!.isEmpty || val == '0') {
                                    return "Mohon diisi";
                                  } else {
                                    return null;
                                  }
                                },
                                decoration: const InputDecoration(
                                  counterText: '',
                                  prefixText: "IDR ",
                                  prefixStyle: TextStyle(
                                    color: Colors.black,
                                  ),
                                  hintText: "Masukkan nomor rekening",
                                  hintStyle: ISTStyle.hintStyle,
                                ),
                                onChanged: (value) {
                                  // if (_nominalZakatBaznas.text.trim().isEmpty) {
                                  //   _nominalZakatBaznas.text = '';
                                  // }
                                },
                              ),
                            ),
                            const SizedBox(height: 16),
                            Container(
                              alignment: Alignment.topLeft,
                              child: const Text(
                                "CATATAN",
                              ),
                            ),
                            Container(
                              alignment: Alignment.topLeft,
                              child: TextFormField(
                                controller: _catatanZakatBaznas,
                                inputFormatters: [
                                  StringUtils.alphaNumeric(),
                                ],
                                maxLength: ISTConstants.catatanTrfMaxLength,
                                decoration: const InputDecoration(
                                  hintText: "Masukkan Catatan",
                                  hintStyle: ISTStyle.hintStyle,
                                ),
                              ),
                            ),
                          ],
                        )),
                  ],
                ),
              ),
              const SizedBox(
                height: 50,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: ISTOutlineButton(
                  onPressed: () {
                    _doTransfer();
                  },
                  text: 'Lanjut',
                ),
              ),
              const SizedBox(
                height: 16,
              )
            ]),
          ),
        ));
  }
}
