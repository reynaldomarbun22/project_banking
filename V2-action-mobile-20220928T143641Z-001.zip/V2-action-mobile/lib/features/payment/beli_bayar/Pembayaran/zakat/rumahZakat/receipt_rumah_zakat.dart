import 'package:bpd_aceh/components/ist_receipt.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/features/home/home_page.dart';
import 'package:bpd_aceh/features/splash/splash.dart';
import 'package:flutter/material.dart';

class ReceiptRumahZakat extends StatelessWidget {
  static const routeName = '/receiptRumahZakat';
  final List<ISTReceiptItem>? list;
  final String? amount;
  final ISTReceiptStatus? status;
  final String? noRef;
  final String? subtitle;

  const ReceiptRumahZakat(
      {Key? key,
      this.noRef,
      this.list,
      this.amount,
      this.status,
      this.subtitle})
      : super(key: key);

//   @override
//   _ReceiptRumahZakatState createState() => _ReceiptRumahZakatState();
// }

// class _ReceiptRumahZakatState extends State<ReceiptRumahZakat> {
//   bool showPass = true;
//   bool isLoading = false;

  @override
  Widget build(BuildContext context) {
    _doFinish() {
      Navigator.pushNamedAndRemoveUntil(
          context, HomePage.routeName, ModalRoute.withName(Splash.routeName));
    }

    _doAddFav() async {
      Map<String, Object?> param = {};
      param['idresi'] = noRef;
      final resp = await API.post(context, '/favorite/add', param);
      if (resp != null && resp['code'] == 0) {}
      Navigator.pop(context);
    }

    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        backgroundColor: Colors.white,
        body: ISTReceipt(
            onTap: () {
              Navigator.pop(context);
              _doAddFav();
            },
            items: list,
            onFinished: () {
              _doFinish();
            },
            title: 'Zakat Rumah Zakat',
            amount: amount,
            status: ISTReceiptStatus.success),
      ),
    );
  }
}
