import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_mpin.dart';
import 'package:bpd_aceh/components/ist_receipt.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/crypto/ist_crypto.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/zakat/Baznaz/baznaz_receipt.dart';
import 'package:flutter/material.dart';

class ZakatBaznasMpinPage extends StatelessWidget {
  static const routeName = '/mpinBaznas';

  const ZakatBaznasMpinPage({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return ISTMPIN(
      appBarTitle: 'Badan Amil Zakat Nasional',
      onFinishedVal: (value) async {
        Map<String, Object> param = {};
        final String pinEnc = await ISTCrypto.encryptAES(value);
        param['mpin'] = pinEnc;

        final resp = await API.post(
            context, '/payment/zakat/BAITULMALACEH/request', param);
        if (resp['code'] != null && resp['code'] == 0) {
          List<ISTReceiptItem> listParam = [];
          List<dynamic> listMap = resp['resi'];
          for (var item in listMap) {
            ISTReceiptItem itemParam =
                ISTReceiptItem(key: item['key'], value: item['value']);
            listParam.add(itemParam);
          }

          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => BaznasReceiptPageBas(
                        list: listParam,
                        amount: resp['amountStr'],
                        subtitle: "Layanan",
                        // keterangan1: resp['additionalinfo'],
                        // keterangan2: resp['additionalinfo1'],
                        status: ISTReceiptStatus.success,
                      )));
        } else if (resp['code'] != null && resp['code'] != 0) {
          if (resp['code'] != -1002) {
            const DialogBox().showImageDialog(
                message: resp['message'],
                isError: true,
                buttonCancel: 'OK',
                onCancel: () {
                  Navigator.pop(context);
                  Navigator.pop(context);
                  Navigator.pop(context);
                },
                onOk: () {},
                context: context);
          } else {
            const DialogBox().showImageDialog(
                message: resp['message'],
                isError: true,
                buttonCancel: 'OK',
                onCancel: () {
                  Navigator.pop(context);
                },
                onOk: () {},
                context: context);
          }
        }
      },
    );
  }
}
