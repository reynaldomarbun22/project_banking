import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/zakat/Baitul/mpinBaitul/mpin_baitul.dart';
import 'package:flutter/material.dart';

class ConfirmationPageMallZakatBaitul extends StatefulWidget {
  static const routeName = '/baitul/confirmBaitul';

  final List<ISTConfirmationItem>? list;

  const ConfirmationPageMallZakatBaitul({Key? key, this.list})
      : super(key: key);

  @override
  _ConfirmationPageMallZakatBaitulState createState() =>
      _ConfirmationPageMallZakatBaitulState();
}

class _ConfirmationPageMallZakatBaitulState
    extends State<ConfirmationPageMallZakatBaitul> {
  @override
  Widget build(BuildContext context) {
    _doTransfer() {
      Navigator.pushNamed(context, ZakatBaitulMpinPage.routeName);
    }

    return Scaffold(
        resizeToAvoidBottomInset: true,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          centerTitle: true,
          title: const Text("Baitul Mal Aceh",
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'Poppins',
              )),
          // actions: <Widget>[
          //   IconButton(
          //     icon: Icon(
          //       Icons.notifications,
          //       color: Colors.white,
          //     ),
          //     onPressed: () {
          //       // _doLogout();
          //     },
          //   )
          // ],
          elevation: 0.0,
          backgroundColor: Pallete.primary,
        ),
        backgroundColor: Colors.white,
        body: ISTConfirmation(
            items: widget.list,
            title: 'Konfirmasi Layanan',
            onFinished: () {
              _doTransfer();
            })

        // body:  ISTConfirmation(
        //       items: <ISTConfirmationItem>[
        //         ISTConfirmationItem(
        //           key: 'Transfer dari',
        //           value: 'Bank Aceh\n610.02.20.022990-3\nYosua Nababan',
        //         ),
        //         ISTConfirmationItem(
        //           key: 'Nominal',
        //           value: 'IDR 1.000.000',
        //         ),
        //         ISTConfirmationItem(
        //           key: 'Catatan',
        //           value: 'Biaya pembangunan Masjid Raya Aceh',
        //         ),
        //         ISTConfirmationItem(
        //           key: 'Biaya Admin',
        //           value: 'IDR 1.000',
        //         ),
        //         ISTConfirmationItem(
        //           key: 'No. Referensi',
        //           value: '2151251',
        //         ),
        //         ISTConfirmationItem(
        //           key: 'Tanggal Transaksi',
        //           value: '02/02/2020 18:18',
        //         ),
        //       ],
        //       title: 'Konfirmasi Transfer',
        //       onFinished: () {
        //         // _doTransfer();
        //       }),
        );
  }
}
