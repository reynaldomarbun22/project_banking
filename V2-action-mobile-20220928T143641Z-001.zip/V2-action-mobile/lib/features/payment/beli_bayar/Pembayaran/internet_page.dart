import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/Paket_Data/inq_paketdata/inquiripaket.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:bpd_aceh/core/controller/controller_menu.dart';

class InternetScreen extends StatefulWidget {
  static const routeName = '/InternetScreen';

  const InternetScreen({Key? key}) : super(key: key);
  @override
  _InternetScreenState createState() => _InternetScreenState();
}

class _InternetScreenState extends State<InternetScreen> {
  final controllerMenu = Get.put(MenuController());
  bool press = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text(
          "Internet",
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'Poppins',
          ),
        ),
//        actions: <Widget>[
//          IconButton(
//            icon: Icon(
//              Icons.notifications,
//              color: Colors.white,
//            ),
//            onPressed: () {
//              // _doLogout();
//            },
//          )
//        ],
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      backgroundColor: Colors.white,
      body: ListView(
        children: <Widget>[
          Visibility(
            visible: controllerMenu.getVisibilityDataInternet(),
            child: ListTile(
              title: const Text('Data Internet'),
              trailing: const Icon(Icons.arrow_forward_ios),
              onTap: () {
                Navigator.pushNamed(context, InquiryPaketData.routeName);
              },
            ),
          ),
          Visibility(
            visible: controllerMenu.getVisibilityDataInternet(),
            child: const Divider(
              thickness: 1,
              color: Colors.grey,
            ),
          ),
        ],
      ),
    );
  }
}
