import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_card_account.dart';
import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/ist_style.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/utils/string_utils.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PLN/prabayarPLN.dart/denom_prabayar.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PLN/prabayarPLN.dart/plnconfirm.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class ListrikPrabayarPage extends StatefulWidget {
  static const routeName = '/listrikPrabayarPage';
  final String? noInvoice;

  const ListrikPrabayarPage({Key? key, this.noInvoice}) : super(key: key);

  @override
  _ListrikPrabayarPageState createState() =>
      // ignore: no_logic_in_create_state
      _ListrikPrabayarPageState(noInvoice);
}

class _ListrikPrabayarPageState extends State<ListrikPrabayarPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final String? noInvoice;
  _ListrikPrabayarPageState(this.noInvoice);
  @override
  void initState() {
    if (noInvoice != null) {
      _idPelanggan.text = noInvoice!;
      favoritPrabayar = true;
      _getDenom();
    }
    super.initState();
    // _getDenom();
  }

  // ignore: unused_field
  bool _autoValidate = false;
  bool favoritPrabayar = false;
  final bool _dropError = false;

  final _idPelanggan = TextEditingController();

  bool _doValidate() {
    if (_formKey.currentState!.validate()) {
      return true;
    } else {
      setState(() {
        _autoValidate = true;
      });
      return false;
    }
  }

  String? result;

  _doInquiry() async {
    if (_doValidate()) {
      Map<String, Object?> param = {};
      param['idPelanggan'] = int.parse(_idPelanggan.text.replaceAll(",", ""));
      param['denomIdx'] = _selected!.denomIndex;
      print(param);

      final resp = await API.post(context, '/pln-prepaid/Inquiry', param);
      // print(resp);
      if (resp['code'] == 0 && resp['code'] != null) {
        List<ISTConfirmationItem> listParam = [];
        List<dynamic> listMap = resp['resi'];
        for (var item in listMap) {
          ISTConfirmationItem itemParam =
              ISTConfirmationItem(key: item['key'], value: item['value']);
          listParam.add(itemParam);
        }
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => ListrikConfirmationPrabayar(
                      list: listParam,
                    )));
      } else {
        const DialogBox().showImageDialog(
            message: resp['message'],
            isError: true,
            image: const Image(
              image: AssetImage('assets/images/icon-failed.png'),
            ),
            buttonCancel: 'OK',
            onOk: () {},
            context: context);
      }
    }
  }

  DenomItem? _selected;
  List<DenomItem> _list = [];

  _getDenom() async {
    try {
      setState(() {
        _selected = null;
      });
      if (_list.isNotEmpty) {
        Future.delayed(Duration.zero);
        _list.clear();
      }
      // Map<String, Object> param = new Map();
      // param['idPel'] = _idPelanggan.text;
      final resp = await API.postNoLoading(context, '/pln-prepaid/denom', {});
      // print(resp);
      if (resp['code'] == 0) {
        var listResp = resp['denomPLN'];
        List<dynamic> listRespMini = (listResp);
        List<DenomItem> listDenom = [];
        //for (var item in listRespMini) {
        for (var i = 0; i < listRespMini.length; i++) {
          DenomItem items = DenomItem(
            denomIndex: i,
            denomination: listRespMini[i]['denomination'].toString(),
            denominationDesc: listRespMini[i]['denominationDesc'],
          );

          listDenom.add(items);
        }

        setState(() {
          _list = listDenom;
        });
      } else {
        print("asdasdasdasda");
      }
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text("Prepaid",
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'Poppins',
            )),
        actions: const <Widget>[],
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      backgroundColor: Colors.white,
      body: Container(
        color: Colors.white,
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              ISTCardAccount(
                context: context,
                menu: ISTMenu.billpay,
              ),
              const SizedBox(
                height: 16,
              ),
              Container(
                padding: const EdgeInsets.only(left: 16, right: 16),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Form(
                        // ignore: deprecated_member_use
                        autovalidateMode: AutovalidateMode.always,
                        key: _formKey,
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: <Widget>[
                              Container(
                                // padding: EdgeInsets.only(left: 8, right: 8),
                                alignment: Alignment.topLeft,
                                child: const Text(
                                  'IDPEL/NO METER :',
                                  style: TextStyle(color: Colors.black87),
                                ),
                              ),
                              favoritPrabayar
                                  ? Column(children: [
                                      Container(
                                          alignment: Alignment.topLeft,
                                          child: Text('$noInvoice')),
                                      const Divider(
                                        thickness: 1.5,
                                      )
                                    ])
                                  : Container(
                                      alignment: Alignment.topLeft,
                                      child: TextFormField(
                                        validator: (val) {
                                          if (val!.isEmpty || val == '0') {
                                            return "Mohon diisi";
                                          } else {
                                            return null;
                                          }
                                        },
                                        inputFormatters: [
                                          // ignore: deprecated_member_use
                                          FilteringTextInputFormatter
                                              .digitsOnly,
                                          StringUtils.noSpace()
                                        ],
                                        controller: _idPelanggan,
                                        onChanged: (val) {
                                          if (_idPelanggan.text.isNotEmpty) {
                                            _getDenom();
                                          } else {
                                            setState(() {
                                              _list.clear();
                                            });
                                          }
                                        },
                                        keyboardType: TextInputType.number,
                                        decoration: const InputDecoration(
                                          hintText: 'Masukkan IDPEL/NO METER',
                                          hintStyle: ISTStyle.hintStyle,
                                        ),
                                      ),
                                    ),
                              const SizedBox(
                                height: 8,
                              ),
                              Container(
                                // padding: EdgeInsets.only(left: 8, right: 8),
                                alignment: Alignment.topLeft,
                                child: const Text(
                                  'NOMINAL :',
                                  style: TextStyle(color: Colors.black87),
                                ),
                              ),
                              DropdownButton<DenomItem>(
                                value: _list.isEmpty
                                    ? null
                                    : _selected,
                                hint: const Text("Pilih NOMINAL",
                                    style: ISTStyle.hintStyle),
                                isExpanded: true,
                                icon: const Icon(Icons.arrow_drop_down),
                                iconSize: 30,
                                // elevation: 16,
                                style: const TextStyle(color: Colors.black),
                                underline: Container(
                                  height: 1,
                                  color: Colors.grey,
                                ),
                                // iconDisabledColor: Colors.grey,

                                iconEnabledColor: Pallete.primary,
                                isDense: false,
                                onChanged: (DenomItem? newValue) {
                                  setState(() {
                                    _selected = newValue;
                                  });
                                },
                                items: _list.map((DenomItem _list) {
                                  return DropdownMenuItem<DenomItem>(
                                    value: _list,
                                    child: Row(
                                      children: <Widget>[
                                        Text(
                                          _list.denominationDesc!,
                                        ),
                                      ],
                                    ),
                                  );
                                }).toList(),
                              ),
                              _dropError
                                  ? Container(
                                      alignment: Alignment.centerLeft,
                                      child: const Text(
                                        'Mohon pilih Nominal',
                                        style: TextStyle(color: Colors.red),
                                      ),
                                    )
                                  : const SizedBox.shrink(),
                            ]),
                      ),
                    ]),
              ),
              const SizedBox(
                height: 50,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: ISTOutlineButton(
                  onPressed: () {
                    _doInquiry();
                  },
                  text: 'Lanjut',
                ),
              ),
              const SizedBox(
                height: 16,
              )
            ],
          ),
        ),
      ),
    );
  }
}
