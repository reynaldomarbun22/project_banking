// import 'dart:convert';
// import 'dart:ui';
// import 'package:bpd_aceh/components/ISTReceipt.dart';
// import 'package:bpd_aceh/components/ISTReceiptRepo.dart';
// import 'package:bpd_aceh/components/Pallete.dart';
// import 'package:bpd_aceh/core/api/api.dart';
// import 'package:bpd_aceh/features/home/home_page.dart';
// import 'package:bpd_aceh/features/inbox/inboxDB.dart';
// import 'package:bpd_aceh/features/inbox/model/inboxModel.dart';
// import 'package:bpd_aceh/features/splash/splash.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';

// class ListrikReceiptPrabayar extends StatelessWidget {
//   static const routeName = '/listrikreceiptPrabayar';
//   final List<ISTReceiptItem> list;
//   final List<ISTReceiptItemInbox> lists;
//   final String amount;
//   final ISTReceiptStatus status;
//   final String noRef;
//   final String img;
//   final String title;
//   final String detail;
//   final String time;
//   final String date;
//   final String waktu;
//   final String subtitle;
//   final String destAcc;

//   const ListrikReceiptPrabayar({
//     Key key,
//     this.destAcc,
//     this.subtitle,
//     @ this.lists,
//     @ this.waktu,
//     @ this.list,
//     @ this.date,
//     @ this.time,
//     @ this.detail,
//     @ this.amount,
//     @ this.status,
//     @ this.noRef,
//     @ this.img,
//     @ this.title,
//   }) : super(key: key);
//   @override
//   Widget build(BuildContext context) {
//     _saveInbox() async {
//       InboxDBRepository repo = InboxDBRepository();
//       await repo.open();
//       InboxModel model = InboxModel();
//       model.subtitle = subtitle;
//       model.listresi = jsonEncode(lists);
//       model.amount = amount;
//       model.time = time;
//       model.date = date;
//       model.detail = detail;
//       model.image = img;
//       model.status = status.index.toString();
//       model.title = title;
//       model.noRef = noRef;
//       await repo.insert(model);
//       await repo.close();
//     }

//     _doFinish() {
//       Navigator.pushNamedAndRemoveUntil(
//           context, HomePage.routeName, ModalRoute.withName(Splash.routeName));
//     }

//     _doAddFav() async {
//       Map<String, Object> param = new Map();
//       param['idresi'] = noRef;
//       final resp = await API.post(context, '/favorite/add', param);
//       if (resp != null && resp['code'] == 0) {
//         showDialog(
//           context: context,
//           barrierDismissible: false,
//           useRootNavigator: true,
//           builder: (BuildContext context) {
//             return AlertDialog(
//               shape: RoundedRectangleBorder(
//                 borderRadius: BorderRadius.all(Radius.circular(20.0)),
//               ),
//               content: SingleChildScrollView(
//                 child: Container(
//                   child: Column(
//                     children: <Widget>[
//                       Container(
//                         child: Text(
//                           'Berhasil',
//                           style:
//                               TextStyle(color: Pallete.primary, fontSize: 20),
//                         ),
//                       ),
//                       SizedBox(
//                         height: 4,
//                       ),
//                       Image(
//                         height: MediaQuery.of(context).size.width * 0.25,
//                         image: AssetImage('assets/images/icon-success.png'),
//                       ),
//                       SizedBox(
//                         height: 4,
//                       ),
//                       Container(
//                         child: Text('Favorit berhasil di tambahkan',
//                             textAlign: TextAlign.center),
//                       ),
//                       SizedBox(
//                         height: 8,
//                       ),
//                       Container(
//                         alignment: Alignment.center,
//                         child: OutlineButton(
//                           onPressed: () {
//                             Navigator.pop(context);
//                           },
//                           borderSide: BorderSide(
//                             color: Pallete.PRIMARY,
//                           ),
//                           splashColor: Pallete.PRIMARY,
//                           shape: RoundedRectangleBorder(
//                             borderRadius: BorderRadius.all(Radius.circular(18)),
//                           ),
//                           child: Text(
//                             "Ok",
//                             style: Theme.of(context)
//                                 .textTheme
//                                 .bodyText1
//                                 .copyWith(
//                                     fontWeight: FontWeight.w600,
//                                     color: Pallete.PRIMARY),
//                           ),
//                         ),
//                       )
//                     ],
//                   ),
//                 ),
//               ),
//               //actions: _checkbutton(context),
//             );
//           },
//         );
//       } else {
//         showDialog(
//           context: context,
//           barrierDismissible: false,
//           useRootNavigator: true,
//           builder: (BuildContext context) {
//             return AlertDialog(
//               // contentPadding: EdgeInsets.all(8),
//               shape: RoundedRectangleBorder(
//                 borderRadius: BorderRadius.all(Radius.circular(20.0)),
//               ),
//               content: SingleChildScrollView(
//                 child: Container(
//                   child: Column(
//                     children: <Widget>[
//                       Container(
//                         child: Text(
//                           'Peringatan',
//                           style: TextStyle(
//                             color: Colors.red,
//                             fontSize: 20,
//                           ),
//                         ),
//                       ),
//                       SizedBox(
//                         height: 4,
//                       ),
//                       Image(
//                         height: MediaQuery.of(context).size.width * 0.25,
//                         image: AssetImage('assets/images/icon-warning.png'),
//                       ),
//                       SizedBox(
//                         height: 4,
//                       ),
//                       Container(
//                         child:
//                             Text(resp['message'], textAlign: TextAlign.center),
//                       ),
//                       SizedBox(
//                         height: 8,
//                       ),
//                       Container(
//                         alignment: Alignment.center,
//                         child: OutlineButton(
//                           onPressed: () {
//                             Navigator.pop(context);
//                           },
//                           borderSide: BorderSide(
//                             color: Colors.red,
//                           ),
//                           // splashColor: Colors.red,
//                           shape: RoundedRectangleBorder(
//                             borderRadius: BorderRadius.all(Radius.circular(18)),
//                           ),
//                           child: Text(
//                             "Batal",
//                             style: Theme.of(context)
//                                 .textTheme
//                                 .bodyText1
//                                 .copyWith(
//                                     fontWeight: FontWeight.w600,
//                                     color: Colors.red),
//                           ),
//                         ),
//                       )
//                     ],
//                   ),
//                 ),
//               ),
//               //actions: _checkbutton(context),
//             );
//           },
//         );
//       }
//     }

//     return WillPopScope(
//       onWillPop: () async => false,
//       child: Scaffold(
//           backgroundColor: Colors.white,
//           body: ISTReceipt(
//               date: waktu,
//               onTap: () {
//                 _doAddFav();
//                 Navigator.pop(context);
//               },
//               items: list,
//               onFinished: () {
//                 _saveInbox();
//                 _doFinish();
//               },
//               title: title,
//               amount: amount,
//               status: status)),
//     );
//   }
// }
import 'package:bpd_aceh/components/ist_receipt.dart';
import 'package:bpd_aceh/components/ist_receipt_repo.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/features/home/home_page.dart';
import 'package:bpd_aceh/features/inbox/inbox_db.dart';
import 'package:bpd_aceh/features/splash/splash.dart';
import 'package:flutter/material.dart';

class ListrikReceiptPrabayar extends StatefulWidget {
  static const routeName = '/listrikreceiptPrabayar';
  final List<ISTReceiptItem>? list;
  final List<ISTReceiptItemInbox>? lists;
  final String? amount;
  final ISTReceiptStatus? status;
  final String? noRef;
  final String? img;
  final String? title;
  final String? detail;
  final String? additional;
  final String? time;
  final String? date;
  final String? waktu;
  final String? subtitle;
  final String? destAcc;

  const ListrikReceiptPrabayar({
    Key? key,
    this.destAcc,
    this.subtitle,
    this.lists,
    this.waktu,
    this.list,
    this.date,
    this.time,
    this.detail,
    this.amount,
    this.status,
    this.noRef,
    this.img,
    this.title,
    keterangan1,
    keterangan2,
    this.additional,
  }) : super(key: key);

  @override
  _ListrikReceiptPrabayarState createState() => _ListrikReceiptPrabayarState();
}

class _ListrikReceiptPrabayarState extends State<ListrikReceiptPrabayar> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    _doFinish() {
      Navigator.pushNamedAndRemoveUntil(
          context, HomePage.routeName, ModalRoute.withName(Splash.routeName));
    }

    _doAddFav() async {
      Map<String, Object?> param = {};
      param['idresi'] = widget.noRef;
      final resp = await API.post(context, '/favorite/add', param);
      if (resp != null && resp['code'] == 0) {
        showDialog(
          context: context,
          barrierDismissible: false,
          useRootNavigator: true,
          builder: (BuildContext context) {
            return AlertDialog(
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(20.0)),
              ),
              content: SingleChildScrollView(
                child: Column(
                  children: <Widget>[
                    const Text(
                      'Berhasil',
                      style: TextStyle(color: Pallete.primary, fontSize: 20),
                    ),
                    const SizedBox(
                      height: 4,
                    ),
                    Image(
                      height: MediaQuery.of(context).size.width * 0.25,
                      image: const AssetImage('assets/images/icon-success.png'),
                    ),
                    const SizedBox(
                      height: 4,
                    ),
                    const Text('Favorit berhasil di tambahkan',
                        textAlign: TextAlign.center),
                    const SizedBox(
                      height: 8,
                    ),
                    Container(
                      alignment: Alignment.center,
                      child: OutlinedButton(
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(
                            color: Pallete.primary,
                          ),
                          primary: Pallete.primary,
                          shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.all(Radius.circular(18)),
                          ),
                        ),
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: Text(
                          "Ok",
                          style: Theme.of(context)
                              .textTheme
                              .bodyText1!
                              .copyWith(
                                  fontWeight: FontWeight.w600,
                                  color: Pallete.primary),
                        ),
                      ),
                    )
                  ],
                ),
              ),
              //actions: _checkbutton(context),
            );
          },
        );
      } else {
        showDialog(
          context: context,
          barrierDismissible: false,
          useRootNavigator: true,
          builder: (BuildContext context) {
            return AlertDialog(
              // contentPadding: EdgeInsets.all(8),
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(20.0)),
              ),
              content: SingleChildScrollView(
                child: Column(
                  children: <Widget>[
                    const Text(
                      'Peringatan',
                      style: TextStyle(
                        color: Colors.red,
                        fontSize: 20,
                      ),
                    ),
                    const SizedBox(
                      height: 4,
                    ),
                    Image(
                      height: MediaQuery.of(context).size.width * 0.25,
                      image: const AssetImage('assets/images/icon-warning.png'),
                    ),
                    const SizedBox(
                      height: 4,
                    ),
                    Text(resp['message'], textAlign: TextAlign.center),
                    const SizedBox(
                      height: 8,
                    ),
                    Container(
                      alignment: Alignment.center,
                      child: OutlinedButton(
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(
                            color: Colors.red,
                          ),
                          // splashColor: Colors.red,
                          shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.all(Radius.circular(18)),
                          ),
                        ),
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: Text(
                          "Batal",
                          style: Theme.of(context)
                              .textTheme
                              .bodyText1!
                              .copyWith(
                                  fontWeight: FontWeight.w600,
                                  color: Colors.red),
                        ),
                      ),
                    )
                  ],
                ),
              ),
              //actions: _checkbutton(context),
            );
          },
        );
      }
    }

    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
          backgroundColor: Colors.white,
          body: ISTReceipt(
              date: date,
              onTap: () {
                Navigator.pop(context);
                _doAddFav();
              },
              items: widget.list,
              noRef: widget.noRef,
              onFinished: () {
                _doFinish();
              },
              title: widget.title,
              amount: widget.amount,
              footer1: Text(
                widget.additional!,
                style: const TextStyle(fontSize: 11, color: Colors.grey),
                textAlign: TextAlign.center,
              ),
              status: widget.status)),
    );
  }
}
