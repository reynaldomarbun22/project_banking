import 'package:bpd_aceh/components/ist_menu_container.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PLN/pascabayarPLN/plninqury.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembayaran/PLN/prabayarPLN.dart/plninqury.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:bpd_aceh/core/controller/controller_menu.dart';

class ListrikScreen extends StatefulWidget {
  static const routeName = '/listrikScreen';

  const ListrikScreen({Key? key}) : super(key: key);

  @override
  _ListrikScreenState createState() => _ListrikScreenState();
}

class _ListrikScreenState extends State<ListrikScreen> {
  final controllerMenu = Get.put(MenuController());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text(
          'Listrik',
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'Poppins',
          ),
        ),
        // actions: <Widget>[
        //   IconButton(
        //     icon: Icon(
        //       Icons.notifications,
        //       color: Colors.white,
        //     ),
        //     onPressed: () {
        //       // _doLogout();
        //     },
        //   )
        // ],
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      body: Container(
        padding: const EdgeInsets.only(bottom: 16),
        color: Colors.white,
        child: ListView(
          children: <Widget>[
            Visibility(
              visible: controllerMenu.getVisibilityPrepaid(),
              child: ListTile(
                title: const Text('Prepaid'),
                trailing: const Icon(Icons.arrow_forward_ios),
                onTap: () {
                  Navigator.pushNamed(context, ListrikPrabayarPage.routeName);
                },
              ),
            ),
            Visibility(
              visible: controllerMenu.getVisibilityPrepaid(),
              child: const Divider(
                thickness: 1,
                color: Colors.grey,
              ),
            ),
            Visibility(
              visible: controllerMenu.getVisibilityPostpaid(),
              child: ListTile(
                  title: const Text('Postpaid'),
                  trailing: const Icon(Icons.arrow_forward_ios),
                  onTap: () {
                    Navigator.pushNamed(
                        context, ListrikPascaBayarPage.routeName);
                  }),
            ),
            Visibility(
              visible: controllerMenu.getVisibilityPostpaid(),
              child: const Divider(
                thickness: 1,
                color: Colors.grey,
              ),
            ),

            // Column(
            //   crossAxisAlignment: CrossAxisAlignment.start,
            //   children: <Widget>[
            //     ISTCardAccount(
            //       context: context,
            //       menu: ISTMenu.billpay,
            //     ),
            //     SizedBox(height: 8),
            //     SingleChildScrollView(
            //       child: buildMenuZakat(context),
            //     )
            //   ],
            // ),
          ],
        ),
      ),
    );
  }
}

buildMenuZakat(context) {
  return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      child: Wrap(
        crossAxisAlignment: WrapCrossAlignment.end,
        children: <Widget>[
          ISTMenuContainer(
            onTap: () {
              Navigator.pushNamed(context, ListrikPascaBayarPage.routeName);
            },
            image: Image.asset(
              'assets/images/icon-teleponrumah.png',
              width: 50,
            ),
            // color: Colors.grey,

            text: 'PraBayar(Token)',
          ),
          ISTMenuContainer(
            onTap: () {
              Navigator.pushNamed(context, ListrikPrabayarPage.routeName);
            },
            image: Image.asset(
              'assets/images/icon-indihome.png',
              width: 50,
            ),
            // color: Colors.grey,
            text: 'PascaBayar',
          ),
        ],
      ));
}
