import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/topup/gopay/component_confirmation.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/topup/gopay/mpin_gopay.dart';
import 'package:flutter/material.dart';

class Gopayconfirmasi extends StatefulWidget {
  static const routeName = '/Gopayconfirmasi';

  final List<ConfirmationItem>? list;
  final String? list1;

  const Gopayconfirmasi({Key? key, this.list, this.list1}) : super(key: key);

  @override
  _GopayconfirmasiState createState() => _GopayconfirmasiState();
}

class _GopayconfirmasiState extends State<Gopayconfirmasi> {
  @override
  Widget build(BuildContext context) {
    _doTransfer() {
      Navigator.pushNamed(context, GopayMPIN.routeName);
    }

    return Scaffold(
        resizeToAvoidBottomInset: true,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          centerTitle: true,
          title: const Text("Gopay",
              style: TextStyle(color: Colors.white, fontFamily: 'Poppins')),
          actions: const <Widget>[],
          elevation: 0.0,
          backgroundColor: Pallete.primary,
        ),
        backgroundColor: Colors.white,
        body: ConfirmationItems(
            items: widget.list,
            items1: widget.list1,
            title: 'Konfirmasi Layanan',
            onFinished: () {
              _doTransfer();
            }));
  }
}
