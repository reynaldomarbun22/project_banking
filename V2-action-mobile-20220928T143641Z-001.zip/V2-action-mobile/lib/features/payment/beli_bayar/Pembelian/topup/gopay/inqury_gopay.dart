import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_card_account.dart';
import 'package:bpd_aceh/components/ist_style.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/topup/gopay/component_confirmation.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/topup/gopay/confirm_gopay.dart';
// import 'package:contact_picker/contact_picker.dart';
import 'package:fluttercontactpicker/fluttercontactpicker.dart';
import 'package:currency_text_input_formatter/currency_text_input_formatter.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';

class GopayPage extends StatefulWidget {
  static const routeName = '/GopayPage';
  final String? noInvoice;

  const GopayPage({Key? key, this.noInvoice}) : super(key: key);

  @override
  // ignore: no_logic_in_create_state
  _GopayPageState createState() => _GopayPageState(noInvoice);
}

class _GopayPageState extends State<GopayPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final String? noInvoice;
  String? redaksiname = "";

  _GopayPageState(this.noInvoice);
  @override
  void initState() {
    if (noInvoice != null) {
      _hpController.text = noInvoice!;
      favoritGopay = true;
    }
    super.initState();
    _getRedaksi();
  }

  // ignore: unused_field
  bool _autoValidate = false;
  bool favoritGopay = false;
  final _hpController = TextEditingController();
  final _nominalGopaycontroller = TextEditingController();
  bool _errorValidateNoHp = false;
  bool _errorValidateNominal = false;

  bool _validateInputs() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      return true;
    } else {
      setState(() {
        _autoValidate = true;
      });
      return false;
    }
  }

  bool _doValidate() {
    if (_validateInputs() != true) return false;
    bool _success = true;
    if (_hpController.text.isEmpty) {
      setState(() {
        _errorValidateNoHp = true;
      });
      _success = false;
    } else if (_nominalGopaycontroller.text.isEmpty) {
      setState(() {
        _errorValidateNominal = true;
      });
      _success = false;
    } else {
      setState(() {
        _errorValidateNoHp = false;
        _errorValidateNominal = false;
      });
    }
    return _success;
  }

  // final ContactPicker _contactPicker = new ContactPicker();
  // ignore: unused_field
  late Contact _contact;

  String? result;

  _getPermission() async {
    if (await Permission.contacts.request().isGranted) {
      _getContact();
    }
  }

  _getContact() async {
    // Contact contact = await _contactPicker.selectContact();
    final PhoneContact contact = await FlutterContactPicker.pickPhoneContact();

    RegExp regExp = RegExp(
      r'{',
      caseSensitive: false,
      multiLine: false,
    );

    RegExp regExp2 = RegExp(
      r'}',
      caseSensitive: false,
      multiLine: false,
    );
    RegExp regExp3 = RegExp(
      r'-',
      caseSensitive: false,
      multiLine: false,
    );
    RegExp regExp4 = RegExp(
      r'(\+62)',
      caseSensitive: false,
      multiLine: false,
    );
    RegExp regExp5 = RegExp(
      r'(\+)',
      caseSensitive: false,
      multiLine: false,
    );
    RegExp regExp6 = RegExp(
      ' ',
      caseSensitive: false,
      multiLine: false,
    );
    var matches = contact.phoneNumber!.number!
        .replaceAll(regExp, "")
        .replaceAll(regExp2, "")
        .replaceAll(regExp3, "")
        .replaceAll(regExp4, "0")
        .replaceAll(regExp5, "")
        .replaceAll(regExp6, "");
    setState(() {
      _contact = contact;
      _hpController.text = matches;
    });
  }

  _getRedaksi() async {
    final resp = await API.postNoLoading(context, '/redaksi/gopay', {});
    if (resp['code'] == 0) {
      setState(() {
        redaksiname = resp['redaksi'];
      });
    }
  }

  _doTransfer() async {
    if (_doValidate()) {
      Map<String, Object> param = {};
      // param['idPel'] = int.parse(_hpController.text.replaceAll(",", ""));
      param['noHandphone'] = _hpController.text;
      param['amount'] =
          int.parse(_nominalGopaycontroller.text.replaceAll(".", ""));

      final resp = await API.post(context, '/gopay/Inquiry', param);
      if (resp['code'] == 0 && resp['code'] != null) {
        List<ConfirmationItem> listParam = [];
        List<dynamic> listMap = resp['resi'];

        var redaksi = resp['additionalinfo'];
        for (var item in listMap) {
          ConfirmationItem itemParam =
              ConfirmationItem(key: item['key'], value: item['value']);
          listParam.add(itemParam);
        }
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => Gopayconfirmasi(
                      list: listParam,
                      list1: redaksi,
                    )));
      } else {
        const DialogBox().showImageDialog(
            message: resp['message'],
            isError: true,
            image: const Image(
              image: AssetImage('assets/images/icon-failed.png'),
            ),
            buttonCancel: 'OK',
            onOk: () {},
            context: context);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text("Gopay",
            style: TextStyle(color: Colors.white, fontFamily: 'Poppins')),
        actions: const <Widget>[],
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      backgroundColor: Colors.white,
      body: Container(
        color: Colors.white,
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              ISTCardAccount(
                context: context,
                menu: ISTMenu.billpay,
              ),
              const SizedBox(
                height: 16,
              ),
              Container(
                padding: const EdgeInsets.only(left: 16, right: 16),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Form(
                        // ignore: deprecated_member_use
                        autovalidateMode: AutovalidateMode.always,
                        key: _formKey,
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: <Widget>[
                              Container(
                                alignment: Alignment.topLeft,
                                child: const Text(
                                  'No. Handphone',
                                  style: TextStyle(color: Colors.black87),
                                ),
                              ),
                              favoritGopay
                                  ? Column(children: [
                                      Container(
                                          alignment: Alignment.topLeft,
                                          child: Text('$noInvoice')),
                                      const Divider(
                                        thickness: 1.5,
                                      )
                                    ])
                                  : Container(
                                      alignment: Alignment.topLeft,
                                      child: TextFormField(
                                        validator: (val) {
                                          var noHp = val!;
                                          noHp = noHp
                                              .replaceAll("62", "0")
                                              .replaceAll("^62", "0")
                                              .replaceAll("^0+", "0")
                                              .replaceAll("^+62", "0");
                                          if (val.isEmpty || val == '0') {
                                            _errorValidateNoHp = true;
                                          } else {
                                            _errorValidateNoHp = false;
                                          }
                                        },
                                        inputFormatters: <TextInputFormatter>[
                                          // ignore: deprecated_member_use
                                          FilteringTextInputFormatter
                                              .digitsOnly,
                                        ],
                                        controller: _hpController,
                                        keyboardType: TextInputType.number,
                                        decoration: InputDecoration(
                                            errorText: _errorValidateNoHp
                                                ? "Mohon di isi"
                                                : null,
                                            hintText: "Masukkan No. Handphone",
                                            hintStyle: ISTStyle.hintStyle,
                                            suffixIcon: IconButton(
                                                icon: Image.asset(
                                                  'assets/images/icon-phonebook.png',
                                                  width: 30,
                                                ),
                                                onPressed: () {
                                                  _getPermission();
                                                })),
                                        maxLength:
                                            ISTConstants.handphoneMaxLength,
                                      ),
                                    ),
                              Container(
                                alignment: Alignment.topLeft,
                                child: const Text(
                                  'Nominal :',
                                  style: TextStyle(color: Colors.black87),
                                ),
                              ),
                              Container(
                                alignment: Alignment.topLeft,
                                child: TextFormField(
                                  validator: (val) {
                                    if (val!.isEmpty || val == '0') {
                                      _errorValidateNominal = true;
                                    } else {
                                      _errorValidateNominal = false;
                                    }
                                  },
                                  inputFormatters: [
                                    CurrencyTextInputFormatter(
                                      decimalDigits: 0,
                                      locale: 'id_ID',
                                      name: '',
                                    )
                                  ],
                                  // inputFormatters: [
                                  //   // ignore: deprecated_member_use
                                  //   FilteringTextInputFormatter.digitsOnly,
                                  // ],
                                  controller: _nominalGopaycontroller,
                                  maxLength: ISTConstants.nominalMaxLength,
                                  onChanged: (value) {
                                    if (_nominalGopaycontroller.text
                                        .trim()
                                        .isEmpty) {
                                      _nominalGopaycontroller.text = '';
                                    }
                                  },
                                  keyboardType: TextInputType.number,
                                  decoration: InputDecoration(
                                    errorText: _errorValidateNominal
                                        ? "Mohon di isi"
                                        : null,
                                    counterText: '',
                                    // errorText:_nominalBLError ? "Mohon diisi" : null,
                                    // prefixText: 'IDR ',
                                    // prefixStyle: TextStyle(),
                                    prefixIcon: Text(
                                      "IDR ",
                                      style: TextStyle(
                                          fontSize: Theme.of(context)
                                              .textTheme
                                              .subtitle1!
                                              .fontSize),
                                    ),
                                    prefixIconConstraints: const BoxConstraints(
                                        minWidth: 0, minHeight: 0),
                                    hintText: 'Masukkan nominal',
                                    hintStyle: ISTStyle.hintStyle,
                                  ),
                                ),
                              ),
                              Row(
                                children: [
                                  Text('$redaksiname',
                                      style: const TextStyle(
                                          color: Colors.grey,
                                          fontStyle: FontStyle.italic,
                                          fontSize: 12)),
                                ],
                              ),
                            ]),
                      ),
                    ]),
              ),
              const SizedBox(
                height: 50,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: ISTOutlineButton(
                  onPressed: () {
                    _doTransfer();
                  },
                  text: 'Lanjut',
                ),
              ),
              const SizedBox(
                height: 16,
              )
            ],
          ),
        ),
      ),
    );
  }
}
