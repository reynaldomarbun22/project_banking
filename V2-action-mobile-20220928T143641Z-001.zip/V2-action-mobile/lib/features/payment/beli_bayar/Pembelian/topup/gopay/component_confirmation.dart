import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:flutter/material.dart';

class ConfirmationItem {
  final String? key;
  final String? value;
  ConfirmationItem({this.key, this.value});
}

class ConfirmationItems extends StatelessWidget {
  const ConfirmationItems({
    Key? key,
    required this.items,
    required this.title,
    required this.onFinished,
    this.items1,
  }) : super(key: key);

  final String title;
  final List<ConfirmationItem>? items;
  final Function onFinished;
  final String? items1;

  List<Widget> _buildItems() {
    List<Widget> ret = [];
    if (items == null || items!.isEmpty) {
      return [];
    }

    for (ConfirmationItem item in items!) {
      ret.add(Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Expanded(flex: 1, child: Text(item.key!)),
          Expanded(
            flex: 1,
            child: Text(
              item.value!,
              textAlign: TextAlign.right,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontFamily: 'Poppins',
              ),
            ),
          )
        ],
      ));
      ret.add(const Divider(
        thickness: 1,
      ));
    }

    return ret;
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: <Widget>[
        const SizedBox(height: 16),
        Center(child: Text(title)),
        const SizedBox(height: 16),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
                border: Border.all(
                  color:
                      _buildItems().isNotEmpty ? Pallete.primary : Colors.white,
                  width: 0.5,
                ),
                borderRadius: BorderRadius.circular(10)),
            child: Column(
              children: _buildItems(),
            ),
          ),
        ),
        const SizedBox(height: 16),
        Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              items1!,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontFamily: 'Poppins',
                // fontStyle: FontStyle.normal,
                fontSize: 12,
                fontWeight: FontWeight.w200,
              ),
            ),
          ],
        ),
        // SizedBox(height: 16),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: ISTOutlineButton(
            text: 'Lanjut',
            onPressed: onFinished as void Function()?,
          ),
        )
      ],
    );
  }
}
