import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/topup/linkAja/mpin_link_aja.dart';
import 'package:flutter/material.dart';

class LinkAjaconfirmasi extends StatefulWidget {
  static const routeName = '/LinkAjaconfirmasi';

  final List<ISTConfirmationItem>? list;

  const LinkAjaconfirmasi({Key? key, this.list}) : super(key: key);

  @override
  _LinkAjaconfirmasiState createState() => _LinkAjaconfirmasiState();
}

class _LinkAjaconfirmasiState extends State<LinkAjaconfirmasi> {
  @override
  Widget build(BuildContext context) {
    _doTransfer() {
      Navigator.pushNamed(context, LinkAjaMPIN.routeName);
    }

    return Scaffold(
        resizeToAvoidBottomInset: true,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          centerTitle: true,
          title: const Text("LinkAja",
              style: TextStyle(color: Colors.white, fontFamily: 'Poppins')),
          actions: const <Widget>[],
          elevation: 0.0,
          backgroundColor: Pallete.primary,
        ),
        backgroundColor: Colors.white,
        body: ISTConfirmation(
            items: widget.list,
            title: 'Konfirmasi Layanan',
            onFinished: () {
              _doTransfer();
            }));
  }
}
