import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/topup/gopay/component_confirmation.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/topup/ovo/mpin_ovo.dart';
import 'package:flutter/material.dart';

class Ovoconfirmasi extends StatefulWidget {
  static const routeName = '/Ovoconfirmasi';

  final List<ConfirmationItem>? list;
  final String? list1;

  const Ovoconfirmasi({Key? key, this.list, this.list1}) : super(key: key);

  @override
  _OvoconfirmasiState createState() => _OvoconfirmasiState();
}

class _OvoconfirmasiState extends State<Ovoconfirmasi> {
  @override
  Widget build(BuildContext context) {
    _doTransfer() {
      Navigator.pushNamed(context, OvoMPIN.routeName);
    }

    return Scaffold(
        resizeToAvoidBottomInset: true,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          centerTitle: true,
          title: const Text("OVO",
              style: TextStyle(color: Colors.white, fontFamily: 'Poppins')),
          actions: const <Widget>[],
          elevation: 0.0,
          backgroundColor: Pallete.primary,
        ),
        backgroundColor: Colors.white,
        body: ConfirmationItems(
            items: widget.list,
            items1: widget.list1,
            title: 'Konfirmasi Layanan',
            onFinished: () {
              _doTransfer();
            }));
  }
}
