import 'package:flutter/material.dart';
class DenomItem {
  final String? denomination;
  final String? denominationDesc;
  final int? denomIndex;

  DenomItem({Key? key, this.denomination, this.denominationDesc, this.denomIndex});
  

}