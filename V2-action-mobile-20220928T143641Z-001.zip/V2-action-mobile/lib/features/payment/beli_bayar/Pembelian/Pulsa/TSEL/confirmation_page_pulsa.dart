import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/Pulsa/TSEL/pulsa_mpin_page.dart';
import 'package:flutter/material.dart';

class ConfirmationPagePulsa extends StatefulWidget {
  static const routeName = '/confirmationPagePulsa';

  final List<ISTConfirmationItem>? list;

  final String? nomorHP;
  final String? biaya;
  final String? nominal;

  const ConfirmationPagePulsa(
      {Key? key, this.nomorHP, this.biaya, this.nominal, this.list})
      : super(key: key);
  @override
  _ConfirmationPagePulsaState createState() => _ConfirmationPagePulsaState();
}

class _ConfirmationPagePulsaState extends State<ConfirmationPagePulsa> {
  _doPurchase() {
    Navigator.pushNamed(context, PulsaMpinPage.routeName);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: true,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          centerTitle: true,
          title: const Text("Pulsa",
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'Poppins',
              )),
          elevation: 0.0,
          backgroundColor: Pallete.primary,
        ),
        backgroundColor: Colors.white,
        body: ISTConfirmation(
            items: widget.list,
            title: 'Konfirmasi Layanan',
            onFinished: () {
              _doPurchase();
            }));
  }
}
