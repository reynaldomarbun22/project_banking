import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_card_account.dart';
import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/ist_style.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/Pulsa/TSEL/confirmation_page_pulsa.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/Pulsa/TSEL/denomitem.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
// import 'package:flutter/services.dart';
import 'package:fluttercontactpicker/fluttercontactpicker.dart';
// import 'package:contact_picker/contact_picker.dart';
import 'package:permission_handler/permission_handler.dart';

class PembelianPulsa extends StatefulWidget {
  static const routeName = '/pembelianPulsa';

  final String? nomorHp;
  final String? value;

  const PembelianPulsa({
    Key? key,
    this.nomorHp,
    this.value,
  }) : super(key: key);

  @override
  // ignore: no_logic_in_create_state
  _PembelianPulsaState createState() => _PembelianPulsaState(nomorHp);
}

class _PembelianPulsaState extends State<PembelianPulsa> {
  String? dropdownValue;
  final TextEditingController _numTopupController = TextEditingController();
  String nomorhp = "";
  String? redaksiname = "";

  final String? nomorHp;

  _PembelianPulsaState(this.nomorHp);

  @override
  void initState() {
    if (nomorHp != null) {
      _numTopupController.text = nomorHp!;
      fromContact = true;
    }
    super.initState();
    _getRedaksi();
    _getDenom();
  }

  bool _numError = false;
  bool _dropError = false;
  bool _success = true;
  bool fromContact = false;

  _doValidate() {
    if (_numTopupController.text == '' ||
        _numTopupController.text.isEmpty) {
      setState(() {
        _numError = true;
      });
      _success = false;
    }

    if (_selected == null) {
      setState(() {
        _dropError = true;
      });
      _success = false;
    } else {
      _numError = false;
      _dropError = false;
      _success = true;
    }
    return _success;
  }

  _doInquiry() async {
    Map<String, Object?> param = {};
    if (_numTopupController.text == '' ||
        _numTopupController.text.isEmpty) {
      setState(() {
        _numError = true;
      });
      _success = false;
    } else {
      param['denomIdx'] = _selected!.denomIndex;
      param['phoneNo'] = _numTopupController.text
          .replaceAll("^62", "0")
          .replaceAll("^0+", "0")
          .replaceAll("^62", "0");
      final resp =
          await API.postNoLoading(context, '/purchase/pulsa/inquiry', param);
      if (resp['code'] == 0) {
        List<ISTConfirmationItem> listParam = [];
        List<dynamic> listMap = resp['resi'];
        for (var item in listMap) {
          ISTConfirmationItem itemParam =
              ISTConfirmationItem(key: item['key'], value: item['value']);
          listParam.add(itemParam);
        }
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => ConfirmationPagePulsa(
                      list: listParam,
                    )));
      } else {
        const DialogBox().showImageDialog(
            message: resp['message'],
            isError: true,
            image: const Image(
              image: AssetImage('assets/images/icon-failed.png'),
            ),
            buttonCancel: 'OK',
            onOk: () {},
            context: context);
      }
    }
    //param['denomIdx'] = double.parse(_selected.denomination).toInt();
    // param['denomIdx'] = _selected.denomIndex;
    // param['phoneNo'] = _numTopupController.text;
    // final resp =
    //     await API.postNoLoading(context, '/purchase/pulsa/inquiry', param);
  }

  DenomItem? _selected;
  List<DenomItem> _list = [];
  String? messageError = "".replaceAll("-", "");
  // ignore: unused_field
  bool _errorMessage = false;
  _getDenom() async {
    try {
      setState(() {
        _selected = null;
      });
      if (_list.isNotEmpty) {
        Future.delayed(Duration.zero);
        _list.clear();
      }
      Map<String, Object> param = {};
      param['phoneNo'] = _numTopupController.text;
      final resp =
          await API.postNoLoading(context, '/purchase/pulsa/denom', param);
      if (resp['code'] == 0) {
        var listResp = resp['denoms'];
        List<dynamic> listRespMini = (listResp);
        List<DenomItem> listDenom = [];
        //for (var item in listRespMini) {
        for (var i = 0; i < listRespMini.length; i++) {
          DenomItem items = DenomItem(
            denomIndex: i,
            denomination: listRespMini[i]['denomination'].toString(),
            denominationDesc: listRespMini[i]['denominationDesc'],
          );

          listDenom.add(items);
        }

        setState(() {
          _list = listDenom;
          _numError = false;
        });
      } else if (resp['code'] != 0 && resp['denoms'] == null) {
        setState(() {
          var message = resp['message'];
          messageError = message;
          _errorMessage = true;
        });
      }
    } catch (_) {}
  }

  // final ContactPicker _contactPicker = new ContactPicker();
  // ignore: unused_field
  late Contact _contact;

  bool status = false;
  String? result;

  // ignore: unused_element
  _getPermission() async {
    if (await Permission.contacts.request().isGranted) {
      // _getContact();
    }
  }

  _getRedaksi() async {
    final resp = await API.postNoLoading(context, '/redaksi/pulsa', {});
    if (resp['code'] == 0) {
      setState(() {
        redaksiname = resp['redaksi'];
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text("Pulsa",
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'Poppins',
            )),
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
          child: Column(crossAxisAlignment: CrossAxisAlignment.center, children: <
              Widget>[
            ISTCardAccount(context: context, menu: ISTMenu.billpay),
            const SizedBox(height: 16),
            Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.only(left: 16, right: 16),
              color: Colors.white,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const Text(
                    "No. Handphone :",
                  ),
                  const SizedBox(
                    height: 8,
                  ),
                  TextFormField(
                    onChanged: (val) {
                      var noHP = val;
                      noHP =
                          noHP.replaceAll("^0+", "0").replaceAll("^+62", "0");
                      if (val.isEmpty || val == '0' || val == '08') {
                        // image = 0;
                        setState(() {
                          _list.clear();
                        });
                      } else {
                        setState(() {
                          _getDenom();
                        });
                      }

                      // else if (noHP.substring(0, 4) == "0859" ||
                      //     noHP.substring(0, 4) == "0817" ||
                      //     noHP.substring(0, 4) == "0877" ||
                      //     noHP.substring(0, 4) == "0818" ||
                      //     noHP.substring(0, 4) == "0878" ||
                      //     noHP.substring(0, 4) == "0819") {
                      //   // image = 2;
                      //   _getDenom();
                      // } else if (noHP.substring(0, 4) == "0814" ||
                      //     noHP.substring(0, 4) == "0855" ||
                      //     noHP.substring(0, 4) == "0815" ||
                      //     noHP.substring(0, 4) == "0856" ||
                      //     noHP.substring(0, 4) == "0858" ||
                      //     noHP.substring(0, 4) == "0816" ||
                      //     noHP.substring(0, 4) == "0857") {
                      //   // image = 3;
                      //   _getDenom();
                      // } else if (noHP.substring(0, 4) == "0881" ||
                      //     noHP.substring(0, 4) == "0882" ||
                      //     noHP.substring(0, 4) == "0883" ||
                      //     noHP.substring(0, 4) == "0884" ||
                      //     noHP.substring(0, 4) == "0885" ||
                      //     noHP.substring(0, 4) == "0886" ||
                      //     noHP.substring(0, 4) == "0887" ||
                      //     noHP.substring(0, 4) == "0888" ||
                      //     noHP.substring(0, 4) == "0889") {
                      //   // image = 4;
                      //   _getDenom();
                      // }
                    },
                    maxLength: ISTConstants.handphoneMaxLength,
                    controller: _numTopupController,
                    decoration: InputDecoration(
                        errorText: _numError ? "Mohon diisi" : null,
                        hintText: "Masukan Nomor Handphone",
                        hintStyle: ISTStyle.hintStyle,
                        suffixIcon: Container(
                          width: 75,
                          alignment: Alignment.bottomRight,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              IconButton(
                                  icon: Image.asset(
                                    'assets/images/icon-phonebook.png',
                                    width: 30,
                                  ),
                                  onPressed: () async {
                                    final PhoneContact contact =
                                        await FlutterContactPicker
                                            .pickPhoneContact();
                                    print(contact);
                                    RegExp regExp = RegExp(
                                      r'{',
                                      caseSensitive: false,
                                      multiLine: false,
                                    );
                                    RegExp regExp2 = RegExp(
                                      r'}',
                                      caseSensitive: false,
                                      multiLine: false,
                                    );
                                    RegExp regExp3 = RegExp(
                                      r'-',
                                      caseSensitive: false,
                                      multiLine: false,
                                    );
                                    RegExp regExp4 = RegExp(
                                      r'(\+62)',
                                      caseSensitive: false,
                                      multiLine: false,
                                    );
                                    RegExp regExp5 = RegExp(
                                      r'(\+)',
                                      caseSensitive: false,
                                      multiLine: false,
                                    );
                                    RegExp regExp6 = RegExp(
                                      ' ',
                                      caseSensitive: false,
                                      multiLine: false,
                                    );
                                    var noHP = contact.phoneNumber!.number!
                                        .replaceAll(regExp, "")
                                        .replaceAll(regExp2, "")
                                        .replaceAll(regExp3, "")
                                        .replaceAll(regExp4, "0")
                                        .replaceAll(regExp5, "")
                                        .replaceAll(regExp6, "");
                                    noHP = noHP;
                                    // .replaceAll("^0+", "0")
                                    // .replaceAll("^+62", "0");
                                    if (contact.phoneNumber!.number == '0' ||
                                        contact.phoneNumber!.number == '08') {
                                      // image = 0;
                                    } else if (noHP.substring(0, 4) == "0811" ||
                                        noHP.substring(0, 4) == "0821" ||
                                        noHP.substring(0, 4) == "0851" ||
                                        noHP.substring(0, 4) == "0812" ||
                                        noHP.substring(0, 4) == "0822" ||
                                        noHP.substring(0, 4) == "0852" ||
                                        noHP.substring(0, 4) == "0813" ||
                                        noHP.substring(0, 4) == "0823" ||
                                        noHP.substring(0, 4) == "0853") {
                                      // image = 1;
                                    } else if (noHP.substring(0, 4) == "0859" ||
                                        noHP.substring(0, 4) == "0817" ||
                                        noHP.substring(0, 4) == "0877" ||
                                        noHP.substring(0, 4) == "0818" ||
                                        noHP.substring(0, 4) == "0878" ||
                                        noHP.substring(0, 4) == "0819") {
                                      // image = 2;
                                    } else if (noHP.substring(0, 4) == "0814" ||
                                        noHP.substring(0, 4) == "0855" ||
                                        noHP.substring(0, 4) == "0815" ||
                                        noHP.substring(0, 4) == "0856" ||
                                        noHP.substring(0, 4) == "0858" ||
                                        noHP.substring(0, 4) == "0816" ||
                                        noHP.substring(0, 4) == "0857") {
                                      // image = 3;
                                    } else if (noHP.substring(0, 4) == "0881" ||
                                        noHP.substring(0, 4) == "0882" ||
                                        noHP.substring(0, 4) == "0883" ||
                                        noHP.substring(0, 4) == "0884" ||
                                        noHP.substring(0, 4) == "0885" ||
                                        noHP.substring(0, 4) == "0886" ||
                                        noHP.substring(0, 4) == "0887" ||
                                        noHP.substring(0, 4) == "0888" ||
                                        noHP.substring(0, 4) == "0889") {
                                      // image = 4;
                                    }

                                    setState(() {
                                      RegExp regExp = RegExp(
                                        r'{',
                                        caseSensitive: false,
                                        multiLine: false,
                                      );
                                      RegExp regExp2 = RegExp(
                                        r'}',
                                        caseSensitive: false,
                                        multiLine: false,
                                      );
                                      RegExp regExp3 = RegExp(
                                        r'-',
                                        caseSensitive: false,
                                        multiLine: false,
                                      );
                                      RegExp regExp4 = RegExp(
                                        r'(\+62)',
                                        caseSensitive: false,
                                        multiLine: false,
                                      );
                                      RegExp regExp5 = RegExp(
                                        r'(\+)',
                                        caseSensitive: false,
                                        multiLine: false,
                                      );
                                      RegExp regExp6 = RegExp(
                                        ' ',
                                        caseSensitive: false,
                                        multiLine: false,
                                      );
                                      var _phoneContact = contact
                                          .phoneNumber!.number!
                                          .replaceAll(regExp, "")
                                          .replaceAll(regExp2, "")
                                          .replaceAll(regExp3, "")
                                          .replaceAll(regExp4, "0")
                                          .replaceAll(regExp5, "")
                                          .replaceAll(regExp6, "");
                                      _numTopupController.text = _phoneContact;
                                      // .replaceAll("^0+", "0")
                                      // .replaceAll("^+62", "0");
                                    });
                                    _getDenom();
                                    // getListDenom();
                                  })
                            ],
                          ),
                        )),
                    keyboardType: TextInputType.number,
                    inputFormatters: <TextInputFormatter>[
                      FilteringTextInputFormatter.digitsOnly
                      // ignore: deprecated_member_use
                      // WhitelistingTextInputFormatter.digitsOnly
                    ],
                  ),
                  // fromContact
                  //     ? Container(
                  //         alignment: Alignment.topLeft,
                  //         padding: EdgeInsets.only(bottom: 8),
                  //         child: Text(
                  //           '$nomorHp',
                  //         ))
                  //     : Container(
                  //         child: TextFormField(
                  //           onChanged: (val) {
                  //             var noHP = val;
                  //             noHP = noHP
                  //                 .replaceAll("62", "0")
                  //                 .replaceAll("^62", "0")
                  //                 .replaceAll("^0+", "0")
                  //                 .replaceAll("^+62", "0");
                  //             if (noHP.length >= 4) {
                  //               _getDenom();
                  //             } else {
                  //               setState(() {
                  //                 _list.clear();
                  //               });
                  //             }
                  //           },
                  //           maxLength: ISTConstants.handphoneMaxLength,
                  //           controller: _numTopupController,
                  //           decoration: InputDecoration(
                  //               errorText: _numError ? "Mohon diisi" : null,
                  //               hintText: "Masukkan Nomor Handphone",
                  //               hintStyle: ISTStyle.hintStyle,
                  //               suffixIcon: IconButton(
                  //                   icon: Image.asset(
                  //                     'assets/images/icon-phonebook.png',
                  //                     width: 30,
                  //                   ),
                  //                   onPressed: () {
                  //                     // _getPermission();
                  //                   })),
                  //           keyboardType: TextInputType.number,
                  //           inputFormatters: <TextInputFormatter>[
                  //             // ignore: deprecated_member_use
                  //             FilteringTextInputFormatter.digitsOnly,
                  //           ],
                  //         ),
                  //       ),

                  //   _errorMessage ? Container(
                  //     alignment: Alignment.centerLeft,
                  //     child: Text(
                  //       messageError,
                  //       style: TextStyle(color: Colors.red),
                  //     ),
                  //   )
                  // : SizedBox.shrink(),
                  const SizedBox(
                    height: 16,
                  ),
                  const Text(
                    "Nominal :",
                  ),
                  DropdownButton<DenomItem>(
                    iconEnabledColor: Pallete.primary,
                    value: _list.isEmpty ? null : _selected,
                    hint:
                        const Text("Pilih Nominal", style: ISTStyle.hintStyle),
                    isExpanded: true,
                    icon: const Icon(Icons.arrow_drop_down),
                    iconSize: 30,
                    // elevation: 16,
                    style: const TextStyle(color: Colors.black),
                    underline: Container(
                      height: 1,
                      color: Colors.grey,
                    ),
                    isDense: false,
                    onChanged: (DenomItem? newValue) {
                      setState(() {
                        _selected = newValue;
                        newValue != null
                            ? _dropError = false
                            : _dropError = true;
                      });
                    },
                    items: _list.map((DenomItem _list) {
                      return DropdownMenuItem<DenomItem>(
                        value: _list,
                        child: Row(
                          children: <Widget>[
                            Text(_list.denominationDesc!),
                          ],
                        ),
                      );
                    }).toList(),
                  ),

                  _dropError
                      ? Container(
                          alignment: Alignment.centerLeft,
                          child: const Text(
                            'Mohon pilih Nominal',
                            style: TextStyle(color: Colors.red),
                          ),
                        )
                      : const SizedBox.shrink(),
                  const SizedBox(
                    height: 8,
                  ),
                  Text('$redaksiname',
                      // '*Operator yang tersedia adalah Telkomsel, XL, Indosat dan Tri.',
                      style: const TextStyle(
                          color: Colors.grey,
                          fontStyle: FontStyle.italic,
                          fontSize: 12)),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.only(left: 16, right: 16),
              child: ISTOutlineButton(
                  onPressed: () {
                    setState(() {});
                    if (!_doValidate()) return;
                    _doInquiry();
                  },
                  text: "Lanjut"),
            ),
            const SizedBox(
              height: 16,
            )
          ])),
    );
  }
}
