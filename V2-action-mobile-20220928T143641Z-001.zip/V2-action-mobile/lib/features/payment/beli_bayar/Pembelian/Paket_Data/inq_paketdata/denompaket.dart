import 'package:flutter/material.dart';
class DenomItemPaket {
  final String? denomination;
  final String? denominationDesc;
  final int? denomIndex;

  DenomItemPaket({Key? key, this.denomination, this.denominationDesc, this.denomIndex});
  

}