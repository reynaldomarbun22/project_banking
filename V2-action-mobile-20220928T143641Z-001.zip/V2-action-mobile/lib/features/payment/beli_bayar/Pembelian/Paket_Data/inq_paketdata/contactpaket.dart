// import 'package:bpd_aceh/components/palete.dart';
// import 'package:collection/collection.dart' show IterableExtension;
// import 'package:contacts_service/contacts_service.dart';
// import 'package:fluttercontactpicker/fluttercontactpicker.dart';
// import 'package:flutter/material.dart';

// // class ContactView extends StatefulWidget {
//   static const routeName = '/ContactView';
//   @override
//   _ContactViewState createState() => _ContactViewState();
// }

// class _ContactViewState extends State<ContactView> {
//   List<Contact> contacts = [];
//   List<Contact> contactsFiltered = [];
//   Map<String, Color> contactsColorMap = new Map();
//   String _searchText = "";
//   TextEditingController searchController = new TextEditingController();
//   TextEditingController _search = TextEditingController();
//   Icon _searchIcon = new Icon(Icons.search);

//   Widget _appBarTitle = Text(
//     'Pilih Kontak',
//     style: TextStyle(
//       color: Colors.white,
//       // fontWeight: FontWeight.bold,
//       // fontSize: FontSize.TITLE,
//     ),
//   );

//   @override
//   void initState() {
//     getAllContacts();
//     searchController.addListener(() {
//       filterContacts();
//     });
//     super.initState();
//   }

//   String flattenPhoneNumber(String phoneStr) {
//     return phoneStr.replaceAllMapped(RegExp(r'^(\+)|\D'), (Match m) {
//       return m[0] == "+" ? "+" : "";
//     });
//   }

//   void _searchPressed() {
//     setState(() {
//       if (this._searchIcon.icon == Icons.search) {
//         this._searchIcon = Icon(Icons.close);
//         this._appBarTitle = TextField(
//           style: TextStyle(color: Colors.white),
//           autofocus: true,
//           controller: searchController,
//           onChanged: (text) {
//             setState(() {
//               this._searchText = text;
//             });
//           },
//           decoration: InputDecoration(
//               prefixIcon: Icon(Icons.search),
//               hintText: 'Cari Kontak...',
//               hintStyle: TextStyle(color: Colors.white)),
//         );
//       } else {
//         this._searchIcon = Icon(Icons.search);
//         this._appBarTitle = Text('Pilih Kontak');
//         this._searchText = "";
//       }
//     });
//   }

//   filterContacts() {
//     List<Contact> _contacts = [];
//     _contacts.addAll(contacts);
//     if (searchController.text.isNotEmpty) {
//       _contacts.retainWhere((contact) {
//         String searchTerm = searchController.text.toLowerCase();
//         String searchTermFlatten = flattenPhoneNumber(searchTerm);
//         String contactName = contact.displayName!.toLowerCase();
//         bool nameMatches = contactName.contains(searchTerm);
//         if (nameMatches == true) {
//           return true;
//         }

//         if (searchTermFlatten.isEmpty) {
//           return false;
//         }

//         var phone = contact.phones!.firstWhereOrNull((phn) {
//           String phnFlattened = flattenPhoneNumber(phn.value!);
//           return phnFlattened.contains(searchTermFlatten);
//         });

//         return phone != null;
//       });

//       setState(() {
//         contactsFiltered = _contacts;
//       });
//     }
//   }

//   getAllContacts() async {
//     List<Contact> _contacts = (await ContactsService.getContacts()).toList();

//     setState(() {
//       contacts = _contacts;
//     });
//   }

//   onTapped(Contact contact) {
//     Navigator.pop(context, {"${contact.phones!.elementAt(0).value}"});
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//         resizeToAvoidBottomInset: true,
//         appBar: AppBar(
//           leading: IconButton(
//             icon: Icon(Icons.arrow_back_ios, color: Colors.white),
//             onPressed: () {
//               Navigator.pop(context);
//             },
//           ),
//           actions: <Widget>[
//             IconButton(
//               color: Colors.white,
//               icon: _searchIcon,
//               onPressed: _searchPressed,
//             ),
//           ],
//           centerTitle: true,
//           // title: Text("Contact", style: TextStyle(color: Colors.white)),
//           title: _appBarTitle,

//           elevation: 0.0,
//           backgroundColor: Pallete.primary,
//         ),
//         backgroundColor: Colors.white,
//         body: Container(
//             padding: EdgeInsets.all(16),
//             child: Column(
//               children: <Widget>[
//                 Expanded(child: Container(child: _buildList())),
//                 SizedBox(
//                   height: 16,
//                 )
//               ],
//             )));
//   }

//   _buildList() {
//     bool isSearching = searchController.text.isNotEmpty;

//     return ListView.separated(
//       separatorBuilder: (context, inx) {
//         return Divider(
//           thickness: 2,
//         );
//       },
//       shrinkWrap: true,
//       itemCount:
//           isSearching == true ? contactsFiltered.length : contacts.length,
//       itemBuilder: (context, index) {
//         Contact contact =
//             isSearching == true ? contactsFiltered[index] : contacts[index];

//         return ListTile(
//           title: Text(contact.displayName!),
//           subtitle: Text(contact.phones!.elementAt(0).value!),
//           leading: (contact.avatar != null && contact.avatar!.length > 0)
//               ? CircleAvatar(
//                   backgroundImage: MemoryImage(contact.avatar!),
//                 )
//               : Container(
//                   child: CircleAvatar(
//                       child: Text(contact.initials(),
//                           style: TextStyle(color: Colors.white)),
//                       backgroundColor: Pallete.primary)),
//           onTap: () => onTapped(contact),
//         );
//       },
//     );
//   }
// }
