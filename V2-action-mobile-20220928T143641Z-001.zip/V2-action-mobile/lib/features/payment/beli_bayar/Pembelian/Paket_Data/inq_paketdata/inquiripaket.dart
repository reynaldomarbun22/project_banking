// ignore_for_file: unnecessary_string_escapes

import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_card_account.dart';
import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/ist_style.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/Paket_Data/inq_paketdata/confirmpaket.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/Paket_Data/inq_paketdata/datapaket.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/Paket_Data/inq_paketdata/denompaket.dart';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
// import 'package:contact_picker/contact_picker.dart';
import 'package:fluttercontactpicker/fluttercontactpicker.dart';
import 'package:permission_handler/permission_handler.dart';
// import 'package:dropdown_below/dropdown_below.dart';

class InquiryPaketData extends StatefulWidget {
  static const routeName = '/InquiryPaketdata';

  final String? nomorHp;
  final String? value;
  final String? code;
  final String? namaVoucher;

  const InquiryPaketData({
    Key? key,
    this.nomorHp,
    this.value,
    this.namaVoucher,
    this.code,
  }) : super(key: key);

  @override
  // ignore: no_logic_in_create_state
  _InquiryPaketDataState createState() => _InquiryPaketDataState(nomorHp);
}

class _InquiryPaketDataState extends State<InquiryPaketData> {
  // ignore: unused_field
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  String? dropdownValue;
  final TextEditingController _numTopupController = TextEditingController();
  String nomorhp = "";
  final _paketVoucherController = TextEditingController();
  String? redaksiname = "";
  String namaVoucher = "";
  String denomIndex = "";

  final String? nomorHp;

  _InquiryPaketDataState(this.nomorHp);

  @override
  void initState() {
    if (nomorHp != null) {
      _numTopupController.text = nomorHp!;
      fromContact = true;
    }
    _paketVoucherController.text = widget.namaVoucher ?? '';

    super.initState();
    _getRedaksi();
    _getDenom();
  }

  bool _numError = false;
  bool _dropError = false;
  bool _success = true;
  bool fromContact = false;

  _doValidate() {
    if (_numTopupController.text == '') {
      setState(() {
        _numError = true;
      });
      _success = false;
    } else if (_paketVoucherController.text == '') {
      setState(() {
        _dropError = true;
      });
      _success = false;
    } else {
      setState(() {
        _numError = false;
        _dropError = false;
        _success = true;
      });
    }
    return _success;
  }

  _doInquiry() async {
    // setState(() {
    //   _doValidate();
    // });
    Map<String, Object> param = {};
    //param['denomIdx'] = double.parse(_selected.denomination).toInt();
    param['denomIdx'] = denomIndex;
    param['phoneNo'] = _numTopupController.text
        .replaceAll("^62", "0")
        .replaceAll("^0+", "0")
        .replaceAll("^62", "0");
    final resp =
        await API.postNoLoading(context, '/purchase/data/inquiry', param);
    if (resp['code'] == 0) {
      List<ISTConfirmationItem> listParam = [];
      List<dynamic> listMap = resp['resi'];
      for (var item in listMap) {
        ISTConfirmationItem itemParam =
            ISTConfirmationItem(key: item['key'], value: item['value']);
        listParam.add(itemParam);
      }
      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => ConfirmationPaketData(
                    list: listParam,
                  )));
    } else {
      const DialogBox().showImageDialog(
          message: resp['message'],
          isError: true,
          image: const Image(
            image: AssetImage('assets/images/icon-failed.png'),
          ),
          buttonCancel: 'OK',
          onOk: () {},
          context: context);
    }
  }

  // ignore: unused_field
  DenomItemPaket? _selected;
  final List<DenomItemPaket> _list = [];

  _getDenom() async {
    try {
      setState(() {
        _paketVoucherController.text = ' ';
      });
      if (_list.isNotEmpty) {
        Future.delayed(Duration.zero);
        _list.clear();
      }
      Map<String, Object> param = {};
      param['phoneNo'] = _numTopupController.text;
      final resp =
          await API.postNoLoading(context, '/purchase/data/denom', param);
      if (resp['code'] == -1020) {
        setState(() {
          _enabled = false;
        });
      } else if (resp['code'] == 0) {
        setState(() {
          _enabled = true;
          _numError = false;
          _dropError = false;
        });
      }
    } catch (_) {}
  }

  _getDenom2() async {
    var result = await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (BuildContext context) => DaftarPaket(
            prefix: _numTopupController.text,
          ),
        ));
    final res = result.toString().replaceAll("\{", "").replaceAll("\}", "");
    if (res != "null") {
      setState(() {
        List<String> resList = res.split("-");
        denomIndex = resList[0];
        namaVoucher = resList[1];
        _paketVoucherController.text = namaVoucher;
        // ignore: unnecessary_null_comparison
        if (_paketVoucherController.text != null ||
            _paketVoucherController.text != "") {
          _dropError = false;
        }
      });
    }
  }

  // final ContactPicker _contactPicker = new ContactPicker();
  // ignore: unused_field
  late Contact _contact;

  bool status = false;
  bool _enabled = false;
  String? result;

  // ignore: unused_element
  _getPermission() async {
    if (await Permission.contacts.request().isGranted) {
      _getContact();
    }
  }

  _getContact() async {
    // Contact contact = await _contactPicker.selectContact();
    final PhoneContact contact = await FlutterContactPicker.pickPhoneContact();

    RegExp regExp = RegExp(
      r'{',
      caseSensitive: false,
      multiLine: false,
    );

    RegExp regExp2 = RegExp(
      r'}',
      caseSensitive: false,
      multiLine: false,
    );
    RegExp regExp3 = RegExp(
      r'-',
      caseSensitive: false,
      multiLine: false,
    );
    RegExp regExp4 = RegExp(
      r'(\+62)',
      caseSensitive: false,
      multiLine: false,
    );
    RegExp regExp5 = RegExp(
      r'(\+)',
      caseSensitive: false,
      multiLine: false,
    );
    RegExp regExp6 = RegExp(
      ' ',
      caseSensitive: false,
      multiLine: false,
    );
    var matches = contact.phoneNumber!.number!
        .replaceAll(regExp, "")
        .replaceAll(regExp2, "")
        .replaceAll(regExp3, "")
        .replaceAll(regExp4, "0")
        .replaceAll(regExp5, "")
        .replaceAll(regExp6, "");
    setState(() {
      _contact = contact;
      _numTopupController.text = matches;
      _paketVoucherController.text = "";
      _numError = false;
    });
    if (matches.length >= 4) {
      _getDenom();
      _numError = false;
      _dropError = false;
    }
    setState(() {
      _list.clear();
    });
  }

  _getRedaksi() async {
    final resp = await API.postNoLoading(context, '/redaksi/paket-data', {});
    if (resp['code'] == 0) {
      setState(() {
        redaksiname = resp['redaksi'];
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text("Data Internet",
            style: TextStyle(color: Colors.white, fontFamily: 'Poppins')),
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      backgroundColor: Colors.white,
      body: Form(
        // key: _formKey,

        child: SingleChildScrollView(
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
              ISTCardAccount(context: context, menu: ISTMenu.billpay),
              const SizedBox(height: 16),
              Container(
                alignment: Alignment.center,
                padding: const EdgeInsets.only(left: 16, right: 16),
                color: Colors.white,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    const Text(
                      "No Handphone :",
                    ),
                    const SizedBox(
                      height: 8,
                    ),
                    fromContact
                        ? Container(
                            alignment: Alignment.topLeft,
                            padding: const EdgeInsets.only(bottom: 8),
                            child: Text(
                              '$nomorHp',
                            ))
                        : TextFormField(
                            onChanged: (val) {
                              var noHP = val;
                              noHP = noHP
                                  .replaceAll("62", "0")
                                  .replaceAll("^62", "0")
                                  .replaceAll("^0+", "0")
                                  .replaceAll("^62", "0");
                              if (noHP.length >= 4) {
                                // setState(() {
                                // _enabled = true;
                                // });
                                _getDenom();
                              } else {
                                setState(() {
                                  _enabled = false;
                                  _paketVoucherController.clear();
                                });
                              }
                            },
                            maxLength: ISTConstants.handphoneMaxLength,
                            controller: _numTopupController,
                            decoration: InputDecoration(
                                errorText: _numError ? "Mohon diisi" : null,
                                hintText: "Masukkan nomor handphone",
                                hintStyle: ISTStyle.hintStyle,
                                suffixIcon: IconButton(
                                    icon: Image.asset(
                                      'assets/images/icon-phonebook.png',
                                      width: 30,
                                    ),
                                    onPressed: () {
                                      // _getPermission();
                                    })),
                            keyboardType: TextInputType.number,
                            inputFormatters: <TextInputFormatter>[
                              // ignore: deprecated_member_use
                              FilteringTextInputFormatter.digitsOnly,
                            ],
                          ),
                    const SizedBox(
                      height: 16,
                    ),
                    const Text(
                      "Voucher Data :",
                    ),
                    Container(
                      alignment: Alignment.topLeft,
                      child: TextFormField(
                        validator: (val) {
                          if (val!.isEmpty) {
                            return "Mohon pilih Voucher Data";
                          } else {
                            return null;
                          }
                        },
                        controller: _paketVoucherController,
                        onTap: () {
                          _getDenom2();
                        },
                        readOnly: true,
                        enabled: _enabled,
                        showCursor: false,
                        decoration: InputDecoration(
                          focusedBorder: const UnderlineInputBorder(
                              borderSide: BorderSide(color: Colors.grey)),

                          enabledBorder: const UnderlineInputBorder(
                            borderSide: BorderSide(color: Colors.grey),
                          ),
                          // errorText:
                          //     _kodeBankError ? "Mohon diisi" : null,
                          hintText: 'Pilih Voucher Data',
                          hintStyle: ISTStyle.hintStyle,
                          suffixIcon: _enabled
                              ? const Icon(
                                  Icons.arrow_forward_ios,
                                  color: Pallete.primary,
                                )
                              : const Icon(Icons.arrow_forward_ios),
                        ),
                      ),
                    ),
                    _dropError
                        ? Container(
                            alignment: Alignment.centerLeft,
                            child: const Text(
                              'Mohon pilih Voucher Data',
                              style: TextStyle(color: Colors.red),
                            ),
                          )
                        : Container(),
                    const SizedBox(
                      height: 8,
                    ),
                    Text('$redaksiname',
                        // '*Operator yang tersedia adalah Telkomsel, dan XL',
                        style: const TextStyle(
                            color: Colors.grey,
                            fontStyle: FontStyle.italic,
                            fontSize: 12)),
                  ],
                ),
              ),
              //   Center(
              //     child: Column(children: <Widget>[DropdownBelow(
              //       itemWidth: 200,
              // items: List<DropdownMenuItem<dynamic>>[

              // ],
              //     )
              //     ]),
              //   ),
              const SizedBox(height: 16),
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16),
                child: ISTOutlineButton(
                    onPressed: () {
                      if (!_doValidate()) return;
                      // if(_formKey.currentState.validate()){
                      _doInquiry();

                      // }
                      // _formKey.currentState.save();
                    },
                    text: "Lanjut"),
              ),
              const SizedBox(
                height: 16,
              )
            ])),
      ),
    );
  }
}
