import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_mpin.dart';
import 'package:bpd_aceh/components/ist_receipt.dart';
import 'package:bpd_aceh/components/ist_receipt_repo.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/crypto/ist_crypto.dart';
import 'package:bpd_aceh/features/home/home_page.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/Paket_Data/inq_paketdata/receiptpaket.dart';
import 'package:bpd_aceh/features/splash/splash.dart';

import 'package:flutter/material.dart';

class PaketDataMPINPage extends StatelessWidget {
  static const routeName = '/PaketDataMPIN';

  const PaketDataMPINPage({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return ISTMPIN(
      onFinishedVal: (value) async {
        Map<String, Object> param = {};
        final String pinEnc = await ISTCrypto.encryptAES(value);
        param['mpin'] = pinEnc;

        final resp = await API.post(context, '/purchase/data/request', param);
        if (resp['code'] != null && resp['code'] == 0) {
          List<ISTReceiptItem> listParam = [];
          List<ISTReceiptItemInbox> listParams = [];
          List<dynamic> listMap = resp['resi'];
          for (var item in listMap) {
            ISTReceiptItem itemParam =
                ISTReceiptItem(key: item['key'], value: item['value']);
            listParam.add(itemParam);
          }
          for (var item in listMap) {
            ISTReceiptItemInbox itemParams =
                ISTReceiptItemInbox(key: item['key'], value: item['value']);
            listParams.add(itemParams);
          }
          print(listMap);

          ISTReceiptStatus status = ISTReceiptStatus.suspect;

          if (resp['status'] != null && resp['status'] == 'success') {
            status = ISTReceiptStatus.success;
          }
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => PaketDataReceipt(
                        additional: resp['additionalInfo'],
                        additional1: resp['additionalInfo1'],
                        list: listParam,
                        amount: resp['amountStr'],
                        status: status,
                        title: resp['titel'],
                        subtitle: "Layanan",
                        date: resp['waktu'],
                        noId: resp['transactionId'],
                        lists: listParams,
                        noRef: resp['idresi'],
                        amountInbox: resp['transactionCurrency'],
                        img: "assets/images/icon-payments-active.png",
                      )));
        } else if (resp['code'] != null && resp['code'] != 0) {
          if (resp['code'] == -1002) {
            //Salah MPIN
            const DialogBox().showImageDialog(
                message: resp['message'],
                isError: true,
                buttonCancel: 'OK',
                onCancel: () {
                  Navigator.pop(context);
                },
                onOk: () {},
                context: context);
          } else if (resp['code'] == -4901) {
            //Saldo Tidak Cukup
            const DialogBox().showImageDialog(
                message: resp['message'],
                isError: true,
                buttonCancel: 'OK',
                onCancel: () {
                  Navigator.pushNamedAndRemoveUntil(context, HomePage.routeName,
                      ModalRoute.withName(Splash.routeName));
                },
                onOk: () {},
                context: context);
          } else if (resp['code'] == -1108) {
            //MPIN Ke Blokir
            const DialogBox().showImageDialog(
                message: resp['message'],
                isError: true,
                buttonCancel: 'OK',
                onCancel: () {
                  Navigator.pushNamedAndRemoveUntil(context, HomePage.routeName,
                      ModalRoute.withName(Splash.routeName));
                },
                onOk: () {},
                context: context);
          } else if (resp['code'] == -9999) {
            //MPIN Ke Blokir
            const DialogBox().showImageDialog(
                message: resp['message'],
                isError: true,
                buttonCancel: 'OK',
                onCancel: () {
                  Navigator.pushNamedAndRemoveUntil(context, HomePage.routeName,
                      ModalRoute.withName(Splash.routeName));
                },
                onOk: () {},
                context: context);
          } else {
            const DialogBox().showImageDialog(
                message: resp['message'],
                isError: true,
                buttonCancel: 'OK',
                onCancel: () {
                  Navigator.pop(context);
                },
                onOk: () {},
                context: context);
          }
        }
      },
    );
  }
}
