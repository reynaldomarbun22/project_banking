import 'package:bpd_aceh/components/ist_card_account.dart';
import 'package:bpd_aceh/components/ist_style.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/features/payment/beli_bayar/Pembelian/Paket_Data/confirmation_page_paketdata.dart';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
// import 'package:contact_picker/contact_picker.dart';
import 'package:fluttercontactpicker/fluttercontactpicker.dart';
import 'package:permission_handler/permission_handler.dart';

class ContactPickerController {
  // ignore: unused_field
  GlobalKey? _contactKey;

  ContactPickerController() {
    _contactKey = GlobalKey();
  }
}

class PembelianPaketData extends StatefulWidget {
  static const routeName = '/pembelianPaketData';

  const PembelianPaketData({Key? key}) : super(key: key);

  // static const routeName = '/payment/beli_bayar/Pulsa/mpin';
  @override
  _PembelianPaketDataState createState() => _PembelianPaketDataState();
}

class _PembelianPaketDataState extends State<PembelianPaketData> {
  // ignore: unused_field
  final List<Item> _list = <Item>[];
  // ignore: unused_field
  final bool _numError = false;
  bool dropdownError = false;
  // ignore: unused_field
  final bool _success = true;
  String? dropdownValue;
  bool _phoneNumberError = false;
  // ignore: unused_field
  final bool _pilihNominalError = false;

  // final ContactPicker _contactPicker = new ContactPicker();

  // ContactPickerController contactPickerController = ContactPickerController();
  // ignore: unused_field
  late Contact _contact;

  final TextEditingController _nomorPaketData = TextEditingController();

  // ignore: unused_field
  final bool _value = true;

  // ignore: unused_element
  _getContact() async {
    await Permission.contacts.request();
    // Contact contact = await _contactPicker.selectContact();
    final PhoneContact contact =
    await FlutterContactPicker.pickPhoneContact();
    RegExp regExp = RegExp(
      r'-',
      caseSensitive: false,
      multiLine: false,
    );
    var matches = contact.phoneNumber!.number!.replaceAll(regExp, '');
    setState(() {
      _contact = contact;
      _nomorPaketData.text = matches;
    });
  }

  bool _doValidate() {
    bool _success = true;
    if (_nomorPaketData.text.trim().isEmpty ||
        _nomorPaketData.text.trim() == '0') {
      setState(() {
        _phoneNumberError = true;
      });
      _success = false;
    } else {
      setState(() {
        _phoneNumberError = false;
      });
    }

    if (dropdownValue == null) {
      setState(() {
        dropdownError = true;
      });
      _success = false;
    } else {
      setState(() {
        dropdownError = false;
      });
    }
    return _success;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: const Text("Paket Data", style: TextStyle(color: Colors.white)),
        actions: <Widget>[
          IconButton(
            icon: const Icon(
              Icons.notifications,
              color: Colors.white,
            ),
            onPressed: () {
              // _doLogout();
            },
          )
        ],
        elevation: 0.0,
        backgroundColor: Pallete.primary,
      ),
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                const ISTCardAccount(context: null, menu: ISTMenu.billpay),
                const SizedBox(height: 32),
                Container(
                  alignment: Alignment.center,
                  padding: const EdgeInsets.only(left: 16, right: 16),
                  color: Colors.white,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      const Text(
                        "No. Handphone :",
                      ),
                      TextFormField(
                        maxLength: ISTConstants.handphoneMaxLength,
                        controller: _nomorPaketData,
                        decoration: InputDecoration(
                            errorText: _phoneNumberError ? "Mohon diisi" : null,
                            hintText: "Masukkan no. handphone",
                            hintStyle: ISTStyle.hintStyle,
                            suffixIcon: IconButton(
                                icon: Image.asset(
                                  'assets/images/icon-phonebook.png',
                                  width: 30,
                                ),
                                onPressed: () {
                                  // _getContact();
                                })),
                        keyboardType: TextInputType.number,
                        inputFormatters: <TextInputFormatter>[
                          // ignore: deprecated_member_use
                          FilteringTextInputFormatter.digitsOnly,
                        ],
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      const Text(
                        "Nominal",
                      ),
                      DropdownButton<String>(
                        value: dropdownValue,
                        hint: const Text("Pilih Nominal", style: ISTStyle.hintStyle),
                        isExpanded: true,
                        icon: const Icon(Icons.arrow_drop_down),
                        iconSize: 30,
                        // elevation: 16,
                        style: const TextStyle(color: Colors.black),
                        underline: Container(
                          height: 1,
                          color: Colors.black,
                        ),
                        onChanged: (String? newValue) {
                          setState(() {
                            dropdownValue = newValue;
                          });
                        },
                        items: <String>['20000', '50000', '100000']
                            .map<DropdownMenuItem<String>>((String value) {
                          return DropdownMenuItem<String>(
                            value: value,
                            child: Text(value),
                          );
                        }).toList(),
                      ),
                      dropdownError
                          ? Container(
                              alignment: Alignment.centerLeft,
                              child: const Text(
                                'Mohon pilih Nominal',
                                style: TextStyle(color: Colors.red),
                              ),
                            )
                          : const SizedBox.shrink(),
                    ],
                  ),
                ),
                const SizedBox(
                  height: 16,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 16, right: 16),
                  child: Expanded(
                      child: ISTOutlineButton(
                          onPressed: () {
                            if (_doValidate()) {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          const ConfirmationPagePaketData()));
                            }
                          },
                          text: "Lanjut")),
                )
              ])),
    );
  }
}

class Item {
  final String? name;
  final int? price;

  Item({this.name, this.price});
}
