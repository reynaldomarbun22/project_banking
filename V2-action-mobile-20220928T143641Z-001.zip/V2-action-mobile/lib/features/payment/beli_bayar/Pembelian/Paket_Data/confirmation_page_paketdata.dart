import 'package:bpd_aceh/components/ist_card_account.dart';
import 'package:bpd_aceh/components/ist_confirmation.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:flutter/material.dart';

class ConfirmationPagePaketData extends StatefulWidget {
  static const routeName = '/confirmationPagePaketData';

  const ConfirmationPagePaketData({Key? key}) : super(key: key);
  @override
  _ConfirmationPagePaketDataState createState() =>
      _ConfirmationPagePaketDataState();
}

class _ConfirmationPagePaketDataState extends State<ConfirmationPagePaketData> {
  //  _doTransfer() {
  //     Navigator.pushNamed(context, TransferMpinPageBankLain.routeName);
  //   }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: true,
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          centerTitle: true,
          title: const Text("Paket Data", style: TextStyle(color: Colors.white)),
          actions: <Widget>[
            IconButton(
              icon: const Icon(
                Icons.notifications,
                color: Colors.white,
              ),
              onPressed: () {
                // _doLogout();
              },
            )
          ],
          elevation: 0.0,
          backgroundColor: Pallete.primary,
        ),
        backgroundColor: Colors.white,
        body: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              const ISTCardAccount(context: null, menu: ISTMenu.home),
              const SizedBox(height: 32),
              Flexible(
                  flex: 2,
                  child: ISTConfirmation(
                      items: <ISTConfirmationItem>[
                        ISTConfirmationItem(
                          key: 'Dari Rekening',
                          value: '610.02.201.2512',
                        ),
                        ISTConfirmationItem(
                          key: 'Nomor Ponsel',
                          value: '082119500454',
                        ),
                        ISTConfirmationItem(
                          key: 'Paket Data',
                          value: 'IDR 50.000',
                        ),
                        ISTConfirmationItem(
                          key: 'Biaya Admin',
                          value: 'IDR 1.000',
                        ),
                        ISTConfirmationItem(
                          key: 'No. Referensi',
                          value: '2151251',
                        ),
                        ISTConfirmationItem(
                          key: 'Tanggal Transaksi',
                          value: '02/02/2020 18:18',
                        ),
                      ],
                      title: 'Konfirmasi Pembelian Paket Data',
                      onFinished: () {
                        // _doTransfer();
                      })),
            ]));
  }
}
