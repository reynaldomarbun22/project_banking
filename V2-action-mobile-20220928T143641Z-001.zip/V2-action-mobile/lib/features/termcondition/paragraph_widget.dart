import 'package:bpd_aceh/components/palete.dart';
import 'package:flutter/material.dart';

class ParagraphWidget extends StatelessWidget {
  final int? left;
  final int? right;
  final String? number;
  final String? judul;
  final List<TextSpan>? textList;

  const ParagraphWidget(
      {Key? key, this.left, this.right, this.number, this.textList, this.judul})
      : super(key: key);
  const ParagraphWidget.lv1(
      {Key? key,
      this.left = 2,
      this.right = 22,
      this.number,
      this.textList,
      this.judul})
      : super(key: key);
  const ParagraphWidget.lv2(
      {Key? key,
      this.left = 3,
      this.right = 18,
      this.number,
      this.textList,
      this.judul})
      : super(key: key);
  const ParagraphWidget.lv3(
      {Key? key,
      this.left = 4,
      this.right = 14,
      this.number,
      this.textList,
      this.judul})
      : super(key: key);
  const ParagraphWidget.lv4(
      {Key? key,
      this.left = 5,
      this.right = 10,
      this.number,
      this.textList,
      this.judul})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Align(
          alignment: Alignment.centerRight,
          child: RichText(
            textAlign: TextAlign.justify,
            softWrap: true,
            text: TextSpan(
              style: const TextStyle(
                  color: Pallete.primary,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Poppins'),
              children: [
                TextSpan(
                    text: judul, style: const TextStyle(fontFamily: 'Poppins')),
              ],
            ),
          ),
        ),
        Expanded(
          flex: left!,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Align(
              alignment: Alignment.centerRight,
              child: RichText(
                textAlign: TextAlign.justify,
                softWrap: true,
                text: TextSpan(
                  style: const TextStyle(
                      color: Colors.black, fontFamily: 'Poppins'),
                  children: [
                    TextSpan(
                        text: number,
                        style: const TextStyle(fontFamily: 'Poppins')),
                  ],
                ),
              ),
            ),
          ),
        ),
        Expanded(
          flex: right!,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Align(
              alignment: Alignment.centerLeft,
              child: RichText(
                textAlign: TextAlign.justify,
                softWrap: true,
                text: TextSpan(
                  style: const TextStyle(
                      color: Colors.black, fontFamily: 'Poppins'),
                  children: textList,
                ),
              ),
            ),
          ),
        )
      ],
    );
  }
}
