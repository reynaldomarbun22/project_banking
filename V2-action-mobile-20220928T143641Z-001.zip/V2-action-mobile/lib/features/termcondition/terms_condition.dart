import 'dart:async';
import 'dart:io';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/features/landing/landing.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class TermsAndCondition extends StatefulWidget {
  static const routeName = '/tna';

  const TermsAndCondition({Key? key}) : super(key: key);

  @override
  _TermsAndConditionState createState() => _TermsAndConditionState();
}

class _TermsAndConditionState extends State<TermsAndCondition> {
  final Completer<WebViewController> _controller =
      Completer<WebViewController>();

  bool? _boolValue = false;
  bool isLoading = true;
  String urlSNK = '';
  String urlAndro = 'https://action.bankaceh.co.id/snk.html';
  String urlIos = 'https://action.bankaceh.co.id/snk-ios.html';

  final Set<Factory> gestureRecognizers = {
    Factory(() => EagerGestureRecognizer()),
  }.toSet();

  @override
  void initState() {
    super.initState();
    if (Platform.isAndroid) WebView.platform = SurfaceAndroidWebView();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Syarat dan Ketentuan",
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'Poppins',
          ),
        ),
        centerTitle: true,
        backgroundColor: Pallete.primary,
      ),
      backgroundColor: Colors.white,
      body: foreground(),
    );
  }

  _onPressed() async {
    if (_boolValue!) {
      await ISTConstants()
          .setConstants(ISTConstants.agreeTermsAndCondition, true);
      Navigator.pushReplacementNamed(context, LandingPageScreen.routeName);
    }
  }

  Widget foreground() {
    return SafeArea(
      child: Column(
        children: <Widget>[
          Expanded(
            child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                child: Stack(
                  children: <Widget>[
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.7,
                      width: MediaQuery.of(context).size.width * 0.9,
                      child: WebView(
                        initialUrl: (Platform.isAndroid)
                            ? 'https://action.bankaceh.co.id/snk.html'
                            : 'https://action.bankaceh.co.id/snk-ios.html',
                        debuggingEnabled: true,
                        javascriptMode: JavascriptMode.unrestricted,
                        gestureRecognizers: gestureRecognizers
                            as Set<Factory<OneSequenceGestureRecognizer>>?,
                        onWebViewCreated:
                            (WebViewController webViewController) {
                          _controller.complete(webViewController);
                        },
                        onPageFinished: (finish) {
                          setState(() {
                            isLoading = false;
                          });
                        },
                      ),
                    ),
                    isLoading
                        ? const Center(
                            child: Text('Waiting...'),
                          )
                        : Stack(),
                    // SizedBox(
                    //   height: 16,
                    // ),
                  ],
                )),
          ),
          const Divider(
            height: 0,
            thickness: 1,
            color: Pallete.primary,
          ),
          Container(
            padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
            child: Row(
              mainAxisSize: MainAxisSize.max,
              children: <Widget>[
                Checkbox(
                    activeColor: Pallete.primary,
                    value: _boolValue,
                    onChanged: (value) {
                      setState(() {
                        _boolValue = value;
                      });
                    }),
                Expanded(
                  child: GestureDetector(
                    onTap: () {
                      setState(() {
                        _boolValue = !_boolValue!;
                      });
                    },
                    child: const Padding(
                      padding: EdgeInsets.only(right: 16.0),
                      child: Text(
                        "Saya menyetujui seluruh syarat dan ketentuan yang diberlakukan oleh setiap pihak terkait.",
                        softWrap: true,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: ISTOutlineButton(
                text: 'Lanjut',
                onPressed: () {
                  _onPressed();
                }),
          ),
          const SizedBox(height: 16)
        ],
      ),
    );
  }
}
