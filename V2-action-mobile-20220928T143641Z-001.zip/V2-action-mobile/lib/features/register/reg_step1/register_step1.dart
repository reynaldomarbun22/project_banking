import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/features/register/provider/register_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_masked_text2/flutter_masked_text2.dart';
import 'package:provider/provider.dart';

class RegisterStep1 extends StatefulWidget {
  static const routeName = '/register/step1';

  const RegisterStep1({Key? key}) : super(key: key);

  @override
  State<RegisterStep1> createState() => _RegisterStep1State();
}

class _RegisterStep1State extends State<RegisterStep1> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  // ignore: unused_field
  bool _autoValidate = false;
  final _pinController = MaskedTextController(mask: ("000000"));
  final _atmController = MaskedTextController(mask: ("0000-0000-0000-0000"));
  final _hpController = MaskedTextController(mask: ("000000000000000"));

  bool showPass = true;
  bool isLoading = false;

  @override
  Widget build(BuildContext context) {
    // ignore: unused_local_variable
    final value = Provider.of<RegisterProvider>(context);
    // ignore: unused_local_variable
    const loginText = Text(
      'Lanjut',
      style: TextStyle(
          fontWeight: FontWeight.w100, color: Colors.white, fontSize: 20),
    );

    bool _validateInputs() {
      if (_formKey.currentState!.validate()) {
        _formKey.currentState!.save();
        return true;
      } else {
        setState(() {
          _autoValidate = true;
        });
        return false;
      }
    }

    // ignore: unused_element
    _doValidateATMPIN() async {
      if (_validateInputs()) {
        Map param = {};
        param['cardATM'] = _atmController.text.replaceAll(" ", "");
        param['pin'] = _pinController.text;
        final resp = await API.post(
            context, '/register/step1', param as Map<String, Object?>);
        if (resp['code'] == 0) {
          // Navigator.pushNamed(context, RegisterStep2.routeName);
        } else {
          const DialogBox().showImageDialog(
              message: resp['message'],
              isError: true,
              image: const Image(
                image: AssetImage('assets/images/icon-failed.png'),
              ),
              buttonCancel: 'OK',
              onOk: () {},
              context: context);
        }
      }
    }

    return SafeArea(
      child: Column(children: <Widget>[
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Form(
            key: _formKey,
            // ignore: deprecated_member_use
            autovalidateMode: AutovalidateMode.always,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                const Text(
                  'Mohon masukkan data perbankan Anda',
                  style: TextStyle(fontSize: 16),
                ),
                const SizedBox(height: 32),
                const Text('NOMOR HANDPHONE ANDA'),
                TextFormField(
                  maxLength: 13,
                  validator: (val) {
                    if (val!.length < 11) {
                      return "Isi nomor Handphone Anda";
                    } else {
                      return null;
                    }
                  },
                  onSaved: (String? val) {
                    _hpController.text = val!;
                  },
                  expands: false,
                  obscureText: false,
                  keyboardType: TextInputType.number,
                  style: const TextStyle(fontSize: 16),
                  decoration: const InputDecoration(
                    hintText: 'Masukkan nomor Handphone Anda',
                  ),
                  controller: _hpController,
                ),
                const SizedBox(height: 8),
                const Text('NOMOR KARTU ATM'),
                TextFormField(
                  maxLength: 19,
                  validator: (val) {
                    if (val!.length < 19) {
                      return "Isi nomor Kartu ATM Anda";
                    } else {
                      return null;
                    }
                  },
                  onSaved: (String? val) {
                    _atmController.text = val!;
                  },
                  expands: false,
                  obscureText: false,
                  keyboardType: TextInputType.number,
                  style: const TextStyle(fontSize: 16),
                  decoration: const InputDecoration(
                      hintText: 'Masukkan nomor Kartu ATM Anda'),
                  controller: _atmController,
                ),
                const SizedBox(height: 8),
                const Text('PIN ATM'),
                TextFormField(
                  maxLength: 6,
                  expands: false,
                  obscureText: true,
                  keyboardType: TextInputType.number,
                  style: const TextStyle(fontSize: 16),
                  decoration: const InputDecoration(
                    hintText: 'Masukkan PIN ATM Anda',
                  ),
                  validator: (val) {
                    if (val!.length < 6) {
                      return "Isi PIN ATM Anda";
                    } else {
                      return null;
                    }
                  },
                  onSaved: (String? val) {
                    _pinController.text = val!;
                  },
                  controller: _pinController,
                ),
                // Padding(
                //   padding: const EdgeInsets.only(top: 30.0),
                //   child: RaisedButton(
                //       padding: EdgeInsets.all(10),
                //       shape: RoundedRectangleBorder(
                //           borderRadius:
                //               BorderRadius.all(Radius.circular(50))),
                //       splashColor: Pallete.primary,
                //       color: Pallete.primary,
                //       focusColor: Pallete.primary,
                //       hoverColor: Pallete.primary,
                //       onPressed: () {
                //         // _doValidateATMPIN();
                //       },
                //       child: loginText),
                // ),
              ],
            ),
          ),
        ),
      ]),
    );
  }
}
