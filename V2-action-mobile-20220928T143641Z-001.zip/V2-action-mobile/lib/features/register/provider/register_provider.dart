import 'package:bpd_aceh/features/register/provider/register_state.dart';
import 'package:flutter/material.dart';

class RegisterProvider with ChangeNotifier {
  RegisterState? _state;

  // ignore: unnecessary_getters_setters
  RegisterState? get state => _state;

  set state(RegisterState? state) {
    _state = state;
  }
}
