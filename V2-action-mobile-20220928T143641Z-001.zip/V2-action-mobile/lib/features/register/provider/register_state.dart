enum RegisterState {
  valid, error 
}

enum RegisterStepState{
  step1,step2,step3,step4
}