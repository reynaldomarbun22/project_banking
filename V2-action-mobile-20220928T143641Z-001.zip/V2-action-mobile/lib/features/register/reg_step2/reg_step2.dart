import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_pin_otp.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/features/landing/landing.dart';
import 'package:bpd_aceh/features/register/reg_step3/reg_step3.dart';
import 'package:flutter/material.dart';

class Reg2 extends StatefulWidget {
  static const String routeName = "/reg2";
  final Map<String, Object>? param;
//  final String param;

  const Reg2({Key? key, this.param}) : super(key: key);
  @override
  _Reg2State createState() => _Reg2State();
}

class _Reg2State extends State<Reg2> {
  _doOTP(value) async {
    Map<String, Object> param = {};

    param['otp'] = value;
    final resp = await API.post(context, '/register/step2', param);
    if (resp['code'] == 0) {
      Navigator.pushNamed(context, Reg3.routeName);
    } else {
      const DialogBox().showImageDialog(
          onOk: () {},
          message: resp['message'],
          isError: true,
          image: const Image(
            image: AssetImage('assets/images/icon-failed.png'),
          ),
          buttonCancel: 'OK',
          onCancel: () {
            Navigator.pushNamed(
              context,
              LandingPageScreen.routeName,
            );
          },
          context: context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Pallete.primary,
      body: SafeArea(
        bottom: false,
        child: ISTOTP(
          appBarTitle: 'Daftar',
          title: 'Masukkan 6 digit Kode OTP Anda',
          onFinishedVal: (value) {
            _doOTP(value);
          },
          param: widget.param,
          state: 'OTPregis',
        ),
      ),
    );
  }
}
