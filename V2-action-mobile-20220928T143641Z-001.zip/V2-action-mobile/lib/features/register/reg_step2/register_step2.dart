// import 'dart:ui';
// import '/features/register/reg_step3/register_step3.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:pin_entry_text_field/pin_entry_text_field.dart';
// import 'package:quiver/async.dart';

// class RegisterStep2 extends StatefulWidget {
//   static const routeName = '/register/step2';

//   @override
//   _RegisterStep2State createState() => _RegisterStep2State();
// }

// class _RegisterStep2State extends State<RegisterStep2> {
//   int _start = 60;

//   int _current = 60;

//   var _visible = false;

//   CountdownTimer countDownTimer;

//   void startTimer() {
//     countDownTimer = CountdownTimer(
//       Duration(seconds: 60),
//       Duration(seconds: 1),
//     );
//     _visible = false;
//     var sub = countDownTimer.listen(null);
//     sub.onData((duration) {
//       setState(() {
//         _current = _start - duration.elapsed.inSeconds;
//       });
//     });
//     sub.onDone(() {
//       _visible = true;
//       sub.cancel();
//     });
//   }

//   @override
//   void initState() {
//     startTimer();
//     super.initState();
//   }

//   @override
//   dispose() {
//     countDownTimer.cancel();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.white,
//         // body: PinForm(),
//         body: otp()
//     );
//   }

// Widget otp(){
//     var text = _current != 0 ? "($_current detik) " : '';

//  return Container(
//           color: Colors.white,
//           child: Center(
//               child: Stack(
//             children: <Widget>[
//               Padding(
//                 padding: const EdgeInsets.all(24.0),
//                 child: Column(children: <Widget>[
//                   Text('Masukkan kode OTP Anda'),
//                   SizedBox(height: 8),
//                   Text(
//                     '6 Digit kode OTP yang dikirimkan ke nomor Handphone Anda',
//                     style: TextStyle(
//                       fontWeight: FontWeight.w100,
//                       fontStyle: FontStyle.italic,
//                     ),
//                   ),
//                   SizedBox(
//                     height: 32,
//                   ),
//                   PinEntryTextField(
//                       fields: 6,
//                       isTextObscure: true,
//                       onSubmit: (String pin) {
//                          Navigator.pushReplacementNamed(context, RegisterStep3.routeName);
//                       }),
//                       SizedBox(height: 16,),
//                   FlatButton(
//                       onPressed: () {
//                         startTimer();
//                       },
//                       child: Text(
//                         'Kirim ulang kode OTP',
//                         style: TextStyle(
//                             color: Colors.red, fontStyle: FontStyle.italic),
//                       )),
//                   Visibility(
//                     child: Container(
//                       child: FlatButton(
//                         color: _current != 0 ? Colors.grey : null,
//                         child: Text('$text'),
//                         onPressed: _visible
//                             ? () {
//                                 startTimer();
//                               }
//                             : null,
//                       ),
//                     ),
//                   ),
//                 ]),
//               )
//             ],
//           )),
//         );
// }
// }
