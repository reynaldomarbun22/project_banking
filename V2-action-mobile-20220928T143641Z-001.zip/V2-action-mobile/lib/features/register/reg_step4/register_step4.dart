import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/features/landing/landing.dart';
import 'package:bpd_aceh/features/login/login.dart';
import 'package:bpd_aceh/features/splash/splash.dart';
import 'package:platform_device_id/platform_device_id.dart';
import 'package:flutter/material.dart';

class RegisterStep4 extends StatelessWidget {
  static const routeName = '/register/step4';

  const RegisterStep4({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text(
          'Daftar',
          style: TextStyle(
            color: Colors.black,
            fontFamily: 'Poppins',
          ),
        ),
        centerTitle: true,
        elevation: 0.0,
        iconTheme: const IconThemeData(color: Colors.black),
        backgroundColor: Colors.transparent,
      ),
      body: const FormPin(),
    );
  }
}

class FormPin extends StatefulWidget {
  const FormPin({Key? key}) : super(key: key);

  @override
  State<FormPin> createState() => _FormPinState();
}

class _FormPinState extends State<FormPin> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  // ignore: unused_field
  bool _autoValidate = false;

  final _mpinController = TextEditingController();
  final _mpinConfirmController = TextEditingController();

  bool showPass = true;
  bool isLoading = false;

  @override
  Widget build(BuildContext context) {
    const loginText = Text(
      'Lanjut',
      style: TextStyle(
          fontWeight: FontWeight.w100, color: Colors.white, fontSize: 20),
    );

    bool _validateInputs() {
      if (_formKey.currentState!.validate()) {
        _formKey.currentState!.save();
        return true;
      } else {
        setState(() {
          _autoValidate = true;
        });
        return false;
      }
    }

    _doValidateUser() async {
      if (_validateInputs()) {
        Map param = {};
        param['mpin'] = _mpinController.text;
        String? deviceid = await PlatformDeviceId.getDeviceId;

        param['deviceId'] = deviceid;

        final resp = await API.post(
            context, '/register/step4', param as Map<String, Object?>);
        if (resp['code'] == 0) {
          ISTConstants().setConstants(ISTConstants.hasRegistered, true);
          const DialogBox().showImageDialog(
              message: "Sukses Membuat User",
              isError: false,
              icon: const Icon(Icons.account_circle),
              buttonOk: 'OK',
              onOk: () {
                Navigator.pushNamedAndRemoveUntil(
                    context,
                    LandingPageScreen.routeName,
                    ModalRoute.withName(Splash.routeName));
                Navigator.pushNamed(context, LoginPage.routeName);
              },
              context: context);
        } else {
          const DialogBox().showImageDialog(
              message: resp['message'],
              isError: false,
              icon: const Icon(Icons.account_circle),
              buttonOk: 'OK',
              onOk: () {},
              context: context);
        }
      }
    }

    return SafeArea(
      child: Center(
        child: Stack(children: <Widget>[
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Form(
              key: _formKey,
              // ignore: deprecated_member_use
              autovalidateMode: AutovalidateMode.always,
              child: ListView(
                children: <Widget>[
                  const Text('Pembuatan 6 Digit MPIN'),
                  const SizedBox(height: 16),
                  TextFormField(
                    maxLength: 6,
                    expands: false,
                    obscureText: true,
                    validator: (val) {
                      if (val!.length < 6) {
                        return "Masukkan 6 digit MPIN Anda";
                      } else {
                        return null;
                      }
                    },
                    onSaved: (String? val) {
                      _mpinController.text = val!;
                    },
                    keyboardType: TextInputType.number,
                    style: const TextStyle(fontSize: 20),
                    decoration: const InputDecoration(
                        hintText: 'MPIN', labelText: 'MPIN'),
                    controller: _mpinController,
                  ),
                  const SizedBox(height: 8),
                  TextFormField(
                    maxLength: 6,
                    expands: false,
                    validator: (val) {
                      if (val != _mpinController.text) {
                        return "MPIN harus sama";
                      } else {
                        return null;
                      }
                    },
                    onSaved: (String? val) {
                      _mpinConfirmController.text = val!;
                    },
                    obscureText: true,
                    keyboardType: TextInputType.number,
                    style: const TextStyle(fontSize: 20),
                    decoration: const InputDecoration(
                        hintText: 'Konfirmasi MPIN',
                        labelText: 'Konfirmasi MPIN'),
                    controller: _mpinConfirmController,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 30.0),
                    child: SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                          onHover: (value) => Pallete.primary,
                          onFocusChange: (value) => Pallete.primary,
                          onLongPress: () => Pallete.primary,
                          style: ElevatedButton.styleFrom(
                            padding: const EdgeInsets.all(10),
                            shape: const RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(50))),
                            primary: Pallete.primary,
                          ),
                          onPressed: () {
                            _doValidateUser();
                          },
                          child: loginText),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
