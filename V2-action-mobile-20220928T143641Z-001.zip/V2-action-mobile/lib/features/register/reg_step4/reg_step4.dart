import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/features/landing/landing.dart';
import 'package:bpd_aceh/features/login/login.dart';
import 'package:bpd_aceh/features/splash/splash.dart';
import 'package:flutter/material.dart';

class Reg4 extends StatefulWidget {
  static const String routeName = "/reg4";

  const Reg4({Key? key}) : super(key: key);

  @override
  _Reg4State createState() => _Reg4State();
}

class _Reg4State extends State<Reg4> {
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(
            title: const Text(
              'Daftar',
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'Poppins',
              ),
            ),
            centerTitle: true,
            elevation: 0.0,
            backgroundColor: Pallete.primary,
          ),
          body: SafeArea(
            child: Container(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Image.asset('assets/images/verifikasiberhasil.png'),
                    const Text(
                      'PROSES  REGISTRASI BERHASIL DILAKUKAN',
                      style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Pallete.primary),
                    ),
                    const Text(
                      'Tekan tombol LOGIN untuk langkah selanjutnya',
                      style: TextStyle(fontSize: 14, color: Pallete.thirdy),
                    ),
                    const Spacer(),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: ISTOutlineButton(
                        onPressed: () {
                          Navigator.pushNamedAndRemoveUntil(
                              context,
                              LandingPageScreen.routeName,
                              ModalRoute.withName(Splash.routeName));
                          Navigator.pushNamed(context, LoginPage.routeName);
                        },
                        text: 'Login',
                      ),
                    )
                  ],
                )),
          )),
    );
  }
}
