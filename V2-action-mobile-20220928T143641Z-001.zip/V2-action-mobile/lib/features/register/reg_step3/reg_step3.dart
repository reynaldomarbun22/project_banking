import 'dart:io';

import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/ist_style.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/core/crypto/ist_crypto.dart';
import 'package:bpd_aceh/core/utils/string_utils.dart';
import 'package:bpd_aceh/features/landing/landing.dart';
import 'package:bpd_aceh/features/register/reg_step4/reg_step4.dart';
import 'package:flutter/material.dart';
import 'package:wc_form_validators/wc_form_validators.dart';

class Reg3 extends StatefulWidget {
  static const String routeName = "/reg3";

  const Reg3({Key? key}) : super(key: key);

  @override
  State<Reg3> createState() => _Reg3State();
}

class _Reg3State extends State<Reg3> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  // ignore: unused_field
  bool _autoValidate = false;

  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();
  final _passwordConfirmController = TextEditingController();

  bool showPass = true;
  bool showPassConfirm = true;
  bool isLoading = false;
  bool _unameError = false;
  bool _passError = false;
  bool _passConfError = false;

  _showPassword() {
    setState(() {
      showPass = !showPass;
    });
  }

  _showPasswordConfirm() {
    setState(() {
      showPassConfirm = !showPassConfirm;
    });
  }

  bool _validateInputs() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      return true;
    } else {
      setState(() {
        _autoValidate = true;
      });
      return false;
    }
  }

  bool _doValidate() {
    if (_validateInputs() != true) return false;
    bool _success = true;
    if (_usernameController.text.isEmpty) {
      setState(() {
        _unameError = true;
      });
      _success = false;
    } else {
      setState(() {
        _unameError = false;
      });
    }
//String pattern = r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,32}$';
//    RegExp regExp = new RegExp(pattern);
//    if (regExp.hasMatch(_passwordController.text)){
//      setState(() {
//        _passError = false;
//      });
//      } else{
//        _passError = true;
//      }

    if (_passwordController.text.isEmpty) {
      setState(() {
        _passError = true;
      });
      _success = false;
    } else {
      setState(() {
        _passError = false;
      });
    }
    if (_passwordConfirmController.text.isEmpty) {
      setState(() {
        _passConfError = true;
      });
      _success = false;
    } else {
      setState(() {
        _passConfError = false;
      });
    }
    return _success;
  }

  _doCreateUser() async {
    if (_doValidate()) {
      Map<String, Object> param = {};

      param['username'] = _usernameController.text;
      final password = await ISTCrypto.encryptAES(_passwordController.text);
      param['password'] = password;

      final resp = await API.post(context, '/register/step3', param);
      if (resp['code'] == 0) {
        Navigator.pushNamed(context, Reg4.routeName);
      } else {
        const DialogBox().showImageDialog(
            onOk: () {},
            message: resp['message'],
            isError: true,
            image: const Image(
              image: AssetImage('assets/images/icon-failed.png'),
            ),
            buttonCancel: 'OK',
            onCancel: () {
              Navigator.pushNamed(
                context,
                LandingPageScreen.routeName,
              );
            },
            context: context);
      }
    }
  }

  _exitApp(BuildContext context) {
    const DialogBox().showImageDialog(
      image: const Image(
        image: AssetImage('assets/images/icon-warning.png'),
      ),
      message: "Anda Akan Membatalkan Proses Pendaftaran Action Mobile.",
      context: context,
      isError: true,
      onOk: () {
        exit(0);
      },
      onCancel: () {
        Navigator.pop(context);
      },
      buttonOk: 'Ya',
      buttonCancel: 'Tidak',
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () => _exitApp(context),
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          leading: Container(),
          title: const Text(
            'Daftar',
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'Poppins',
            ),
          ),
          centerTitle: true,
          elevation: 0.0,
          iconTheme: const IconThemeData(color: Colors.black),
          backgroundColor: Pallete.primary,
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            child: Container(
              padding: const EdgeInsets.all(16),
              child: Form(
                key: _formKey,
                // ignore: deprecated_member_use
                autovalidateMode: AutovalidateMode.always,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Container(
                        alignment: Alignment.topLeft,
                        child:
                            const Text('Silakan buat Username dan Password')),
                    const SizedBox(height: 16),
                    Container(
                        alignment: Alignment.topLeft,
                        child: const Text('USERNAME')),
                    TextFormField(
                      inputFormatters: [
                        StringUtils.alphaNumeric(),
                        StringUtils.noSpace()
                      ],
                      onChanged: (val) {
                        setState(() {
                          if (val.isEmpty) {
                            _unameError = true;
                          } else {
                            _unameError = false;
                          }
                        });
                      },
                      maxLength: 25,
                      expands: false,
                      obscureText: false,
                      keyboardType: TextInputType.text,
                      onSaved: (String? val) {
                        _usernameController.text = val!;
                      },
                      decoration: InputDecoration(
                        counterText: '',
                        hintText: 'Masukkan username Anda',
                        hintStyle: ISTStyle.hintStyle,
                        errorText: _unameError ? "Mohon diisi" : null,
                      ),
                      controller: _usernameController,
                      validator: (val) {
                        if (val!.length < 8) {
                          return "*minimal 8 karakter";
                        } else {
                          return null;
                        }
                      },
                    ),
                    const SizedBox(height: 8),
                    Container(
                        alignment: Alignment.topLeft,
                        child: const Text('PASSWORD')),
                    TextFormField(
                      inputFormatters: [
                        // StringUtils.alphaNumeric(),
                        StringUtils.noSpace()
                      ],
                      onChanged: (val) {
                        setState(() {
                          if (val.isEmpty) {
                            _passError = true;
                          } else {
                            _passError = false;
                          }
                        });
                      },
                      maxLength: ISTConstants.passwordMaxLength,
                      expands: false,
                      obscureText: showPass,
                      keyboardType: TextInputType.text,
                      validator: Validators.compose([
                        Validators.required('Mohon diisi'),
                        Validators.patternString(
                            r'^(?=.*?[a-z])(?=.*?[0-9]).{8,32}$',
                            'Minimal 8 karakter kombinasi huruf dan angka'),
                        Validators.minLength(
                            8, 'Minimal 8 karakter kombinasi huruf dan angka')
                      ]),
                      onSaved: (String? val) {
                        _passwordController.text = val!;
                      },
                      decoration: InputDecoration(
                        hintText: 'Masukkan Password Anda',
                        errorText: _passError ? "Mohon diisi" : null,
                        hintStyle: ISTStyle.hintStyle,
                        suffixIcon: IconButton(
                          icon: Icon(showPass
                              ? Icons.visibility
                              : Icons.visibility_off),
                          onPressed: () {
                            _showPassword();
                          },
                        ),
                      ),
                      controller: _passwordController,
                    ),
                    const SizedBox(height: 8),
                    Container(
                        alignment: Alignment.topLeft,
                        child: const Text('KONFIRMASI PASSWORD')),
                    TextFormField(
                      onChanged: (val) {
                        setState(() {
                          if (val.isEmpty) {
                            _passConfError = true;
                          } else {
                            _passConfError = false;
                          }
                        });
                      },
                      // maxLength: 25,
                      expands: false,
                      validator: (val) {
                        if (val != _passwordController.text) {
                          return "*konfirmasi password tidak sama";
                        } else {
                          return null;
                        }
                      },
                      onSaved: (String? val) {
                        _passwordConfirmController.text = val!;
                      },
                      inputFormatters: [
                        // StringUtils.alphaNumeric(),
                        StringUtils.noSpace()
                      ],
                      obscureText: showPassConfirm,
                      keyboardType: TextInputType.text,
                      decoration: InputDecoration(
                        hintText: 'Konfirmasi Password Anda',
                        errorText: _passConfError ? "Mohon diisi" : null,
                        hintStyle: ISTStyle.hintStyle,
                        suffixIcon: IconButton(
                          icon: Icon(showPassConfirm
                              ? Icons.visibility
                              : Icons.visibility_off),
                          onPressed: () {
                            _showPasswordConfirm();
                          },
                        ),
                      ),
                      controller: _passwordConfirmController,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 16),
                      child: ISTOutlineButton(
                          onPressed: () {
                            _doCreateUser();
                          },
                          text: 'Lanjut'),
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
