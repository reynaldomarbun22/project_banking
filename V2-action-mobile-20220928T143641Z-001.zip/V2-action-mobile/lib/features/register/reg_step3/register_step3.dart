import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/crypto/ist_crypto.dart';
import 'package:bpd_aceh/features/register/reg_step4/register_step4.dart';
import 'package:flutter/material.dart';

class RegisterStep3 extends StatelessWidget {
  static const routeName = '/step3';

  const RegisterStep3({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text(
          'Daftar',
          style: TextStyle(
            color: Colors.black,
            fontFamily: 'Poppins',
          ),
        ),
        centerTitle: true,
        elevation: 0.0,
        iconTheme: const IconThemeData(color: Colors.black),
        backgroundColor: Colors.transparent,
      ),
      body: const PinForm3(),
    );
  }
}

class PinForm3 extends StatefulWidget {
  const PinForm3({Key? key}) : super(key: key);

  @override
  State<PinForm3> createState() => _PinForm3State();
}

class _PinForm3State extends State<PinForm3> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  // ignore: unused_field
  bool _autoValidate = false;

  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();
  final _passwordConfirmController = TextEditingController();

  bool showPass = true;
  bool isLoading = false;

  @override
  Widget build(BuildContext context) {
    _showPassword() {
      setState(() {
        showPass = !showPass;
      });
    }

    // ignore: unused_local_variable
    const loginText = Text(
      'Lanjut',
      style: TextStyle(
          fontWeight: FontWeight.w100, color: Colors.white, fontSize: 20),
    );

    bool _validateInputs() {
      if (_formKey.currentState!.validate()) {
        _formKey.currentState!.save();
        return true;
      } else {
        setState(() {
          _autoValidate = true;
        });
        return false;
      }
    }

    _doValidateUser() async {
      if (_validateInputs()) {
        Map param = {};
        param['username'] = _usernameController.text;
        final password = await ISTCrypto.encryptAES(_passwordController.text);
        param['password'] = password;

        final resp = await API.post(
            context, '/register/step3', param as Map<String, Object?>);
        if (resp['code'] == 0) {
          Navigator.pushNamed(context, RegisterStep4.routeName);
        } else {
          const DialogBox().showImageDialog(
              message: resp['message'],
              isError: true,
              image: const Image(
                image: AssetImage('assets/images/icon-failed.png'),
              ),
              buttonCancel: 'OK',
              onOk: () {},
              context: context);
        }
      }
    }

    return SafeArea(
      child: Center(
        child: Stack(children: <Widget>[
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Form(
              key: _formKey,
              // ignore: deprecated_member_use
              autovalidateMode: AutovalidateMode.always,
              child: ListView(
                children: <Widget>[
                  const Text('Silakan buat Username dan Password s'),
                  const SizedBox(height: 16),
                  const Text('USERNAME'),
                  TextFormField(
                    maxLength: 30,
                    expands: false,
                    obscureText: false,
                    keyboardType: TextInputType.text,
                    style: const TextStyle(fontSize: 16),
                    decoration:
                        const InputDecoration(hintText: 'Masukkan username Anda'),
                    controller: _usernameController,
                    validator: (val) {
                      if (val!.length < 8) {
                        return "*minimal 8 karakter";
                      } else {
                        return null;
                      }
                    },
                  ),
                  const SizedBox(height: 8),
                  const Text('PASSWORD'),
                  TextFormField(
                    expands: false,
                    obscureText: showPass,
                    keyboardType: TextInputType.text,
                    style: const TextStyle(fontSize: 16),
                    validator: (val) {
                      if (val!.length < 8) {
                        return "*minimal 8 karakter kombinasi huruf dan angka";
                      } else {
                        return null;
                      }
                    },
                    onSaved: (String? val) {
                      _passwordController.text = val!;
                    },
                    decoration: InputDecoration(
                      hintText: 'Masukkan Password Anda',
                      hintStyle:
                          const TextStyle(fontSize: 14, fontStyle: FontStyle.italic),
                      suffixIcon: IconButton(
                        icon: const Icon(Icons.remove_red_eye),
                        onPressed: () {
                          _showPassword();
                        },
                      ),
                    ),
                    controller: _passwordController,
                  ),
                  const SizedBox(height: 8),
                  const Text('KONFIRMASI PASSWORD'),
                  TextFormField(
                    expands: false,
                    validator: (val) {
                      if (val != _passwordController.text) {
                        return "*minimal 8 karakter kombinasi huruf dan angka";
                      } else {
                        return null;
                      }
                    },
                    obscureText: showPass,
                    keyboardType: TextInputType.text,
                    style: const TextStyle(fontSize: 16),
                    decoration: InputDecoration(
                      hintText: 'Konfirmasi Password Anda',
                      hintStyle:
                          const TextStyle(fontSize: 14, fontStyle: FontStyle.italic),
                      suffixIcon: IconButton(
                        icon: const Icon(Icons.remove_red_eye),
                        onPressed: () {
                          _showPassword();
                        },
                      ),
                    ),
                    controller: _passwordConfirmController,
                    onSaved: (String? val) {
                      _passwordConfirmController.text = val!;
                    },
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 16),
                    child: ISTOutlineButton(
                        onPressed: () {
                          _doValidateUser();
                        },
                        text: 'Lanjut'),
                  ),
                ],
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
