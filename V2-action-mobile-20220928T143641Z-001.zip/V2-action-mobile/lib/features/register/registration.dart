import 'package:bpd_aceh/components/dialog_box.dart';
import 'package:bpd_aceh/components/palete.dart';
import 'package:bpd_aceh/components/button.dart';
import 'package:bpd_aceh/core/api/api.dart';
import 'package:bpd_aceh/core/constants/ist_constants.dart';
import 'package:bpd_aceh/core/crypto/ist_crypto.dart';
import 'package:bpd_aceh/features/landing/landing.dart';
import 'package:bpd_aceh/features/login/login.dart';
import 'package:bpd_aceh/features/register/provider/register_provider.dart';
import 'package:bpd_aceh/features/register/reg_step1/register_step1.dart';
import 'package:bpd_aceh/features/register/reg_step4/register_step4.dart';
import 'package:bpd_aceh/features/splash/splash.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:quiver/async.dart';

class Registration extends StatefulWidget {
  static const String routeName = "/registration";

  const Registration({Key? key}) : super(key: key);

  @override
  _RegistrationState createState() => _RegistrationState();
}

class _RegistrationState extends State<Registration> {
  late int _currentStep = 0;
  final int _start = 60;

  int _current = 60;

  var _visible = false;

  late CountdownTimer countDownTimer;

  void startTimer() {
    countDownTimer = CountdownTimer(
      const Duration(seconds: 60),
      const Duration(seconds: 1),
    );
    _visible = false;
    var sub = countDownTimer.listen(null);
    sub.onData((duration) {
      setState(() {
        _current = _start - duration.elapsed.inSeconds;
      });
    });
    sub.onDone(() {
      _visible = true;
      sub.cancel();
    });
  }

  @override
  void initState() {
    startTimer();
    super.initState();
  }

  @override
  dispose() {
    countDownTimer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Pallete.primary,
      appBar: AppBar(
        leading: IconButton(
            icon: const Icon(
              Icons.arrow_back_ios,
              color: Colors.white,
            ),
            onPressed: () {
              Navigator.pop(context);
            }),
        title: const Text(
          'Daftar',
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'Poppins',
          ),
        ),
        centerTitle: true,
        elevation: 0.0,
        iconTheme: const IconThemeData(color: Colors.black),
        backgroundColor: Pallete.primary,
      ),
      body: SafeArea(
        child: Theme(
          data: ThemeData(
              canvasColor: Pallete.primary,
              primaryColor: Pallete.secondary,
              backgroundColor: Pallete.primary),
          child: ChangeNotifierProvider<RegisterProvider>(
            create: (context) => RegisterProvider(),
            child: Stepper(
              controlsBuilder:
                  (BuildContext context, ControlsDetails controlsDetails) =>
                      ISTOutlineButton(
                text: 'Lanjut',
                onPressed: () {
                  controlsDetails;
                },
              ),
              type: StepperType.horizontal,
              currentStep: _currentStep,
              onStepTapped: (int step) => setState(() => _currentStep = step),
              onStepContinue: _currentStep < 3
                  ? () => setState(() => _currentStep += 1)
                  : null,
              onStepCancel: _currentStep > 0
                  ? () => setState(() => _currentStep -= 1)
                  : null,
              steps: <Step>[
                Step(
                  title: const Text(''),
                  content: SingleChildScrollView(
                      // ignore: avoid_unnecessary_containers
                      child: Container(child: const RegisterStep1())),
                  isActive: _currentStep == 0,
                  state: _currentStep >= 0
                      ? StepState.complete
                      : StepState.disabled,
                ),
                Step(
                  title: const Text(''),
                  content:
                      SingleChildScrollView(child: Container(child: otp())),
                  isActive: _currentStep == 1,
                  state: _currentStep >= 1
                      ? StepState.complete
                      : StepState.disabled,
                ),
                Step(
                  title: const Text(''),
                  content: const PinForm3(),
                  isActive: _currentStep == 2,
                  state: _currentStep >= 2
                      ? StepState.complete
                      : StepState.disabled,
                ),
                Step(
                  title: const Text(''),
                  content: const FormPin(),
                  isActive: _currentStep == 3,
                  state: _currentStep >= 3
                      ? StepState.complete
                      : StepState.disabled,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget otp() {
    var text = _current != 0 ? "($_current detik) " : '';

    return Container(
      padding: const EdgeInsets.all(8.0),
      color: Colors.white,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          const Text('Masukkan kode OTP Anda'),
          const SizedBox(height: 8),
          const Text(
            '6 Digit kode OTP yang dikirimkan ke nomor Handphone Anda',
            style: TextStyle(
              fontWeight: FontWeight.w100,
              fontStyle: FontStyle.italic,
            ),
          ),
          const SizedBox(
            height: 32,
          ),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(children: <Widget>[
              // PinEntryTextField(
              //     fields: 6,
              //     isTextObscure: true,
              //     onSubmit: (String pin) {
              //       Navigator.pushReplacementNamed(
              //           context, RegisterStep3.routeName);
              //     }),
              const SizedBox(
                height: 16,
              ),
              TextButton(
                  onPressed: () {
                    startTimer();
                  },
                  child: const Text(
                    'Kirim ulang kode OTP',
                    style: TextStyle(
                        color: Colors.red, fontStyle: FontStyle.italic),
                  )),
              Visibility(
                child: TextButton(
                  style: TextButton.styleFrom(
                    primary: _current != 0 ? Colors.grey : null,
                  ),
                  child: Text(text),
                  onPressed: _visible
                      ? () {
                          startTimer();
                        }
                      : null,
                ),
              ),
            ]),
          )
        ],
      ),
    );
  }
}

class PinForm3 extends StatefulWidget {
  const PinForm3({Key? key}) : super(key: key);

  @override
  State<PinForm3> createState() => _PinForm3State();
}

class _PinForm3State extends State<PinForm3> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  // ignore: unused_field
  bool _autoValidate = false;

  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();
  final _passwordConfirmController = TextEditingController();

  bool showPass = true;
  bool isLoading = false;

  @override
  Widget build(BuildContext context) {
    _showPassword() {
      setState(() {
        showPass = !showPass;
      });
    }

    // ignore: unused_local_variable
    const loginText = Text(
      'Lanjut',
      style: TextStyle(
          fontWeight: FontWeight.w100, color: Colors.white, fontSize: 20),
    );

    bool _validateInputs() {
      if (_formKey.currentState!.validate()) {
        _formKey.currentState!.save();
        return true;
      } else {
        setState(() {
          _autoValidate = true;
        });
        return false;
      }
    }

    // ignore: unused_element
    _doValidateUser() async {
      if (_validateInputs()) {
        Map param = {};
        param['username'] = _usernameController.text;
        final password = await ISTCrypto.encryptAES(_passwordController.text);
        param['password'] = password;

        final resp = await API.post(
            context, '/register/step3', param as Map<String, Object?>);
        if (resp['code'] == 0) {
          Navigator.pushNamed(context, RegisterStep4.routeName);
        } else {
          const DialogBox().showImageDialog(
              message: resp['message'],
              isError: true,
              image: const Image(
                image: AssetImage('assets/images/icon-failed.png'),
              ),
              buttonCancel: 'OK',
              onOk: () {},
              context: context);
        }
      }
    }

    return Container(
      padding: const EdgeInsets.only(top: 10, bottom: 10),
      child:
          Column(mainAxisAlignment: MainAxisAlignment.start, children: <Widget>[
        Form(
          key: _formKey,
          // ignore: deprecated_member_use
          autovalidateMode: AutovalidateMode.always,
          child: Column(
            children: <Widget>[
              Container(
                  alignment: Alignment.topLeft,
                  child: const Text('Silakan buat Username dan Password')),
              const SizedBox(height: 16),
              Container(
                  alignment: Alignment.topLeft, child: const Text('USERNAME')),
              TextFormField(
                maxLength: 30,
                expands: false,
                obscureText: false,
                keyboardType: TextInputType.text,
                style: const TextStyle(fontSize: 16),
                decoration:
                    const InputDecoration(hintText: 'Masukkan username Anda'),
                controller: _usernameController,
                validator: (val) {
                  if (val!.length < 8) {
                    return "*minimal 8 karakter";
                  } else {
                    return null;
                  }
                },
              ),
              const SizedBox(height: 8),
              Container(
                  alignment: Alignment.topLeft, child: const Text('PASSWORD')),
              TextFormField(
                expands: false,
                obscureText: showPass,
                keyboardType: TextInputType.text,
                style: const TextStyle(fontSize: 16),
                validator: (val) {
                  if (val!.length < 8) {
                    return "*minimal 8 karakter kombinasi huruf dan angka";
                  } else {
                    return null;
                  }
                },
                onSaved: (String? val) {
                  _passwordController.text = val!;
                },
                decoration: InputDecoration(
                  hintText: 'Masukkan Password Anda',
                  hintStyle: const TextStyle(
                      fontSize: 14, fontStyle: FontStyle.italic),
                  suffixIcon: IconButton(
                    icon: const Icon(Icons.remove_red_eye),
                    onPressed: () {
                      _showPassword();
                    },
                  ),
                ),
                controller: _passwordController,
              ),
              const SizedBox(height: 8),
              Container(
                  alignment: Alignment.topLeft,
                  child: const Text('KONFIRMASI PASSWORD')),
              TextFormField(
                expands: false,
                validator: (val) {
                  if (val != _passwordController.text) {
                    return "*minimal 8 karakter kombinasi huruf dan angka";
                  } else {
                    return null;
                  }
                },
                obscureText: showPass,
                keyboardType: TextInputType.text,
                style: const TextStyle(fontSize: 16),
                decoration: InputDecoration(
                  hintText: 'Konfirmasi Password Anda',
                  hintStyle: const TextStyle(
                      fontSize: 14, fontStyle: FontStyle.italic),
                  suffixIcon: IconButton(
                    icon: const Icon(Icons.remove_red_eye),
                    onPressed: () {
                      _showPassword();
                    },
                  ),
                ),
                controller: _passwordConfirmController,
                onSaved: (String? val) {
                  _passwordConfirmController.text = val!;
                },
              ),
              // Padding(
              //   padding: const EdgeInsets.only(top: 30.0),
              //   child: Container(
              //     width: double.infinity,
              //     child: RaisedButton(
              //         padding: EdgeInsets.all(10),
              //         shape: RoundedRectangleBorder(
              //             borderRadius:
              //                 BorderRadius.all(Radius.circular(50))),
              //         splashColor: Pallete.primary,
              //         color: Pallete.primary,
              //         focusColor: Pallete.primary,
              //         hoverColor: Pallete.primary,
              //         onPressed: () {
              // _doValidateUser();
              //         },
              //         child: loginText),
              //   ),
              // ),
            ],
          ),
        ),
      ]),
    );
  }
}

class FormPin extends StatefulWidget {
  const FormPin({Key? key}) : super(key: key);

  @override
  State<FormPin> createState() => _FormPinState();
}

class _FormPinState extends State<FormPin> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  // ignore: unused_field
  bool _autoValidate = false;

  final _mpinController = TextEditingController();
  final _mpinConfirmController = TextEditingController();

  bool showPass = true;
  bool isLoading = false;

  @override
  Widget build(BuildContext context) {
    // ignore: unused_local_variable
    const loginText = Text(
      'Lanjut',
      style: TextStyle(
          fontWeight: FontWeight.w100, color: Colors.white, fontSize: 20),
    );

    bool _validateInputs() {
      if (_formKey.currentState!.validate()) {
        _formKey.currentState!.save();
        return true;
      } else {
        setState(() {
          _autoValidate = true;
        });
        return false;
      }
    }

    // ignore: unused_element
    _doValidateUser() async {
      if (_validateInputs()) {
        Map param = {};
        param['mpin'] = _mpinController.text;
        // String deviceid = await DeviceId.getID;
        // param['deviceId'] = deviceid;

        final resp = await API.post(
            context, '/register/step4', param as Map<String, Object?>);
        if (resp['code'] == 0) {
          ISTConstants().setConstants(ISTConstants.hasRegistered, true);
          const DialogBox().showImageDialog(
              message: "Sukses Membuat User",
              isError: false,
              icon: const Icon(Icons.account_circle),
              buttonOk: 'OK',
              onOk: () {
                Navigator.pushNamedAndRemoveUntil(
                    context,
                    LandingPageScreen.routeName,
                    ModalRoute.withName(Splash.routeName));
                Navigator.pushNamed(context, LoginPage.routeName);
              },
              context: context);
        } else {
          const DialogBox().showImageDialog(
              message: resp['message'],
              isError: false,
              icon: const Icon(Icons.account_circle),
              buttonOk: 'OK',
              onOk: () {
                Navigator.pushNamed(context, LandingPageScreen.routeName);
              },
              context: context);
        }
      }
    }

    return Column(children: <Widget>[
      Form(
        key: _formKey,
        // ignore: deprecated_member_use
        autovalidateMode: AutovalidateMode.always,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const Text('Pembuatan 6 Digit MPIN'),
            const SizedBox(height: 16),
            TextFormField(
              maxLength: 6,
              expands: false,
              obscureText: true,
              validator: (val) {
                if (val!.length < 6) {
                  return "Masukkan 6 digit MPIN Anda";
                } else {
                  return null;
                }
              },
              onSaved: (String? val) {
                _mpinController.text = val!;
              },
              keyboardType: TextInputType.number,
              style: const TextStyle(fontSize: 20),
              decoration: const InputDecoration(hintText: 'MPIN'),
              controller: _mpinController,
            ),
            const SizedBox(height: 8),
            TextFormField(
              maxLength: 6,
              expands: false,
              validator: (val) {
                if (val != _mpinController.text) {
                  return "MPIN harus sama";
                } else {
                  return null;
                }
              },
              onSaved: (String? val) {
                _mpinConfirmController.text = val!;
              },
              obscureText: true,
              keyboardType: TextInputType.number,
              style: const TextStyle(fontSize: 20),
              decoration: const InputDecoration(
                  hintText: 'Konfirmasi MPIN', labelText: 'Konfirmasi MPIN'),
              controller: _mpinConfirmController,
            ),
            // Padding(
            //   padding: const EdgeInsets.only(top: 30.0),
            //   child: Container(
            //     width: double.infinity,
            //     child: RaisedButton(
            //         padding: EdgeInsets.all(10),
            //         shape: RoundedRectangleBorder(
            //             borderRadius:
            //                 BorderRadius.all(Radius.circular(50))),
            //         splashColor: Pallete.primary,
            //         color: Pallete.primary,
            //         focusColor: Pallete.primary,
            //         hoverColor: Pallete.primary,
            //         onPressed: () {
            //           _doValidateUser();
            //         },
            //         child: loginText),
            //   ),
            // ),
          ],
        ),
      ),
    ]);
  }
}
